﻿package 
{
	import flash.display.Sprite;
	import flash.display.Loader;
	import flash.display.Bitmap;
	import flash.display.BitmapData;
	
	import flash.events.Event;
	import flash.events.MouseEvent;
	
	import flash.ui.Mouse;
	import flash.ui.MouseCursorData;
	
	import flash.net.URLRequest;
	
	
	/**
	 * CustomCursorExample 类 用于自定义鼠标光标
	 * @author TKCB
	 */
	public class CustomCursorExample extends Sprite
	{
		/// 加载自定义光标
		private var loader1:Loader;
		private var loader2:Loader;
		private var num:uint;// 记录加载次数
		
		private static var cursor:String;// 记录本机原始光标的名字
		
		function CustomCursorExample()
		{
			/// 初始化
			loader1 = new Loader();
			loader2 = new Loader();
			num = 0;
			
			//cursor = Mouse.cursor;
			
			/// 加载外部自定义光标的图片
			var loaderHandler:Function = function(eve:Event):void
			{
				num++;
				if(num >= 2) setMouseCursorData();
			}
			loader1.contentLoaderInfo.addEventListener(Event.COMPLETE, loaderHandler);
			loader2.contentLoaderInfo.addEventListener(Event.COMPLETE, loaderHandler);
			loader1.load(new URLRequest("pic/mouseCursor/SC2_MouseCursor_A1.png"));
			loader2.load(new URLRequest("pic/mouseCursor/SC2_MouseCursor_A2.png"));
		}
		
		/**
		 * 设置自定义光标
		 */
		private function setMouseCursorData():void
		{
			trace( loader1.content.width );
			/// 设置鼠标光标的图像数据
			var dataVector:Vector.<BitmapData> = new Vector.<BitmapData>(2);
			dataVector[0] = (loader1.content as Bitmap).bitmapData;
			dataVector[1] = (loader2.content as Bitmap).bitmapData;
			
			/// 设置鼠标光标
			var mouseCursorData:MouseCursorData = new MouseCursorData();
			mouseCursorData.data = dataVector;// 设置自定义本机光标的数组
			mouseCursorData.frameRate = 12;// 数组中图片的帧速率
			
			/// 设置本机鼠标光标
			Mouse.registerCursor("TKCBmouseCursorData", mouseCursorData);// 注册本机鼠标光标
			Mouse.cursor = "TKCBmouseCursorData";// 使用注册的本机光标
			
			var mouseTFHandler:Function = function(eve:MouseEvent):void
			{
				//// 文本框下边和右边判断时候都减去了1像素，那是因为刚好有1像素的误差
				var boo:Boolean = eve.stageX > tf.x && (tf.mouseX < tf.width - 1) && eve.stageY > tf.y && (tf.mouseY < tf.height -1);
				if(boo)
				{
					tf.text = "1、鼠标在文本框内部";
					//Mouse.cursor = cursor;
				}
				else
				{
					//Mouse.cursor = "TKCBmouseCursorData";
					tf.text = "2、鼠标在文本框外部";
				}
			}
			stage.addEventListener(MouseEvent.MOUSE_MOVE, mouseTFHandler);
			
		}
		
	}
}
