﻿package
{
	import flash.display.BitmapData;
	import flash.display.Bitmap;
	import flash.display.Shape;
	import flash.display.Sprite;
	import flash.events.Event;
	import flash.geom.ColorTransform;
	import flash.geom.Matrix;
	import flash.geom.Rectangle;
	import flash.media.Sound;
	import flash.media.SoundMixer;
	import flash.net.URLRequest;
	import flash.utils.ByteArray; 
	[SWF( backgroundColor='0', frameRate='35', height='400', width='512')]
	
	public class Main extends Sprite
	{
		private var sound: Sound;
		private var bytes: ByteArray;
		private var output: BitmapData;
		private var peaks: BitmapData;
		private var fadeFill: BitmapData
		private var displace: Matrix;
		private var rect: Rectangle;
		private var drawArea: Rectangle;
		private var gradient: Array;
		private var darken: ColorTransform;
		
		public function Main()
		{
			sound = new Sound();
			sound.load( new URLRequest( 'http://disk.yyjxkj.com/banzhu/dandan/CS3WQP/天路.mp3' ) );
			sound.play();
			drawArea=new Rectangle( 0, 0, 500, 450 )
			bytes = new ByteArray();
			output = new BitmapData( drawArea.width, drawArea.height, true, 0 );
			peaks = new BitmapData(  drawArea.width, drawArea.height, true, 0 );
			fadeFill = new BitmapData(  drawArea.width, drawArea.height, true, 0x08000000 );
			
			displace = new Matrix();
			displace.tx = 2;
			displace.ty = -1;
			darken = new ColorTransform();
			//darken = new ColorTransform( 1, 1, 1, 1, -2, -2, -2, 0 );
			rect=new Rectangle( 0, 0, 1, 0 )

			addChild( new Bitmap( output ) );
			addChild( new Bitmap( peaks ) );
			
			stage.addEventListener( Event.ENTER_FRAME, enterFrameHandler );
			
			graphics.beginFill( 0 );
			graphics.drawRect( 0, 0, drawArea.width, drawArea.height );
			graphics.endFill();
			
			gradient = createRainbowGradientArray();
		}
		
		private function enterFrameHandler(event:Event):void 
		{

			peaks.fillRect( peaks.rect, 0 );
			SoundMixer.computeSpectrum( bytes, true, 2 );
			
			var value: Number;
			var height: Number;
			
			var smooth: Number;
			
			for( var i: int = 0 ; i < 256 ; i++ )
			{
				value = bytes.readFloat();
				
				if( i == 0 ) smooth = value;
				else smooth += ( value - smooth ) / 8;
				
				height = 2 + smooth * 0xf0;
				
				rect.x = 8 + i;
				rect.y = drawArea.height-80 + ( i >> 2 ) - height;
				rect.height = height;
				
				peaks.setPixel32( rect.x, rect.y, 0xffffffff );

				output.fillRect( rect, 0xff000000 | gradient[i] );
			}
			output.draw( fadeFill, null, null, null, null, true );
			output.draw( output, displace, null, null, null, true );
		}
		
		private function createRainbowGradientArray(): Array
		{
			var gradient: Array = new Array();
			
			var shape: Shape = new Shape();
			var bmp: BitmapData = new BitmapData( 256, 1, false, 0 );
			
			var colors: Array = [ 0x003366, 0x0066cc, 0xffff00, 0x00ff00, 0x00ffff ];
			var alphas: Array = [ 0, 100, 100, 100, 100 ];
			var ratios: Array = [ 0, 32, 128, 192, 255 ];
			
			var matrix: Matrix = new Matrix();
			
			matrix.createGradientBox( 256, 1, 0, 0, 0 );
			
			shape.graphics.beginGradientFill( 'linear', colors, alphas, ratios, matrix );
			shape.graphics.drawRect( 0, 0, 256, 1 );
			shape.graphics.endFill();
			
			bmp.draw( shape );
			
			for( var i: int = 0 ; i < 256 ; i++ )
			{
				gradient[i] = bmp.getPixel( i, 0 );
			}
			
			return gradient;
		}
	}
}
