﻿package com.anttikupila.revolt {
	import flash.media.*;
	import flash.display.*;
	import flash.net.*;
	import flash.events.*;
	import flash.utils.*;
	import flash.filters.DropShadowFilter;
	import com.anttikupila.soundSpectrum.SoundProcessor;
	import com.anttikupila.revolt.presets.*;
	
	public class Revolt extends Sprite {
		private var sp:SoundProcessor;
		private var bitmapData:BitmapData;
		private var presetList:Array;
		private var presetInt:Timer;
		private var preset:Preset;
		private var lastChange:Number;
		private var bitmap:Bitmap;
	
		function Revolt(w:uint, h:uint) {
			
			sp = new SoundProcessor();		
			
			bitmapData = new BitmapData(w, h, false, 0x000000)
			bitmap = addChild(new Bitmap(bitmapData)) as Bitmap;
			
			presetList = new Array(new LineFourier(), new LineNoFourier(), new Explosion(), new LineSmooth(), new LineWorm(), new Tunnel());
//			presetList = new Array(new LineWorm());
			
			var initialDelay:Timer = new Timer(7100, 1);
			initialDelay.addEventListener(TimerEvent.TIMER, setupTimer);
			initialDelay.start();
		
			// initialize
			nextPreset(null);
			
			//this.addEventListener(Event.ENTER_FRAME, compute);
			this.addEventListener(MouseEvent.CLICK, nextPreset);
		}
		
		
		
		private function compute(ev:Event):void {
			var soundArray:Array = sp.getSoundSpectrum(preset.fourier);
			preset.applyGfx(bitmapData, soundArray);
		}
		
		private function setupTimer(ev:Event):void {
			presetInt = new Timer(12950, 0);
			presetInt.addEventListener(TimerEvent.TIMER, nextTimedPreset);
			presetInt.start();
			nextPreset(null);
		}
		
		private function nextPreset(ev:Event):void {
			var index:uint = Math.floor(Math.random()*presetList.length);
			var newPreset:Preset = presetList[index];
			if (newPreset != preset) {
				preset = newPreset;
				preset.init();
				//trace("next effect is '" + preset.toString().toLowerCase() + "'");
			} else {
				nextPreset(null);
			}
			lastChange = getTimer();
		}
		
		private function nextTimedPreset(ev:Event):void {
			if (getTimer() - lastChange > 5000) {
				nextPreset(ev);
			}
		}
		
		
		public function onStageReSize():void
		{
			
			if (bitmapData)
			{
				bitmapData.dispose();
			}
			bitmapData = new BitmapData(stage.stageWidth,stage.stageHeight,true,0);
			bitmap = addChild(new Bitmap(bitmapData)) as Bitmap;
			
		}
		
		public function pause():void
		{
			this.removeEventListener(Event.ENTER_FRAME, compute);
			presetInt.stop();
		}
		
		public function start():void
		{
			this.addEventListener(Event.ENTER_FRAME, compute);
			presetInt.start();
		}
		
		
		
	}
}