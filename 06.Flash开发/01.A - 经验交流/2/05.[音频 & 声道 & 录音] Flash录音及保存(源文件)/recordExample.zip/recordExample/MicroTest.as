﻿package 
{
	import flash.media.MicrophoneEnhancedMode;
	import flash.media.MicrophoneEnhancedOptions;
	import com.anttikupila.revolt.Revolt;

	import flash.display.Sprite;
	import flash.display.StageAlign;
	import flash.display.StageScaleMode;
	import flash.events.Event;
	import flash.events.MouseEvent;
	import flash.events.SampleDataEvent;
	import flash.events.StatusEvent;
	import flash.media.Microphone;

	import flash.media.Sound;
	import flash.media.SoundChannel;
	import flash.net.FileFilter;
	import flash.net.FileReference;
	import flash.text.TextField;
	import flash.text.TextFieldAutoSize;
	import flash.text.TextFormat;
	import flash.utils.ByteArray;
	import flash.utils.Endian;



	public class MicroTest extends Sprite
	{
		private var recordControl:Sprite;
		private var startRecord:Btn;
		private var stopRecord:Btn;
		private var clearRecord:Btn;
		private var saveRecord:Btn;

		private var playControl:Sprite;
		private var playButton:Btn;
		private var pauseButton:Btn;
		private var stopButton:Btn;


		private var playTime:TextField;
		private var traceText:TextField;
		private var progheight:int = 16;

		private var microphone:Microphone;
		private var soundBytes:ByteArray;
		private var isRecording:Boolean = false;

		private var sound:Sound;
		private var soundChannel:SoundChannel;
		private var position:uint = 0;
		private var isPlaying:Boolean = false;

		private var revolt:Revolt;

		public function MicroTest()
		{
			if (stage)
			{
				init();
			}
			else
			{
				addEventListener(Event.ADDED_TO_STAGE, init);
			}
		}

		private function init(e:Event = null):void
		{
			removeEventListener(Event.ADDED_TO_STAGE, init);
			stage.align = StageAlign.TOP_LEFT;
			stage.scaleMode = StageScaleMode.NO_SCALE;


			microphone = Microphone.getEnhancedMicrophone();
			if (! microphone)
			{
				microphone = Microphone.getMicrophone();
			}
			microphone.setSilenceLevel(5, 10000);
			microphone.gain = 50;
			microphone.rate = 44;
			var option:MicrophoneEnhancedOptions = new MicrophoneEnhancedOptions();
			option.autoGain = true;
			microphone.enhancedOptions = option;
			microphone.addEventListener(StatusEvent.STATUS, micStatusHandler);
			soundBytes = new ByteArray();;
			sound = new Sound();


			playTime = new TextField();
			playTime.defaultTextFormat = new TextFormat("Verdana",12,0xcccccc);
			playTime.autoSize = TextFieldAutoSize.LEFT;
			playTime.selectable = false;
			playTime.x = 10;
			playTime.y = 10;
			playTime.text = millToTime(0) + "/" + millToTime(0);
			addChild(playTime);

			traceText=new TextField();
			traceText.defaultTextFormat = new TextFormat("Verdana",12,0xcccccc);
			traceText.autoSize = TextFieldAutoSize.LEFT;
			traceText.selectable = false;
			traceText.x = 110;
			traceText.y = 10;
			traceText.text = "TRACE：" + "录音及保存";
			addChild(traceText);


			recordControl = new Sprite  ;
			recordControl.x = 10;
			recordControl.y = 40;
			addChild(recordControl);

			startRecord = createButton("开始录音",startRecordHandler);
			startRecord.x = 0;
			recordControl.addChild(startRecord);
			stopRecord = createButton("暂停录音",stopRecordHandler);
			stopRecord.x = startRecord.x + startRecord.width + 11;
			recordControl.addChild(stopRecord);
			clearRecord = createButton("清除录音",clearRecordHandler);
			clearRecord.x = stopRecord.x + stopRecord.width + 11;
			recordControl.addChild(clearRecord);
			saveRecord = createButton("保存录音",saveRecordHandler);
			saveRecord.x = clearRecord.x + clearRecord.width + 11;
			recordControl.addChild(saveRecord);

			playControl = new Sprite  ;
			playControl.x = 10;
			playControl.y = 80;
			addChild(playControl);

			playButton = createButton("播放",playButtonHandler);
			playButton.x = 0;
			playControl.addChild(playButton);
			pauseButton = createButton("暂停",pauseButtonHandler);
			pauseButton.x = playButton.x + playButton.width + 11;
			playControl.addChild(pauseButton);
			stopButton = createButton("停止",stopButtonHandler);
			stopButton.x = pauseButton.x + pauseButton.width + 11;
			playControl.addChild(stopButton);

			var sprite:Sprite=new Sprite();
			sprite.graphics.beginFill(0xffffff);
			sprite.graphics.drawRect(0,playControl.y+30,stage.stageWidth,1);
			addChild(sprite);
			revolt = new Revolt(stage.stageWidth,stage.stageHeight - 110);
			revolt.y = playControl.y + 31;
			addChild(revolt);

		}

		//控制按钮
		private function createButton(value:String,handle:Function)
		{
			var btn:Btn = new Btn();
			btn.txt.htmlText = "<font FACE=\"Verdana\" SIZE=\"12\"color=\"#ffffff\" >" + value + "</font>";
			btn.addEventListener(MouseEvent.CLICK, handle);
			return btn;
		}

		private function micStatusHandler(event:StatusEvent):void
		{
			traceText.text = "TRACE：" + "Microphone is muted?: " + microphone.muted;
			switch (event.code)
			{
				case "Microphone.Unmuted" :
					traceText.text = "TRACE：" + "Microphone access was allowed";
					break;
				case "Microphone.Muted" :
					traceText.text = "TRACE：" + "Microphone access was denied";
					break;
			}
		}



		private function startRecordHandler(event:MouseEvent=null):void
		{
			if (soundBytes.length > 0)
			{
				traceText.text = "TRACE：" + "继续录音";
				pauseButtonHandler()
			}
			else
			{
				traceText.text = "TRACE：" + "开始录音";
			}
			isRecording = true;
			microphone.addEventListener(SampleDataEvent.SAMPLE_DATA, microphoneSampHandler);
		}

		private function microphoneSampHandler(event:SampleDataEvent):void
		{
			while (event.data.bytesAvailable)
			{
				soundBytes.writeFloat(event.data.readFloat());
			}
			setTime();
		}

		private function stopRecordHandler(event:MouseEvent=null):void
		{
			traceText.text = "TRACE：" + "停止录音";
			isRecording = false;
			if (microphone.hasEventListener(SampleDataEvent.SAMPLE_DATA))
			{
				microphone.removeEventListener(SampleDataEvent.SAMPLE_DATA, microphoneSampHandler);
			}
			//soundBytes.position = 0;
			stopButtonHandler()
		}
		private function clearRecordHandler(event:MouseEvent=null):void
		{
			traceText.text = "TRACE：" + "清除录音";
			isRecording = false;
			if (microphone.hasEventListener(SampleDataEvent.SAMPLE_DATA))
			{
				microphone.removeEventListener(SampleDataEvent.SAMPLE_DATA, microphoneSampHandler);
			}
			soundBytes.clear();
			playTime.text = millToTime(0) + "/" + millToTime(0);
		}
		private function saveRecordHandler(event:MouseEvent=null):void
		{
			traceText.text = "TRACE：" + "保存录音";
			new FileReference().save(generFileData(),"recorder.wav");
		}

		private function generFileData():ByteArray
		{
			var bin:ByteArray = new ByteArray();
			var rate:uint = 44100;
			var bits:uint = 16;
			var soundChannels:uint = 1;
			var data:ByteArray = encodeBytes(soundBytes,rate);

			bin.endian = Endian.LITTLE_ENDIAN;
			bin.writeUTFBytes( "RIFF" );
			bin.writeInt( uint( data.length + 44 ) );
			bin.writeUTFBytes( "WAVE" );
			bin.writeUTFBytes( "fmt " );
			bin.writeInt( uint( 16 ) );
			bin.writeShort( uint( 1 ) );
			bin.writeShort( soundChannels );
			bin.writeInt( rate );
			bin.writeInt( uint( rate * soundChannels * ( bits / 8 ) ) );
			bin.writeShort( uint( soundChannels * bits / 8 ) );
			bin.writeShort( bits );
			bin.writeUTFBytes( "data" );
			bin.writeInt( data.length );
			bin.writeBytes( data );
			bin.position = 0;
			return bin;
		}

		private function encodeBytes( bytes:ByteArray, rate:uint=44100 , volume:int=1):ByteArray
		{
			var buffer:ByteArray = new ByteArray();
			buffer.endian = Endian.LITTLE_ENDIAN;
			var isplay:Boolean = isPlaying;
			if (isplay)
			{
				pauseButtonHandler();
			}
			position = bytes.position;

			bytes.position = 0;

			//wav采样 
			var fullrate:uint = 44100;
			var readed:uint = 0;
			var sipled:uint = 0;
			while ( bytes.bytesAvailable )
			{

				readed +=  4;

				if (sipled/readed < rate/fullrate)
				{
					buffer.writeShort( bytes.readFloat() * (0x7fff * volume) );
					sipled +=  4;
				}
				else
				{
					bytes.readFloat();
				}

				if (readed >= fullrate)
				{
					sipled = 0;
					readed = 0;
				}
			}
			bytes.position = position;
			if (isplay)
			{
				playButtonHandler();
			}
			return buffer;
		}

		//写入播放数据
		private function sampleDataEventHandler(event:SampleDataEvent):void
		{
			setTime();
			for (var i:int = 0; i < 8192 && soundBytes.bytesAvailable > 0; i++)
			{
				var sample:Number = soundBytes.readFloat();
				event.data.writeFloat(sample);
				event.data.writeFloat(sample);
			}
			position = soundBytes.position;
		}

		private function playButtonHandler(event:MouseEvent=null):void
		{
			if (soundBytes.length > 0)
			{
				if (isRecording)
				{
					stopRecordHandler();
				}
				if (soundBytes.position > 0)
				{
					traceText.text = "TRACE：" + "继续播放";
				}
				else
				{
					traceText.text = "TRACE：" + "开始播放";
				}
				if (soundChannel)
				{
					if (soundChannel.hasEventListener(Event.SOUND_COMPLETE))
					{
						soundChannel.removeEventListener(Event.SOUND_COMPLETE, soundCompleteHandler);
					}
					soundChannel.stop();
				}
				isPlaying = true;
				sound.addEventListener(SampleDataEvent.SAMPLE_DATA, sampleDataEventHandler);
				soundChannel = sound.play();
				soundChannel.addEventListener(Event.SOUND_COMPLETE, soundCompleteHandler);
				revolt.start();
			}
			else
			{
				traceText.text = "TRACE：" + "请先录音";
			}
		}
		private function pauseButtonHandler(event:MouseEvent=null):void
		{
			if (soundBytes.length > 0&&isPlaying)
			{
				traceText.text = "TRACE：" + "暂停播放";
				isPlaying = false;
				sound.removeEventListener(SampleDataEvent.SAMPLE_DATA, sampleDataEventHandler);
				soundChannel.stop();
			}
		}
		private function stopButtonHandler(event:MouseEvent=null):void
		{
			if (soundBytes.length > 0&&isPlaying)
			{
				traceText.text = "TRACE：" + "停止播放";
				sound.removeEventListener(SampleDataEvent.SAMPLE_DATA, sampleDataEventHandler);
				soundChannel.stop();
				soundCompleteHandler();
			}
			soundBytes.position=0
			position = 0;
			setTime()
		}

		private function soundCompleteHandler(e:Event=null):void
		{
			revolt.pause();
			traceText.text = "TRACE：" + "播放完成";
			isPlaying = false;
			if (soundChannel.hasEventListener(Event.SOUND_COMPLETE))
			{
				soundChannel.removeEventListener(Event.SOUND_COMPLETE, soundCompleteHandler);
			}
			soundBytes.position = 0;
			position = 0;
			playTime.text = millToTime(position);
			setTime();
		}




		private function setTime():void
		{
			var length:uint = soundBytes.length;
			if (length>0 )
			{
				playTime.text = millToTime(soundBytes.length / 44100 / 4 * (position / length)) + "/" + millToTime(Math.round(soundBytes.length / 44100 / 4));
			}
			else
			{
				playTime.text = millToTime(0) + "/" + millToTime(0);
			}
		}







		private function millToTime(mill:Number):String
		{
			var minutes = int(mill / 60);
			var seconds = int(mill % 60);
			minutes < 10 ? minutes = "0" + minutes:null;
			seconds < 10 ? seconds = "0" + seconds:null;
			return minutes+ ":" + seconds;
		}



	}

}