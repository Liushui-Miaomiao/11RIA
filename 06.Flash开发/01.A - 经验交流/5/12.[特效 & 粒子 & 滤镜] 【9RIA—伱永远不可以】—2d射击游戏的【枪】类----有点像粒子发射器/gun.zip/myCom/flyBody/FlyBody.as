﻿package  myCom.flyBody{
	

	public class FlyBody  {
		
		/*初始状态*/
		public static const STATE_INIT:int=0
		/*运行中*/
		public static const STATE_RUN:int=1
		/*攻击中*/
		public static const STATE_ATTACK:int=2
			/*休息中*/
		public static const STATE_REST:int=3
			/*死了*/
		public static const STATE_DEAD:int=4
			/*生命值巅峰*/
		public static const HEALTH_VALUE:int=100
		
		public var x:Number 
		public var y:Number 
		public var vx:Number 
		public var vy:Number 
		public var health:int//生命
		public var state:int
		public var rotation:Number 
		
		public function FlyBody(intX:Number,intY:Number,Vx:Number=0,Vy:Number=0) {
			// constructor code
			x=intX
			y=intY
			vx=Vx
			vy=Vy
			health=HEALTH_VALUE
			state=STATE_INIT
			rotation=0
		}
		
		
		
		public function update():void 
		{
			x+=vx
			y+=vy
		}
		
		public function setSpeedAndDirection(speed:Number =0,directionRotate:Number=90 ):void 
		{
			vx=speed*Math.cos (Math.PI/180*directionRotate)
			vy=speed*Math.sin (Math.PI/180*directionRotate)
		}
		
		
	}
	
}
