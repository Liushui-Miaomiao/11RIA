﻿package  myCom.airShip{
	import myCom.flyBody.FlyBody;
	import myCom.gun.Gun;
	import flash.geom.Point;
	import flash.display.Sprite;
	
	
	
	
	public class AirShip extends FlyBody  {
		
		private var gunPoints_in:Vector .<Point >//武器绑定的点 这个是内部
		
		public var gunPoints:Vector .<Point >//武器绑定的点  外部链接的
		
		public var aimObject:Sprite //与之绑定的对象
		
		
		public function AirShip(AimObject:Sprite ,intX:Number,intY:Number) {
			// constructor code
			super(intX,intY)
			aimObject=AimObject
			rotation=0
			
			gunPoints_in=new Vector.<Point> ()
			gunPoints=new Vector.<Point> ()
		}
		
		public override function update():void 
		{
			super.update ()
			
			 pointUpdate()
			aimObject.x=this.x
			aimObject.y=this.y
			aimObject.rotation =this.rotation 
			
		}
		//点 更新
		private function pointUpdate():void 
		{
			
			//----------位置更新
			var tp:Point =new Point ()
			
			for(var i in gunPoints)
			{
				tp=aimObject.localToGlobal (gunPoints_in[i])
				gunPoints[i].x=tp.x
				gunPoints[i].y=tp.y
				
			}
		}
		//加以个点
		public function addPoint(point:Point ):void 
		{
			var p:Point =point.clone ()
			gunPoints_in.push (p)
			var p2:Point =aimObject.localToGlobal (point)
			gunPoints.push (p2)
			
		}
		//减1个点
		public function delPoint(index:int):void 
		{
			
			gunPoints_in.splice (index,1)
			gunPoints.splice (index,1)
		}
		
		//--------------
		//让对象 与 点 绑定，，与 类 的绑定
		public function bindingObject(...Objects):void 
		{
			if(Objects.length <gunPoints.length )
			{
				trace("airShip; bindingObject():: 对象太少")
				return;
			}
			for(var i in gunPoints)
			{
				Objects[i].x=gunPoints[i].x
				Objects[i].y=gunPoints[i].y
				
			}
		}
		
		
	}
	
}
