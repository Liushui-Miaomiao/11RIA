﻿package  myCom.bullet{
	import flash.geom.Point;
	/*跟踪弹*/
	
	public class FollowBullet extends Bullet  {
		
		public var goal:Point //目标
		public var speed:Number 
		public var rotation:Number 
		public function FollowBullet(intX:Number,intY:Number,Speed:Number ,Type:uint=1) {
			
			super(intX,intY)
			this.type =Type
			goal=new Point (0,0)
			speed=2
			rotation=0
			setSpeed()
		}
		
		public override function fly():void
		{
			var dx:Number  = goal.x - x;
			var dy:Number  = goal.y - y;
			rotation = Math.atan2(dy, dx) * 180 / Math.PI;
			setSpeed()
			super.fly()
			
		}
		private function setSpeed():void 
		{
			vx = speed * Math.cos(rotation);
			vy = speed * Math.sin(rotation);
		}
	}
	
}
