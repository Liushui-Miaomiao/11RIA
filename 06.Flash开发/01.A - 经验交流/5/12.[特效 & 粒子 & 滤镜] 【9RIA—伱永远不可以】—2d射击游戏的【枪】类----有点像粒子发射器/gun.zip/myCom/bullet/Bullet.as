﻿package  myCom.bullet{
	import flash.geom.Point;
	import flash.net.drm.VoucherAccessInfo;

	
	/*
	@子弹
	
	
	*/
	
	
	public class Bullet {
		/*初始状态*/
		public static const STATE_INIT:int=0
		/*飞行*/
		public static const STATE_FLY:int=1
		/*子弹碰撞*/
		public static const STATE_HIT:int=2
		/*子弹死亡*/
		public static const STATE_DEAD:int=3
		/*备用状态*/
		public static const STATE_B:int=99
	
		
		
		
		public var x:Number 
		public var y:Number 
		public var vx:Number 
		public var vy:Number 
		public var r:Number //半径
		public var state:int
		public var type:uint//子弹类型
		public var goalIndex:int//目标序号
		public var length:Number //已经走过的路程
		
		public function Bullet(intX:Number,intY:Number,Vx:Number=0,Vy:Number=0,Type:uint=1) {
			
			x=intX
			y=intY
			vx=Vx
			vy=Vy
			type=Type
			r=0//默认半径为0
			state=STATE_INIT
			length=0
		}
		//子弹飞行  更新
		public function fly():void 
		{
			
			x+=vx
			y+=vy
			length+=vx*vx+vy*vy//走过的路程
		}
		/*
		#设置 子弹飞行速度 与 飞行方向
		@
		@速度
		@方向角度  
		*/
		public function setSpeedAndDirection(speed:Number =0,directionRotate:Number=90 ):void 
		{
			vx=speed*Math.cos (Math.PI/180*directionRotate)
			vy=speed*Math.sin (Math.PI/180*directionRotate)
		}
			/*
		#设置 子弹从哪里发射
		@
		@发射点
		@速度
		@发射方向
		*/
		
		public function shootFrom(p:Point ,speed:Number ,directionRotate:Number):void 
		{
			setSpeedAndDirection(speed ,directionRotate)
			x=p.x
			y=p.y
		}
		//销毁子弹
		/*public function destroy():void 
		{
			
		}*/
		
		
	}
	
}
