﻿package  com.bullet{
	import flash.geom.Point;
	
	/*
	弹匣
	
	
	
	*/
	
	
	public class Magazine{
		
		
		public var magazine:Vector .<Bullet >
		 
		
		/*
		@子弹数量
		@子弹初始位置
		@子弹型号
		*/
		public function Magazine(number:int,type:int=1) {
			// constructor code
			magazine=new Vector.<Bullet> ()
			
			reSet(number,type)
			
			}
		/*
			%%%%重置 弹匣
		@子弹数量
			@子弹初始位置
		@子弹型号
		*/
		public function reSet(number:int,type:int=1):void 
			{
				
				this.destroy()
				
				
				for (var i=number;i>0;i--)
				{
					
					var b:Bullet =new Bullet (0,0,0,0,type)
					magazine.push (b)
				}
				
			}
		/*添加子弹
			@@数量
			
			*/
		public function addBullet(number:int=1,type:int=1):void  
			{
				
				var b:Bullet =new Bullet (0,0,0,0,type)
				magazine.push (b)
				
			}
		/*减少一颗子弹
			@@索引
			
			*/
		public function delBulletAt(index:int=0):void  
			{
				
				magazine.splice (index,1)
				
			}
			/*减少子弹
			@@s数量
			@@是否从 弹匣顶部删除，否则  从底部
			*/
		public function delBullet(number:int=1,isTop:Boolean =false):void  
			{
				var i
				if(isTop){
					for( i =number;i>0;i--){
					magazine.pop ()
					}
				}else{
					for( i =number;i>0;i--){
					magazine.shift ()
					}
				}
			}
			/*释放弹匣*/
		public function destroy():void 
			{
				for(var i in magazine){
					magazine[i]=null
				}
				magazine.length =0
			}
		
		
	}
	
}
