﻿package  myCom.gun{
	import myCom.bullet.Magazine;
	import myCom.bullet.Bullet;
	import flash.geom.Point;
	import flash.events.EventDispatcher;

	
	
	public class Gun {
		
		public static const MODE_NORMAL:int=0
		public static const MODE_RANDOM:int=1
		public static const MODE_SHOTGUN:int=2//散弹枪模式
		public static const MODE_PARALLEL:int=3//并排  比如这样  F：=====  E：三三三三三三
		//public static const MODE_RANDOM:int=1
		private const ROF_MAX_VALUE:int=120//最快射速
		
		public var magazine:Vector .<Bullet > //弹夹  存放子弹
		
		public var bulletBox:Vector .<Bullet >//存放 已经射出的子弹
		
		public var x:Number 
		public var y:Number 
		
		public var name:String 
		
		public var rotation:Number //枪的角度
		
		public var rateOfFire:Number //射击频率 0~1  越大越慢
		
		public var shootRadius:Number //射程半径
		
		public var bulletSpeed:Number //子弹的速度
		
		public var shootMode:int//射击模式
		
		public var bulletUnlimited:Boolean //子弹无限模式
		
		public var shootBulletNum:int//每次射出去多少颗子弹
		//{MODE_SHOTGUN散弹模式下 ： }
		
		public var rotationOffset:Number /* 偏移角度说明:
		
		1.MODE_RANDOM 模式下，，偏移角度，是随机偏移角度
		2.MODE_SHOTGUN 散弹模式下，偏移角度为  ：散弹的散射角度
		
		
		*/
		
		public var xyOffset:Point   //XY偏移  只有在 随机模式下MODE_RANDOM
		
		public var hasBullet:Boolean //有子弹吗
		
		
		private var enventDispatcher:EventDispatcher 
		/*枪
		##
		@坐标
		
		@子弹的数量
		
		*/
		public function Gun(X:Number ,Y:Number ,Name:String ="gun",bulletNum:int=10,bulletType:int=1) {
			
			x=X
			y=Y
			name=Name
			rotation=0
			rateOfFire=0.5
			bulletSpeed=2
			shootMode=MODE_NORMAL
			rotationOffset=20
			xyOffset=new Point (0,4)
			hasBullet=true
			shootRadius=40
			 bulletUnlimited=true//子弹无限
			shootBulletNum=3
			//创建弹匣
			magazine =new Vector.<Bullet> ()
			reSetMagazine(bulletNum,bulletType)
			//
			bulletBox=new Vector.<Bullet> ()//新盒子
			//
			enventDispatcher=new EventDispatcher ()
			//
			
		}
		/*更新
		
		*/
		public function update():void 
		{
			//子弹 更新
			for(var i in bulletBox)
			{
				bulletBox [i].fly ()//更新子弹
				
				if(bulletBox [i].length>shootRadius*shootRadius)
				{
					
					bulletBox [i].state =Bullet.STATE_DEAD
					bulletBox [i].length=0
				}
				
				if(bulletBox [i].state ==Bullet.STATE_DEAD ){bulletBox.splice (i,1)}
			}
		}
		
		
		
		/*射击
		
		*/
		private var rof_i:int=9999//射速 计数
		public function shoot():void 
		{
			
			
			//射速----------
			rof_i++
			
			if(rof_i> rateOfFire*ROF_MAX_VALUE)
				{
					shootBulletNum=this.shootMode==MODE_SHOTGUN?shootBulletNum:1//如果不是散弹模式，就每次射一颗子弹
					getBullet(shootBulletNum)
					rof_i=0
					
				}
			//--------------------
			
			
		}
		/*瞄准一个对象*/
		public function AimedAt(X:Number ,Y:Number ):void 
		{
			this.rotation =Math.atan2((Y-y),(X-x))*180/Math.PI 
		}
		//---
		/*从弹匣获取子弹 到 盒子里 发射
		
		@获取的数量
		*/
		private function getBullet(number:int=1):void 
		{
			
			
			if(hasBullet==false && bulletUnlimited==false){
				enventDispatcher.dispatchEvent (new GunEvent (GunEvent.MAGAZINE_EMPTY ))//发送一个没有子弹了的事件
				return void;
				}
				hasBullet=true
			for(var i in magazine)
			{
				
				if(magazine[i].state ==Bullet.STATE_DEAD && bulletUnlimited){
					
					magazine[i].state =Bullet.STATE_INIT
				}
				
				if(magazine[i].state ==Bullet.STATE_INIT)
				{
					
					magazine[i].state =Bullet.STATE_FLY
					 pepareBullet(magazine[i])//根据射击模式 初始一颗子弹
					
					//bulletBox.push(magazine[i])
					bulletBox[bulletBox.length]= magazine[i]
					
						number-=1
					//数量足够，退出
					if(number==0){
						
						rotation_i=0//散弹计数清零
						enventDispatcher.dispatchEvent (new GunEvent (GunEvent.WHEN_FIRE ))//发送一个  正在发射子弹的事件
						return
						
						
						}
						
				}
			}
			
			
			
			hasBullet=false
			
			
		}
		/*准备一颗子弹
		根据模式准备子弹，
		*/
		private var rotation_i:Number =0//计数  散弹模式
		private function pepareBullet(bullet:Bullet):void{
			
			switch(shootMode)
			{
				case MODE_NORMAL:
					bullet.x=x
					bullet.y=y
					bullet.setSpeedAndDirection (bulletSpeed,rotation)
					bullet.length =0
				break;
				case MODE_RANDOM:
					bullet.x=x+xyOffset.x*Math.random()-xyOffset.x*.5
					bullet.y=y+xyOffset.y*Math.random()-xyOffset.y*.5
					var rr:Number =rotation+rotationOffset*Math.random()-rotationOffset*.5//随机角度
					
					bullet.x += Math.cos(rr/180*Math.PI ) * (bullet.x-x) - Math.sin(rr/180*Math.PI ) * (bullet.y-y);
					bullet.y += Math.cos(rr/180*Math.PI ) *(bullet.y- y) + Math.sin(rr/180*Math.PI ) * (bullet.x-x);
					
					bullet.setSpeedAndDirection (bulletSpeed,rr)
					bullet.length =0
				break;
				case MODE_SHOTGUN:
					if(rotation_i<shootBulletNum){
					
						rotation_i++
					}else{rotation_i=0}
					var e_ratation:Number =rotationOffset/(shootBulletNum+1)//每次旋转的角度+e_ratation*rotation_i
					
					bullet.x=x
					bullet.y=y
					bullet.setSpeedAndDirection (bulletSpeed,rotation-rotationOffset*.5+e_ratation*rotation_i)
					
					bullet.length =0
				break;
					case MODE_PARALLEL:
					if(rotation_i<shootBulletNum){
					
						rotation_i++
					}else{rotation_i=0}
					var e_m:Number =xyOffset.x/(shootBulletNum+1)//每次旋转的角度+e_ratation*rotation_i
					
					bullet.x=x+e_m
					bullet.y=y
					bullet.setSpeedAndDirection (bulletSpeed,rotation)
					
					bullet.length =0
				break;
	
			}	
			
		}
		//--------------------------------------------------------
		/*弹匣里面重新利用几颗子弹  但是 不发射
		
		*/
		public function reUseBullet(number:int=1):void
		{
			
			number=number<1?1:number
			hasBullet=true
			// getBullet()
			for(var i in magazine)
			{
				
				if(magazine[i].state ==Bullet.STATE_DEAD){
					
					magazine[i].state =Bullet.STATE_INIT
					number-=1
					
					//数量足够，退出
					if(number==0){return}
					
					}
				
			}
			trace("reUseBullet()::弹匣里面全是可以用于发射的子弹")
		}
		/*抑制弹匣里面的子弹，，不让它可以发射
		
		*/
		public function deadBullet(number:int):void
		{
			for(var i in magazine)
			{
				
				if(magazine[i].state ==Bullet.STATE_INIT){
					
					magazine[i].state =Bullet.STATE_DEAD
					number-=1
					//数量足够，退出
					if(number==0){return}
					
					}
				
			}
			trace("deadBullet()::弹匣里面 ，没有可以用于发射的子弹")
		}
				//--------------------------------------------------------
		/*
		//获取 弹匣里面 可用的子弹数
		*/
		public function getMagazieSurplus():int
		{
			var number:int=0
			for(var i in magazine)
			{
				
				if(magazine[i].state ==Bullet.STATE_INIT){
					number++
					
			}
		}
			return number
		}
		/*
		//设置所有子弹的半径
		*/
		public function setAllBulletRudios(number:Number):void
		{
			
			for(var i in magazine)
			{
				magazine[i].r=number
					
			}
		}
		/*
		//设置成点射模式
		*/
		public function setFixelFrie():void
		{
			rateOfFire=0
		}
		//--------------监听事件
		public function addEventListener(type:String ,listener:Function):void 
		{
			enventDispatcher.addEventListener (type,listener)
		}
		public function removeEventListener(type:String ,listener:Function):void 
		{
			enventDispatcher.removeEventListener (type,listener)
		}
		//---------------------------------------------------------------------------------------------------
				
		/*
	
		/*
			%%%%重置 弹匣
		@子弹数量
			@子弹初始位置
		@子弹型号
		*/
		public function reSetMagazine(number:int,type:int=1):void 
			{
				
				this.clearMagazine()
				hasBullet=true
				addBullet(number,type)
				
				
			}
		/*添加子弹
			@@数量
			
			*/
		public function addBullet(number:int=1,type:int=1):void  
			{
				hasBullet=true
				for(var i =number;i>0;i--){
					var b:Bullet =new Bullet (-999,-999,0,0,type)
					b.state =Bullet.STATE_INIT
					b.setSpeedAndDirection (bulletSpeed,rotation)
					magazine[magazine.length]=b
				}
				
			}
		/*减少一颗子弹
			@@索引
			
			*/
		public function delBulletAt(index:int=0):void  
			{
				
				magazine.splice (index,1)
				
			}
			/*减少子弹
			@@s数量
			@@是否从 弹匣顶部删除，否则  从底部
			*/
		public function delBullet(number:int=1,isTop:Boolean =false):void  
			{
				var i
				if(isTop){
					for( i =number;i>0;i--){
					magazine.pop ()
					}
				}else{
					for( i =number;i>0;i--){
					magazine.shift ()
					}
				}
			}
			/*释放弹匣*/
		public function clearMagazine():void 
			{
				for(var i in magazine){
					magazine[i]=null
				}
				magazine.length =0
				hasBullet=true
			}
		
		
	}
	
}
