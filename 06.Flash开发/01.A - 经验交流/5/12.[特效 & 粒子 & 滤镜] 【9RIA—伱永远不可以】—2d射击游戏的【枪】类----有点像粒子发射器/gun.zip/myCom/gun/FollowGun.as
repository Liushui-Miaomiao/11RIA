﻿package  myCom.gun{
	import flash.geom.Point;
	import myCom .bullet .Bullet 

	public class FollowGun extends Gun  {
			
		public var goalsP:Vector .<Point >//目标们
		
		public function FollowGun(X:Number ,Y:Number ,Name:String ="gun",bulletNum:int=10,bulletType:int=1) {
			super(X,Y,Name,bulletNum,bulletType)
			
		}
		
		
		
		/*添加子弹
			@@数量
			
			*/
		public override function addBullet(number:int=1,type:int=1):void  
			{
				hasBullet=true
				for(var i =number;i>0;i--){
					var b:Bullet =new Bullet (-999,-999,0,0,type)
					b.goalIndex =0//对应的目标序号
					b.state =Bullet.STATE_INIT
					b.setSpeedAndDirection (bulletSpeed,rotation)
					magazine[magazine.length]=b
				}
				
			}
	}
	
}
