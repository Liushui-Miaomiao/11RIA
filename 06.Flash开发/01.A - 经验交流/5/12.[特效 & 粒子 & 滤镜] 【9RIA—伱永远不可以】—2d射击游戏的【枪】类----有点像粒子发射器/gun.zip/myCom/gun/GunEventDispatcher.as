﻿package  com.gun{
	import flash.events.EventDispatcher;
	
	
	
	
	public class GunEventDispatcher extends EventDispatcher {
		
		
		public function GunEventDispatcher() {
			
		}
	}
	
}
