﻿package  myCom.gun{
	import flash.events.Event;
	
	
	
	public class GunEvent extends Event {
		
		public static const WHEN_FIRE:String="whenFire";
		
		public static const MAGAZINE_EMPTY:String="magazineEmpty";
		
		public var  hurtValue:Number 
		
		public function GunEvent(type:String,HurtValue:Number =0 ) {
			
			super(type)
			hurtValue=HurtValue
			
			
		}
	}
	
}
