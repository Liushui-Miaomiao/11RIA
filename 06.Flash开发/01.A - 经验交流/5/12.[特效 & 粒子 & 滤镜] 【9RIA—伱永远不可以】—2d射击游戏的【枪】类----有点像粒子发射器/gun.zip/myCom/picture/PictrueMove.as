﻿package  myCom.picture{
	import flash.geom.Rectangle;
	import flash.display.MovieClip;
	
	
	
	public class PictrueMove {
		
		public var array:Vector .<MovieClip >
		public var vx:Number 
		public var vy:Number 
		public var displayX
		
		public function PictrueMove(DisplayX:Number =-1 ) {
			array=new Vector .<MovieClip > ()
			vx=-2
			vy=0
			displayX=DisplayX
		}
		public function bandingTowMC(mc1:MovieClip ,mc2:MovieClip ):void 
		{
			array.push (mc1,mc2)
		mc1.x=0
			mc2.x=mc1.x+mc1.width 
			array[0].gotoAndStop(1)
			array[1].gotoAndStop(1)
		}
		public function move():void 
		{
			for (var i in array){
				
				array[i].x+=vx
				array[i].y+=vy
				if(array[i].x>=displayX){
					
				}else{
					array[i].gotoAndStop(int(array[i].totalFrames *Math.random ()))
					array[i].x=array[i==1?0:1].x+array[i==1?0:1].width 
					
				}
			}
			
			
			
		}
	}
	
}
