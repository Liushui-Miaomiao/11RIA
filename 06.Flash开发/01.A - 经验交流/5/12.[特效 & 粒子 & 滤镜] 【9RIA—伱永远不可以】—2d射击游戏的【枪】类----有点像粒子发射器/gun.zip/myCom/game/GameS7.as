﻿package  myCom.game{
	
	public class GameS7 {
		
		public static const STATE_INIT:int=0
		
		public static const STATE_MENUE:int=1
		
		public static const STATE_STORE:int=2
		
		public static const STATE_ABOUT:int=3
				
		public static const STATE_HELP:int=4
				
		public static const STATE_OPINIONS:int=5
				
		public static const STATE_SETING:int=6
				
		public static const STATE_GAME_INIT:int=7
				
		public static const STATE_GAME_RUN:int=8
				
		public static const STATE_GAME_PAUSE:int=9
				
		public static const STATE_GAME_RUN:int=10
						
		public static const STATE_GAME_RESTART:int=11
					
		public static const STATE_GAME_OVER:int=13
		
				//预备状态			
		public static const STATE_GAME_EMPTY_1:int=14
								
		public static const STATE_GAME_EMPTY_2:int=14
		//-----------------------------@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@-------------------------------------------------
		
		
		public var state:int
		
		public var speed:uint
		
		
		/*游戏*/
		public function GameS7(runSpeed:uint=1) {
			
			speed=runSpeed
			state=STATE_INIT
			
		}
		/*游戏运行
		
		*/
		public function run():void 
		{
			switch (state)
			{
				case STATE_INIT:
					
				break;
			}
		}
		
		
		
	}
	
}
