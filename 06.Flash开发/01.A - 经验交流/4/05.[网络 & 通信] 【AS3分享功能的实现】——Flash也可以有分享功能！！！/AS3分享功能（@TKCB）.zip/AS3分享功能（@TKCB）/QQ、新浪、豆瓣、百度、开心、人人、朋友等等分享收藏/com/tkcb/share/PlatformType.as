﻿/*
 * 作　　者：TKCB
 * 作者信息：身高（0.00167公里+）；体重（0.06吨±）；年龄（公元1990后）；籍贯（有兵马俑的地方）；星座（最后一个星座）；血型（万能型）；人生格言（The king come back.）。
 * 交流学习：加QQ群[AS3殿堂之路]（96759336）,群里有无数主城、架构、妹子、LOL战友，欢迎交流讨论。
 * 联系方式：QQ（2414268040）；E-mail（tkcb@qq.com）；手机（15029932353)。
 * 个人网站：www.tkcb.cc（来这里关注我吧，这里有我所有的作品，分享的资料，我的介绍和动态，还有更多你想不到的）
 */


package com.tkcb.share
{
	/**
	 * PlatformType 各大平台分享功能API的类型
	 * @author TKCB（www.tkcb.cc）
	 * @创建时间 2015-8-2
	 * @修改时间 2015-8-2
	 */
	public class PlatformType
	{
		/** 百度搜藏 */
		public static const BAI_DU_SOU_CANG:String = "baiduSouCang";
		/** 豆瓣网 */
		public static const Dou_Ban:String = "douBan";
		/** 开心网 */
		public static const KAI_XIN:String = "kaiXin";
		/** QQ好友或QQ群或QQ组 */
		public static const QQ : String = "QQ";
		/** QQ空间 */
		public static const QQ_ZONE : String = "QQZone";
		/** QQ微博 */
		public static const QQ_MICRO_BLOG : String = "QQMicroBlog";
		/** QQ朋友圈 */
		public static const QQ_PENG_YOU : String = "QQPengYou";
		/** 人人网 */
		public static const REN_REN : String = "renren";
		/** 新浪微博 */
		public static const SINA_MICRO_BLOG : String = "sinaMicroBlog";
	}
}