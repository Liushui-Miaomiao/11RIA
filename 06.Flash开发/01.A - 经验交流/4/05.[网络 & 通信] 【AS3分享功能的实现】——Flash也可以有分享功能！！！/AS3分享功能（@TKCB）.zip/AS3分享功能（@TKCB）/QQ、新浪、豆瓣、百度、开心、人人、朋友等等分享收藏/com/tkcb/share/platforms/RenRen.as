﻿/*
 * 作　　者：TKCB
 * 作者信息：身高（0.00167公里+）；体重（0.06吨±）；年龄（公元1990后）；籍贯（有兵马俑的地方）；星座（最后一个星座）；血型（万能型）；人生格言（The king come back.）。
 * 交流学习：加QQ群[AS3殿堂之路]（96759336）,群里有无数主城、架构、妹子、LOL战友，欢迎交流讨论。
 * 联系方式：QQ（2414268040）；E-mail（tkcb@qq.com）；手机（15029932353)。
 * 个人网站：www.tkcb.cc（来这里关注我吧，这里有我所有的作品，分享的资料，我的介绍和动态，还有更多你想不到的）
 */


package com.tkcb.share.platforms
{
	import com.tkcb.share.ShareData;
	
	/**
	 * 人人网API			http://wiki.dev.renren.com/wiki/API2
	 * 人人网分享代码	http://dev.renren.com/website/?widget=rrshare&content=use
	 */    
	
	/**
	 * 人人网具有以下API
	 * @param resourceUrl	分享的资源Url  
	 * @param srcUrl		分享的资源来源Url,默认为header中的Referer,如果分享失败可以调整此值为resourceUrl试试
	 * @param title			分享的标题
	 * @param description	分享详细描述
	 * @param pic			分享的图片。  //多张图片同事分享又该如何
	 */  
	
	
	/**
	 * PlatForm 平台分享功能API的实例类
	 * @author TKCB（www.tkcb.cc）
	 * @创建时间 2015-8-2
	 * @修改时间 2015-8-2
	 */
	public class RenRen extends PlatformObject
	{
		//************************ ************************* 构造函数 ******************** *********** *** **////
		/**
		 * ...
		 */
      	public function RenRen ()
		{
			shareURL = "http://widget.renren.com/dialog/share?";
		}
		
		
		//************************ ************************* 方　　法 ******************** *********** *** **////
		/**
		 * 设置平台的URL地址，其实就是将ShareData对象中的数据以字符串形式写入shareURL中
		 * @return 设置好的URL地址
		 */
		override public function setURL ( data : ShareData ) : String
		{
			shareData = data;
			
			shareURL += ("resourceUrl=" + shareData.url);
			shareURL += ("&srcUrl=" + shareData.url);
			shareURL += ("&title=" + shareData.title);
			shareURL += ("&description=" + shareData.summary);
			shareURL += ("&pic=" + shareData.pics[0]);
			
			return shareURL;
		}
		
		
	}
}