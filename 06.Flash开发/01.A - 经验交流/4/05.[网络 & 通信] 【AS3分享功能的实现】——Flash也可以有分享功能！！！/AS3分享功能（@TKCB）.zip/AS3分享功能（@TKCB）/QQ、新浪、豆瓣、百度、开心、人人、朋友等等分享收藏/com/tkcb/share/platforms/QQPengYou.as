﻿/*
 * 作　　者：TKCB
 * 作者信息：身高（0.00167公里+）；体重（0.06吨±）；年龄（公元1990后）；籍贯（有兵马俑的地方）；星座（最后一个星座）；血型（万能型）；人生格言（The king come back.）。
 * 交流学习：加QQ群[AS3殿堂之路]（96759336）,群里有无数主城、架构、妹子、LOL战友，欢迎交流讨论。
 * 联系方式：QQ（2414268040）；E-mail（tkcb@qq.com）；手机（15029932353)。
 * 个人网站：www.tkcb.cc（来这里关注我吧，这里有我所有的作品，分享的资料，我的介绍和动态，还有更多你想不到的）
 */


package com.tkcb.share.platforms
{
	import com.tkcb.share.ShareData;
	
	/**
	 * 腾讯API:http://wiki.open.qq.com/wiki/API%E5%AF%BC%E8%88%AA%E5%9B%BE
	 * 腾讯微博API http://wiki.open.qq.com/wiki/%E8%85%BE%E8%AE%AF%E5%BC%80%E6%94%BE%E5%B9%B3%E5%8F%B0%E5%BE%AE%E5%8D%9AOpenAPI%E8%B0%83%E7%94%A8%E8%AF%B4%E6%98%8E
	 * 腾讯空间分享代码：http://connect.qq.com/intro/share/ 
	 * 腾讯qq好友 http://connect.qq.com/intro/sharetoqq
	 */    
	
	/**
	 * QQ朋友圈具有以下API
	 * @param url       分享的url
	 * @param to        pengyou，表示分享到朋友圈的
	 * @param title     分享标题(可选)
	 * @param desc      分享理由(风格应模拟用户对话),支持多分享语随机展现（使用|分隔）
	 * @param summary   分享摘要(可选)
	 * @param pics      分享图片(可选) 分享的图片集合。多张图片用"|"分开
	 * @param site      分享来源(可选) 如：QQ分享
	 */    
	
	
	/**
	 * PlatForm 平台分享功能API的实例类
	 * @author TKCB（www.tkcb.cc）
	 * @创建时间 2015-8-2
	 * @修改时间 2015-8-2
	 */
	public class QQPengYou extends PlatformObject
	{
		//************************ ************************* 构造函数 ******************** *********** *** **////
		/**
		 * ...
		 */
		public function QQPengYou ()
		{
			shareURL = "http://sns.qzone.qq.com/cgi-bin/qzshare/cgi_qzshare_onekey?";
		}
		
		
		//************************ ************************* 方　　法 ******************** *********** *** **////
		/**
		 * 设置平台的URL地址，其实就是将ShareData对象中的数据以字符串形式写入shareURL中
		 * @return 设置好的URL地址
		 */
		override public function setURL ( data : ShareData ) : String
		{
			shareData = data;
			
			shareURL += ("url=" + shareData.url);
			shareURL += ("&to=" + 'pengyou');
			shareURL += ("&title=" + shareData.title);
			shareURL += ("&desc=" + shareData.desc);
			shareURL += ("&summary=" + shareData.summary);
			shareURL += ("&pics=");
			var i : int;
			var len : int = shareData.pics.length;
			for( i = 0 ; i < len; i++ )
			{
				shareURL += (shareData.pics[i] + "|");
			}
			shareURL += ("&site=" + shareData.site);
			
			return shareURL;
		}
		
		
	}
}