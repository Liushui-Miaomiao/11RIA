﻿/*
 * 作　　者：TKCB
 * 作者信息：身高（0.00167公里+）；体重（0.06吨±）；年龄（公元1990后）；籍贯（有兵马俑的地方）；星座（最后一个星座）；血型（万能型）；人生格言（The king come back.）。
 * 交流学习：加QQ群[AS3殿堂之路]（96759336）,群里有无数主城、架构、妹子、LOL战友，欢迎交流讨论。
 * 联系方式：QQ（2414268040）；E-mail（tkcb@qq.com）；手机（15029932353)。
 * 个人网站：www.tkcb.cc（来这里关注我吧，这里有我所有的作品，分享的资料，我的介绍和动态，还有更多你想不到的）
 */


package com.tkcb.share
{
	import flash.utils.Dictionary;
	
	//// 分享类型和分享数据对象
	import com.tkcb.share.PlatformType;
	import com.tkcb.share.ShareData;
	
	//// 分享平台对象
	import com.tkcb.share.platforms.PlatformObject;
	import com.tkcb.share.platforms.BaiduSouCang;
	import com.tkcb.share.platforms.DouBan;
	import com.tkcb.share.platforms.KaiXin;
	import com.tkcb.share.platforms.QQ;
	import com.tkcb.share.platforms.QQMicroBlog;
	import com.tkcb.share.platforms.QQPengYou;
	import com.tkcb.share.platforms.QQZone;
	import com.tkcb.share.platforms.RenRen;
	import com.tkcb.share.platforms.SinaMicroBlog;
	
	
	/**
	 * ShareController 统一的分享API控制类，也可以单独使用各个平台的分享API，但这样就相对麻烦一些了
	 * @author TKCB（www.tkcb.cc）
	 * @创建时间 2015-8-2
	 * @修改时间 2015-8-2
	 */
	public class ShareController
	{
		//************************ ************************* 静态属性 ******************** *********** *** **////
		//// 分享平台的API实例对象
		private static var baiduSouCang : BaiduSouCang;
		private static var douBan : DouBan;
		private static var kaiXin : KaiXin;
		private static var qq : QQ;
		private static var qqMicroBlog : QQMicroBlog;
		private static var qqPengYou : QQPengYou;
		private static var qqZone : QQZone;
		private static var renRen : RenRen;
		private static var sinaMicroBlog : SinaMicroBlog;
		
		/** 统一的分享数据对象 */
		private static var shareData : ShareData;
		
		
		//************************ ************************* 静态方法 ******************** *********** *** **////
		/**
		 * 统一设置分享数据对象
		 * @param data 统一的分享数据对象
		 */
		public static function setShareData ( data : ShareData ) : void
		{
			// 设置新的分享数据对象
			shareData = data;
			
			//// 判断所有的“分享平台的API实例对象”是否完成初始化
			if ( baiduSouCang == null )
			{
				baiduSouCang = new BaiduSouCang();
				douBan = new DouBan();
				kaiXin = new KaiXin();
				qq = new QQ();
				qqMicroBlog = new QQMicroBlog();
				qqPengYou = new QQPengYou();
				qqZone = new QQZone();
				renRen = new RenRen();
				sinaMicroBlog = new SinaMicroBlog();
			}
			
			//// 设置各个平台的分享API的URL地址
			baiduSouCang.setURL( shareData );
			douBan.setURL( shareData );
			kaiXin.setURL( shareData );
			qq.setURL( shareData );
			qqMicroBlog.setURL( shareData );
			qqPengYou.setURL( shareData );
			qqZone.setURL( shareData );
			renRen.setURL( shareData );
			sinaMicroBlog.setURL( shareData );
			
		}
		
		/**
		 * 获取指定平台的分享的URL地址
		 * @param type 要获取的平台类型
		 * @return 获取分享到的URL地址
		 */
		public static function getShareURL ( type : String ) : String
		{
			var url : String;
			switch ( type )
			{
				case PlatformType.BAI_DU_SOU_CANG:
					url = baiduSouCang.getURL();
					break;
					
				case PlatformType.Dou_Ban:
					url = douBan.getURL();
					break;
					
				case PlatformType.KAI_XIN:
					url = kaiXin.getURL();
					break;
					
				case PlatformType.QQ:
					url = qq.getURL();
					break;
					
				case PlatformType.QQ_ZONE:
					url = qqZone.getURL();
					break;
					
				case PlatformType.QQ_MICRO_BLOG:
					url = qqMicroBlog.getURL();
					break;
					
				case PlatformType.QQ_PENG_YOU:
					url = qqPengYou.getURL();
					break;
					
				case PlatformType.REN_REN:
					url = renRen.getURL();
					break;
					
				case PlatformType.SINA_MICRO_BLOG:
					url = sinaMicroBlog.getURL();
					break;
			}
			
			return url;
		}
		
		
	}
}