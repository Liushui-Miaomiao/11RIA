﻿/*
 * 作　　者：TKCB
 * 作者信息：身高（0.00167公里+）；体重（0.06吨±）；年龄（公元1990后）；籍贯（有兵马俑的地方）；星座（最后一个星座）；血型（万能型）；人生格言（The king come back.）。
 * 交流学习：加QQ群[AS3殿堂之路]（96759336）,群里有无数主城、架构、妹子、LOL战友，欢迎交流讨论。
 * 联系方式：QQ（2414268040）；E-mail（tkcb@qq.com）；手机（15029932353)。
 * 个人网站：www.tkcb.cc（来这里关注我吧，这里有我所有的作品，分享的资料，我的介绍和动态，还有更多你想不到的）
 */


package com.tkcb.share.platforms
{
	import com.tkcb.share.ShareData;
	
	/**
	 * 豆瓣网分享API		http://www.douban.com/service/sharebutton
	 */    
	
	/**
	 * 豆瓣网具有以下API
	 * @param url  链接的地址   
	 * @param title 分享标题
	 * @param desc 分享的理由
	 */     
	
	
	/**
	 * DouBan 平台分享功能API的实例类
	 * @author TKCB（www.tkcb.cc）
	 * @创建时间 2015-8-2
	 * @修改时间 2015-8-2
	 */
	public class DouBan extends PlatformObject
	{
		//************************ ************************* 构造函数 ******************** *********** *** **////
		/**
		 * ...
		 */
		public function DouBan ()
		{
			shareURL = "http://www.douban.com/share/service?";
		}
		
		
		//************************ ************************* 方　　法 ******************** *********** *** **////
		/**
		 * 设置平台的URL地址，其实就是将ShareData对象中的数据以字符串形式写入shareURL中
		 * @return 设置好的URL地址
		 */
		override public function setURL ( data : ShareData ) : String
		{
			shareData = data;
			
			shareURL += ("url=" + shareData.url);
			shareURL += ("&title=" + shareData.title);
			shareURL += ("&comment=" + shareData.summary);
			shareURL += ("&image=" + shareData.pics[0]);
			
			return shareURL;
		}
		
		
	}
}