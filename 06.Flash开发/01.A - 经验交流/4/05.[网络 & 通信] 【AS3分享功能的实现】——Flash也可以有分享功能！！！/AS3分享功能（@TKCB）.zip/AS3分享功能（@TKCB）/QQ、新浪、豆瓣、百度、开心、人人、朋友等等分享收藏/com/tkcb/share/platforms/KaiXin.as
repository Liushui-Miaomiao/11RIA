﻿/*
 * 作　　者：TKCB
 * 作者信息：身高（0.00167公里+）；体重（0.06吨±）；年龄（公元1990后）；籍贯（有兵马俑的地方）；星座（最后一个星座）；血型（万能型）；人生格言（The king come back.）。
 * 交流学习：加QQ群[AS3殿堂之路]（96759336）,群里有无数主城、架构、妹子、LOL战友，欢迎交流讨论。
 * 联系方式：QQ（2414268040）；E-mail（tkcb@qq.com）；手机（15029932353)。
 * 个人网站：www.tkcb.cc（来这里关注我吧，这里有我所有的作品，分享的资料，我的介绍和动态，还有更多你想不到的）
 */


package com.tkcb.share.platforms
{
	import com.tkcb.share.ShareData;
	
	/**
	 * 开心网API		http://open.kaixin001.com/document.php?type=records
	 */    
	
	/**
	 * 开心网具有以下API
	 * @param url		分享网址   
	 * @param content	(可选)需要分享的文字，当文字为空时，自动抓取分享网址的title 
	 * @param starid	(可选)公共主页id
	 * @param aid		(可选)显示分享来源
	 * @param showcount	是否显示分享数
	 * @param style		显示样式  11这个可以跳过人人网ico图标链接
	 * @param pic		(可选)分享的图片,多个使用半角逗号分隔
	 */ 
	
	
	/**
	 * PlatForm 平台分享功能API的实例类
	 * @author TKCB（www.tkcb.cc）
	 * @创建时间 2015-8-2
	 * @修改时间 2015-8-2
	 */
	public class KaiXin extends PlatformObject
	{
		//************************ ************************* 构造函数 ******************** *********** *** **////
		/**
		 * ...
		 */
		public function KaiXin ()
		{
			shareURL = "http://www.kaixin001.com/rest/records.php?showcount=1&style=11&aid=100056404&starid=115392646";
		}
		
		
		//************************ ************************* 方　　法 ******************** *********** *** **////
		/**
		 * 设置平台的URL地址，其实就是将ShareData对象中的数据以字符串形式写入shareURL中
		 * @return 设置好的URL地址
		 */
		override public function setURL ( data : ShareData ) : String
		{
			shareData = data;
			
			shareURL += ("&url=" + shareData.url);
			shareURL += ("&content=" + shareData.summary);
			shareURL += ("&pic=");
			var i : int;
			var len : int = shareData.pics.length;
			for( i = 0 ; i < len; i++ )
			{
				shareURL += (shareData.pics[i] + ",");
			}
			
			return shareURL;
		}
		
		
	}
}