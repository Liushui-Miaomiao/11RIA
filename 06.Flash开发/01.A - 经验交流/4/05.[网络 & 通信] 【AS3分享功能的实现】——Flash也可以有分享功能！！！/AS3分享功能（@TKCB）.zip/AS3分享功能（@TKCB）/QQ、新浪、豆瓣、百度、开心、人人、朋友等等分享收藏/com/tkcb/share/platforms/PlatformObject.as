﻿/*
 * 作　　者：TKCB
 * 作者信息：身高（0.00167公里+）；体重（0.06吨±）；年龄（公元1990后）；籍贯（有兵马俑的地方）；星座（最后一个星座）；血型（万能型）；人生格言（The king come back.）。
 * 交流学习：加QQ群[AS3殿堂之路]（96759336）,群里有无数主城、架构、妹子、LOL战友，欢迎交流讨论。
 * 联系方式：QQ（2414268040）；E-mail（tkcb@qq.com）；手机（15029932353)。
 * 个人网站：www.tkcb.cc（来这里关注我吧，这里有我所有的作品，分享的资料，我的介绍和动态，还有更多你想不到的）
 */


package com.tkcb.share.platforms
{
	import com.tkcb.share.ShareData;
	
	/**
	 * PlatformObject 各大平台分享功能API的抽象类
	 * @author TKCB（www.tkcb.cc）
	 * @创建时间 2015-8-2
	 * @修改时间 2015-8-2
	 */
	public class PlatformObject
	{
		//************************ ************************* 属　　性 ******************** *********** *** **////
		/** 分享的URL地址 */
		protected var shareURL : String;
		
		/** 分享的数据，这些数据最终会以字符串的形式添加到shareURL属性中，形成一个完整的API接口可接受的URL字符串 */
		protected var shareData : ShareData;
		
		
		//************************ ************************* 构造函数 ******************** *********** *** **////
		/**
		 * ...
		 */
		public function PlatformObject ()
		{
			
		}
		
		
		//************************ ************************* 方　　法 ******************** *********** *** **////
		/**
		 * 设置平台的URL地址，其实就是将ShareData对象中的数据以字符串形式写入shareURL中
		 * @return 设置好的URL地址
		 */
		public function setURL ( data : ShareData ) : String
		{
			shareData = data;
			return shareURL;
		}
		
		/**
		 * 获取平台的URL地址
		 * @return 设置好的URL地址
		 */
		public function getURL () : String
		{
			return shareURL;
		}
	}
}