﻿/*
 * 作　　者：TKCB
 * 作者信息：身高（0.00167公里+）；体重（0.06吨±）；年龄（公元1990后）；籍贯（有兵马俑的地方）；星座（最后一个星座）；血型（万能型）；人生格言（The king come back.）。
 * 交流学习：加QQ群[AS3殿堂之路]（96759336）,群里有无数主城、架构、妹子、LOL战友，欢迎交流讨论。
 * 联系方式：QQ（2414268040）；E-mail（tkcb@qq.com）；手机（15029932353)。
 * 个人网站：www.tkcb.cc（来这里关注我吧，这里有我所有的作品，分享的资料，我的介绍和动态，还有更多你想不到的）
 */


package com.tkcb.share
{
	/**
	 * ShareData 分享的数据集合对象，用于统一的存储分享要用到的数据（标题，文字，说明，图片，网址等等）
	 * @author TKCB（www.tkcb.cc）
	 * @创建时间 2015-8-2
	 * @修改时间 2015-8-2
	 */
	public class ShareData
	{
		//************************ ************************* 属　　性 ******************** *********** *** **////
		/** 跳转链接 */
		private  var _url : String = "";
		/** 分享标题 */
		private  var _title : String = "";
		/** 分享理由 */
		private  var _desc : String = "";
		/** 分享摘要 */
		private  var _summary : String ="";
		/** 分享来源 */
		private  var _site : String = "";
		/** 视频地址 */
		private	 var _flash : String = "";
		/** 分享小图片 */
		private  var _pics : Array = [];
		
		//************************ ************************* get  set ******************** *********** *** **////
		//// 点击跳转的链接
		/**
		 * @param value
		 * 点击跳转的链接
		 */		
		public function set url ( value : String ) : void
		{
			_url = value;
		}
		public function get url ( ) : String
		{
			return encodeURI( _url );
		}
		
		//// 分享的标题
		/**
		 * @param value
		 * 分享的标题
		 */		
		public function set title ( value : String) : void
		{
			_title = value;
		}
		public function get title () : String
		{
			return encodeURI( _title );
		}
		
		//// 分享的理由
		/**
		 * @param value
		 * 分享的理由
		 */		
		public function set desc ( value : String ) : void
		{
			_desc = value;
		}
		public function get desc () : String
		{
			return encodeURI( _desc );
		}
		
		//// 分享的摘要
		/**
		 * @param value
		 * 分享的摘要
		 */		
		public function set summary ( value : String ) : void
		{
			_summary = value;
		}
		public function get summary () : String
		{
			return encodeURI( _summary );
		}
		
		//// 分享来源
		/**
		 * @param value
		 * 分享来源
		 */		
		public function set site( value : String ) : void
		{
			_site = value;
		}
		public function get site () : String
		{
			return encodeURI( _site );
		}
		
		//// 视频地址
		/**
		 * @param value
		 * 视频地址
		 */		
		public function set flash ( value : String) : void
		{
			_flash = value;
		}
		public function get flash () : String
		{
			return encodeURI( _flash );
		}
		
		//// 分享的图片集合
		/**
		 * @param value
		 * 分享的图片集合
		 */		
		public function set pics ( value : Array ) : void
		{
			_pics = [];
			var i : int;
			var len : int = value.length;
			for ( i = 0; i < len; i++ )
			{
				_pics.push( escape( value[i] ) );
				// _pics.push( encodeURI(value[i]) );
			}
		}
		public function get pics () : Array
		{
			return _pics;
		}
	}
}