package com.vini123.share.platform
{
	/**
	 * 
	 * @author Vini123
	 * 开心网API http://open.kaixin001.com/document.php?type=records
	 */    
	
	/**
	 * 
	 * @param url  分享网址   
	 * @param content (可选)需要分享的文字，当文字为空时，自动抓取分享网址的title 
	 * @param starid (可选)公共主页id
	 * @param aid (可选)显示分享来源
	 * @param showcount 是否显示分享数
	 * @param style 显示样式  11这个可以跳过人人网ico图标链接
	 * @param pic (可选)分享的图片,多个使用半角逗号分隔
	 */ 
	
	public class Kaixin extends PlatForm
	{
		
		public function Kaixin():void
		{
			shareUrl = "http://www.kaixin001.com/rest/records.php?showcount=1&style=11&aid=100056404&starid=115392646";
		}
		
		/**
		 * 
		 * @return 分享到新浪微博的最终地址
		 * 
		 */		
		override public function get url():String
		{
			shareUrl += ("&url=" + shareData.url);
			shareUrl += ("&content=" + shareData.summary);
			shareUrl += ("&pic=");
			for(var i:int = 0 ; i< shareData.pics.length ; i++)
			{
				shareUrl += (shareData.pics[i] + ",");
			}
			return shareUrl;
		}
	}
}