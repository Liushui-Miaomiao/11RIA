package com.vini123.share.platform
{
	/**
	 * 
	 * @author Vini123
	 * 人人网API:http://wiki.dev.renren.com/wiki/API2
	 * 人人网分享代码：http://dev.renren.com/website/?widget=rrshare&content=use
	 */    
	
	/**
	 * @param resourceUrl  分享的资源Url  
	 * @param srcUrl 分享的资源来源Url,默认为header中的Referer,如果分享失败可以调整此值为resourceUrl试试
	 * @param title 分享的标题
	 * @param description 分享详细描述
	 * @param pic 分享的图片。  //多张图片同事分享又该如何
	 */  
	
	public class Renren extends PlatForm
	{
		
      	public function Renren():void
		{
			shareUrl = "http://widget.renren.com/dialog/share?";
		}
		
		/**
		 * 
		 * @return 分享到新浪微博的最终地址
		 * 
		 */		
		override public function get url():String
		{
			shareUrl += ("resourceUrl=" + shareData.url);
			shareUrl += ("&srcUrl=" + shareData.url);
			shareUrl += ("&title=" + shareData.title);
			shareUrl += ("&description=" + shareData.summary);
			shareUrl += ("&pic=" + shareData.pics[0]);
			return shareUrl;
		}
	}
}