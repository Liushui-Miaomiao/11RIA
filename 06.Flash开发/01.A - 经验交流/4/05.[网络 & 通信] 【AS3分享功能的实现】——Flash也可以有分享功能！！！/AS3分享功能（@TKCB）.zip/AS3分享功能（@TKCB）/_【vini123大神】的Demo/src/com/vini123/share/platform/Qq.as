package com.vini123.share.platform
{
	public class Qq extends PlatForm
	{
		/**
		 * 
		 * @author Vini123
		 * 腾讯API:http://wiki.open.qq.com/wiki/API%E5%AF%BC%E8%88%AA%E5%9B%BE
		 * 腾讯微博API http://wiki.open.qq.com/wiki/%E8%85%BE%E8%AE%AF%E5%BC%80%E6%94%BE%E5%B9%B3%E5%8F%B0%E5%BE%AE%E5%8D%9AOpenAPI%E8%B0%83%E7%94%A8%E8%AF%B4%E6%98%8E
		 * 腾讯空间分享代码：http://connect.qq.com/intro/share/ 
		 * 腾讯qq好友 http://connect.qq.com/intro/sharetoqq
		 */    
		
		/**
		* @param url       获取URL，可加上来自分享到QQ标识，方便统计
		* @param title     分享标题(可选)
		* @param desc      分享理由(风格应模拟用户对话),支持多分享语随机展现（使用|分隔）
		* @param summary   分享摘要(可选)
		* @param pics      分享图片(可选) 分享的图片集合。多张图片用"|"分开
		* @param flash     视频地址(可选)
		* @param site      分享来源(可选) 如：QQ分享
		* @param style     201
		* @param width     32
		* @param height    32
		*/
		
		private var width:int = 32;
		private var height:int = 32;
		private var style:String = '201';
		
		public function Qq()
		{
			shareUrl = "http://connect.qq.com/widget/shareqq/index.html?";
		}
		
		/**
		 * 
		 * @return 分享到Qq好友的最终地址
		 * 
		 */		
		override public function get url():String
		{
			shareUrl += ("url=" + shareData.url);
			shareUrl += ("&title=" + shareData.title);
			shareUrl += ("&desc=" + shareData.desc);
			shareUrl += ("&summary=" + shareData.summary);
			shareUrl += ("&pics=");
			for(var i:int = 0 ; i< shareData.pics.length ; i++)
			{
				shareUrl += (shareData.pics[i] + "|");
			}
			shareUrl += ("&flash=" + shareData.flash);
			shareUrl += ("&site=" + shareData.site);
			shareUrl += ("&style=" + style);
			shareUrl += ("&width=" + width);
			shareUrl += ("&height=" + height);
			return shareUrl;
		}
	}
}