package com.vini123.share.view
{
	import flash.display.Sprite;
	import flash.events.Event;
	import flash.events.MouseEvent;
	import flash.text.TextField;
	import flash.text.TextFieldAutoSize;
	import flash.text.TextFieldType;
	import flash.text.TextFormat;
	
	public class InputText extends Sprite
	{
		private var background:Sprite;
		private var borderColor:int = 0;
		private var textMask:Sprite;
		
		private var _font:String;
		private var _size:int;
		private var _color:int;
		private var _bold:Boolean;
		private var _width:int;
		protected var _text:TextField;
		private var _textFormat:TextFormat;
		

		
		public function InputText(font:String , size:int , color:int , bold:Boolean = true , width:int = 250)
		{
			_font = font;
			_size = size;
			_color = color;
			_bold = bold;
			_width = width;
			
			initialize();
		}
		
		public function set type(value:String):void
		{
			_text.type = value;
		}
		
		private function initialize():void
		{
			_textFormat = new TextFormat(_font , _size , _color, _bold);
			_text = new TextField();
			_text.autoSize = TextFieldAutoSize.LEFT;
			_text.type = TextFieldType.INPUT;
			_text.defaultTextFormat = _textFormat;
			_text.border = false;
			_text.addEventListener(Event.CHANGE , textChangeHandler);
			addChild(_text);
			
			background = new Sprite();
			textMask = new Sprite();
			addBackground();
		}
		
		private function addBackground():void
		{
			background.graphics.clear();
			if(borderColor)
			{
				background.graphics.lineStyle(1,borderColor);
			}
			
			background.graphics.beginFill(0xffff00 , 0.0);
			background.graphics.drawRect(0 , 0 , _width , (_text.textHeight + 5));
			addChildAt(background , 0);
			
			
			textMask.graphics.clear();
			textMask.graphics.beginFill(0xffff00 , 0.3);
			textMask.graphics.drawRect(0 , 0 , _width -2 ,(_text.textHeight + 5));
			textMask.graphics.endFill();
			addChild(textMask);
			_text.mask = textMask;
			this.addEventListener(MouseEvent.MOUSE_DOWN , mouseDownHandler);
		}
		
		private function textChangeHandler(e:Event):void
		{

		}
		
		private function mouseDownHandler(e:MouseEvent):void
		{
			stage.focus = _text;
			addEventListener(Event.ENTER_FRAME , enterHandler);
			addEventListener(MouseEvent.MOUSE_UP , mouseUpHandler);
			stage.addEventListener(MouseEvent.MOUSE_UP , mouseUpHandler);
		}
		
		private function enterHandler(e:Event):void
		{
			if(mouseX <= 0 && _text.x < 0)
			{
				_text.x +=2;
			}
			else if(mouseX >= _width && (_text.width > _width))
			{
				if(_text.x > (_width - _text.width))
				{
					_text.x -=2;
				}
			}
		}
		
		private function mouseUpHandler(e:MouseEvent):void
		{
			removeEventListener(Event.ENTER_FRAME , enterHandler);
			removeEventListener(MouseEvent.MOUSE_UP , mouseUpHandler);
			stage.removeEventListener(MouseEvent.MOUSE_UP , mouseUpHandler);
		}
		
		public function set asPassword(value:Boolean):void
		{
			_text.displayAsPassword = value;
		}
		
		public function set maxChars(value:int):void
		{
			_text.maxChars = value;
		}
		
		public function set restrict(value:String):void
		{
			_text.restrict = value;
		}
		
		public function set selectable(value:Boolean):void
		{
			if(value)
			{
				this.addEventListener(MouseEvent.MOUSE_DOWN , mouseDownHandler);
			}
			else
			{
				this.removeEventListener(MouseEvent.MOUSE_DOWN , mouseDownHandler);
			}
			_text.selectable = value;
		}
		
		public function get text():String
		{
			return _text.text;
		}
		
		public function set text(value:String):void
		{
			_text.text = value;
			_text.x = 0;
		}
		
		public function set htmlText(value:String):void
		{
			_text.htmlText = value;
			_text.x = 0;
		}
		
		public override function get width():Number
		{
			return _width;
		}
		
		public override function get height():Number
		{
			return _text.textHeight;
		}
		
		public function setBorderColor(value:int):void
		{
			borderColor = value;
			addBackground();
		}
		
		protected function resize(gap:int , sonHeight:int , correctY:int = 0):void
		{
			background.graphics.clear();
			_text.x = gap;
			_text.y = (sonHeight - _text.textHeight) * 0.5 + correctY;
		}
	}
}