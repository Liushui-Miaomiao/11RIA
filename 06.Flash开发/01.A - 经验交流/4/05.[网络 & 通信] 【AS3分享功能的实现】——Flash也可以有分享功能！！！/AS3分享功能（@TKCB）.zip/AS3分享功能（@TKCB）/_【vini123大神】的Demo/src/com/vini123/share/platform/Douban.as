package com.vini123.share.platform
{
	/**
	 * 
	 * @author Vini123
	 * 豆瓣网添加分享代码  http://www.douban.com/service/sharebutton
	 */    
	
	/**
	 * 
	 * @param url  链接的地址   
	 * @param title 分享标题
	 * @param desc 分享的理由
	 */     
	
	public class Douban extends PlatForm
	{
		public function Douban()
		{
			shareUrl = "http://www.douban.com/share/service?";
		}
		
		/**
		 * 
		 * @return 分享到新浪微博的最终地址
		 * 
		 */		
		override public function get url():String
		{
			shareUrl += ("url=" + shareData.url);
			shareUrl += ("&title=" + shareData.title);
			shareUrl += ("&comment=" + shareData.summary);
			shareUrl += ("&image=" + shareData.pics[0]);
			return shareUrl;
		}
	}
}