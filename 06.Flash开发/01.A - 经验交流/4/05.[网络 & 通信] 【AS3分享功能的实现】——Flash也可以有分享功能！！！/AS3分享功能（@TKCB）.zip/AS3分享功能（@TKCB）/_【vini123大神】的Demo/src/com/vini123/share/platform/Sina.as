package com.vini123.share.platform
{
	/**
	 * 
	 * @author Vini123
	 * 新浪微博API:http://open.weibo.com/wiki/%E5%BE%AE%E5%8D%9AAPI#.E8.AF.9D.E9.A2.98
	 * http://open.weibo.com/sharebutton  //分享按钮创建
	 * 可参考： http://open.weibo.com/sharebutton http://open.weibo.com/wiki/2/statuses/upload_url_text
	 */    
	
	/**
	 * 
	 * @param url  链接的地址   
	 * @param title 分享的标题
	 * @param pic 分享的图片 ,多张图片用||隔开
	 */  

	public class Sina extends PlatForm
	{
		private var appKey:String = '68xuzK';
		private var searchPic:String = 'true';
		private var style:String = 'number';
		
		public function Sina():void
		{
			shareUrl = "http://service.weibo.com/share/share.php?type=button&ralateUid=1764700305&language=zh_cn&default_text=";
		}
		
		/**
		 * 
		 * @return 分享到新浪微博的最终地址
		 * 
		 */		
		override public function get url():String
		{
			shareUrl += ("&url=" + shareData.url);
			shareUrl += ("&title=" + shareData.title);
			shareUrl += ("&pic=");
			for(var i:int = 0 ; i< shareData.pics.length ; i++)
			{
				shareUrl += (shareData.pics[i] + "||");
			}
			shareUrl += ("&appkey=" + appKey);
			shareUrl += ("&searchPic=" + searchPic);
			shareUrl += ("&style=" + style);
			return shareUrl;
		}
	}
}