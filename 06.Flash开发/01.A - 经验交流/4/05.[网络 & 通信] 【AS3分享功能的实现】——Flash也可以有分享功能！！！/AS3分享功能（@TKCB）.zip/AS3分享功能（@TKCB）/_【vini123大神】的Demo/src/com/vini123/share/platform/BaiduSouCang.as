package com.vini123.share.platform
{
	/**
	 * 
	 * @author Vini123
	 * http://help.baidu.com/question?prod_en=collect&class=501&id=1000572
	 */ 
	
	/**
	 * @param it   标题 
	 * @param iu   链接的网址
	 * @param dc   分享的描述
	 */   
	
	public class BaiduSouCang extends PlatForm
	{
		public function BaiduSouCang()
		{
			shareUrl = "http://cang.baidu.com/do/add?";
		}
		
		/**
		 * 
		 * @return 分享到百度搜藏的最终url
		 * 
		 */		
		override public function get url():String
		{
			shareUrl += ("it=" + shareData.title);
			shareUrl += ("&iu=" + shareData.url);
			shareUrl += ("&dc=" + shareData.desc);
			shareUrl += ('&fr=ien#nw=1');
			return shareUrl;
		}
	}
}