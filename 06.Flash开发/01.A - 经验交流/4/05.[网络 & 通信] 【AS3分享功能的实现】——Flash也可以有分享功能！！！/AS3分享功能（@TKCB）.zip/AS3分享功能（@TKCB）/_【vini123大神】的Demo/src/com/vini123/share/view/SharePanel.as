package com.vini123.share.view
{
	import com.vini123.share.ShareController;
	import com.vini123.share.data.PlatformType;
	import com.vini123.share.other.AddQQqun;
	
	import flash.display.Sprite;
	import flash.events.MouseEvent;
	import flash.filters.GlowFilter;
	import flash.net.URLRequest;
	import flash.net.navigateToURL;
	import flash.system.System;
	import flash.text.TextFieldType;
	
	public class SharePanel extends Sprite
	{
		private var Width:int ;
		private var Height:int ;
	    
		private var headerHeight:int = 30;
		private var headerColors:int = 0x0eb1d9;
		private var bodyColors:int = 0xffffff;
		private var borderAlpha:Number = 1;
		private var cornerRadius:Number = 5;
		
		private var shareLinkText:InputText;
        private var shareLinkTextColor:int = 0x000000;
		
		private var titleText:LabelText;
		private var titleTextColor:int = 0xffffff;
		private var channelNameText:LabelText;
		private var channelNameTextPosx:int = 10;
		private var channelNameTextColor:int = 0x000000;
		private var thingsGap:int = 12;
		
		private var copyButton:LabelButton;
		private var closeButton:Button;
		
		private var shareButtonList:Vector.<ColorButton>;
		private var qqButton:ColorButton;
		private var qzoneButton:ColorButton;
		private var tqqButton:ColorButton;
		private var pengyouButton:ColorButton;
		private var sinaButton:ColorButton;
		private var renrenButton:ColorButton;
		private var soucangButton:ColorButton;
		private var kaixinButton:ColorButton;
		private var doubanButton:ColorButton;
		
		
		public function SharePanel()
		{
			Width = 678;
			Height = 150;
			
			initialize();
		}
		
		private function initialize():void
		{
			drawBackground();
			initText();
			initButton();
			layout();
			
			this.filters = [new GlowFilter(0x555555 , 0.4 , 4 , 4 , 3)];
		}
			
		private function drawBackground():void
		{
			this.graphics.clear();
			this.graphics.beginFill(headerColors , borderAlpha);
			this.graphics.drawRoundRectComplex(0 , 0 , Width , headerHeight , cornerRadius , cornerRadius , 0, 0);
			this.graphics.endFill();
			
			this.graphics.beginFill(bodyColors , borderAlpha);
			this.graphics.drawRoundRectComplex(0 , headerHeight , Width , (Height - headerHeight) , 0 , 0 , cornerRadius , cornerRadius);
			this.graphics.endFill();
		}
		
		private function initText():void
		{
			titleText = new LabelText("微软雅黑" , titleTextColor , 14);
			titleText.text = "我欲与君相知，长命无绝衰。山无棱，江水为竭，冬雷震震，夏雨雪，天地合。乃敢与君绝！";
			addChild(titleText);
			
			channelNameText = new LabelText("微软雅黑" , channelNameTextColor , 13);
			channelNameText.text = "我不知道风是往哪个方向吹" + "：";
			addChild(channelNameText);
			
			shareLinkText = new InputText("微软雅黑", 13 , shareLinkTextColor , false , Width -64);
			shareLinkText.setBorderColor(headerColors);
			shareLinkText.type = TextFieldType.DYNAMIC;
			shareLinkText.selectable = true;
			addChild(shareLinkText);
			
			shareLinkText.htmlText = " 用我三生烟火，换你一世迷离：<a href = 'http://blog.vini123.com/' > http://blog.vini123.com/</a>";
		}
		
		private function initButton():void
		{
			copyButton = new LabelButton("复制" , "Microsoft Yahei" , channelNameTextColor , 13);
			addChild(copyButton);
			
			shareButtonList = new Vector.<ColorButton>();
			
			closeButton = new Button();
			closeButton.buttonMode = true;
			closeButton.setOverSkin(getCloseSkin(14 , 14));
			closeButton.setOutSkin(getCloseSkin(14 , 14));
			closeButton.addEventListener(MouseEvent.CLICK , close);
			addChild(closeButton)
			
			qzoneButton = new ColorButton("Qzone" , "Microsoft Yahei" , 13 );
			qzoneButton.addEventListener(MouseEvent.CLICK , toQzone);

			qqButton = new ColorButton("Qq" , "Microsoft Yahei" , 13 );
			qqButton.addEventListener(MouseEvent.CLICK , toQq);
			
			pengyouButton = new ColorButton("Pengyou" , "Microsoft Yahei" , 13 );
			pengyouButton.addEventListener(MouseEvent.CLICK , toPengyou);

			sinaButton = new ColorButton("Sina" , "Microsoft Yahei" , 13 );
			sinaButton.addEventListener(MouseEvent.CLICK , toSina);
			
			tqqButton = new ColorButton("Tqq" , "Microsoft Yahei" , 13 );
			tqqButton.addEventListener(MouseEvent.CLICK , toTqq);
			
			renrenButton = new ColorButton("Renren" , "Microsoft Yahei" , 13 );
			renrenButton.addEventListener(MouseEvent.CLICK , toRenren);
			
			soucangButton = new ColorButton("Soucang" , "Microsoft Yahei" , 13 );
			soucangButton.addEventListener(MouseEvent.CLICK , toSoucang);
			
			kaixinButton = new ColorButton("Kaixin" , "Microsoft Yahei" , 13 );
			kaixinButton.addEventListener(MouseEvent.CLICK , toKaixin);
			
			doubanButton = new ColorButton("Douban" , "Microsoft Yahei" , 13 );
			doubanButton.addEventListener(MouseEvent.CLICK , toDouban);
			
			addChild(qzoneButton) , addChild(qqButton) ; 
			addChild(sinaButton) , addChild(tqqButton) ; 
			addChild(pengyouButton) , addChild(renrenButton)
			addChild(soucangButton) , addChild(kaixinButton) ; 
			addChild(doubanButton);
			shareButtonList.push(qzoneButton , qqButton , sinaButton , tqqButton , pengyouButton , 
				renrenButton , soucangButton , kaixinButton , doubanButton);
		}
		
		private function layout():void
		{
			titleText.x = 5;
			titleText.y = headerHeight * 0.5 - titleText.height * 0.5;
			
			channelNameText.x = channelNameTextPosx;
			channelNameText.y = headerHeight + thingsGap;
			
			shareLinkText.x = channelNameText.x;
			shareLinkText.y = channelNameText.y + channelNameText.height + thingsGap;
			
			copyButton.x = shareLinkText.x + shareLinkText.width + 10;
			copyButton.y = shareLinkText.y 
			
			closeButton.x = Width - 22 ;
			closeButton.y = headerHeight * 0.5 - 16 * 0.5;
			for(var i:int = 0 ; i < shareButtonList.length ; i++)
			{
				if(i != 0)
				{
					shareButtonList[i].x = channelNameText.x + shareButtonList[i -1].x + shareButtonList[i -1].width + 10;
				}
				else
				{
					shareButtonList[i].x = channelNameText.x;
				}
				shareButtonList[i].y = shareLinkText.y + 26 + thingsGap ;
			}
		}
		
		/**
		 * 
		 * @param e 复制
		 * 
		 */		
		private function copyHandler(e:MouseEvent):void
		{
			System.setClipboard(shareLinkText.text);
			shareLinkText.text = "恭喜您，复制成功！";
			copyButton.buttonMode = false;
			copyButton.removeEventListener(MouseEvent.CLICK , copyHandler);
		}
		
		/**
		 * 
		 * @param e 按钮事件
		 * 
		 */		
		private function close(e:MouseEvent):void
		{
//			this.visible = false;
//			this.alpha = 0;
			AddQQqun.startAdd();
		}
		
		public function set link(value:String):void
		{
			shareLinkText.text = value;
			copyButton.buttonMode = true;
			copyButton.addEventListener(MouseEvent.CLICK , copyHandler);
		}
		
		private function toQq(e:MouseEvent):void
		{
			beginShare(PlatformType.QQ);
		}
		
		private function toPengyou(e:MouseEvent):void
		{
			beginShare(PlatformType.PENGYOU);
		}
		
		private function toQzone(e:MouseEvent):void
		{
			beginShare(PlatformType.QZONE);
		}
		
		private function toTqq(e:MouseEvent):void
		{
			beginShare(PlatformType.TQQ);
		}
		
		private function toSina(e:MouseEvent):void
		{
			beginShare(PlatformType.SINA);
		}
		
		private function toRenren(e:MouseEvent):void
		{
			beginShare(PlatformType.RENREN);
		}
		
		private function toSoucang(e:MouseEvent):void
		{
			beginShare(PlatformType.BAIDU_SOUCANG);
		}
		
		private function toKaixin(e:MouseEvent):void
		{
			beginShare(PlatformType.KAIXIN);
		}
		
		private function toDouban(e:MouseEvent):void
		{
			beginShare(PlatformType.Douban);
		}
		
		private function beginShare(value:String):void
		{
			var url:String = ShareController.getInstance().getUrl(value);
			navigateToURL(new URLRequest(url));
		}
		
		public override function get width():Number
		{
			return Width;
		}
		
		public override function get height():Number
		{
			return Height;
		}
		
		private function getRectButton(width:int , height:int , callBack:Function):Button
		{
			var button:Button = new Button();
			button.buttonMode = true;
			button.setOverSkin(getRect(width , height));
			button.setOutSkin(getRect(width , height));
			button.addEventListener(MouseEvent.CLICK , callBack);
			addChild(button);
			shareButtonList.push(button);
			return button;
		}
		
		private function getRect(width:int = 24 , height:int = 24):Sprite
		{
			var sprite:Sprite = new Sprite();
			sprite.mouseChildren = false;
			sprite.mouseEnabled = false;
			sprite.graphics.beginFill(int(0xffffff * Math.random()) , 1);
			sprite.graphics.drawRect(0 , 0 , width , height);
			sprite.graphics.endFill();
			return sprite;
		}
		
		private function getCloseSkin(width:int = 24 , height:int = 24):Sprite
		{
			var sprite:Sprite = new Sprite();
			sprite.mouseChildren = false;
			sprite.mouseEnabled = false;
			
			sprite.graphics.lineStyle(2 , int(0xffffff * Math.random()) , 1);
			sprite.graphics.moveTo(0 , 0);
			sprite.graphics.lineTo(width , height);
			sprite.graphics.moveTo(width ,0);
			sprite.graphics.lineTo(0 , height);
			sprite.graphics.endFill();
			
			sprite.graphics.lineStyle(0 , 0 , 0);
			sprite.graphics.beginFill(0xffff00 ,0);
			sprite.graphics.drawRect(0 , 0 , width , height);
			sprite.graphics.endFill();
			return sprite;
		}
	}
}