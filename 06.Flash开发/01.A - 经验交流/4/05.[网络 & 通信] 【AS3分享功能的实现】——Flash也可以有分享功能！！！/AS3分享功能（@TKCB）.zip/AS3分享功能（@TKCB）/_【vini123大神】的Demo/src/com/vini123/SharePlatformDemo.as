package com.vini123
{
	import flash.display.Sprite;
	import flash.display.StageAlign;
	import flash.display.StageScaleMode;
	import flash.events.Event;
	
	import com.vini123.share.ShareController;
	import com.vini123.share.view.SharePanel;
	
	[SWF(width="690" , height="250" , frameRate="30" , backgroundColor = "#ffffff")]
	public class SharePlatformDemo extends Sprite
	{
		private var sharePanel:SharePanel;
		
		public function SharePlatformDemo()
		{
			addEventListener(Event.ADDED_TO_STAGE , addToStageHandler);
		}
		
		private function addToStageHandler(e:Event):void
		{
			removeEventListener(Event.ADDED_TO_STAGE , addToStageHandler);
			
			stage.scaleMode = StageScaleMode.NO_SCALE;
			stage.align = StageAlign.TOP_LEFT;
			stage.addEventListener(Event.RESIZE , resizeHandler);
			
			initialize();
			resizeHandler();
		}
		
		private function initialize():void
		{
			sharePanel = new SharePanel();
			addChild(sharePanel);
			
			fillData();
		}
		
		private function resizeHandler(e:Event = null):void
		{
			sharePanel.x = stage.stageWidth * 0.5 - sharePanel.width * 0.5;
			sharePanel.y = stage.stageHeight * 0.5 - sharePanel.height * 0.5;
		}
		
		private function fillData():void
		{
			ShareController.getInstance().title = "非你网，非你不可";
			ShareController.getInstance().desc = "没有花香，没有树高。我是一个无人知道的小草。";
			ShareController.getInstance().site = "http://www.vini123.com";
			ShareController.getInstance().summary = "仿佛有痛楚。如果我晕眩，那是因为幻觉丰盛，能量薄弱。足已支持我对你的迷恋，不够支持我们的快乐。";
			ShareController.getInstance().url = "http://blog.vini123.com";
			ShareController.getInstance().flash = "http://v.qq.com/page/t/4/8/t00159sip48.html";
			ShareController.getInstance().pics = ["http://p4.xyx.hao123img.com/img/middleNewLogo/20140320_middle_133f54ea66c93874.jpg" ,
												  "http://s0.hao123img.com/res/r/image/2015-01-09/f3fac913f83576f131139c9d3cbc30d7.jpg",
												  "http://s0.hao123img.com/res/r/image/2014-12-05/95ccc5332153b5b0b64600d882574f33.gif"];
		}
	}
}