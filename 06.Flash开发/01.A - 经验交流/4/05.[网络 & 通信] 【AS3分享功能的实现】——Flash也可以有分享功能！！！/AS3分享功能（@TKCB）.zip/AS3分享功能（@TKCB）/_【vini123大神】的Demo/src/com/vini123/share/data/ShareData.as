package com.vini123.share.data
{
	/**
	 * 
	 * @author Vini123
	 *  http://www.cuplayer.com/player/PlayerCodeAs/2014/05261338.html
	 */	
	public class ShareData
	{
		private  var _url:String = "";  //跳转链接
		private  var _title:String = "";  //分享标题
		private  var _desc:String = ""; //分享理由
		private  var _summary:String =""; //分享摘要
		private  var _site:String = "";  //分享来源
		private var _flash:String = "";  //视频地址
		private  var _pics:Array = []; //分享小图
		
		/**
		 * 
		 * @param value
		 * 点击跳转的链接
		 */		
		public function set url(value:String):void
		{
			_url = value;
		}
		
		public function get url():String
		{
			return encodeURI(_url);
		}
		
		/**
		 * 
		 * @param value
		 * 分享的标题
		 */		
		public function set title(value:String):void
		{
			_title = value;
		}
		
		public function get title():String
		{
			return encodeURI(_title);
		}
		
		/**
		 * 
		 * @param value
		 * 分享的理由
		 */		
		public function set desc(value:String):void
		{
			_desc = value;
		}
		
		public function get desc():String
		{
			return encodeURI(_desc);
		}
		
		/**
		 * 
		 * @param value
		 * 分享的摘要
		 */		
		public function set summary(value:String):void
		{
			_summary = value;
		}
		
		public function get summary():String
		{
			return encodeURI(_summary);
		}
		
		/**
		 * 
		 * @param value
		 * 分享来源
		 */		
		public function set site(value:String):void
		{
			_site = value;
		}
		
		public function get site():String
		{
			return encodeURI(_site);
		}
		
		/**
		 * 
		 * @param value
		 * 视频地址
		 */		
		public function set flash(value:String):void
		{
			_flash = value;
		}
		
		public function get flash():String
		{
			return encodeURI(_flash);
		}

		/**
		 * 
		 * @param value
		 * 分享的图片集合
		 */		
		public function set pics(value:Array):void
		{
			_pics = [];
			for(var i:int = 0 ; i< value.length ; i++)
			{
				_pics.push(escape(value[i]));
//				_pics.push(encodeURI(value[i]));
			}
		}
		
		public function get pics():Array
		{
			return _pics;
		}
	}
}