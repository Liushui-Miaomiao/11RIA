package com.vini123.share.view
{
	import flash.display.Sprite;
	import flash.events.MouseEvent;
	import flash.text.TextField;
	import flash.text.TextFieldAutoSize;
	import flash.text.TextFormat;
	
	public class LabelButton extends Sprite
	{
		private var label:String;
		private var labelTxt:TextField;
		private var line:Sprite;
		private var background:Sprite;
		
		private var color:int;
		private var size:int;
		private var font:String;
		
		public function LabelButton(label:String , font:String , color:int , size:int)
		{
			this.mouseChildren = false;
			this.buttonMode = true;
			this.font = font;
			this.color = color;
			this.size = size;
			this.label = label;
			initialize();
		}
		
		private function initialize():void
		{
			addTxt();
//			addLine();
			addBackground();
			addEvent();
		}
		
		private function addTxt():void
		{
			labelTxt = new TextField();
			labelTxt.autoSize = TextFieldAutoSize.LEFT;
			labelTxt.defaultTextFormat = new TextFormat( font , size , color);
			addChild(labelTxt);
			
			labelTxt.text = label;
		}
		
		private function addLine():void
		{
			line = getLine(labelTxt.textWidth , 1 , color);
			addChild(line);
			line.visible = false;
			line.y = labelTxt.textHeight + 5;
			line.x = 2;
		}
		
		private function addBackground():void
		{
			background = getRectSprite(labelTxt.textWidth + 2 , labelTxt.height , 0xff00ff , 0);
			addChild(background);
		}
		
		private function getRectSprite(w:int , h:Number , color:int , alpha:Number = 1):Sprite
		{
			var sp:Sprite = new Sprite();
			sp.graphics.beginFill(color , alpha);
			sp.graphics.drawRect(0 , 0 , w , h);
			sp.graphics.endFill();
			return sp;
		}
		
		private function getLine(w:int , h:Number , color:int , alpha:Number = 1):Sprite
		{
			var sp:Sprite = new Sprite();
			sp.graphics.lineStyle(h , color , 1);
			sp.graphics.moveTo(0,0);
			sp.graphics.lineTo(w, 0);
			sp.graphics.lineTo(0,0);
			return sp;
		}
		
		private function addEvent():void
		{
			this.addEventListener(MouseEvent.ROLL_OVER , overHandler);
			this.addEventListener(MouseEvent.ROLL_OUT , outHandler);
		}
		
		private function overHandler(e:MouseEvent):void
		{
//			line.visible = true;
		}
		
		private function outHandler(e:MouseEvent):void
		{
//			line.visible = false;
		}
		
		public override function get width():Number
		{
			return background.width;
		}
		
		public override function get height():Number
		{
			return background.height;
		}
	}
}