package com.vini123.share.platform
{
	import com.vini123.share.data.ShareData;

	public class PlatForm
	{
		protected var shareUrl:String;
		protected var shareData:ShareData;
		
		public function PlatForm()
		{
			
		}
		
		public function set data(value:ShareData):void
		{
			shareData = value;
		}
		
		public function get url():String
		{
			return "";
		}
	}
}