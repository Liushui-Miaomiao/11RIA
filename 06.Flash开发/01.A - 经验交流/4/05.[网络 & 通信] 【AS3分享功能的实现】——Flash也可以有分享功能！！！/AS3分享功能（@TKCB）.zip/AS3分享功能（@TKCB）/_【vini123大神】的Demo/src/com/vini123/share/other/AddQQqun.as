package com.vini123.share.other
{
	import flash.net.URLRequest;
	import flash.net.navigateToURL;

	/**
	 * 
	 * @author vini123
	 * help http://qun.qq.com/join.html
	 */	
	public class AddQQqun
	{
		private static const url:String = "http://shang.qq.com/wpa/qunwpa?idkey=7e186232394731577f6f8dff9c73d3180c50dfdcc60aaff4510fc33780933c9d";
		
		public function AddQQqun()
		{
			
		}
		
		public static function startAdd():void
		{
			navigateToURL(new URLRequest(url));
		}
	}
}