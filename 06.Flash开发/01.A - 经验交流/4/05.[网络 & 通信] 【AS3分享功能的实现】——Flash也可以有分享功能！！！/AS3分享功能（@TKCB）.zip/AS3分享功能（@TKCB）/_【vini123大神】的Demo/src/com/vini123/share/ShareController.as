package com.vini123.share
{
	import flash.utils.Dictionary;
	
	import com.vini123.share.data.PlatformType;
	import com.vini123.share.data.ShareData;
	import com.vini123.share.platform.BaiduSouCang;
	import com.vini123.share.platform.Douban;
	import com.vini123.share.platform.Kaixin;
	import com.vini123.share.platform.PengyouQq;
	import com.vini123.share.platform.PlatForm;
	import com.vini123.share.platform.QZone;
	import com.vini123.share.platform.Qq;
	import com.vini123.share.platform.Renren;
	import com.vini123.share.platform.Sina;
	import com.vini123.share.platform.Tqq;

	/**
	 * 
	 * @author Vini123
	 * 
	 */	
	public class ShareController
	{
		private var shareData:ShareData;
		private var platformDic:Dictionary;
		
		private static var instance:ShareController;
		
		public function ShareController()
		{
			initialize();
		}
		
		public static function getInstance():ShareController
		{
			if(!instance)
			{
				instance = new ShareController();
			}
			return instance;
		}
		
		public function initialize():void
		{
			shareData = new ShareData();
			platformDic = new Dictionary();
			
			addPlatForm(PlatformType.QQ , new Qq());
			addPlatForm(PlatformType.QZONE , new QZone());
			addPlatForm(PlatformType.TQQ , new Tqq());
			addPlatForm(PlatformType.PENGYOU , new PengyouQq());
			addPlatForm(PlatformType.SINA , new Sina());
			addPlatForm(PlatformType.RENREN , new Renren());
			addPlatForm(PlatformType.BAIDU_SOUCANG , new BaiduSouCang());
			addPlatForm(PlatformType.KAIXIN , new Kaixin());
			addPlatForm(PlatformType.Douban , new Douban());
		}
		
		private function addPlatForm(type:String , platform:PlatForm):void
		{
			if(!platformDic[type])
			{
				platform.data = shareData;
				platformDic[type] = platform;
			}
		}
		
		/**
		 * 
		 * @param value 分享的平台类型  PlatformType
		 * @return 获取分享到的url地址
		 * 
		 */		
		public function getUrl(value:String):String
		{
			return (platformDic[value] as PlatForm).url;
		}
		
		/**
		 * 
		 * @param value
		 * 点击跳转的链接
		 */		
		public function set url(value:String):void
		{
			shareData.url = value;
		}
		
		/**
		 * 
		 * @param value
		 * 分享的标题
		 */		
		public function set title(value:String):void
		{
			shareData.title = value;
		}

		
		/**
		 * 
		 * @param value
		 * 分享的理由
		 */		
		public function set desc(value:String):void
		{
			shareData.desc = value;
		}
		
		/**
		 * 
		 * @param value
		 * 分享的摘要
		 */		
		public function set summary(value:String):void
		{
			shareData.summary = value;
		}
		
		/**
		 * 
		 * @param value
		 * 分享来源
		 */		
		public function set site(value:String):void
		{
			shareData.site = value;
		}

		/**
		 * 
		 * @param value
		 * 视频地址
		 */		
		public function set flash(value:String):void
		{
			shareData.flash = value;
		}
		
		/**
		 * 
		 * @param value
		 * 分享的图片集合
		 */		
		public function set pics(value:Array):void
		{
			shareData.pics = value;
		}
	}
}