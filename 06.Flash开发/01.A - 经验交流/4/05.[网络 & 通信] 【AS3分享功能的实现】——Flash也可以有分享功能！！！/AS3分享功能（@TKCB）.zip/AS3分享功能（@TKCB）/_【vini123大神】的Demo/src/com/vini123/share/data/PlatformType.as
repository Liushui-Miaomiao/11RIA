package com.vini123.share.data
{
	public class PlatformType
	{
		public static const QQ:String = "qq";  //qq好友或qq群或qq组;
		public static const QZONE:String = "qzone"; //qq空间
		public static const TQQ:String = "tqq"; //qq微博
		public static const PENGYOU:String = "pengyou"; //朋友圈
		public static const SINA:String = "sina"; //新浪微博
		public static const RENREN:String = "renren"; //分享到人人网
		public static const BAIDU_SOUCANG:String = "baiduSoucang"; //分享到百度搜藏
		public static const KAIXIN:String = "kaixin"; //分享到开心网
		public static const Douban:String = "douban"; //分享到豆瓣网
	}
}