package com.vini123.share.platform
{
	/**
	 * 
	 * @author Vini123
	 * 腾讯API:http://wiki.open.qq.com/wiki/%E3%80%90QQ%E7%99%BB%E5%BD%95%E3%80%91add_share#1.2.09.E6.A0.BC.E5.BC.8F
	 * 腾讯微博分享代码：http://dev.t.qq.com/websites/qshare/
	 * 腾讯空间分享代码：http://connect.qq.com/intro/share/ 
	 * 腾讯qq好友 http://connect.qq.com/intro/sharetoqq
	 */    
	
	/**
	 * 
	 * @param url  链接的地址   
	 * @param title 标题
	 * @param summary 分享摘要
	 * @param pic 分享的图片
	 */  
	
	public class Tqq extends PlatForm
	{
		public function Tqq():void
		{
			shareUrl = "http://share.v.t.qq.com/index.php?c=share&a=index";
		}
      
		/**
		 * 
		 * @return 分享到腾讯微博的最终地址
		 * 
		 */		
		override public function get url():String
		{
			shareUrl += ("&url=" + shareData.url);
			shareUrl += ("&title=" + shareData.title);
			shareUrl += ("&summary=" + shareData.summary);
			shareUrl += ("&pic=");
			for(var i:int = 0 ; i< shareData.pics.length ; i++)
			{
				shareUrl += (shareData.pics[i] + "|");
			}
			return shareUrl;
		}
	}
}