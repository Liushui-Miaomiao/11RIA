package com.vini123.share.view
{
	import flash.display.Sprite;
	import flash.events.MouseEvent;
	import flash.text.TextField;
	import flash.text.TextFieldAutoSize;
	import flash.text.TextFormat;
	
	public class ColorButton extends Sprite
	{
		private var textField:TextField;
		private var textFormat:TextFormat;
		
		private var label:String;
		private var font:String;
		private var size:int;
		private var bold:Boolean;
		private var overColor:int;
		private var defaultColor:int;
		
		private var gap:int = 5;
		
		public function ColorButton(label:String , font:String , size:int , color:int = 0 , bold:Boolean = true)
		{
			this.label = label;
			this.font = font;
			this.size = size;
			this.bold = bold;
			
			if(color == 0)
			{
				defaultColor = int(Math.random() * 0xffffff);
				overColor = int(Math.random() * 0xffffff);
			}
			else
			{
				defaultColor = color;
				overColor = int(Math.random() * color);
			}
			
			this.mouseChildren = false;
			initialize();
		}
		
		private function initialize():void
		{
			textFormat = new TextFormat(font , size , defaultColor , bold);
			textField = new TextField();
			textField.wordWrap = false;
			textField.multiline = false;
			textField.autoSize = TextFieldAutoSize.LEFT;
			textField.defaultTextFormat = textFormat;
			addChild(textField);
			
			textField.text = label;
			textField.x = textField.y = gap;
			
			this.graphics.beginFill(int(Math.random() * 0xffffff) , 1);
			this.graphics.drawRoundRect(0 , 0 , textField.width + gap * 2 , textField.height + gap *2 , 5 , 5);
			this.graphics.endFill();
			
			this.buttonMode = true;
			this.addEventListener(MouseEvent.ROLL_OVER , overHandler);
			this.addEventListener(MouseEvent.ROLL_OUT , outHandler);
		}
		
		private function overHandler(event:MouseEvent):void
		{
			textFormat.color = overColor;
			textField.setTextFormat(textFormat);
		}
		
		private function outHandler(event:MouseEvent):void
		{
			textFormat.color = defaultColor;
			textField.setTextFormat(textFormat);
		}
	}
}