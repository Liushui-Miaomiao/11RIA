package com.vini123.share.view
{
	import flash.display.DisplayObject;
	import flash.display.Sprite;
	import flash.events.MouseEvent;
	
	/**
	 * 
	 * @author vini123
	 * date 2014/12/18
	 */	
	public class Button extends Sprite
	{
		private const OUT_STATE:int = 1;
		private const OVER_STATE:int = 2;
		private var state:int = OUT_STATE;
		
		private var currSkin:DisplayObject = null;
		private var outSkin:DisplayObject = null;
		private var overSkin:DisplayObject = null;
		
		protected var _enabled:Boolean = true;
		
		public function Button()
		{
			this.mouseChildren = false;
			this.addEventListener(MouseEvent.ROLL_OVER , overHandler);
			this.addEventListener(MouseEvent.ROLL_OUT , outHandler);
		}

		private function overHandler(e:MouseEvent):void
		{
			state = OVER_STATE;
			redraw();
		}
		
		private function outHandler(e:MouseEvent):void
		{
			state = OUT_STATE;
			redraw();
		}
		
		public function get enabled():Boolean
		{
			return _enabled;
		}
		
		public function set enabled(value:Boolean):void
		{
			_enabled = value;
		}
		
		/**
		 * 
		 * @param value 添加皮肤
		 * 
		 */		
		public function setOutSkin(value:DisplayObject):void
		{
			outSkin = value;
			redraw();
		}
		
		public function setOverSkin(value:DisplayObject):void
		{
			overSkin = value;
			redraw();
		}
		
		protected function redraw():void
		{
			if(!_enabled)return;
			
			var skin:DisplayObject;
			if(state == OUT_STATE)
			{
				skin = outSkin;
			}
			else if(state == OVER_STATE)
			{
				skin = overSkin;
			}
			setCurrSkin(skin);
		}
		
		private function setCurrSkin(value:DisplayObject):void
		{
			if(currSkin != null)
			{
				if(currSkin.parent == this)
				{
					removeChild(currSkin);
				}
				currSkin = null;
			}
			if(value != null)
			{
				currSkin = value;
				addChildAt(currSkin , 0);
			}
		}
	}
}