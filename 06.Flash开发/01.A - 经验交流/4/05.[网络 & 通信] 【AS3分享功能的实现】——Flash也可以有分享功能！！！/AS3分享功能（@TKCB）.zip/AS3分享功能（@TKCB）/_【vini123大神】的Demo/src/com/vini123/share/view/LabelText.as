package com.vini123.share.view
{
	import flash.display.Sprite;
	import flash.text.TextField;
	import flash.text.TextFieldAutoSize;
	import flash.text.TextFormat;
	
	public class LabelText extends Sprite
	{
		private var _text:TextField;
		private var _textFormat:TextFormat;
		
		private var _color:int;
		private var _size:int;
		private var _font:String;
		
		public function LabelText(font:String , color:int , size:int)
		{
			this.mouseChildren = false;
			this._font = font;
			this._color = color;
			this._size = size;
			initialize();
		}

		private function initialize():void
		{
			_textFormat = new TextFormat( _font , _size , _color);
			_text = new TextField();
			_text.autoSize = TextFieldAutoSize.LEFT;
			_text.defaultTextFormat = _textFormat;
			addChild(_text);
		}
		
		public function get text():String
		{
			return _text.text;
		}
		
		public function set text(value:String):void
		{
			_text.text = value;
		}
		
		public function get font():String
		{
			return _font;
		}
		
		public function set font(value:String):void
		{
			_font = value;
			_textFormat.font = _font;
			_text.defaultTextFormat = _textFormat;
		}
		
		public function get size():int
		{
			return _size;
		}
		
		public function set size(value:int):void
		{
			_size = value;
			_textFormat.size = _size;
			_text.defaultTextFormat = _textFormat;
		}

		public function get color():int
		{
			return _color;
		}
		
		public function set color(value:int):void
		{
			_color = value;
			_textFormat.color = _color;
			_text.defaultTextFormat = _textFormat;
		}
		
		public override function get width():Number
		{
			return _text.textWidth
		}
		
		public override function get height():Number
		{
			return _text.textHeight
		}
	}
}