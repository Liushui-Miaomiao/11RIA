﻿/*
 * 作　　者：TKCB
 * 作者信息：身高（0.00167公里+）；体重（0.06吨±）；年龄（公元1990后）；籍贯（有兵马俑的地方）；星座（最后一个星座）；血型（万能型）；人生格言（The king come back.）。
 * 交流学习：加QQ群[AS3殿堂之路]（96759336）,群里有无数主城、架构、妹子、LOL战友，欢迎交流讨论。
 * 联系方式：QQ（2414268040）；E-mail（tkcb@qq.com）；手机（15029932353)。
 * 个人网站：www.tkcb.cc（来这里关注我吧，这里有我所有的作品，分享的资料，我的介绍和动态，还有更多你想不到的）
 */



package
{
	import flash.display.Sprite;
	import flash.display.StageDisplayState;
	
	import flash.events.MouseEvent;
	
	import flash.external.ExternalInterface;
	
	import flash.text.TextField;
	
	import fl.motion.MotionEvent;
	import flash.events.Event;
	
	/**
	 * Main 文档类
	 */
	public class Main extends Sprite
	{
		/**
		 * ...
		 */
		public function Main ()
		{
			ExternalInterface.addCallback( "invokeToJS", invokeToJS ); 	// 注册外部调用，JS调用
			ExternalInterface.addCallback( "invokeToJSObject", invokeToJSObject ); 	// 注册外部调用，JS调用
			ExternalInterface.addCallback( "invokeToJSArray", invokeToJSArray ); 	// 注册外部调用，JS调用
			
			this[ "jsStringBtn" ].addEventListener( MouseEvent.CLICK, invokeByJS );
			this[ "jsObjectBtn" ].addEventListener( MouseEvent.CLICK, invokeByJS2 );
			this[ "jsArrayBtn" ].addEventListener( MouseEvent.CLICK, invokeByJS3 );
			
			this[ "fullScreenBtn" ].addEventListener( MouseEvent.CLICK, fullScreenBtnHandel );
		}
		
		
		/** 调用JS函数，获取数据（文本） */
		private function invokeByJS ( eve : MouseEvent ) : void
		{
			if ( ExternalInterface.available ) {
				var jsStr: String = ExternalInterface.call( "invokeByAs" );	 // 调用JS函数，网页中的JS代码写的函数
				this["jsText"].text = jsStr;
			}
		}
		
		/** 调用JS函数，获取数据（Object） */
		private function invokeByJS2 ( eve : MouseEvent ) : void
		{
			if ( ExternalInterface.available ) {
				var jsStr : Object = ExternalInterface.call( "invokeByAsObject" );	 // 调用JS函数，网页中的JS代码写的函数
				this["jsText"].text = "名字：" + jsStr.name + "  生日：" + jsStr.birthday;
			}
		}
		
		/** 调用JS函数，获取数据（Array） */
		private function invokeByJS3 ( eve : MouseEvent ) : void
		{
			if ( ExternalInterface.available ) {
				var jsStr : Array = ExternalInterface.call( "invokeByAsArray" );	 // 调用JS函数，网页中的JS代码写的函数
				this["jsText"].text = jsStr.toString();
			}
		}
		
		/** 全屏和退出全屏 */
		private function fullScreenBtnHandel ( eve : MouseEvent ) : void
		{
			if ( this.stage.displayState == StageDisplayState.FULL_SCREEN )
			{
				this.stage.displayState = StageDisplayState.NORMAL;
			}
			else
			{
				this.stage.displayState = StageDisplayState.FULL_SCREEN;
			}
		}
		
		/** 外部JS调用的函数，用于获取SWF内的数据 */
		public function invokeToJS () : String
		{
			return this["asText"].text;
		}
		
		/** 外部JS调用的函数，用于获取SWF内的数据 */
		public function invokeToJSObject () : Object
		{
			var obj : Object = { name:"TKCB", birthday:"1992.2.20" };
			return obj;
		}
		
		/** 外部JS调用的函数，用于获取SWF内的数据 */
		public function invokeToJSArray () : Array
		{
			var arr : Array = [ 1, 2, 3, 4, 5 ];
			return arr;
		}
	}
}