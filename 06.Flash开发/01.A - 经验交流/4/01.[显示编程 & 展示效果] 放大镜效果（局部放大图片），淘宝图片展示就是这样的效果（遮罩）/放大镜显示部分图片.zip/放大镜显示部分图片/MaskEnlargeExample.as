﻿package
{
	import flash.display.Sprite;
	import mask.MaskEnlarge;
	
	public class MaskEnlargeExample extends Sprite
	{
		public function MaskEnlargeExample()
		{
			var me:MaskEnlarge = new MaskEnlarge();
			me.maskDisplay(picA, picB, null, 110, 80);
			addChild(me);
		}
	}
}