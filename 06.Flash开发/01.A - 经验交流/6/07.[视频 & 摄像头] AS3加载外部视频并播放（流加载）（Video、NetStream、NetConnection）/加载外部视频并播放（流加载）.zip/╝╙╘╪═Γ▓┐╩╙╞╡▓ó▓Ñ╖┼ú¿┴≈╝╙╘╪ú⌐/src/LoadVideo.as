﻿package 
{
	import flash.display.Sprite;
	import flash.display.StageDisplayState;
	
	import flash.net.NetConnection;
	import flash.net.NetStream;
	
	import flash.media.Video;
	import flash.media.SoundTransform;
	
	import flash.events.AsyncErrorEvent;
	import flash.events.MouseEvent;
	
	import flash.geom.Rectangle;
	
	/**
	 * LoadVideo 类，用于播放Flv视频。与Flv文件建立连接、创建视频流并播放视频
	 * @author TKCB
	 */
	public class LoadVideo extends Sprite
	{
		private var nc:NetConnection;// 建立连接
		private var ns:NetStream;// 创建视频流，并播放视频
		private var vid:Video;// 显示视频
		
		private var seekNumber:uint = 100;// 控制快进
		private var volumeNumber:SoundTransform = new SoundTransform();// 控制音量
		
		function LoadVideo(){
			
			// 建立连接
			nc = new NetConnection();
			nc.connect(null);
			
			// 创建视频流，并播放视频
			ns = new NetStream(nc);
			ns.addEventListener(AsyncErrorEvent.ASYNC_ERROR, asyncErrorHandler);
			ns.play("video/高清版：唐伯虎点秋香（周星驰）国语中字.mp4");
			
			/// 显示视频
			vid = new Video();
			vid.attachNetStream(ns);
			vid.x = 91.4;
			vid.y = 43.75;
			vid.smoothing = true;	// 使视频在放大的情况下不至于出现像素锯齿，原理就是插补数据（插补像素）
			addChild(vid);
			
			trace(vid.width);
			trace(vid.height);
			
			stopC.addEventListener(MouseEvent.CLICK, stopHandler);// 暂停视频流
			playC.addEventListener(MouseEvent.CLICK, playHandler);// 播放视频流
			seekC.addEventListener(MouseEvent.CLICK, seekHandler);// 搜索指定关键帧
			stopplay.addEventListener(MouseEvent.CLICK, stopplayHandler);// 暂停/播放视频流
			fullScreen.addEventListener(MouseEvent.CLICK, fullScreenHandler);// 全屏
			normal.addEventListener(MouseEvent.CLICK, normalHandler);// 退出全屏
			volume0.addEventListener(MouseEvent.CLICK, volumeHandler);// 控制音量
			volume1.addEventListener(MouseEvent.CLICK, volumeHandler);// 控制音量
		}
		
		/**
		* 捕获连接异常
		*/
		private function asyncErrorHandler(eve:AsyncErrorEvent):void
		{
			// 错误处理
			trace("连接异常");
		}
		
		/**
		 * 暂停视频流
		 */
		private function stopHandler(eve:MouseEvent):void
		{
			ns.pause();
		}
		
		/**
		 * 播放视频流
		 */
		private function playHandler(eve:MouseEvent):void
		{
			ns.resume();
		}
		
		/**
		 * 搜索指定关键帧
		 */
		private function seekHandler(eve:MouseEvent):void
		{
			ns.seek(seekNumber);
			seekNumber += 30;
		}
		
		/**
		 * 暂停/播放视频流
		 */
		private function stopplayHandler(eve:MouseEvent):void
		{
			ns.togglePause();
		}
		
		/**
		 * 全屏
		 */
		private function fullScreenHandler(eve:MouseEvent):void
		{
			// 指定全屏的区域，可以仅仅指定视频区域放大为全屏
			var screenRectangle:Rectangle = new Rectangle(vid.x, vid.y, vid.width, vid.height);
			stage.fullScreenSourceRect = screenRectangle;
			
			stage.displayState = StageDisplayState.FULL_SCREEN;
		}
		
		/**
		 * 退出全屏
		 */
		private function normalHandler(eve:MouseEvent):void
		{
			stage.displayState = StageDisplayState.NORMAL;
		}
		
		/**
		 * 控制音量
		 */
		private function volumeHandler(eve:MouseEvent):void
		{
			if(eve.target == volume1 && volumeNumber.volume < 3)
			{
				volumeNumber.volume = int((volumeNumber.volume + 0.1) * 10) / 10;
				ns.soundTransform = volumeNumber;
				trace(volumeNumber.volume);
			}else if(eve.target == volume0 && volumeNumber.volume > 0)
			{
				volumeNumber.volume = int((volumeNumber.volume - 0.1) * 10) / 10;
				ns.soundTransform = volumeNumber;
				trace(volumeNumber.volume);
			}
		}
		
	}
}