﻿package com {


	import flash.display.MovieClip;
	import flash.display.StageDisplayState;
	import flash.events.Event;
	import flash.events.KeyboardEvent;
	import flash.events.MouseEvent;
	import flash.geom.Rectangle;
	import flash.media.SoundTransform;
	import flash.media.Video;
	import flash.net.NetConnection;
	import flash.net.NetStream;
	import flash.system.Capabilities;
	import flash.system.fscommand;

	/**
	 * 加载类
	 * @author  John
	 */

	public class VideoPlayer extends MovieClip {
		private var _main: Main;

		private var _video: Video;
		private var _videoPlayerMC: MovieClip;
		private var _volumn: Number = 0.5; //初始音量
		private var _netCon: NetConnection; //在客户端和服务器之间创建双向连接
		private var _netStream: NetStream; //通过 NetConnection 打开了一个单向流通道
		private var _soundTransform: SoundTransform;
		private var _clientObj: Object;
		private var _duration: Number;
		private var _playPlanNum: Number; //播放进度
		private var _recordVolume: Number;
		private var _nowCache: Number; //现在缓存到哪了
		private var _isMovePPBtn: Boolean = false; //是否拖动播放进度按钮
		private var _isMoveVPBtn: Boolean = false; //是否拖动音量按钮
		private var _isVideoEnd: Boolean = false;
		private var _isStartPlay: Boolean = false; //是否开始播放

		private var tempWidth: Number;
		private var pWidth: Number;

		public function VideoPlayer(p_main: Main): void {
			_main = p_main;

			addVideoPlayerMC()

			createVideo();

			changeVolumeBarBtnSite();

			initEvent();
		}

		private function addVideoPlayerMC(): void {
			_videoPlayerMC = new VideoPlayerMC();
			this.addChild(_videoPlayerMC);
		}


		/**
		 *创建播放器
		 *
		 */
		private function createVideo(): void {

			_video = new Video();
			_video.width = _videoPlayerMC.videoMC.width;
			_video.height = _videoPlayerMC.videoMC.height;
			_video.smoothing = true;
			_videoPlayerMC.videoMC.addChild(_video);

		}

		private function initEvent(): void {
			_videoPlayerMC.volumeBtn.buttonMode = true;
			_videoPlayerMC.volumeBtn.addEventListener(MouseEvent.CLICK, doVolume);

			_videoPlayerMC.volumeBar.volumeBarBtn.buttonMode = true;
			_videoPlayerMC.volumeBar.volumeBarBtn.addEventListener(MouseEvent.MOUSE_DOWN, downVolumeBar);

			_videoPlayerMC.screenBtn.buttonMode = true;
			_videoPlayerMC.screenBtn.addEventListener(MouseEvent.CLICK, doScreen);

			this.addEventListener(MouseEvent.MOUSE_UP, upMouse);
			this.addEventListener(MouseEvent.MOUSE_MOVE, doMove);
		}

		private function addEvent(): void {
			_videoPlayerMC.playBtn.buttonMode = true;
			_videoPlayerMC.playBtn.addEventListener(MouseEvent.CLICK, doPlay);


			_videoPlayerMC.speedBtn.buttonMode = true;
			_videoPlayerMC.speedBtn.addEventListener(MouseEvent.CLICK, doSpeed);
			_videoPlayerMC.recedeBtn.buttonMode = true;
			_videoPlayerMC.recedeBtn.addEventListener(MouseEvent.CLICK, doRecede);
			_videoPlayerMC.stopBtn.buttonMode = true;
			_videoPlayerMC.stopBtn.addEventListener(MouseEvent.CLICK, doStop);

			_videoPlayerMC.playBar.buttonMode = true;
			_videoPlayerMC.playBar.addEventListener(MouseEvent.CLICK, doPlayBar);

			_videoPlayerMC.playBar.playBarBtn.buttonMode = true;
			_videoPlayerMC.playBar.playBarBtn.addEventListener(MouseEvent.MOUSE_DOWN, downPlayBar);
		}

		private function delEvent(): void {
			this.removeEventListener(Event.ENTER_FRAME, enterFrame);

			_videoPlayerMC.playBtn.buttonMode = false;
			_videoPlayerMC.playBtn.removeEventListener(MouseEvent.CLICK, doPlay);


			_videoPlayerMC.speedBtn.buttonMode = false;
			_videoPlayerMC.speedBtn.removeEventListener(MouseEvent.CLICK, doSpeed);
			_videoPlayerMC.recedeBtn.buttonMode = false;
			_videoPlayerMC.recedeBtn.removeEventListener(MouseEvent.CLICK, doRecede);
			_videoPlayerMC.stopBtn.buttonMode = false;
			_videoPlayerMC.stopBtn.removeEventListener(MouseEvent.CLICK, doStop);

			_videoPlayerMC.playBar.buttonMode = false;
			_videoPlayerMC.playBar.removeEventListener(MouseEvent.CLICK, doPlayBar);

			_videoPlayerMC.playBar.playBarBtn.buttonMode = false;
			_videoPlayerMC.playBar.playBarBtn.removeEventListener(MouseEvent.MOUSE_DOWN, downPlayBar);
		}

		/**
		 *全局时时监听
		 *
		 */
		private function enterFrame(e: Event): void {
			if (this.mouseX > this.width || this.mouseX < 0 || this.mouseY > this.height || this.mouseY < 0) {
				upMouse(null);
			}

			if (_duration > 0) { //监听时间	

				_videoPlayerMC.timeView.text = TimeConvert.convert(_netStream.time) + "/" + TimeConvert.convert(_duration);

				_playPlanNum = _netStream.time / _duration;
				_videoPlayerMC.playBar.playBarBtn.x = _videoPlayerMC.playBar.width * _playPlanNum; //播放进度

				//播放结束
				if (TimeConvert.convert(_netStream.time) == TimeConvert.convert(_duration) && _isVideoEnd == false) {
					_isVideoEnd = true;
				}
			}


			if (_netStream) {

				if (_netStream.bytesLoaded > 0) {

					if (_isStartPlay == false) { //判断视频是否开始
						addEvent();
						_isStartPlay = true;
					}

					_nowCache = _netStream.bytesLoaded / _netStream.bytesTotal;
					var tempCache: int = Math.round(_nowCache * 100);
					_videoPlayerMC.playBar.gotoAndStop(tempCache); //缓冲进度
				}
			}



			//检测是不是在缓冲中
			if (_playPlanNum >= _nowCache) {
				_videoPlayerMC.loopMC.rotation += 10;
				_videoPlayerMC.playBar.playBarBtn.x = _nowCache * _videoPlayerMC.playBar.width;
			}

		}


		/**
		 *播放视频
		 *
		 */
		public function playVideo(p_site: String): void {
			removeVideo();

			_soundTransform = new SoundTransform();
			_netCon = new NetConnection();
			_netCon.connect(null);
			_netStream = new NetStream(_netCon);
			_clientObj = new Object();

			_clientObj.onMetaData = MetaDataHandler;
			_netStream.client = _clientObj;
			_video.attachNetStream(_netStream);
			_netStream.play(p_site);
			_videoPlayerMC.playBtn.gotoAndStop(2);
			_netStream.inBufferSeek = true;
			changeVolume();

			_isVideoEnd = false;
			_isStartPlay = false;

			this.addEventListener(Event.ENTER_FRAME, enterFrame);
		}

		/**
		 *移除视频
		 *
		 */
		public function removeVideo(): void {

			if (_netStream) {
				_netStream.close();
			}
			_soundTransform = null;
			_netCon = null;
			_netStream = null;
			_clientObj = null;
			delEvent();
		}


		private function MetaDataHandler(infoObject: Object): void {
			_duration = infoObject.duration; //获取视频总时间
		}

		/**
		 *改变音量调节按钮位置
		 *
		 */
		private function changeVolumeBarBtnSite(): void {
			_videoPlayerMC.volumeBar.volumeBarBtn.x = _videoPlayerMC.volumeBar.volumeBg.width * _volumn;
		}

		/**
		 *改变声音
		 *
		 */
		private function changeVolume(): void {
			if (_netStream != null) {
				_soundTransform.volume = _volumn;
				_netStream.soundTransform = _soundTransform;
				_videoPlayerMC.volumeBar.gotoAndStop(Math.round(_volumn * 10));
			}

		}

		/**
		 *播放
		 * @param e
		 *
		 */
		private function doPlay(e: MouseEvent): void {
			if (_videoPlayerMC.playBtn.currentFrame == 2) { //暂停
				_videoPlayerMC.playBtn.gotoAndStop(1);
				_netStream.pause();
			} else { //继续播
				_videoPlayerMC.playBtn.gotoAndStop(2);
				_netStream.resume();
			}
		}

		/**
		 *拖动进度按钮
		 *
		 */
		private function downPlayBar(e: MouseEvent): void {
			_isMovePPBtn = true;
			_videoPlayerMC.playBar.playBarBtn.startDrag(true, new Rectangle(0, 3, _videoPlayerMC.playBar.playBarBg.width, 0));
		}

		/**
		 * 拖动音量按钮
		 * @param e
		 *
		 */
		private function downVolumeBar(e: MouseEvent): void {
			_isMoveVPBtn = true;
			_videoPlayerMC.volumeBar.volumeBarBtn.startDrag(true, new Rectangle(0, 6, _videoPlayerMC.volumeBar.volumeBg.width, 0));
		}

		/**
		 *鼠标放开
		 * @param e
		 *
		 */
		private function upMouse(e: MouseEvent): void {
			if (_isMovePPBtn) {
				_isMovePPBtn = false;
				_videoPlayerMC.playBar.playBarBtn.stopDrag();
			}

			if (_isMoveVPBtn) {
				_isMoveVPBtn = false;
				_videoPlayerMC.volumeBar.volumeBarBtn.stopDrag();
			}

		}

		/**
		 *改变播放位置
		 *
		 */
		private function changePlayPlace(): void {
			var tempPercent: Number = _videoPlayerMC.playBar.playBarBtn.x / _videoPlayerMC.playBar.width;


			if (_videoPlayerMC.playBar.playBarBtn.x < (_nowCache * _videoPlayerMC.playBar.width)) {
				_netStream.seek(_duration * tempPercent);
			}
		}

		/**
		 *鼠标点击移动
		 * @param e
		 *
		 */
		private function doMove(e: MouseEvent): void {
			if (e.buttonDown) {
				if (_isMovePPBtn) {
					changePlayPlace();
				}

				if (_isMoveVPBtn) {
					_volumn = _videoPlayerMC.volumeBar.volumeBarBtn.x / _videoPlayerMC.volumeBar.volumeBg.width;
					if (_volumn > 1) {
						_volumn = 1;
					}
					_recordVolume = _volumn;
					changeVolume();
				}
			}
		}

		/**
		 *开关音乐
		 * @param e
		 *
		 */
		private function doVolume(e: MouseEvent): void {

			if (_videoPlayerMC.volumeBtn.currentFrame == 1) {
				_recordVolume = _volumn;
				_volumn = 0;
				_videoPlayerMC.volumeBtn.gotoAndStop(2);
			} else {
				_volumn = _recordVolume;
				_videoPlayerMC.volumeBtn.gotoAndStop(1);
			}
			changeVolume();
			changeVolumeBarBtnSite();
		}

		/**
		 *开关全屏
		 *
		 */
		private function doScreen(e: MouseEvent): void {

			if (_videoPlayerMC.screenBtn.currentFrame == 2) {

				_videoPlayerMC.screenBtn.gotoAndStop(1);
				
				stage.displayState=StageDisplayState.NORMAL; 

				stage.removeEventListener(KeyboardEvent.KEY_DOWN, endScreen);
				_videoPlayerMC.removeEventListener(MouseEvent.ROLL_OVER, overFun);
				_videoPlayerMC.removeEventListener(MouseEvent.ROLL_OUT, outFun);

				//_videoPlayerMC.alpha = 1;


			} else {

				_videoPlayerMC.screenBtn.gotoAndStop(2);
				stage.displayState=StageDisplayState.FULL_SCREEN_INTERACTIVE;

				//				stage.addEventListener(KeyboardEvent.KEY_DOWN,endScreen);
				//				_videoPlayerMC.addEventListener(MouseEvent.ROLL_OVER,overFun);
				//				_videoPlayerMC.addEventListener(MouseEvent.ROLL_OUT,outFun);	
				//				_videoPlayerMC.alpha = 0;         
			}
		}

		/**
		 *按了ESC键退出全屏
		 * @param e
		 *
		 */
		private function endScreen(e: KeyboardEvent): void {
			if (e.keyCode == 27) {
				doScreen(null);
				trace("按了ESC");
			}
		}
		/**
		 *出现控制栏
		 * @param e
		 *
		 */
		private function overFun(e: MouseEvent): void {

			trace("出现");
		}

		/**
		 *隐藏控制栏
		 * @param e
		 *
		 */
		private function outFun(e: MouseEvent): void {
			trace("隐藏");
		}

		/**
		 *下一视频
		 *
		 */
		private function doSpeed(e: MouseEvent): void {

			_main.changePlayer(true);
		}

		/**
		 *上一视频
		 *
		 */
		private function doRecede(e: MouseEvent): void {

			_main.changePlayer(false);
		}

		/**
		 *停止
		 * @param e
		 *
		 */
		private function doStop(e: MouseEvent): void {
			_videoPlayerMC.playBtn.gotoAndStop(1);
			_netStream.pause();
			_netStream.seek(0);
		}

		/**
		 *按播放进度栏
		 * @param e
		 *
		 */
		private function doPlayBar(e: MouseEvent): void {
			_videoPlayerMC.playBar.playBarBtn.x = _videoPlayerMC.playBar.mouseX;
			changePlayPlace();
		}
	}
}