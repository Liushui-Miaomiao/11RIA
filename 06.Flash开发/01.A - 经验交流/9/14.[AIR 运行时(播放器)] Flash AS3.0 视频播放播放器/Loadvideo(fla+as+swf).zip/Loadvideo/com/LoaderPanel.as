﻿package com {
	import flash.utils.Dictionary;
	/**
	 * 加载管理类,一个一个加载
	 * @author   John
	 */
	public class LoaderPanel {
		private static var _loaderPanel: LoaderPanel;
		private var _allUrlArr: Array = []; //全部加载地址
		private var _allBackNameArr: Array = []; //全部回调名字
		private var _completeBackFunDic: Dictionary = new Dictionary; //完成后回调函数
		private var _progressBackFunDic: Dictionary = new Dictionary; //进度回调函数
		private var _errorBackFunDic: Dictionary = new Dictionary; //错误回调函数
		private var _isLoader: Boolean = false; //是否在加载

		public function LoaderPanel() {

		}

		public static function getInstance(): LoaderPanel {
			if (_loaderPanel == null) {
				_loaderPanel = new LoaderPanel();
			}
			return _loaderPanel;
		}


		/**
		 * 加载
		 */
		public function addLoader(p_url: String, p_backName: String, p_completeFun: Function, p_progressFun: Function = null, p_errorFun: Function = null): void {
			if (_allBackNameArr.indexOf(p_backName) == -1) {
				_allUrlArr.push(p_url);
				_allBackNameArr.push(p_backName);
				_completeBackFunDic[p_backName] = p_completeFun;
				_progressBackFunDic[p_backName] = p_progressFun;
				_errorBackFunDic[p_backName] = p_errorFun;
				if (_isLoader == false) { //如果没开始加载，开始加载
					startLoader();
				}
			} else {
				trace("该加载项已经在队列中！");
			}

		}

		private function startLoader(): void {
			_isLoader = true;
			LoaderCenter.getInstance().addLoadUrl(_allUrlArr[0], addComplete, addProgress, addError);
		}

		private function addComplete(p_obj: Object): void {
			_isLoader = false;
			var tempName: String = _allBackNameArr[0];
			//删除上一个加载，如果还有继续加载
			_allUrlArr.shift();
			_allBackNameArr.shift();
			if (_allUrlArr.length != 0) {
				startLoader();

			}

			if (_completeBackFunDic[tempName] != null) {
				_completeBackFunDic[tempName](p_obj, tempName);
			}
		}

		private function addProgress(p_obj: Object): void {
			if (_progressBackFunDic[_allBackNameArr[0]] != null) {
				_progressBackFunDic[_allBackNameArr[0]](p_obj);
			}
		}

		private function addError(): void {
			if (_errorBackFunDic[_allBackNameArr[0]] != null) {
				_errorBackFunDic[_allBackNameArr[0]]();
			}
			trace("加载错误");
			//删除上一个加载，如果还有继续加载
			_allUrlArr.shift();
			_allBackNameArr.shift();
			if (_allUrlArr.length != 0) {
				startLoader();
			}
		}

	}

}