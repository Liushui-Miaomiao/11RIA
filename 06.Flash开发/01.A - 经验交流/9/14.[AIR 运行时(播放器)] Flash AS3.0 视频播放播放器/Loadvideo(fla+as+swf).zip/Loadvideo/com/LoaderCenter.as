﻿package com {
	import flash.display.Loader;
	import flash.display.MovieClip;
	import flash.events.Event;
	import flash.events.EventDispatcher;
	import flash.events.IOErrorEvent;
	import flash.events.ProgressEvent;
	import flash.net.URLLoader;
	import flash.net.URLRequest;
	import flash.system.ApplicationDomain;
	import flash.system.LoaderContext;
	import flash.utils.Dictionary;
	/**
	 * 加载类
	 * @author  John
	 */
	public class LoaderCenter {
		private static var loaderCenter: LoaderCenter;
		private var _loader: Loader;
		private var _urlLoader: URLLoader;
		private var _progressFun: Function;
		private var _completeFun: Function;
		private var _errorFun: Function;
		private var _allUrl: Dictionary;

		public static function getInstance(): LoaderCenter {
			if (loaderCenter == null) {
				loaderCenter = new LoaderCenter();
			}
			return loaderCenter;
		}


		/**
		 * 加载外部SWF 或 BitMap 或 XML
		 * @param p_url 加载地址
		 * @param p_progressFun 加载中进度  回调{Num:进度,Loaded:当前加载字节数,total:总字节数}，
		 * 						获取方式：var _data:Object;  进度：_data.Num;当前加载字节数;_data.Loaded;总字节数：_data.total
		 * @param p_completeFun 完成加载  回调加载到的SWF或BitMap
		 * 						获取方式：var _data:Object;  是SWF:_data.content as MovieClip; 是BitMap:_data.content as Bitmap;是XML:XML(_data.data)
		 * @param p_errorFun 加载错误
		 *
		 */
		public function addLoadUrl(p_url: String, p_completeFun: Function, p_progressFun: Function = null, p_errorFun: Function = null): void {
			_progressFun = p_progressFun;
			_completeFun = p_completeFun;
			_errorFun = p_errorFun;
			startAddLoader(p_url);
		}

		private function startAddLoader(p_url: String): void {
			var tempUrl: Array = p_url.split(".");
			var tempURLRequest: URLRequest = new URLRequest(p_url);
			if (tempUrl[1] == "xml") {
				_urlLoader = new URLLoader(tempURLRequest);
				_urlLoader.addEventListener(IOErrorEvent.IO_ERROR, goIOError);
				_urlLoader.addEventListener(ProgressEvent.PROGRESS, goProgress);
				_urlLoader.addEventListener(Event.COMPLETE, goComplete);
			} else {

				var context: LoaderContext = new LoaderContext();
				context.applicationDomain = ApplicationDomain.currentDomain;
				_loader = new Loader();
				_loader.load(tempURLRequest, context);
				_loader.contentLoaderInfo.addEventListener(ProgressEvent.PROGRESS, goProgress);
				_loader.contentLoaderInfo.addEventListener(Event.COMPLETE, goComplete);
				_loader.contentLoaderInfo.addEventListener(IOErrorEvent.IO_ERROR, goIOError);
			}

		}


		/**
		 *加载进度
		 * @param e
		 *
		 */
		private function goProgress(e: ProgressEvent): void {
			var tempNum: int = uint(e.bytesLoaded / e.bytesTotal * 100);
			if (_progressFun != null) {
				_progressFun({
					Num: tempNum,
					Loaded: e.bytesLoaded,
					total: e.bytesTotal
				});
			}

		}

		/**
		 *加载完成
		 * @param e
		 *
		 */
		private function goComplete(e: Event): void {
			if (_urlLoader != null) {
				_urlLoader.removeEventListener(IOErrorEvent.IO_ERROR, goIOError);
				_urlLoader.removeEventListener(ProgressEvent.PROGRESS, goProgress);
				_urlLoader.removeEventListener(Event.COMPLETE, goComplete);
				_urlLoader = null;
			}

			if (_loader != null) {
				_loader.contentLoaderInfo.removeEventListener(ProgressEvent.PROGRESS, goProgress);
				_loader.contentLoaderInfo.removeEventListener(Event.COMPLETE, goComplete);
				_loader.contentLoaderInfo.removeEventListener(IOErrorEvent.IO_ERROR, goIOError);
				_loader = null;
			}
			_completeFun(e.currentTarget);

		}

		/**
		 *加载出错
		 * @param e
		 *
		 */
		private function goIOError(e: IOErrorEvent): void {
			if (_errorFun != null) {
				_errorFun();
			}
		}


	}

}