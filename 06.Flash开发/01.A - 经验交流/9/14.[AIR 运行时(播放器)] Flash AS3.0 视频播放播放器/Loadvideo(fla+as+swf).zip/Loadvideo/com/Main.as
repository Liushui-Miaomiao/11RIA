﻿package com {
	import flash.display.MovieClip;
	import flash.display.StageScaleMode;
	import flash.events.Event;
	import flash.system.Security;


	/**
	 * 主类
	 * @author  John
	 */
	public class Main extends MovieClip {
		private var _videoPlayer: VideoPlayer;
		private var _videoXML: XML;

		private var _videoN: int = 0;

		public function Main(): void {

			//Security.allowDomain("*");
			//Security.allowInsecureDomain("*");

			if (stage) {
				initStage(null);
			} else {
				this.addEventListener(Event.ADDED_TO_STAGE, initStage);
			}
		}

		private function initStage(e: Event): void {
			this.removeEventListener(Event.ADDED_TO_STAGE, initStage);

			stage.scaleMode = StageScaleMode.EXACT_FIT;
			LoaderPanel.getInstance().addLoader("data/config.xml", "data", addCompleteFun);

		}

		private function addCompleteFun(p_obj: Object, p_name: String): void {
			_videoXML = XML(p_obj.data);

			addVideoPlayer();
		}

		private function addVideoPlayer(): void {
			_videoPlayer = new VideoPlayer(this);
			this.addChild(_videoPlayer);
			goPlayVideo();
		}

		/**
		 *去播放视频
		 *
		 */
		public function goPlayVideo(): void {
			if (_videoXML == null) {
				_videoPlayer.playVideo("ExperimentVideo.mp4");
				return;
			}

			if (_videoXML.AllVideoSite.OneVideoSite.length() == 0) {
				trace("没视频可以播！");
				return;
			}

			_videoPlayer.playVideo(_videoXML.AllVideoSite.OneVideoSite[_videoN].@site);
		}

		/**
		 *改变播放
		 *
		 */
		public function changePlayer(p_isNext: Boolean): void {
			if (_videoXML == null) {
				return;
			}

			if (p_isNext) {
				_videoN++;
				if (_videoN == _videoXML.AllVideoSite.OneVideoSite.length()) {
					_videoN = 0;
				}
			} else {
				_videoN--;

				if (_videoN == -1) {
					_videoN = _videoXML.AllVideoSite.OneVideoSite.length() - 1;
				}

			}
			goPlayVideo();
		}

	}


}