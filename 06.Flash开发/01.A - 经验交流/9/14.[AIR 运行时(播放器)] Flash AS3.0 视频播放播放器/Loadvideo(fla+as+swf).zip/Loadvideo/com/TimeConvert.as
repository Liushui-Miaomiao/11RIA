﻿package com
{
	/**
	 *时间转换 
	 * @author John
	 * 
	 */	
	public class TimeConvert
	{
		
		public static function convert(p_timeNum:int):String {
			var myHour:String=int(p_timeNum / 3600).toString();
			if(myHour.length<2)
			{
				myHour="0"+myHour;
			}
			
			var myMinute:String=int(p_timeNum % 3600 / 60).toString();
			if(myMinute.length<2)
			{
				myMinute="0"+myMinute;
			}
			
			var mySecond:String=int(p_timeNum % 3600 % 60).toString();
			if(mySecond.length<2)
			{
				mySecond="0"+mySecond;
			}
			
			return myHour+":"+myMinute+":"+mySecond;
		}
	}
}