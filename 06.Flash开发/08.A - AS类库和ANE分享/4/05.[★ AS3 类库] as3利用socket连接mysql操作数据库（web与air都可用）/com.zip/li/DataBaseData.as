﻿package com.li
{
    public class DataBaseData
    {
        public var host:String;
        public var port:int;
        public var username:String;
        public var password:String;
        public var database:String;
    }
}
