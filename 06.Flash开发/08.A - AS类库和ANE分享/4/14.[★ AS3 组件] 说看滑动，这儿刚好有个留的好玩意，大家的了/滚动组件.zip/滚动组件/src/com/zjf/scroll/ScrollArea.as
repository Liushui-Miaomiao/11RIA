/*
  仿苹果触摸滚动条 (横板+竖版+自动)
Copyright (c) 2009, www.zwwdm.com, 张建飞  ，  qq:380661512
All rights reserved.
*/
package com.zjf.scroll
{
	import flash.display.DisplayObject;
	import flash.display.DisplayObjectContainer;
	import flash.display.Shape;
	import flash.display.Sprite;
	import flash.events.Event;
	import flash.events.MouseEvent;
	import flash.geom.Point;
	import flash.geom.Rectangle;
	import flash.utils.getTimer;
	
	public class ScrollArea extends Sprite
	{
		public static const H:int = 1;                //滚动条的方向
		public static const V:int = 2;
		public static const AUTO:int = 3;
		private const BARSIZE:int = 7;           //滚动条的固定的高度或宽度
		
		private var _direction:int;
		private var _scrollRectPoint:Point;            //xy的滑动范围点
		private var isdragging:Boolean = false;
		private var _maskPoint:Point;
		private var mousePoint:Point;                //存放鼠标按下的点的坐标
		private var currPPoint:Point;				 //记录当前滚动内容的坐标
		private var prevPPoint:Point;                //记录上一个滚动内容的坐标
		private var scroll_interval:Boolean = false;
		private var scrolltrackingpoints:Array;      //记录滑动的点和时间
		private var speedPoint:Point;                //滑动速度
		private var _content:DisplayObjectContainer;
		private var _mask:DisplayObject;
		private var _hasBar:Boolean;
		private var _barColor:uint;
		private var _hBar:Shape;
		private var _vBar:Shape;
		private var barLimit:Point;
		private var barSize:Point;
		private var _isBarHDown:Boolean;
		private var _isBarVRight:Boolean;
		private var _barMargin:Number;
		/**
		 * 仿iphone触摸滚动条
		 * @param		content		      	  	DisplayObjectContainer		 * 被遮罩对象,滑动的内容
		 * @param		myMask		            DisplayObject     			 * 遮罩对象
		 * @param		direction		        int		     		         * 滑动的方向      取值为1,2,3
		 * @param		hasBar		            Boolean		      			 * 是否显示滚动条
		 * @param		barColor		        uint		         		 * 滚动条的颜色
		 * @param		barMargin		        Number		       			 * 控制滚动条的位置
		 * @param		isBarHDown		        Boolean		      	         * 横向的滚动条是否在下面
		 * @param		isBarVRight		   		Boolean		      	         * 纵向的滚动条是否在右面
		 */ 
		public function ScrollArea(content:DisplayObjectContainer,myMask:DisplayObject,direction:int=3,hasBar:Boolean=false,barColor:uint=0x000000,barMargin:Number=0,isBarHDown:Boolean = true,isBarVRight:Boolean=true)
		{
			scrolltrackingpoints = [];
			_scrollRectPoint = new Point();
			mousePoint = new Point();
			currPPoint = new Point();
			prevPPoint = new Point();
			speedPoint = new Point();
			barSize = new Point();
			barLimit = new Point();
			_mask = myMask;
			_content = content;
			_barColor = barColor;
			this.direction = direction;
			_barMargin = barMargin;
			_isBarHDown = isBarHDown;
			_isBarVRight = isBarVRight;
			setRectLimit();
			this.addChild(_content);
			this.addChild(_mask);
			_content.mask = _mask;
			this.hasBar = hasBar;
			drawBar();
			_content.addEventListener(MouseEvent.MOUSE_DOWN, mouseDownHandler, false,0,true);
			updatepos();
		}
		//鼠标按下
		private function mouseDownHandler(event:MouseEvent) : void
		{
			event.stopImmediatePropagation();
			scrolltrackingpoints = [];
			removeEventListener(Event.ENTER_FRAME, enterframehandler);
			stage.addEventListener(MouseEvent.MOUSE_UP, mouseUpHandler,false,0,true);
			stage.addEventListener(MouseEvent.MOUSE_MOVE, mouseMoveHandler,false,0,true);
			isdragging = false;
			mousePoint.x = this.mouseX;
			mousePoint.y = this.mouseY;
		}
		//鼠标移动
		private function mouseMoveHandler(event:MouseEvent) : void
		{
			event.stopImmediatePropagation();
			_content.mouseChildren = false;
			if(_hBar)_hBar.visible = true;
			if(_vBar)_vBar.visible = true;
			var mX:* = this.mouseX;
			var mY:* = this.mouseY;
			if (!isdragging)
			{
				if (_direction & 1 && Math.abs(mX - mousePoint.x) > 5 || _direction & 2 && Math.abs(mY - mousePoint.y) > 5)
				{
					if (scroll_interval)
					{
						removeEventListener(Event.ENTER_FRAME, enterframehandler);
						scroll_interval = false;
					}
					isdragging = true;
					mousePoint.x = mX;
					mousePoint.y = mY;
					prevPPoint.x = currPPoint.x = _content.x;
					prevPPoint.y = currPPoint.y = _content.y;
				}
			}
			if (isdragging)
			{
				addtrackingpoint(mX, mY, int(getTimer()));
				currPPoint.x = prevPPoint.x + (mX - mousePoint.x) ;      //注册点在左上角，如果相反，分别取负号
				currPPoint.y = prevPPoint.y + (mY - mousePoint.y) ;
				if (_scrollRectPoint.x > 0)
				{
					currPPoint.x /= 2;
				}
				else
				{
					currPPoint.x = currPPoint.x - (currPPoint.x > 0 ? (currPPoint.x) : (currPPoint.x < _scrollRectPoint.x ? (currPPoint.x - _scrollRectPoint.x) : (0))) / 2;
				}
				if (_scrollRectPoint.y > 0)
				{
					currPPoint.y /= 2;;
				}
				else
				{
					currPPoint.y = currPPoint.y - (currPPoint.y > 0 ? (currPPoint.y) : (currPPoint.y < _scrollRectPoint.y ? (currPPoint.y - _scrollRectPoint.y) : (0))) / 2;
				}
				updatepos();
			}
		}
		//鼠标抬起
		private function mouseUpHandler(event:MouseEvent) : void
		{
			event.stopImmediatePropagation();
			_content.mouseChildren = true;
			var startPoint:Object = null;
			var endPoint:Object = null;
			stage.removeEventListener(MouseEvent.MOUSE_UP, mouseUpHandler);
			stage.removeEventListener(MouseEvent.MOUSE_MOVE, mouseMoveHandler);
			if (isdragging)
			{
				removeoldtrackingpoints(int(getTimer()));
				if (scrolltrackingpoints.length > 1)
				{
					startPoint = scrolltrackingpoints[0];
					endPoint = scrolltrackingpoints[(scrolltrackingpoints.length - 1)];
					var absX:Number = endPoint.x - startPoint.x;
					var absY:Number = endPoint.y - startPoint.y;
					var totalTime:Number = (endPoint.time - startPoint.time) / 15;
					speedPoint.x = absX / totalTime ;          //注册点改变方向相反
					speedPoint.y = absY / totalTime ;
				}
				else
				{
					speedPoint.x = 0;
					speedPoint.y = 0;
				}
				scroll_interval = true;
				addEventListener(Event.ENTER_FRAME, enterframehandler,false,0,true);
			}
		}
		//实时刷新
		private function enterframehandler(event:Event = null) : void
		{
			currPPoint.x += speedPoint.x;
			currPPoint.y += speedPoint.y;
			speedPoint.x = speedPoint.x * 0.95;
			speedPoint.y = speedPoint.y * 0.95;
			var argX :Number = 0;
			var argY:Number = 0;
			if (_scrollRectPoint.x > 0)
			{
				argX = currPPoint.x;
			}
			else if (currPPoint.x < _scrollRectPoint.x)
			{
				argX = currPPoint.x - _scrollRectPoint.x;
			}
			else if (currPPoint.x > 0)
			{
				argX = currPPoint.x;
			}
			if (argX * argX < 0.1)
			{
				argX = 0;
			}
			if (_scrollRectPoint.y > 0)
			{
				argY = currPPoint.y;
			}
			else if (currPPoint.y < _scrollRectPoint.y)
			{
				argY = currPPoint.y - _scrollRectPoint.y;
			}
			else if (currPPoint.y >0)
			{
				argY = currPPoint.y;
			}
			if (argY * argY < 0.1)
			{
				argY = 0;
			}
			if ((_direction & 1) == 0)
			{
				argX = 0;
				speedPoint.x = 0;
			}
			if ((_direction & 2) == 0)
			{
				argY = 0;
				speedPoint.y = 0;
			}
			if (argX != 0)
			{
				argX = argX * -1;
				if (argX * speedPoint.x <= 0)
				{
					speedPoint.x += argX * 0.08;
				}
				else
				{
					speedPoint.x = argX * 0.15;
				}
			}
			if (argY != 0)
			{
				argY = argY * -1;
				if (argY * speedPoint.y <= 0)
				{
					speedPoint.y += argY * 0.08;
				}
				else
				{
					speedPoint.y = argY * 0.15;
				}
			}
			if (argX == 0 && argY == 0 && Math.sqrt(speedPoint.x * speedPoint.x + speedPoint.y * speedPoint.y) < 0.05)
			{
				speedPoint.x = 0;
				speedPoint.y = 0;
				removeEventListener(Event.ENTER_FRAME, enterframehandler);
				scroll_interval = false;
				if(_hBar)_hBar.visible = false;
				if(_vBar)_vBar.visible = false;
			}
			updatepos();
		}
		//更新位置
		private function updatepos() : void
		{
			if ((_direction & 1) == 1)
			{
				_content.x = currPPoint.x;
			}
			else
			{
				currPPoint.x = 0;
			}
			if ((_direction & 2) == 2)
			{
				_content.y = currPPoint.y;
			}
			else
			{
				currPPoint.y = 0;
			}
			drawBar();
		}
		//记录轨迹点
		private function addtrackingpoint(tkX:int, tkY:int, tkTime:int) : void
		{
			removeoldtrackingpoints(tkTime);
			var obj:Object = new Object();
			obj.time = tkTime;
			obj.x = tkX;
			obj.y = tkY;
			scrolltrackingpoints.push(obj);
		}   
		//删除时间相近的点（在100毫秒之内）
		private function removeoldtrackingpoints(tkTime:int) : void
		{
			while (scrolltrackingpoints.length > 0)
			{
				if (tkTime - scrolltrackingpoints[0].time <= 100)
				{
					break;
				}
				scrolltrackingpoints.shift();
			}
		}
		//绘制更新滚动条 
		private function drawBar():void{
			if(_hBar){
				_hBar.graphics.clear();
				_hBar.graphics.beginFill(_barColor, 0.7);
				_hBar.graphics.drawRoundRect(0, 0,barSize.x ,BARSIZE, BARSIZE, BARSIZE);
				_hBar.graphics.endFill();
				var hbX:Number = _content.x*(_mask.width-barSize.x)/_scrollRectPoint.x;
				if(hbX < 0){
					hbX = 0;
					_hBar.graphics.clear();
					_hBar.graphics.beginFill(_barColor, 0.7);
					var barW1:Number = (1-_content.x/_mask.width)*barSize.x;
					if(barW1<BARSIZE)barW1 = BARSIZE;
					_hBar.graphics.drawRoundRect(0, 0,barW1, BARSIZE, BARSIZE, BARSIZE);
					_hBar.graphics.endFill();
				}
				if(hbX>barLimit.x){
					hbX = barLimit.x;
					_hBar.graphics.clear();
					_hBar.graphics.beginFill(_barColor, 0.7);
					var barW2:Number = (1-(_scrollRectPoint.x-_content.x)/_mask.width)*barSize.x;
					if(barW2<BARSIZE)barW2 = BARSIZE;
					_hBar.graphics.drawRoundRect(0, 0,barW2, BARSIZE, BARSIZE, BARSIZE);
					_hBar.graphics.endFill();
					hbX = hbX+barSize.x-barW2;
				}
				_hBar.x = hbX;
			}
			if(_vBar){
				_vBar.graphics.clear();
				_vBar.graphics.beginFill(_barColor, 0.7);
				_vBar.graphics.drawRoundRect(0, 0,BARSIZE,barSize.y , BARSIZE, BARSIZE);
				_vBar.graphics.endFill();
				var vbY:Number = _content.y*(_mask.height-barSize.y)/_scrollRectPoint.y;
				if(vbY < 0){
					vbY = 0;
					_vBar.graphics.clear();
					_vBar.graphics.beginFill(_barColor, 0.7);
					var barH1:Number = (1-_content.y/_mask.height)*barSize.y;
					if(barH1<BARSIZE)barH1 = BARSIZE;
					_vBar.graphics.drawRoundRect(0, 0,BARSIZE, barH1, BARSIZE, BARSIZE);
					_vBar.graphics.endFill();
				}
				if(vbY>barLimit.y){
					vbY = barLimit.y;
					_vBar.graphics.clear();
					_vBar.graphics.beginFill(_barColor, 0.7);
					var barH2:Number = (1-(_scrollRectPoint.y-_content.y)/_mask.height)*barSize.y;
					if(barH2<BARSIZE)barH2 = BARSIZE;
					_vBar.graphics.drawRoundRect(0, 0,BARSIZE, barH2, BARSIZE, BARSIZE);
					_vBar.graphics.endFill();
					vbY = vbY+barSize.y-barH2;
				}
				_vBar.y = vbY;
			}
		}
		//初始化设置范围
		private function setRectLimit():void{
			_scrollRectPoint.x = _mask.width - _content.width;
			_scrollRectPoint.y = _mask.height - _content.height ;
			barSize.x = _mask.width*_mask.width/_content.width;
			barSize.y = _mask.height*_mask.height/_content.height;
			barLimit.x = _mask.width-barSize.x;
			barLimit.y = _mask.height-barSize.y;
		}
		//更新方法
		public function refresh():void{
			setRectLimit();
			hasBar = hasBar;
			updatepos();
		}
		public function set hasBar(bool:Boolean):void{
			if(bool){
				if(direction == 1){
					setHbar(true);
					setVbar(false);
				}else if(direction == 2){
					setHbar(false);
					setVbar(true);
				}else if(direction == 3){
					setHbar(true);
					setVbar(true);
				}
			}else{
				setHbar(false);
				setVbar(false);
			}
			_hasBar = bool;
		}
		private function setHbar(bool:Boolean):void{
			if(bool){
				if(_hBar == null){
					_hBar = new Shape();
					this.addChild(_hBar);
					_hBar.visible = false;
				}
				if(_isBarHDown){
					_hBar.y = _mask.height-BARSIZE+_barMargin;
				}else{
					_hBar.y = _barMargin;
				}
			}else{
				if(_hBar && this.contains(_hBar)){
					this.removeChild(_hBar);
					_hBar.graphics.clear();
					_hBar = null;
				}
			}
		}
		private function setVbar(bool:Boolean):void{
			if(bool){
				if(_vBar == null){
					_vBar = new Shape();
					this.addChild(_vBar);
					_vBar.visible = false;
				}
				if(_isBarVRight){
					_vBar.x = _mask.width-BARSIZE+_barMargin;
				}else{
					_vBar.x = _barMargin;
				}
			}else{
				if(_vBar && this.contains(_vBar)){
					this.removeChild(_vBar);
					_vBar.graphics.clear();
					_vBar = null;
				}
			}
		}
		//是否显示滚动条
		public function get hasBar():Boolean{
			return _hasBar;
		}
		public function set direction(value:int):void{
			_direction = value;
		}
		//滚动方向
		public function get direction():int{
			return _direction;
		}
	}
}