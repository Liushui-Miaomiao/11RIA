package
{
	import com.zjf.scroll.ScrollArea;
	
	import flash.display.Shape;
	import flash.display.SimpleButton;
	import flash.display.Sprite;
	import flash.display.StageAlign;
	import flash.display.StageScaleMode;
	import flash.events.MouseEvent;
	import flash.text.TextField;
	import flash.utils.setTimeout;
	
	public class TouchScroll extends Sprite
	{
		private var _content:Sprite;
		private var area:ScrollArea;
		private var sp:Shape;
		
		private var h:SimpleButton;
		private var v:SimpleButton;
		private var auto:SimpleButton;
		private var view:SimpleButton;
		private static var myLog:TextField;
		/**
		 * TouchArea is a class to create a touch scroll, that is a kind of scrollbar to scroll your contents by touching the screen and moving your mouse or finger, mostly used for touch screen devices
		 * 
		 * <b>Copyright 2012, zwwdm.com. All rights reserved.</b>
		 * For seeing the scroll preview and sample files visit <a href="http://zwwdm.com/?p=84/">http://zwwdm.com/?p=84/</a>
		 * 
		 * 
		 * @author 张建飞  zwwdm.com - 11/29/2012
		 * @version 1.0
		 */
		public function TouchScroll()
		{
			stage.align = StageAlign.TOP_LEFT;
			stage.scaleMode = StageScaleMode.NO_SCALE;
			
			//control buttons
			h = this["_hbtn"];
			v = this["_vbtn"];
			auto = this["_autobtn"];
			view = this["_viewbtn"];
			
			myLog = this["_mylog"];
			h.addEventListener(MouseEvent.CLICK,hClick,false,0,true);
			v.addEventListener(MouseEvent.CLICK,vClick,false,0,true);
			auto.addEventListener(MouseEvent.CLICK,autoClick,false,0,true);
			view.addEventListener(MouseEvent.CLICK,viewClick,false,0,true);
			
			
			//构建滚动内容
			_content = new Sprite();  
			for(var i:int = 0;i<30;i++){
				for(var j:int=0;j<30;j++){
					var cube:Cube = new Cube(i+" : "+j);
					_content.addChild(cube);
					cube.x = j*(cube.width+10);
					cube.y = i*(cube.height+10);
				}
			}
			sp = new Shape();
			sp.graphics.beginFill(0xff0000,0);
			sp.graphics.drawRect(0,0,480,340);
			sp.graphics.endFill();
			
			area = new ScrollArea(_content,sp, ScrollArea.V,true,0xff0000);
			area.x = 37;
			area.y = 125;
			this.addChild(area);
			
			
		}
		private function hClick(e:MouseEvent):void{
			e.stopImmediatePropagation();
			area.direction = ScrollArea.H;
			area.refresh();
		}
		private function vClick(e:MouseEvent):void{
			e.stopImmediatePropagation();
			area.direction = ScrollArea.V;
			area.refresh();
		}
		private function autoClick(e:MouseEvent):void{
			e.stopImmediatePropagation();
			area.direction = ScrollArea.AUTO;
			area.refresh();
		}
		private function viewClick(e:MouseEvent):void{
			e.stopImmediatePropagation();
			if(sp.width == 480){
				sp.width = 340;
				area.x = 97;
			}else{
				sp.width = 480;
				area.x = 37;
			}
			area.refresh();
		}
		public static function log(value:String):void{
			myLog.text = value;
			setTimeout(function (){myLog.text = ""},3000);
		}
	}
}