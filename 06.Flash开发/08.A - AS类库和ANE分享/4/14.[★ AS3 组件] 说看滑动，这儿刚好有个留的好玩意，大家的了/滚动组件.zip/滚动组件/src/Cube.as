package
{
	import flash.display.Sprite;
	import flash.events.Event;
	import flash.events.MouseEvent;
	import flash.text.TextField;
	import flash.text.TextFieldAutoSize;
	import flash.text.TextFormat;
	
	public class Cube extends Sprite
	{
		private var _id:String;
		private const SIZE:Number = 100;
		public function Cube(id:String)
		{
			_id = id;
			this.graphics.beginFill(Math.random()*0xffffff);
			this.graphics.drawRect(0,0,SIZE,SIZE);
			this.graphics.endFill();
			var tf:TextField = new TextField();
			tf.autoSize = TextFieldAutoSize.CENTER;
			this.addChild(tf);
			tf.x = (SIZE-tf.width)/2;
			tf.y = 30;
			tf.mouseEnabled = false;
			tf.selectable = false;
			var tfm:TextFormat = new TextFormat();
			tfm.size = 28;
			tfm.color = 0xff0000;
			tf.defaultTextFormat = tfm;
			tf.text = id;
			
			this.addEventListener(MouseEvent.CLICK,onClick);
		}
		private function onClick(e:Event):void{
			e.stopImmediatePropagation();
			TouchScroll.log(_id+" 被点击了！");
		}
	}
}