package
{
	import com.adobe.crypto.MD5;
	
	import flash.events.Event;
	import flash.events.IOErrorEvent;
	import flash.net.URLLoader;
	import flash.net.URLRequest;
	import flash.net.URLRequestMethod;
	import flash.text.TextField;
	
	import so.cuo.platform.wechat.WeChat;
	import so.cuo.platform.wechat.WeChatEvent;

	public class PayUtil
	{
		public const ORDER_URL:String="https://api.mch.weixin.qq.com/pay/unifiedorder";
		public  var APP_ID:String;//应用id    wx450d6531293d4afb
		public  var MCH_ID:String;//合作partner id  1290205602
		public  var API_KEY:String;//商户号，支付专用的key，用户后台自己设置1214tt66788iuy6y6tr5678ugww22bb2
		public  var NOTIFY_URL:String="http://open.weixin.qq.com/";//支付完成的服务器端通知地址，如果要进行服务器端验证，设置这个地址
//		public var textf:TextField;
		public function sign(xml:XML):String{
			var tempString:String="";
			for each(var c:XML in xml.children()){
				tempString+=c.name()+"="+c+"&";
			}
			tempString=tempString+"key="+API_KEY;
			return MD5.hash(tempString).toUpperCase();
		}
		public function createOrdor(goodInfo:String,fee:int,tradeNO:String=null,oncomplete:Function=null,onfail:Function=null):void{
			if(tradeNO==null){
				tradeNO=randString();
			}
			var nonce_str:String=this.randString();
			var xml:XML=<xml>
			<appid>{APP_ID}</appid>
			<body>{goodInfo}</body>
			<mch_id>{MCH_ID}</mch_id>
			<nonce_str>{nonce_str}</nonce_str>
			<notify_url>{NOTIFY_URL}</notify_url>
			<out_trade_no>{tradeNO}</out_trade_no>
			<total_fee>{fee}</total_fee>
			<trade_type>APP</trade_type>
			</xml>;
			
			var sign:String=sign(xml);
			xml.sign=sign;
			
//			textf.text+=xml;
			var request:URLRequest=new URLRequest(ORDER_URL);
			request.method=URLRequestMethod.POST;
			request.data=xml;
			var uloader:URLLoader=new URLLoader(request);
			uloader.addEventListener(Event.COMPLETE,oncomplete);
			uloader.addEventListener(IOErrorEvent.IO_ERROR,onfail);
		}
		public function startPay(goodInfo:String,fee:int,tradeNO:String=null):void{
			this.createOrdor(goodInfo,fee,tradeNO,onComplete,onFail);
		}
		protected function onComplete(e:Event):void{
			var uloader:URLLoader=URLLoader(e.target);
			var data:XML=new XML(uloader.data);
//			textf.text+=data;
			if(data.prepay_id){
				pay(data.prepay_id);
			}else{
				WeChat.getInstance().dispatchEvent(new WeChatEvent(WeChatEvent.onSendResult,data));
			}
		}
		protected function onFail(e:IOErrorEvent):void{
			WeChat.getInstance().dispatchEvent(new WeChatEvent(WeChatEvent.onSendResult,e.text));
		}
		protected function pay(prepayid:String):void
		{
			var ps:String="parepay_id="+prepayid;
			if(WeChat.getInstance().isIOS()){
				ps="Sign=WXPay";
			}
			var timestamp:String=int(new Date().time/1000)+"";
			var noncestr:String=randString();
			var pay:XML=<xml>
							<appid>{APP_ID}</appid>
							<noncestr>{noncestr}</noncestr>
							<package>{ps}</package>
							<partnerid>{MCH_ID}</partnerid>
							<prepayid>{prepayid}</prepayid>
							<timestamp>{timestamp}</timestamp>
						</xml>
			pay.sign=sign(pay);
//			textf.text+=pay;
			WeChat.getInstance().sendPayRequest(pay.appid,pay.partnerid,prepayid,noncestr,ps,pay.sign,timestamp);
		}
		protected function randString():String{
			return new Date().time+""+int(Math.random()*100);
		}
	}
}