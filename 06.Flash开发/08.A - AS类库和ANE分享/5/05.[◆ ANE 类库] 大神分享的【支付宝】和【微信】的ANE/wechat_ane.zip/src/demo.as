package
{
	
	import flash.display.BitmapData;
	import flash.display.PNGEncoderOptions;
	import flash.display.Sprite;
	import flash.display.StageAlign;
	import flash.display.StageScaleMode;
	import flash.filesystem.File;
	import flash.filesystem.FileMode;
	import flash.filesystem.FileStream;
	import flash.geom.Matrix;
	import flash.text.TextField;
	import flash.text.TextFormat;
	import flash.utils.ByteArray;
	
	import so.cuo.platform.wechat.WeChat;
	import so.cuo.platform.wechat.WeChatEvent;
	import so.cuo.platform.wechat.WechatError;
	import so.cuo.platform.wechat.WechatScene;
	
	public class demo extends Sprite
	{
		private var wx:WeChat=WeChat.getInstance();
		private var out:TextField;
		var payutil:PayUtil=new PayUtil();
		public function demo()
		{
			super();
			stage.align = StageAlign.TOP_LEFT;
			stage.scaleMode = StageScaleMode.NO_SCALE;
			var ui:UISprite=new UISprite(clickHandler);
			this.addChild(ui);
			ui.addButton("check",0,0);
			ui.addButton("open",200,0);
			ui.addButton("auth",80,100);
			ui.addButton("text",0,160);
			ui.addButton("image",280,180);
			ui.addButton("link",280,280);
			ui.addButton("webimage",280,380);
			ui.addButton("clean",0,380);
			ui.addButton("pay",300,80);
			
			out=ui.addButton("out",0,440);
			out.width=460;
			out.height=600;
			out.multiline=true;
			
//			payutil.APP_ID="wxad9982d02417a613";
			payutil.APP_ID="wxc13e52b4b39fe8b4";
			payutil.MCH_ID="1290205601";
			payutil.API_KEY="1214tt66788iuy6y6tr5678ugww22bb9";
//			payutil.textf=out;
			if(!wx.supportDevice){
				trace2("not support device");
				return;
			}else{
				wx.registerApp(payutil.APP_ID);//flash 善
//				wx.registerApp("wx21fb4d35f5eba36b");//my 
//				wx.registerApp("wx36df57f2890e8314");
				wx.addEventListener(WeChatEvent.onSendResult,onSendResult);
			}
			
		}
		
		protected function onSendResult(event:WeChatEvent):void
		{
			
			if(event.data==WechatError.WXErrCodeUserCancel){
				trace2("用户取消了发送");
			}
			trace2(event.type+"  "+event.data);
		}
	
		private function clickHandler(label:String):void{
			if(label!="clean"&&label!="")
			trace2("click "+label);
			if(!wx.supportDevice){
				trace2("not  support device");
				return;
			}
			else if(label=="check"){
				trace2(wx.getApiVersion()+"  url:"+wx.getWXAppInstallUrl()+" isInstalled:"+wx.isWXAppInstalled()+"  "+wx.isWXAppSupportApi());
			}
			else if(label=="pay"){
				payutil.startPay("test good",1);
			}
			else if(label=="auth"){
				trace2(""+wx.sendAuthRequest(int(Math.random()*10000)+""));
			}
			else if(label=="text"){
				trace2(""+wx.sendTextMessage(new Date().toString(),WechatScene.WXSceneTimeline));
			}
			else if(label=="link"){
//				var url:String=this.saveInfoToCameraRoll(333,"3355");
//				trace2(""+wx.sendLinkMessage(url,"http://www.cuo.so/","m game","zui h",WechatScene.WXSceneTimeline));
				trace2(""+wx.sendLinkMessage("http://www.ptbus.com/uploads/allimg/1312/25/1456_1046577301.jpg","http://www.cuo.so/","m game","zui h",WechatScene.WXSceneTimeline));
			}
			else if(label=="image"){
				var url:String="http://www.ptbus.com/uploads/allimg/1312/25/1456_1046577301.jpg";
//				url=this.saveInfoToCameraRoll(333,"3355");
//				trace2("file",url);
				trace2(""+wx.sendImageMessage(url,new Date().toString(),WechatScene.WXSceneTimeline));
			}
			else if(label=="webimage"){
				wx.sendWebImageMessage("http://s0.hao123img.com/res/r/image/2014-05-07/bcb15a0409c0eb0a87cf0c2ac3e04c05.gif","title image test",WechatScene.WXSceneTimeline);
			}
			else if(label=="clean"){
				out.text="";
			}
		}
		
		
		private function saveInfoToCameraRoll(id:int,pass:String):String
		{
			//			if(CameraRoll.supportsAddBitmapData){
			var bitmap:BitmapData=new BitmapData(480,320);
			var format:TextFormat=new TextFormat();
			format.size=36;
			var title:TextField=new TextField();
			title.defaultTextFormat=format;
			title.width=480;
			title.text="hha";//L.forKey("gametitle");
			bitmap.draw(title);
			var nameLabel:TextField=new TextField();
			nameLabel.defaultTextFormat=format;
			nameLabel.text="ID:"+id;
			nameLabel.width=480;
			var matrix:Matrix=new Matrix();
			matrix.ty=60;
			bitmap.draw(nameLabel,matrix);
			var passLabel:TextField=new TextField();
			passLabel.defaultTextFormat=format;
			passLabel.text="pp";//L.forKey("passwordTag")+pass;
			passLabel.width=480;
			matrix.ty=120;
			bitmap.draw(passLabel,matrix);
			//				var encode:b
			var bytes:ByteArray=bitmap.encode(bitmap.rect,new  PNGEncoderOptions());
			trace2("start create image");
			var file:File=File.createTempFile();//File.applicationStorageDirectory.resolvePath("temp.png");
			trace2(file.exists+"   file info "+file.nativePath);
			var st:FileStream=new FileStream();
			st.open(file,FileMode.WRITE);
			st.writeBytes(bytes);
			st.close();
			trace2(file.exists+file.nativePath);
			return file.nativePath;
		}
		private function trace2(str:String):void{
			trace(str);
			out.text+=str+"\n";
		}
	}
}