package tg.draw
{
	import flash.display.Sprite;
	import flash.display.GraphicsPath;
	import flash.events.*;
	import flash.geom.*;
	import flash.display.Shape;
	import flash.utils.Timer;
	/**
	 * 蚂蚁线，流动的虚线
	 * @author jempty 2014-8-21
	 * @example antsline = new AntsLine(20, 30, 30);
			    antsline.thickness = 3;
				antsline.color1 = 0xcccc66;
				antsline.colorAlpha2 = 0;//单线模式
				addChild(antsline);
				antsline.startPoint = new Point(dx,dy); 
				//
				antsline.addPoint(dx, dy);
				antsline.addPoint(dx,dy);
				......
				antsline.startMotion();
	 */
	public class AntsLine extends Sprite
	{
		private var antsPath:GraphicsPath;
		private var antsLine:Shape=new Shape();
		private var _startPoint:Point; //开始点位置
		private var _endPoint:Point;
		private var timer:Timer;
		/**是否时时绘制*/
		public var oftenDraw:Boolean = false;
		/**颜色1*/
		public var color1:uint = 0x000000;
		/**颜色2*/
		public var color2:uint = 0xffffff;
		/**颜色1的透明度,如果只希望一种颜色,就把其中一种颜色的透明度设为0*/
		public var colorAlpha1:Number = 1;
		/**颜色2的透明度,如果只希望一种颜色,就把其中一种颜色的透明度设为0*/
		public var colorAlpha2:Number = 1;
		/**流动速度*/
		public var speed:Number = 1.2;
		/**线条厚度,影响整体的大小*/
		public var thickness:Number = 5;
		//
		private var pathList:Vector.<GraphicsPath> = new Vector.<GraphicsPath>();
		private var matrixList:Vector.<Matrix> = new Vector.<Matrix>();
		private var speedList:Vector.<Array> = new Vector.<Array>();
		private var index:int;
		private var _iw:Number;
		private var _ih:Number;
		private var prevPt:Point;
		private var fristPt:Boolean = true;
		/**
		 * 
		 * @param	delayTime
		 * @param	iw 影响蚂蚁线的宽度
		 * @param	ih 影响蚂蚁线的高度
		 */
		public function AntsLine(delayTime:uint=50,iw:Number=30,ih:Number=30)
		{
			_iw = iw;
			_ih = ih;
			addChild(antsLine);
			addPath();
			timer = new Timer(delayTime);
            timer.addEventListener(TimerEvent.TIMER,onTimerHandler,false,0,true);
		}
		/**创建路径*/
		private function addPath():void
		{
			antsPath = new GraphicsPath();
			pathList.push(antsPath); 
			index++;
		}
		/**设置开始点*/
		public function set startPoint(value:Point):void
		{
			this._startPoint = value;
			antsPath.moveTo(value.x, value.y);
		}
		//
		private function get pervEndPoint():Point {
			var path:GraphicsPath = pathList[pathList.length - 2];
			var len:int = path.data.length;
			return new Point(path.data[len - 2], path.data[len - 1]);
		}
		/**
		 * 添加直线连接点
		 * @param	px 过点x
		 * @param	py 过点y
		 */
		public function addPoint(px:Number,py:Number):void
		{
			setParams(px, py);
		}
		/**
		 * 添加曲线连接点,如果控制点弧度过大会导致蚂蚁线扭曲变形
		 * 一般情况建议使用addPoint方法
		 * @param	controlX 控制点x
		 * @param	controlY 控制点y
		 * @param	px 过点x
		 * @param	py 过点y
		 */
		public function addCurvePoint(controlX:Number,controlY:Number,px:Number,py:Number):void {
			setParams(px, py, controlX, controlY, true);
		}
		private function setParams(px:Number,py:Number,controlX:Number=0,controlY:Number=0,isCurve:Boolean=false):void {
			if (prevPt == null) prevPt = _startPoint;
			var dx:Number = px - prevPt.x;
			var dy:Number = py - prevPt.y;
			var angle:Number = Math.atan2(dy, dx);
			//angle *= 180 / Math.PI;
			var matix:Matrix = new Matrix(); 
			matix.createGradientBox(_iw, _ih, angle, 0, 0);
			//方向判断
			var tx:Number, ty:Number; 
			if (dx == 0) {
				tx = 0;
			}else {
				tx = dx / Math.abs(dx) * speed;
			}
			if (dy == 0) {
				ty = 0;
			}else {
				ty = dy / Math.abs(dy) * speed;
			}
			if (fristPt) {
				fristPt = false;
			}else {
				addPath();
				startPoint = pervEndPoint;
			}
			if (isCurve) antsPath.curveTo(controlX, controlY, px, py);
			else antsPath.lineTo(px, py);
			matrixList.push(matix);
			speedList.push([tx, ty]);
			
			prevPt.x = px;
			prevPt.y = py;
		}
		/**开始动画*/
		public function startMotion():void
		{
			if (!isRuning) {
				timer.start();
			}
		}
		/**停止动画*/
		public function stopMotion():void
		{
			timer.stop();
		}
        /**是否在运动*/
		public function get isRuning():Boolean
		{
			return timer.running;
		}
		private function onTimerHandler(event:TimerEvent):void
		{
			draw();
		}
		private function draw():void
		{
			antsLine.graphics.clear();
			antsLine.graphics.lineStyle(thickness);//
			var i:int;
			var len:int = pathList.length; 
			var tx:Number;
			var ty:Number;
			for (i = 0; i < len; i++) {
				antsLine.graphics.lineGradientStyle("linear", [color1, color2], [colorAlpha1, colorAlpha2], [0xFF/2, 0xFF/2], matrixList[i], "repeat");
				antsLine.graphics.drawPath(pathList[i].commands, pathList[i].data);
				matrixList[i].tx +=  speedList[i][0];
				matrixList[i].ty +=  speedList[i][1]; 
				tx = matrixList[i].tx;
				ty = matrixList[i].ty;
				if (Math.abs(tx) > 5000) {
					matrixList[i].tx = 0;
				}
				if (Math.abs(ty) > 5000) {
					matrixList[i].ty = 0;
				}
			}
		}
		//清理填充，线条 ，和数据
		public function clear():void
		{
			this.graphics.clear();
			antsLine.graphics.clear();
			stopMotion();
			pathList.length = 0;
			matrixList.length = 0;
			speedList.length = 0;
		}
		public function kill():void {
			clear();
			timer.removeEventListener(TimerEvent.TIMER,onTimerHandler);
			removeChild(antsLine);
			pathList = null;
			matrixList = null;
			speedList = null;
		}
	}

}