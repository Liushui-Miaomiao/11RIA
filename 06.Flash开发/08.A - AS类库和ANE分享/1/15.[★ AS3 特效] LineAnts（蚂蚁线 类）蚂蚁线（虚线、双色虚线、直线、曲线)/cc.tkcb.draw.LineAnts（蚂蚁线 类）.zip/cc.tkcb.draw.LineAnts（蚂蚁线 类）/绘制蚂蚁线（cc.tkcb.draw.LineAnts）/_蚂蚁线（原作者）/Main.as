﻿package 
{
	import flash.display.Sprite;
	import flash.events.*;
	import flash.geom.Point;
	import tg.draw.AntsLine;

	public class Main extends Sprite
	{
		private var antsline:AntsLine;
		private var end:Boolean;
		private var antList:Array = [];
		private var index:int = 0;
		private var frist:Boolean = true;
		private var dex:int = 0;
		
		public function Main()
		{
			antsline = new AntsLine(20, 30, 30);
			antsline.thickness = 3;
			antsline.color1 = 0xcccc66;
			antsline.colorAlpha2 = 0;
			addChild(antsline);
			stage.addEventListener(MouseEvent.CLICK, onMouseHandler);
		}
		private function onMouseHandler(event:MouseEvent):void
		{
			if (frist) {
				frist = false;
				antsline.startPoint = new Point(event.stageX, event.stageY); 
			}else {
				
				//antsline.addCurvePoint(Math.random()*800,Math.random()*600,event.stageX, event.stageY);
				antsline.addPoint(event.stageX, event.stageY);
				if(!antsline.isRuning)antsline.startMotion();
			}
		}

	}

}
