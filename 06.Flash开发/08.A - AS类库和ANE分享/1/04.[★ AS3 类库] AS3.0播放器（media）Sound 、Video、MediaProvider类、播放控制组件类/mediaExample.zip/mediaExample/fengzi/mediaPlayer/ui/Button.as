﻿ package fengzi.mediaPlayer.ui
{
    import flash.events.MouseEvent;
	public class Button extends Label
	{
		var color:uint
		 public function Button (_color:uint):void
		{
			color=_color
			this.setColor(color);
			this.addEventListener(MouseEvent.MOUSE_OVER, overHandler);
			this.addEventListener(MouseEvent.MOUSE_OUT, outHandler);
		}
		private function overHandler(event:MouseEvent):void
		{
			this.setColor(0xff0000);

		}

		private function outHandler(event:MouseEvent):void
		{

			this.setColor(color);


		}

	}
}