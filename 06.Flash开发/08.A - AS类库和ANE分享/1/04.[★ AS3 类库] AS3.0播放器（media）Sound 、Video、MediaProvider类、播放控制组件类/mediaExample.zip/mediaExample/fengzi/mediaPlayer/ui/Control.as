﻿/**
* 播放（进度）控制类
* @author wu
* @date 2-18/2014
**/
package fengzi.mediaPlayer.ui
{
	import fengzi.mediaPlayer.events.MediaEvent;
	import caurina.transitions.Tweener;

	import flash.display.MovieClip;
	import flash.events.Event;
	import flash.events.MouseEvent;

	import flash.utils.setInterval;
	import flash.utils.clearInterval;
	import flash.geom.Rectangle;
	import flash.utils.Timer;
	import flash.events.TimerEvent;

	public class Control extends MovieClip
	{
		private var player:Object;
		private var scrubbInterval:Number;//播放进度计时器
		private var scrubbing:Boolean;//是否正在拖动状态的布尔值
		private var seekpoint:Number;//播放的位置

		private var _isPlay:Boolean;
		private var showInterval:Number;
		private var volInterval:Number;
		private var mute:Boolean;

		private var controrlTimer:Timer;



		public function Control(value:Object)
		{
			player = value;
			volControl.player = player;
			status = false;
			muteButton.gotoAndStop(1);
			fullButton.gotoAndStop(2);
			init();

		}

		function init():void
		{
			seekBar.buttonMode = true;//拖柄
			seekBar.visible = false;
			seekIcon.visible = false;
			seekIcon.gotoAndStop(1);
			muteButton.buttonMode = true;
			fullButton.buttonMode = true;
			loadBar.mouseEnabled = false;//下载进度条
			playheadBar.mouseEnabled = false;//播放进度条
			playheadBar.height = 2;
			loadBar.height = 2;
			seekControlBar.height = 2;

			player.addEventListener(MediaEvent.STATUS, playerStatusHandler);

			controrlTimer = new Timer(30);
			controrlTimer.addEventListener(TimerEvent.TIMER,timerHandler);
			controrlTimer.start();
			playButton.addEventListener(MouseEvent.CLICK,playButtonClickHandler);
			playIcon.addEventListener(MouseEvent.CLICK,playButtonClickHandler);
			pauseButton.addEventListener(MouseEvent.CLICK, pauseButtonClickHandler);
			nextButton.addEventListener(MouseEvent.CLICK,nextButtonClickHandler);
			fullButton.addEventListener(MouseEvent.CLICK,fullButtonClickHandler);
			seekBar.addEventListener(MouseEvent.MOUSE_DOWN,seekBarDownHandler);
			seekBar.addEventListener(MouseEvent.MOUSE_OVER,overHandler);
			seekBar.addEventListener(MouseEvent.MOUSE_OUT,outHandler);
			seekControlBar.addEventListener(MouseEvent.MOUSE_DOWN,seekBarDownHandler);
			seekControlBar.addEventListener(MouseEvent.MOUSE_OVER,overHandler);
			seekControlBar.addEventListener(MouseEvent.MOUSE_OUT,outHandler);
			muteButton.addEventListener(MouseEvent.MOUSE_DOWN,muteButtonDownHandler);

		}

		private function muteButtonDownHandler(event:MouseEvent):void
		{
			mute = ! mute;
			if (mute)
			{
				player.volume = 0;
			}
			else
			{
				player.volume = volControl.volume;
			}

		}

		public function moveHandler():void
		{
			if (showInterval)
			{
				clearInterval(showInterval);
			}
			showInterval = setInterval(showUpdate,2000);
			seekBar.visible = true;
			Tweener.addTween(seekControlBar,{height:7,time:0.3,transition:"linear"});
			Tweener.addTween(loadBar,{height:7,time:0.3,transition:"linear"});
			Tweener.addTween(playheadBar,{height:7,time:0.3,transition:"linear"});
			if (mouseX>80&&mouseX<120&&mouseY>2)
			{
				Tweener.addTween(volControl,{x:120,time:0.5,transition:"linear"});
			}
			if (volInterval)
			{
				clearInterval(volInterval);
			}
			volInterval = setInterval(volUpdate,1000);
		}
		function volUpdate():void
		{
			clearInterval(volInterval);
			if (mouseX<80||mouseX>185||mouseY<2||mouseY>26)
			{
				Tweener.addTween(volControl,{x:47,time:0.3,transition:"linear"});
			}
		}

		function showUpdate():void
		{
			clearInterval(showInterval);
			seekBar.visible = false;
			Tweener.addTween(seekControlBar,{height:2,time:0.3,transition:"linear"});
			Tweener.addTween(loadBar,{height:2,time:0.3,transition:"linear"});
			Tweener.addTween(playheadBar,{height:2,time:0.3,transition:"linear"});

		}

		private function playerStatusHandler(event:MediaEvent):void
		{
			switch (event.data)
			{
				case "play" :
					status = false;
					break;
			}
		}
		//播放进度显示控制（有几种控制方法）
		private function timerHandler(event:TimerEvent):void
		{

			if (player.playheadTime > 0 && player.duration > 0)
			{
				seekBar.x = player.playheadTime / player.duration * seekControlBar.width;
			}
			else
			{
				seekBar.x = seekControlBar.x;
			}

			loadBar.width = player.percentLoaded * seekControlBar.width;
			playTime.txt.htmlText = "<font FACE=\"Verdana\" SIZE=\"11\">" + millToTime(player.playheadTime) + "|" + millToTime(player.duration) + "</font>";
			playheadBar.width = seekBar.x;
			if (player.volume > 0)
			{
				muteButton.gotoAndStop(1);

			}
			else
			{
				muteButton.gotoAndStop(2);

			}

		}

		private function seekBarDownHandler(event:MouseEvent=null):void
		{
			player.playing = false;
			var rectangle:Rectangle = new Rectangle(seekControlBar.x,seekBar.y,Math.round(loadBar.width - 0));
			seekBar.startDrag(false,rectangle);
			stage.addEventListener(MouseEvent.MOUSE_MOVE,seekMoveHandler);
			stage.addEventListener(MouseEvent.MOUSE_UP,seekBarUpHandler);
			controrlTimer.stop();
			seekBar.x = mouseX;

			if (mouseX >=loadBar.width)
			{
				seekBar.x = loadBar.width;
			}
			seekMoveHandler();
			dispatchEvent(new MediaEvent(MediaEvent.STATUS,"seekBar.Down"));


		}
		private function seekBarUpHandler(event:MouseEvent):void
		{
			stage.removeEventListener(MouseEvent.MOUSE_MOVE,seekMoveHandler);
			stage.removeEventListener(MouseEvent.MOUSE_UP,seekBarUpHandler);
			seekBar.stopDrag();
			player.playing = true;
			player.resume();
			player.seek(seekpoint);
			status = false;
			controrlTimer.start();
			dispatchEvent(new MediaEvent(MediaEvent.STATUS,"seekBar.Up"));
		}

		function seekMoveHandler(event:MouseEvent=null):void
		{

			seekpoint = seekBar.x / seekControlBar.width * player.duration;
			playTime.txt.htmlText = "<font FACE=\"Verdana\" SIZE=\"11\">" + millToTime(seekpoint) + "|" + millToTime(player.duration) + "</font>";
			playheadBar.width = seekBar.x;

			dispatchEvent(new MediaEvent(MediaEvent.STATUS,"seekBar.Drag"));

			scrubbUpdate();
		}

		private function overHandler(event:MouseEvent):void
		{
			var dur:Number;
			if (player.isFormats)
			{
				dur = player.duration;
			}
			else
			{
				dur = player.duration / 1000;
			}
			if (dur<3600)
			{
				seekIcon.gotoAndStop(1);
			}
			else
			{
				seekIcon.gotoAndStop(2);
			}
			seekIcon.visible = true;
			if (scrubbInterval)
			{
				clearInterval(scrubbInterval);
			}
			scrubbInterval = setInterval(scrubbUpdate,30);

		}

		private function outHandler(event:MouseEvent):void
		{

			clearInterval(showInterval);
			seekIcon.visible = false;
		}

		//鼠标移动控制时间
		function scrubbUpdate()
		{
			var dur:Number;
			if (player.isFormats)
			{
				dur = player.duration;
			}
			else
			{
				dur = player.duration / 1000;
			}

			seekIcon.x = mouseX;

			if (dur<3600)
			{
				if (mouseX<20)
				{
					seekIcon.x = 20;
				}
				if (mouseX>stage.stageWidth-20)
				{
					seekIcon.x = stage.stageWidth - 20;
				}
			}
			else
			{
				if (mouseX<30)
				{
					seekIcon.x = 30;
				}
				if (mouseX>stage.stageWidth-30)
				{
					seekIcon.x = stage.stageWidth - 30;
				}
			}

			seekIcon.txt.htmlText = "<font FACE=\"Verdana\" SIZE=\"11\">" + millToTime(mouseX / seekControlBar.width * player.duration) + "</font>";
		}












		private function fullButtonClickHandler(event:MouseEvent):void
		{
			switch (stage.displayState)
			{
				case "normal" :
					stage.displayState = "fullScreen";
					fullButton.gotoAndStop(1);
					break;

				case "fullScreen" :
					stage.displayState = "normal";
					fullButton.gotoAndStop(2);
					break;
			}
			player.stageResize();
		}




		public function playButtonClickHandler(event:MouseEvent=null):void
		{
			player.resume();
			status = false;
		}

		public function pauseButtonClickHandler(event:MouseEvent=null):void
		{
			player.pause();
			status = true;
		}


		private function nextButtonClickHandler(event:MouseEvent):void
		{
			player.next();

		}

		public function stageResize():void
		{
			controlBack.width = stage.stageWidth;
			seekControlBar.width = stage.stageWidth;
			fullButton.x = stage.stageWidth - 27;
			playTime.x = stage.stageWidth - 40;
			listButton.x = stage.stageWidth - 68;
			playIcon.x = int(stage.stageWidth * .5);
			playIcon.y = int(stage.stageHeight * -.5);
			switch (stage.displayState)
			{
				case "normal" :
					fullButton.gotoAndStop(2);
					break;

				case "fullScreen" :
					fullButton.gotoAndStop(1);
					break;
			}
		}

		private function set status(value:Boolean):void
		{
			if (value)
			{
				pauseButton.visible = false;
				playButton.visible = true;
				playIcon.visible = true;
				_isPlay = true;

			}
			else
			{
				pauseButton.visible = true;
				playButton.visible = false;
				playIcon.visible = false;
				_isPlay = false;
			}

		}

		//返回时间格式
		function millToTime(mill:Number):String
		{
			var dur:Number;
			if (player.isFormats)
			{
				mill = mill;
				dur = player.duration;
			}
			else
			{
				dur = player.duration / 1000;
				mill = mill / 1000;
			}
			var hours=int(mill/3600);
			var minutes = int((mill / 60)% 60);
			var seconds = int(mill % 60);
			hours < 10 ? hours = "0" + hours:null;
			minutes < 10 ? minutes = "0" + minutes:null;
			seconds < 10 ? seconds = "0" + seconds:null;
			if (dur< 3600)
			{
				return minutes+ ":" + seconds;
			}
			else
			{
				return hours+":"+minutes+ ":" + seconds;
			}

		}

		public function get isPlay():Boolean
		{
			return _isPlay;
		}







	}

}