﻿package fengzi.mediaPlayer
{
	import fengzi.mediaPlayer.media.MediaProvider;
	import fengzi.mediaPlayer.events.MetaDataEvent;
	import fengzi.mediaPlayer.events.MediaEvent;
	import fengzi.mediaPlayer.ui.Control;
	import fengzi.mediaPlayer.ui.Playlist;
	import fengzi.menu.Menu;
	import caurina.transitions.Tweener;


	import flash.display.Sprite;
	import flash.utils.Timer;
	import flash.events.TimerEvent;
	import flash.display.Stage;
	import flash.events.MouseEvent;
	import flash.utils.setInterval;
	import flash.utils.clearInterval;
	import flash.ui.Mouse;


	public class MediaPlayer extends Sprite
	{
		private var _stage:Stage;
		private var player:MediaProvider;
		private var playlist:Playlist;
		private var loading:Loading;
		private var control:Control;
		private var doubleButton:DoubleButton;

		private var url:*;
		private var title:*;
		private var timer:Timer;
		private var click:Boolean;
		private var showInterval:Number;

		private var menu:Menu;

		public function MediaPlayer()
		{
			init();
		}
		private function init():void
		{
			menu = new Menu(this);
			menu.buildLinkMenu("AS3.0   MediaExample",true);
			menu.buildLinkMenu("Author 疯子（wu） @ date 2-12/2019",true);
		}

		public function set mediaPath(_url:*):void
		{
			url = _url;
		}

		public function set list(_list:*):void
		{
			title = _list;
		}


		public function initPlay():void
		{
			player = new MediaProvider(url);
			player.addEventListener(MediaEvent.STATUS, playerStatusHandler);
			addChild(player);
			player.initPlay();

			playlist = new Playlist(title,url);
			playlist.player = player;
			addChild(playlist);
			playlist.visible = false;

			loading=new Loading();
			loading.stop();
			loading.visible = false;
			addChild(loading);

			doubleButton=new DoubleButton();
			addChild(doubleButton);

			control = new Control(player);
			addChild(control);
			control.y = _stage.stageHeight - 30;

			setChildIndex(playlist,numChildren-1);

			timer = new Timer(35);
			timer.addEventListener(TimerEvent.TIMER,timerHandler);
			timer.start();

			doubleButton.doubleClickEnabled = true;
			doubleButton.addEventListener(MouseEvent.CLICK,clickHandle);
			doubleButton.addEventListener(MouseEvent.DOUBLE_CLICK,doubleHandle);
			control.listButton.addEventListener(MouseEvent.CLICK,listButtonClickHandle);
			_stage.addEventListener(MouseEvent.MOUSE_MOVE,moveHandler);
		}

		private function playerStatusHandler(event:MediaEvent):void
		{
			switch (event.data)
			{
				case "play" :
					//trace("开始播放");
					break;
				case "NetStream.Buffer.Full" ://trace("缓冲完毕");
					//trace("缓冲完毕")
					break;
				case "NetStream.Play.Stop" ://trace("播放完成");
					break;
				case "NetStream.Play.StreamNotFound" ://trace("加载失败");
					break;
			}
		}

		private function listButtonClickHandle(event:MouseEvent):void
		{
			if (playlist.visible)
			{
				playlist.visible = false;
			}
			else
			{
				playlist.visible = true;
			}
		}

		private function moveHandler(event:MouseEvent):void
		{
			control.moveHandler();
			if (showInterval)
			{
				clearInterval(showInterval);
			}
			showInterval = setInterval(showUpdate,3000);
			Tweener.addTween(control,{y:_stage.stageHeight - 30,time:0.3,transition:"linear"});
			Mouse.show();
		}

		function showUpdate():void
		{
			clearInterval(showInterval);
			if (stage.displayState == "fullScreen")
			{
				Tweener.addTween(control,{y:_stage.stageHeight+15,time:0.3,transition:"linear"});
				playlist.visible = false;
				Mouse.hide();
			}
		}

		function doubleHandle(event:MouseEvent):void
		{
			switch (stage.displayState)
			{
				case "normal" :
					stage.displayState = "fullScreen";
					break;

				case "fullScreen" :
					stage.displayState = "normal";
					break;
			}
			click = true;
		}


		function clickHandle(event:MouseEvent):void
		{
			click = false;
			var clickTime:Timer = new Timer(270,1);//270豪秒后只执行一次
			clickTime.start();
			clickTime.addEventListener(TimerEvent.TIMER,clickTimeHandler);
		}
		function clickTimeHandler(event:TimerEvent):void
		{

			if (! click)
			{
				if (control.isPlay)
				{
					control.playButtonClickHandler();
				}
				else
				{
					control.pauseButtonClickHandler();
				}
			}
		}



		private function timerHandler(event:TimerEvent):void
		{
			if (player.bufferPct < 100)
			{
				loading.play();
				loading.visible = true;
			}
			else
			{
				loading.stop();
				loading.visible = false;
			}
			if (player.percentLoaded >= 100)
			{
				timer.stop();
			}
		}

		public function stageResize():void
		{
			if (Tweener.isTweening(control))
			{
				Tweener.removeTweens(control);
			}
			control.y = stage.stageHeight - 30;
			doubleButton.width = stage.stageWidth;
			doubleButton.height = stage.stageHeight;
			loading.x = stage.stageWidth * .5;
			loading.y = stage.stageHeight * .5 - 40;
			playlist.x=(stage.stageWidth-380)*.5;
			playlist.y = stage.stageHeight - playlist.height - 60;
			control.stageResize();
			player.stageResize();
		}



		private function byteMB(value:Number):String
		{
			if (player.isFormats)
			{
				value = value / 1024 / 10;
			}
			else
			{
				value = value / 1024 / 10.24;
			}

			var max = int((value / 100));
			var min = int((value % 100));
			max < 10 ? max = "0" + max:null;
			min < 10 ? min = "0" + min:null;
			return max + "." + min;
		}

		private function millToTime(mill:Number):String
		{
			if (player.isFormats)
			{
				mill = mill;
			}
			else
			{
				mill = mill / 1000;
			}

			var minutes = int(mill / 60);
			var seconds = int(mill % 60);
			minutes < 10 ? minutes = "0" + minutes:null;
			seconds < 10 ? seconds = "0" + seconds:null;
			return minutes+ ":" + seconds;
		}

		public function set stages(_stage:Stage):void
		{
			this._stage = _stage;
		}






	}

}