﻿package fengzi.mediaPlayer.events
{
	import flash.events.Event;

	public class MetaDataEvent extends Event
	{

		public static const META_DATA:String = "MetaDataEvent_META_DATA";

		public var data:Object;


		/*
		* 构造函数
		*/
		public function MetaDataEvent(type:String, object:Object,bubbles:Boolean = false, cancelable:Boolean = false)
		{
			super(type, bubbles, cancelable);
			data = object;
		}

		/*
		* clone方法必须重写
		*/
		override public function clone():Event
		{
			return new MetaDataEvent(type, data,bubbles, cancelable);
		}
	}
}