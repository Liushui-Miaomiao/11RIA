﻿package fengzi.mediaPlayer.ui
{
	import flash.text.TextField;
	import flash.text.TextFieldAutoSize;
	public class Label extends TextField
	{
		public function Label():void
		{
			this.selectable=false;
			this.autoSize=TextFieldAutoSize.LEFT;
			
		}
		public function setColor(value:uint):void
		{
			this.textColor=value;
		}

	}
}