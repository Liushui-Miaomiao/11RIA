﻿/**
* 网速测试
* @author wu
* @date 1-12/2019
**/

package fengzi.mediaPlayer.media
{
	import flash.utils.Timer;
	import flash.events.TimerEvent;

	public class HTTPLive
	{

		private var _player:Object;
		private var timer:Timer;
		private var bandwidthArray:Array;
		private var repeatCount:int = 0;
		private var bandwidthNum:Number = 0;

		public function HTTPLive():void
		{
			bandwidthArray = [];
			timer = new Timer(1000);
		}

		public function set player(object:Object):void
		{
			_player = object;
			timer.addEventListener(TimerEvent.TIMER,timerHandler);
			timer.start();
		}

		private function timerHandler(event:TimerEvent):void
		{
			if (_player.bytesLoaded > 0)
			{
				if (_player.bytesLoaded < _player.bytesTotal)
				{
					bandwidthArray.push(Math.round(_player.bytesLoaded / 1000 * 8));
					if ((repeatCount == 0))
					{
						bandwidthNum = bandwidthArray[repeatCount];
					}
					else
					{
						bandwidthNum = bandwidthArray[repeatCount] - bandwidthArray[(repeatCount - 1)];
					}
					repeatCount++;
				}
				else
				{
					clear();
				}
			}
		}

		public function clear():void
		{
			if (_player != null)
			{
				_player = null;
			}
			timer.removeEventListener(TimerEvent.TIMER,timerHandler);
			timer.reset();
			bandwidthNum = 0;
			bandwidthArray = [];
			repeatCount = 0;
		}

		public function get bandwidth():Number
		{
			return bandwidthNum;
		}


	}
}