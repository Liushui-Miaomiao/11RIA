﻿/**
* 曲目菜单类
**/

package fengzi.mediaPlayer.ui
{
	import fengzi.mediaPlayer.events.MetaDataEvent;
	import fengzi.mediaPlayer.events.MediaEvent;
	import flash.display.Sprite;
	import flash.display.DisplayObject;
	import flash.events.MouseEvent;
	import flash.events.Event;
	import flash.events.TimerEvent;
	import flash.utils.Timer;


	public class Playlist extends Sprite
	{
		public static const STR_LENGTH:int = 23;//为了显示的曲目名字不超越背景框边界，控制显示字符的个数（多余的字符用...表示）


		private var _player:Object;

		private var pageSize:int;
		private var itemButton:ItemButton;
		private var item:Array = [];
		private var itemIndex:int = 0;
		private var itemTotal:int;
		private var songTotal:int;
		private var pageIndex:int;
		private var currentPageIndex:int;
		private var pageTotal:int;
		private var currentPage:Array = [];

		private var pageTotalText:Label;
		private var startButton:Button;
		private var nextButton:Button;
		private var prevButton:Button;
		private var endButton:Button;

		private var currentPageText:Label;

		private var list:*;
		private var urlPath:*;


		private var butColor:uint;
		private var itemColor:uint;
		private var statusColor:uint;

		private var itemIcon:Sprite;

		private var songIcon:TxtF;


		var timer:Timer;

		/*
		* Playlist
		* @param list 曲目名称
		* @param urlPath 连接地址
		* @param _butColor 翻页按钮颜色
		* @param _statusColor 高光颜色（当前曲目按钮颜色）
		* @param pageSize 每页显示曲目按钮数
		*/

		public function Playlist(list: * ,urlPath: * ,_butColor:uint=0xffffff,_statusColor:uint=0xff00ff,pageSize:int=6):void
		{

			this.list = list;
			this.urlPath = urlPath;
			this.pageSize = pageSize;

			/*翻页按钮颜色*/
			butColor = _butColor;
			/*曲目按钮颜色*/
			itemColor = _butColor;
			/*当前曲目按钮颜色*/
			statusColor = _statusColor;

			initplaylist();

		}



		private function initplaylist()
		{
			if (list is XMLList||list is XML)
			{
				songTotal = list.length();
			}
			if (list is Array)
			{
				songTotal = list.length;
			}

			//创建所有曲目按钮
			if (list is XMLList||list is XML||list is Array)
			{
				for (var i:int = 0; i <songTotal; i++)
				{
					var _str:String =(urlPath[i]).toString();
					var str:String = _str.slice(_str.lastIndexOf(".") + 1,_str.length);
					if (str!="mp3")
					{
						itemButton = new ItemButton(i,list[i],true,STR_LENGTH);
					}
					else
					{
						itemButton = new ItemButton(i,list[i],false,STR_LENGTH);
					}
					itemButton.name = i.toString();

					item.push(itemButton);

					state(itemIndex,true);
				}
			}
			else if (list is String)
			{
				str = urlPath.slice(urlPath.lastIndexOf(".") + 1,urlPath.length);
				if (str!="mp3")
				{
					itemButton = new ItemButton(0,list,true,STR_LENGTH);
				}
				else
				{
					itemButton = new ItemButton(0,list,false,STR_LENGTH);
				}
				itemButton.name = "0";
				item.push(itemButton);
				state(itemIndex,true);

			}

			itemTotal = item.length;
			pageTotal = Math.ceil((itemTotal / pageSize));

			//初始组件列表
			init();


			//初始曲目列表状态
			open(pageIndex);

			songIcon = new TxtF(380);
			songIcon.visible = false;
			addChild(songIcon);

		}


		public function set player(value:Object):void
		{
			_player = value;
			_player.addEventListener(MediaEvent.STATUS, playerStatusHandler);
			timer = new Timer(35);
			timer.addEventListener(TimerEvent.TIMER,timerHandler);
			timer.start();
		}

		//曲目加载进度
		private function timerHandler(event:TimerEvent):void
		{
			for (var i:int =0; i < itemTotal; i++)
			{
				if (_player.index != i)
				{
					var str:String = list[i];
					if (str.length > STR_LENGTH)
					{
						str = str.slice(0,STR_LENGTH) + "...";
					}
					item[i].setPlayState(_player,"up",str,STR_LENGTH);
				}
				else
				{
					str = list[itemIndex];
					if (str.length > STR_LENGTH)
					{
						str = str.slice(0,STR_LENGTH) + "...";
					}
					item[itemIndex].setPlayState(_player,"down",str,STR_LENGTH);
					continue;
				}
			}
			if (_player.percentLoaded >= 1)
			{
				timer.stop();
			}
		}

		//播放控制曲目列表状态
		private function playerStatusHandler(event:Event):void
		{
			timer.start();
			itemIndex = event.target.index;
			state(itemIndex,true);
			jump(itemIndex);
			open(pageIndex);
		}




		/*清除当前页的对象*/
		private function clear():void
		{
			for (var i:int = 0; i < currentPage.length; i++)
			{
				var displayObject:DisplayObject = currentPage[i] as DisplayObject;
				removeChild(displayObject);
				displayObject = null;

			}
			currentPage = [];

		}

		/*显示当前页的对象*/
		private function open(index:int):void
		{
			clear();
			currentPageText.htmlText = "第" + "<font FACE=\"Verdana\" >" + (index + 1) +  "/" + pageTotal + "页" + "</font>";
			var startIndex:int = index * pageSize;
			var endIndex:int = startIndex + pageSize;

			if ((endIndex > itemTotal - 1))
			{
				endIndex = itemTotal;
			}

			for (var i:int = startIndex; i < endIndex; i++)
			{
				item[i].x = 6;
				item[i].y = 5 + Math.floor((i - startIndex)) * 20;
				addChild(item[i]);
				currentPage.push(item[i]);
				item[i].addEventListener(MouseEvent.CLICK,clickHandler);
				item[i].addEventListener(MouseEvent.MOUSE_OVER,overHandler);
				item[i].addEventListener(MouseEvent.MOUSE_OUT,outHandler);
			}

		}

		private function clickHandler(event:MouseEvent=null):void
		{
			itemIndex = int(event.currentTarget.name);
			state(itemIndex,true);
			_player.clear();
			_player.index = itemIndex;
			_player.initPlay();

		}
		private function overHandler(event:MouseEvent):void
		{
			event.currentTarget.setColor(0x990000);
			itemIcon.visible = true;
			itemIcon.width = event.currentTarget.width + 2;
			itemIcon.x = 4;
			itemIcon.y = event.currentTarget.y - 1;


			var str:String = list[int(event.currentTarget.name)];
			songIcon.text = convert(int(event.currentTarget.name)+1)+"."+str;
			songIcon.y = int(event.currentTarget.name)*20 - (songIcon.length-8);
			setChildIndex(songIcon,numChildren-1);
			if (str.length > STR_LENGTH)
			{
				songIcon.visible = true;
			}


		}



		private function outHandler(event:MouseEvent):void
		{
			songIcon.visible = false;
			itemIcon.visible = false;
			state(itemIndex,true);
		}
		//曲目列表状态
		public function state(index:int,onClick:Boolean):void
		{
			itemIndex = index;
			for (var i:int = 0; i < item.length; i++)
			{
				if ((index == i))
				{
					if (onClick)
					{
						item[i].setColor(statusColor);
						item[i].status = "down";
					}
					else
					{
						item[i].setColor(itemColor);
					}
				}
				else
				{
					item[i].setColor(itemColor);
					item[i].status = "up";
				}
			}
		}



		/*初始UI*/
		private function init():void
		{
			/*背景框*/
			var listBack=new Sprite();
			listBack.graphics.lineStyle(0,0xffffff,1);
			listBack.graphics.beginFill(0x333333,0.4);
			listBack.graphics.drawRect(0.5,0.5,380,pageSize*20+41);
			listBack.graphics.endFill();
			addChild(listBack);


			/*假虚线*/
			for (var i:int=0; i<68; i++)
			{
				var lin:Sprite=new Sprite();
				lin.graphics.beginFill(butColor);
				lin.graphics.drawRect(i * 5.5 + 4, pageSize*20+11, 4, 1);
				lin.graphics.endFill();
				addChild(lin);
			}

			/*鼠标进入item的背景*/
			itemIcon=new Sprite();
			itemIcon.graphics.lineStyle(0,0xffffff,0.4);
			itemIcon.graphics.beginFill(0x333333,0.4);
			itemIcon.graphics.drawRect(0.5,0.5,240,20);
			itemIcon.graphics.endFill();
			addChild(itemIcon);
			itemIcon.visible = false;



			pageTotalText=new Label();
			pageTotalText.setColor(butColor);
			pageTotalText.x = 6;
			pageTotalText.y = pageSize * 20 + 17;
			pageTotalText.htmlText = "<font FACE=\"Verdana\" >" +"共"+pageTotal+"页"+"   "+"每页"+pageSize+"首" + "</font>";
			addChild(pageTotalText);



			startButton = new Button(butColor);
			startButton.x = pageTotalText.x + pageTotalText.width + 18;
			startButton.y = pageSize * 20 + 17;
			startButton.htmlText = "<a href=\"event:\">首页</a>";
			addChild(startButton);

			nextButton = new Button(butColor);
			nextButton.x = startButton.x + startButton.width + 18;
			nextButton.y = pageSize * 20 + 17;
			nextButton.htmlText = "<a href=\"event:\">下一页</a>";
			addChild(nextButton);

			prevButton = new Button(butColor);
			prevButton.x = nextButton.x + nextButton.width + 18;
			prevButton.y = pageSize * 20 + 17;
			prevButton.htmlText = "<a href=\"event:\">上一页</a>";
			addChild(prevButton);

			endButton = new Button(butColor);
			endButton.x = prevButton.x + prevButton.width + 18;
			endButton.y = pageSize * 20 + 17;
			endButton.htmlText = "<a href=\"event:\">尾页</a>";
			addChild(endButton);

			currentPageText = new Label();
			currentPageText.setColor(butColor);
			currentPageText.x = endButton.x + endButton.width + 18;
			currentPageText.y = pageSize * 20 + 17;
			currentPageText.text = "第" + (pageIndex + 1) + "页";
			addChild(currentPageText);

			/*翻页按钮控制翻页*/
			startButton.addEventListener(MouseEvent.CLICK,startHandler);
			nextButton.addEventListener(MouseEvent.CLICK,nextHandler);
			prevButton.addEventListener(MouseEvent.CLICK,prevHandler);
			endButton.addEventListener(MouseEvent.CLICK,endHandler);

		}


		//开始页
		private function startHandler(event:MouseEvent):void
		{
			pageIndex = 0;
			open(pageIndex);
		}
		//下一页
		private function nextHandler(event:MouseEvent):void
		{
			if ((pageIndex < pageTotal - 1))
			{
				pageIndex++;
			}
			open(pageIndex);
		}
		//上一页
		private function prevHandler(event:MouseEvent):void
		{
			if ((pageIndex > 0))
			{
				pageIndex--;
			}
			open(pageIndex);
		}
		//结束页
		private function endHandler(event:MouseEvent):void
		{
			pageIndex = pageTotal - 1;
			open(pageIndex);
		}


		/*播放索引控制翻页*/
		public function jump(index:int):void
		{
			pageIndex=int(index/pageSize);
			open(pageIndex);
		}
		//返回一个两位数的字符串（01、02、03...）
		private function convert(num:int):String
		{
			if ((num < 10))
			{
				return "0" + num.toString();
			}
			return num.toString();
		}






	}

}