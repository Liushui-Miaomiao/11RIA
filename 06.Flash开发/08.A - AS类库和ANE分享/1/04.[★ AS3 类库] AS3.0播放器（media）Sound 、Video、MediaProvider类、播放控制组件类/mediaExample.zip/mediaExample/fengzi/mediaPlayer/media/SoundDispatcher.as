﻿/**
* sound封装类
* 所有注释恐有差错，见者酌情理解
* @author wu
* @date 1-12/2019
**/

package fengzi.mediaPlayer.media
{
	import fengzi.mediaPlayer.events.MediaEvent;

	import flash.events.Event;
	import flash.events.EventDispatcher;
	import flash.events.SecurityErrorEvent;
	import flash.events.ProgressEvent;
	import flash.events.IOErrorEvent;
	import flash.media.Sound;
	import flash.media.SoundChannel;
	import flash.media.SoundTransform;
	import flash.net.URLRequest;

	public class SoundDispatcher extends EventDispatcher
	{


		private var sound:Sound;
		private var _soundChannel:SoundChannel = new SoundChannel  ;
		private var _transform:SoundTransform = new SoundTransform  ;
		private var startTime:Number = 0;
		private var _playing:Boolean;//播放的布尔值
		private var _paused:Boolean;//暂停的布尔值
		private var _scrubbing:Boolean;//是否正在调用seek()的布尔值
		private var url:String;
		private var _bufferTime:int = 3000;//缓冲区的时间(毫秒)

		public function play(_url:String):void
		{
			url = _url;
			sound = new Sound  ;
			sound.load(new URLRequest(url));
			configureListeners(sound,true);
			_soundChannel = sound.play();
			_soundChannel.soundTransform = _transform;
			_soundChannel.addEventListener(Event.SOUND_COMPLETE,soundCompleteHandler);

			_playing = true;
			_paused = true;
			_scrubbing = false;

		}


		private function configureListeners(dispatcher:EventDispatcher,isListener:Boolean):void
		{
			if (isListener)
			{
				dispatcher.addEventListener(Event.ID3,id3Handler);
				dispatcher.addEventListener(ProgressEvent.PROGRESS,progressHandler);
				dispatcher.addEventListener(Event.COMPLETE,completeHandler);
				dispatcher.addEventListener(IOErrorEvent.IO_ERROR,ioErrorHandler);
				dispatcher.addEventListener(SecurityErrorEvent.SECURITY_ERROR,securityErrorHandler);
			}
			else
			{
				dispatcher.removeEventListener(Event.ID3,id3Handler);
				dispatcher.removeEventListener(ProgressEvent.PROGRESS,progressHandler);
				dispatcher.removeEventListener(Event.COMPLETE,completeHandler);
				dispatcher.removeEventListener(IOErrorEvent.IO_ERROR,ioErrorHandler);
				dispatcher.removeEventListener(SecurityErrorEvent.SECURITY_ERROR,securityErrorHandler);

			}
		}

		private function id3Handler(event:Event):void
		{

		}

		private function progressHandler(event:ProgressEvent):void
		{
		}

		private function ioErrorHandler(event:IOErrorEvent):void
		{
			dispatchEvent(new MediaEvent(MediaEvent.STATUS, event.type));
		}

		private function completeHandler(event:Event):void
		{
			if (sound.length == 0)
			{
				dispatchEvent(new MediaEvent(MediaEvent.STATUS, "ioError"));

			}
			dispatchEvent(new MediaEvent(MediaEvent.STATUS, event.type));
		}

		private function securityErrorHandler(event:SecurityErrorEvent):void
		{
			dispatchEvent(new MediaEvent(MediaEvent.STATUS, event.type));
		}

		private function soundCompleteHandler(event:Event):void
		{
			if (! _scrubbing)
			{
				dispatchEvent(new MediaEvent(MediaEvent.STATUS, event.type));
			}
		}






		/****************** 公开方法 ******************/

		/*停止声音并关闭声音流*/
		public function close():void
		{
			if ((sound != null))
			{
				_soundChannel.stop();
				try
				{
					sound.close();

				}
				catch (error:Error)
				{

				}

				configureListeners(sound,false);
				_soundChannel.removeEventListener(Event.SOUND_COMPLETE,soundCompleteHandler);
				sound = null;
			}
		}


		public function stop():void
		{
			startTime = 0;
			seek(startTime);
			_soundChannel.stop();
			_playing = false;
		}


		public function pause():void
		{
			startTime = _soundChannel.position;
			_soundChannel.stop();
			_paused = false;
		}

		public function resume():void
		{
			_playing = true;
			_paused = true;
			_soundChannel.stop();
			seek(startTime);
		}




		/*定位播放*/
		public function seek(value:Number):void
		{
			if (_paused)
			{
				_soundChannel.stop();
				_soundChannel = sound.play(value);
				_soundChannel.soundTransform = _transform;
				_soundChannel.addEventListener(Event.SOUND_COMPLETE,soundCompleteHandler);
				if (((value > 0) && value >= duration))
				{
					dispatchEvent(new MediaEvent(MediaEvent.STATUS, "soundComplete"));
				}
			}
			else
			{
				_soundChannel = sound.play(value);
				startTime = _soundChannel.position;

			}
		}




		/*_soundChannel对象*/
		public function get soundChannel():Object
		{
			return _soundChannel;
		}

		/*音量*/
		public function get volume():Number
		{
			return _transform.volume;
		}

		public function set volume(value:Number):void
		{
			_transform.volume = value;
			if ((_soundChannel != null))
			{
				_soundChannel.soundTransform = _transform;
			}
		}

		/*声音平衡*/
		public function get pan():Number
		{
			return _transform.pan;
		}

		public function set pan(value:Number):void
		{
			_transform.pan = value;
			if ((_soundChannel != null))
			{
				_soundChannel.soundTransform = _transform;
			}

		}

		/*左右声道*/
		public function get leftPeak():Number
		{
			return _soundChannel.leftPeak;
		}



		public function get rightPeak():Number
		{
			return _soundChannel.rightPeak;
		}


		/*也加载字节*/
		public function get bytesLoaded():Number
		{
			return sound.bytesLoaded;
		}



		/*总字节*/
		public function get bytesTotal():Number
		{
			return sound.bytesTotal;
		}



		/*加载比*/
		public function get percentLoaded():Number
		{
			return bytesLoaded / bytesTotal;
		}

		/*播放位置*/
		public function get position():Number
		{
			return _soundChannel.position;
		}

		/*总长度*/
		public function get duration():Number
		{
			if (sound)
			{
				return sound.length/(sound.bytesLoaded/sound.bytesTotal);
			}

			return 0;
		}

		public function get length():Number
		{
			return sound.length;
		}

		//缓冲区缓冲进度
		public function get bufferPct():int
		{
			var buffer:Number = Math.min(Math.round((sound.length-position)/_bufferTime*100), 100);
			if (isNaN(buffer))
			{
				buffer = 0;
			}
			return buffer;
		}


		/*kbps（加载完成后才能精确获取）*/
		public function get kbps():Number
		{
			return Math.round(sound.bytesTotal / duration * 1000 * 8 / 1024 / 32) * 32;
		}

		/*播放进度比*/
		public function get playheadPercentage():Number
		{
			return position / duration;
		}

		/*ID3信息*/
		public function get ID3Info():Object
		{
			return sound.id3;
		}

		//播放的布尔值
		public function set playing(value:Boolean):void
		{
			_playing = value;
		}
		//暂停的布尔值
		public function get paused():Boolean
		{
			return _paused;
		}

		//拖动定位播放的布尔值
		public function set scrubbing(value:Boolean):void
		{
			_scrubbing = value;
		}

	}
}