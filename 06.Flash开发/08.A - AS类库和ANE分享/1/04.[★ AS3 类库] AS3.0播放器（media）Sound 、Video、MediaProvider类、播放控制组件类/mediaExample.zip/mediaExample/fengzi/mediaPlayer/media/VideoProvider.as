﻿/**
* video封装类 继承Video
* 所有注释恐有差错，见者酌情理解
* @author wu
* @date 1-12/2019
**/

package fengzi.mediaPlayer.media
{
	//两个自定义事件MetaDataEvent、MediaEvent
	import fengzi.mediaPlayer.events.MetaDataEvent;
	import fengzi.mediaPlayer.events.MediaEvent;


	import flash.media.Video;
	import flash.net.NetStream;
	import flash.media.SoundTransform;
	import flash.net.NetConnection;
	import flash.events.NetStatusEvent;
	import flash.events.IEventDispatcher;
	import flash.geom.Transform;

	public class VideoProvider extends Video
	{

		private var ns:NetStream;
		private var _pauseing:Boolean;//暂停的布尔值
		private var _bufferTime = 3;//缓冲区长度（秒）
		private var stransform:SoundTransform;
		private var _playing:Boolean;//播放的布尔值
		private var _url:String;
		private var _duration:int;
		private var nc:NetConnection;
		var metaData:*;

		public function VideoProvider()
		{
			stransform = new SoundTransform  ;

		}

		//播放视频的基本方法
		public function play(url:String):void
		{
			_url = url;
			//创建 NetConnection 对象 
			nc = new NetConnection();
			//如果连接到没有使用服务器的视频文件，则通过向 connect() 方法传递值null来播放流式视频文件
			nc.connect(null);
			//创建 NetStream 对象（该对象将 NetConnection 对象作为参数）
			ns = new NetStream(nc);
			//指定要加载的视频文件地址
			ns.play(url);
			//使用 Video 类的 attachNetStream() 方法附加以前创建的 NetStream 对象
			this.attachNetStream(ns);
			//指定调用回调方法的对象 
			ns.client = new Object  ;
			ns.client.onMetaData = customClient;//回调视频信息
			//音量（平移）控制
			ns.soundTransform = stransform;

			ns.bufferTime = _bufferTime;//缓冲区长度（秒）
			configureListeners(ns,true);//帧听视频状态
			smoothing = true;//平滑处理（对视频进行平滑处理，有这一说，是否有效果难说）
			_playing = true;
		}
		//回调正在播放的视频文件中嵌入的描述性信息（接收视频文件信息供我们调用，比如：视频的宽高、总帧数等原始信息）
		private function customClient(object:Object):void
		{
			_duration = object.duration;
			//发送MetaDataEvent事件
			dispatchEvent(new MetaDataEvent(MetaDataEvent.META_DATA,object));
		}

		//帧听视频状态
		private function configureListeners(dispatcher:IEventDispatcher,value:Boolean):void
		{
			if (value)
			{
				dispatcher.addEventListener(NetStatusEvent.NET_STATUS,netStatusHandler);
			}
			else
			{
				dispatcher.removeEventListener(NetStatusEvent.NET_STATUS,netStatusHandler);
			}
		}

		//视频缓冲、加载等信息
		private function netStatusHandler(event:NetStatusEvent):void
		{
			metaData = event;
			/*发送视频的缓冲、加载等等状态事件
			很多状态，常用到的有：
			* NetStream.Buffer.Empty 填充缓冲区
			* NetStream.Buffer.Full 缓冲区已满
			* NetStream.Play.Start 播放已开始
			* NetStream.Play.Stop 播放结束
			* NetStream.Play.StreamNotFound 加载失败
			*/
			dispatchEvent(new MediaEvent(MediaEvent.STATUS,event.info.code));
		}

		/************ 以下是公开方法 ***********/
		//定位（播放）
		public function seek(value:Number):void
		{
			//指定视频开始播放的位置
			if (metaData.info.code == "NetStream.Seek.InvalidTime")
			{
				ns.seek(metaData.info.details);
			}
			else
			{
				ns.seek(value);
			}


			if (! _pauseing)
			{
				if (_duration * percentLoaded< _duration)
				{
					if (value >=_duration * percentLoaded- ns.bufferTime)
					{
						//指定视频播放的位置大等于缓冲进度的时候，发送填充缓冲区事件
						new MediaEvent(MediaEvent.STATUS,"NetStream.Buffer.Empty");
					}
				}
			}

		}

		//清除视频（画面、流）
		public function clearVideo():void
		{
			clear();
			if ((nc != null))
			{
				nc = null;
			}
			if ((ns != null))
			{
				try
				{
					ns.close();
				}
				catch (event:Error)
				{
				}
				configureListeners(ns,false);
				ns = null;
			}
		}

		//播放
		public function resume():void
		{
			if (_playing)
			{
				ns.resume();
			}
			else
			{
				play(_url);
			}
			_pauseing = false;
		}
		//暂停
		public function pause():void
		{
			ns.pause();
			_pauseing = true;
		}
		//停止
		public function stop():void
		{
			_playing = false;
			clearVideo();
		}
		//播放时间
		public function get time():Number
		{
			if (ns != null)
			{
				return ns.time;
			}
			return 0;
		}

		//总时间
		public function get duration():int
		{
			return _duration;
		}
		//播放进度
		public function get playheadPercentage():Number
		{
			return time / duration;
		}

		//也加载字节
		public function get bytesLoaded():Number
		{
			if (ns != null)
			{
				return ns.bytesLoaded;
			}
			return 0;
		}

		//总字节
		public function get bytesTotal():Number
		{
			if (ns != null)
			{
				return ns.bytesTotal;
			}
			return 0;
		}


		//加载比
		public function get percentLoaded():Number
		{
			if (ns != null)
			{
				return bytesLoaded / bytesTotal;
			}
			return 0;
		}


		//缓冲区中的数据
		public function get bufferLength():Number
		{
			return ns.bufferLength;
		}

		//缓冲区长度
		public function get bufferTime():Number
		{
			return ns.bufferTime;
		}


		//缓冲区进度比
		public function get bufferPct():Number
		{
			var buffer:Number = Math.min(Math.round(bufferLength/bufferTime*100), 100);
			if (isNaN(buffer))
			{
				buffer = 0;
			}
			return buffer;
		}


		//音量
		public function get volume():Number
		{
			return stransform.volume;
		}

		public function set volume(value:Number):void
		{
			stransform.volume = value;
			if ((ns != null))
			{
				ns.soundTransform = stransform;
			}
		}
		//平衡
		public function get pan():Number
		{
			return stransform.pan;
		}

		public function set pan(value:Number):void
		{
			stransform.pan = value;
			if (ns!=null)
			{
				ns.soundTransform = stransform;
			}

		}


		//播放的布尔值
		public function set playing(value:Boolean):void
		{
			_playing = value;
		}



	}
}