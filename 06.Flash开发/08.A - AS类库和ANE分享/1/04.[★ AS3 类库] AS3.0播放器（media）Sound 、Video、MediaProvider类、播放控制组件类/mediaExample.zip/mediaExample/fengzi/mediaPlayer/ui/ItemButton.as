﻿
/*曲目按钮*/
package fengzi.mediaPlayer.ui
{
	import flash.display.Sprite;
	import flash.events.MouseEvent;
	import flash.events.Event;

	import flash.text.TextField;
	import flash.text.TextFieldAutoSize;
	import flash.text.TextFormat;

	public class ItemButton extends Sprite
	{
		//曲目名称
		private var label:Label;
		//曲目编号
		private var index:Label;
		//视频图标
		private var videoIcon:VideoIcon;

		/*
		* ItemButton
		* @param _index 曲目编号
		* @param value 曲目名称
		* @param isVideo 曲目类型的布尔值（视频、MP3）
		* @param strLength 曲目名称长度
		*/
		public function ItemButton(_index:int,value:String,isVideo:Boolean,strLength:int):void
		{
			if (value.length > strLength)
			{
				value = value.slice(0,strLength) + "...";
			}

			index=new Label();
			label = new Label();
			videoIcon = new VideoIcon();
			setColor(0x999999);

			index.htmlText ="<font FACE=\"Verdana\" SIZE=\"13\">" +convert(_index+1) +"."+ "</font>";
			label.htmlText = "<font FACE=\"Verdana\" SIZE=\"13\">" + value + "</font>";


			addChild(index);
			addChild(label);
			addChild(videoIcon);

			if (isVideo)
			{
				videoIcon.visible = true;
				videoIcon.x = index.width;
				label.x = index.width + 14;
			}
			else
			{
				videoIcon.visible = false;
				label.x = index.width - 2;
			}

			status = "up";

		}


		//文本颜色
		public function setColor(value:uint):void
		{
			label.setColor(value);
			index.setColor(value);
		}

		public function set status(value:String):void
		{
			switch (value)
			{
				case "up" :
					break;
				case "down" :
					break;
			}
		}


		//加载进度
		public function setPlayState(value:Object,type:String,labeltxt:String,strLength:int):void
		{
			var percent:String;

			if (labeltxt.length > strLength)
			{
				labeltxt = labeltxt.slice(0,strLength) + "...";
			}
			if (type == "down")
			{
				if (value.percentLoaded < 1)
				{
					percent=(Math.round(value.bytesLoaded / value.bytesTotal * 100)).toString() +"% ";
					label.htmlText = "<font FACE=\"Verdana\" SIZE=\"10\" color=\"#ff0000\">" + percent + "</font>" + "<font FACE=\"Verdana\" SIZE=\"13\">" + labeltxt + "</font>";
				}
				else
				{
					label.htmlText = "<font FACE=\"Verdana\" SIZE=\"13\">" + labeltxt + "</font>";

				}

			}
			else if (type=="up")
			{
				label.htmlText = "<font FACE=\"Verdana\" SIZE=\"13\">" + labeltxt + "</font>";
			}

		}


		private function convert(num:int):String
		{
			if (num<10)
			{
				return "0"+num.toString();
			}

			return num.toString();
		}







	}
}