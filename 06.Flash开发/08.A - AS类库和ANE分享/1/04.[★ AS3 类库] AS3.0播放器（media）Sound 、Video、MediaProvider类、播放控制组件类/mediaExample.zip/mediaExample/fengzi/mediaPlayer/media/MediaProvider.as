﻿/**
* media封装类
* 所有注释恐有差错，见者酌情理解
* @author wu
* @date 1-12/2019
**/


package fengzi.mediaPlayer.media
{

	import fengzi.mediaPlayer.events.MetaDataEvent;
	import fengzi.mediaPlayer.events.MediaEvent;
	import fengzi.visualization.Pv3dCircle;

	import flash.display.Sprite;
	import flash.display.DisplayObject;


	public class MediaProvider extends Sprite
	{

		private var sound:SoundDispatcher;//MP3对象
		private var video:VideoProvider;//视频对象
		private var httpLive:HTTPLive;//文件下载速度提示

		private var _data:Object;//装载视频信息

		private var url:*;//曲目地址
		private var _volume:Number = 1;//初始音量
		private var _erroring:Boolean;//加载错误的布尔值
		private var _index:int = 0;//播放地址的索引
		private var _isFormats:Boolean;//视频、MP3的布尔值
		private var _scrubbing:Boolean;//拖动定位播放的布尔值
		private var videoW:Number;//视频的宽
		private var videoH:Number;//视频的高

		private var pv3dCircle:Pv3dCircle;//声控3D动画（使用声音（SoundChannel）声道控制）

		/*
		* MediaProvider
		* @param url 连接地址，可以是XML、Array数组、String
		*/
		public function MediaProvider(url: * ):void
		{
			this.url = url;
			httpLive = new HTTPLive();
			pv3dCircle = new Pv3dCircle(720,480);
			addChild(pv3dCircle);

		}
		//播放
		public function initPlay():void
		{
			pv3dCircle.visible = false;
			pv3dCircle.reset();
			//首先播放视频;
			video = new VideoProvider();
			//指定地址并播放（currentUrl解析地址）
			video.play(currentUrl(url));
			//传送video对象给HTTPLive类
			httpLive.player = video;
			//监听回调事件
			video.addEventListener(MetaDataEvent.META_DATA,onMetaData);
			//监听视频状态
			video.addEventListener(MediaEvent.STATUS,videoStatusHandler);
			_isFormats = true;
			_erroring = false;
			_scrubbing = false;
			dispatchEvent(new MediaEvent(MediaEvent.STATUS,"play"));
		}
		//回调视频信息
		private function onMetaData(event:MetaDataEvent):void
		{
			//获取视频的所有信息
			_data = event.data;
			//获取视频原始宽高
			videoW = event.data.width;
			videoH = event.data.height;
			addChild(video);
			//缩放视频宽高
			stageResize();
			//发送回调事件
			dispatchEvent(new MetaDataEvent(MetaDataEvent.META_DATA,event.data));
		}



		private function videoStatusHandler(event:MediaEvent):void
		{
			switch (event.data)
			{
				case "NetStream.Play.Start" ://开始播放
					break;
				case "NetStream.Buffer.Empty" ://填充缓冲区
					new MediaEvent(MediaEvent.STATUS,"NetStream.Buffer.Empty");
					break;
				case "NetStream.Buffer.Full" ://缓冲完毕
					new MediaEvent(MediaEvent.STATUS,"NetStream.Buffer.Full");
					break;
				case "NetStream.Play.Stop" :
					//播放完成接着播放下一个曲目
					if (! _scrubbing)
					{
						next();
					}
					break;

				case "NetStream.Play.StreamNotFound" :
					//如果视频加载失败，先清除，
					clear();
					//再测试播放MP3
					playSound();
					break;
			}
			dispatchEvent(new MediaEvent(MediaEvent.STATUS,event.data));
		}
		//播放MP3
		private function playSound():void
		{
			//MP3对象
			sound = new SoundDispatcher();
			//监听声音状态
			sound.addEventListener(MediaEvent.STATUS,soundStatusHandler);
			sound.play(currentUrl(url));
			_isFormats = false;
			httpLive.player = sound;
			pv3dCircle.player = sound;
			pv3dCircle.visible = true;
			pv3dCircle.start();
			//缩放pv3dCircle宽高;
			stageResize();

		}

		private function soundStatusHandler(event:MediaEvent):void
		{
			//如果播放完成或者加载失败，执行next()方法
			switch (event.data)
			{
				case "soundComplete" :
					//播放完成
					if (! _scrubbing)
					{
						next();
					}
					break;
				case "ioError" :
					if (! _scrubbing)
					{
						next();
					}
					_erroring = true;
					break;
			}
			dispatchEvent(new MediaEvent(MediaEvent.STATUS,event.data));
		}

		//解析文件地址的方法
		private function currentUrl(url: * ):String
		{
			var _url:String;
			if (url is XMLList || url is Array)
			{
				_url = url[_index];
			}
			else
			{
				if (url is String)
				{
					_url = url;
				}
			}
			return _url;
		}

		/*
		* 缩放显示对象的方法：
		* @param object 缩放对象
		* @param preferredWidth 对象初始宽度
		* @param preferredHeight 对象初始高度
		* @param width 对象缩放后的宽度
		* @param height 对象缩放后的高度
		*/
		private function setSize(object:Object,preferredWidth:Number,preferredHeight:Number,width:Number,height:Number):void
		{
			if (((preferredWidth / preferredHeight) > width / height))
			{
				object.width = width;
				object.height = object.width / preferredWidth * preferredHeight;
			}
			else
			{
				object.height = height;
				object.width = object.height / preferredHeight * preferredWidth;
			}

			//对象居中
			object.x = (width - object.width) / 2;
			object.y = (height - object.height) / 2;
		}


		//返回视频的帧频（视频每秒播放的帧数）
		private function fpsInfo(value:Object):String
		{
			var _fps:String;
			//MP4 m4a
			if (value.framerate != undefined)
			{
				_fps = int(value.framerate).toString();
			}
			//FLV
			if (value.videoframerate != undefined)
			{
				_fps = int(value.videoframerate).toString();
			}
			return _fps;
		}

		//返回视频类型
		private function mediaType(value:Object):String
		{
			var str:String;
			if (value.audiocodecid != undefined)
			{
				if (value.videoframerate != undefined)
				{
					str = "mp4";
				}
				else
				{
					str = "m4a";
				}
			}
			if (value.framerate != undefined)
			{
				str = "flv";
			}
			return str;
		}

		/*************** 以下是公开方法 **************************/

		//缩放视频、3D动画（pv3dCircle）
		public function stageResize():void
		{
			if (_isFormats)
			{
				if (stage.displayState != "fullScreen")
				{
					setSize(video,videoW,videoH,stage.stageWidth,stage.stageHeight - 30);
				}
				else
				{
					setSize(video,videoW,videoH,stage.stageWidth,stage.stageHeight);
				}
			}
			else
			{
				if (stage.displayState != "fullScreen")
				{
				setSize(pv3dCircle,720,480,stage.stageWidth,stage.stageHeight-30);
				}
				else
				{
				setSize(pv3dCircle,720,480,stage.stageWidth,stage.stageHeight);
				}
				//也可以重新实例一个pv3dCircle（注释掉上面的缩放方法）
				/*pv3dCircle.reset();
				removeChild(pv3dCircle);
				pv3dCircle = null;
				pv3dCircle = new Pv3dCircle(stage.stageWidth,stage.stageHeight);
				addChild(pv3dCircle);
				pv3dCircle.player = sound;
				pv3dCircle.start();*/
			}

		}




		//定位播放
		public function seek(value:Number):void
		{
			if (! _erroring)
			{
				if (_isFormats)
				{
					video.seek(value);
				}
				else
				{
					sound.seek(value);
				}
			}
		}


		//播放
		public function resume():void
		{
			if (_isFormats)
			{
				video.resume();
			}
			else
			{
				sound.resume();
			}
			dispatchEvent(new MediaEvent(MediaEvent.STATUS,"Media.Resume"));
		}

		//暂停
		public function pause():void
		{
			if (_isFormats)
			{
				video.pause();
			}
			else
			{
				sound.pause();
			}
			dispatchEvent(new MediaEvent(MediaEvent.STATUS,"Media.Pause"));
		}
		//停止
		public function stop():void
		{
			if (_isFormats)
			{
				video.stop();
			}
			else
			{
				sound.stop();
			}
			dispatchEvent(new MediaEvent(MediaEvent.STATUS,"Media.Stop"));
		}
		//上一个
		public function prev():void
		{
			clear();
			if (url is XMLList)
			{
				_index = _index > 0 ? _index - 1:_index = url.length() - 1;
			}
			if (url is Array)
			{
				_index = _index > 0 ? _index - 1:_index = url.length - 1;
			}
			initPlay();
			dispatchEvent(new MediaEvent(MediaEvent.STATUS,"Media.Prev"));
		}
		//下一个
		public function next():void
		{
			clear();
			if (url is XMLList)
			{
				_index = _index < url.length() - 1 ? _index + 1:_index = 0;
			}
			if (url is Array)
			{
				_index = _index < url.length - 1 ? _index + 1:_index = 0;
			}
			initPlay();
			dispatchEvent(new MediaEvent(MediaEvent.STATUS,"Media.Next"));
		}





		//视频、MP3
		public function get fileType():String
		{

			if (video != null && data != null)
			{
				return mediaType(data);
			}
			if ((sound != null))
			{
				return "mp3";
			}
			return "null";
		}

		//视频的帧频、MP3的KBPS
		public function get fpsAndKbps():String
		{
			if (video != null&& data != null)
			{
				return "Fps: "+fpsInfo(data);
			}
			if (sound != null)
			{
				return "Kbps: "+int(sound.kbps).toString();
			}
			return "0";
		}

		//下载速度 kbps/秒
		public function get bandwidth():String
		{
			return (httpLive.bandwidth).toString()+"kbps/s";
		}


		//总时间
		public function get duration():Number
		{
			if (video || sound)
			{
				if (_isFormats)
				{
					return video.duration;
				}
				return sound.duration;
			}
			return 0;
		}


		//播放时间
		public function get playheadTime():Number
		{
			if (video || sound)
			{
				if (_isFormats)
				{
					return video.time;
				}
				return sound.position;
			}
			return 0;
		}

		//加载进度
		public function get percentLoaded():Number
		{
			if (video || sound)
			{
				if (_isFormats)
				{
					return video.percentLoaded;
				}
				return sound.percentLoaded;
			}
			return 0;
		}

		//缓冲区缓冲进度
		public function get bufferPct():Number
		{
			if (video || sound)
			{
				if (_isFormats)
				{
					return video.bufferPct;
				}
				return sound.bufferPct;
			}
			return 0;
		}

		//也加载字节
		public function get bytesLoaded():Number
		{

			if (video || sound)
			{
				if (_isFormats)
				{
					return video.bytesLoaded;
				}
				return sound.bytesLoaded;
			}
			return 0;

		}
		//总字节
		public function get bytesTotal():Number
		{
			if (video || sound)
			{
				if (_isFormats)
				{
					return video.bytesTotal;
				}
				return sound.bytesTotal;
			}
			return 0;
		}




		//播放进度
		public function get playheadPercentage():Number
		{
			if (video || sound)
			{
				if (_isFormats)
				{
					return video.playheadPercentage;
				}
				return sound.playheadPercentage;
			}
			return 0;
		}

		//播放地址的索引
		public function set index(value:int):void
		{
			_index = value;
		}

		public function get index():int
		{
			return _index;
		}

		//音量
		public function get volume():Number
		{

			if ((video != null))
			{
				return video.volume;
			}
			if ((sound != null))
			{
				return sound.volume;
			}
			return 0;
		}

		public function set volume(value:Number):void
		{
			_volume = value;
			if ((video != null))
			{
				video.volume = _volume;
			}
			if ((sound != null))
			{
				sound.volume = _volume;
			}
		}
		/*声音平衡*/
		public function get pan():Number
		{

			if ((video != null))
			{
				return video.pan;
			}
			if ((sound != null))
			{
				return sound.pan;
			}
			return 0;
			return _transform.pan;
		}

		public function set pan(value:Number):void
		{
			if ((video != null))
			{
				video.pan = value;
			}
			if ((sound != null))
			{
				sound.pan = value;
			}
		}

		//视频信息
		public function get data():Object
		{
			return _data;
		}

		//正在播放的文件类型 的布尔值
		public function get isFormats():Boolean
		{
			return _isFormats;
		}

		//清除视频（流）、MP3（流）
		public function clear():void
		{
			if (video != null)
			{
				video.removeEventListener(MetaDataEvent.META_DATA,onMetaData);
				video.clearVideo();
				if (video.parent)
				{
					removeChild(video);
				}
				video = null;
			}
			if (sound != null)
			{
				sound.close();
				sound = null;
			}
			//关闭下载速度提示
			httpLive.clear();
		}

		//拖动定位播放的布尔值
		public function set scrubbing(value:Boolean):void
		{
			_scrubbing = value;
		}

		//文件播放状态
		public function set playing(value:Boolean):void
		{
			if (video != null)
			{
				video.playing = value;
			}
			if (sound != null)
			{
				sound.playing = value;
			}
		}









	}
}