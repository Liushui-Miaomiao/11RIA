﻿/**
* 音量控制类
* @author wu
* @date 2-18/2014
**/
package fengzi.mediaPlayer.ui
{
	import flash.display.MovieClip;
	import flash.geom.Rectangle;
	import flash.events.MouseEvent;
	import flash.display.Sprite;

	public class VolControl extends MovieClip
	{
		private var _volume:Number = 1;
		private var _player:*;
		
		public function VolControl()
		{
			init();
		}

		public function set player(value:Object):void
		{
			_player = value;
		}




		private function init():void
		{
			volumeBar.buttonMode = true;
			
			volumeBar.addEventListener(MouseEvent.MOUSE_DOWN,volumeBarDownHandler);
			volumeControlBar.addEventListener(MouseEvent.MOUSE_DOWN,volumeControlBarDownHandler);
		}

		private function volumeBarDownHandler(event:MouseEvent=null):void
		{
			var rectangle:Rectangle = new Rectangle(volumeControlBar.x,volumeBar.y,volumeControlBar.width - 5,0);
			volumeBar.startDrag(false,rectangle);
			stage.addEventListener(MouseEvent.MOUSE_UP,volumeBarUpHandler);
			stage.addEventListener(MouseEvent.MOUSE_MOVE,volumeChangeHandler);
		}

		private function volumeBarUpHandler(event:MouseEvent):void
		{
			volumeBar.stopDrag();
			stage.removeEventListener(MouseEvent.MOUSE_UP,volumeBarUpHandler);
			stage.removeEventListener(MouseEvent.MOUSE_MOVE,volumeChangeHandler);

		}

		private function volumeChangeHandler(event:MouseEvent=null):void
		{
			_volume=(volumeBar.x-volumeControlBar.x)/(volumeControlBar.width-5);
			_player.volume = _volume;
			volumeheadBar.width=_player.volume * (volumeControlBar.width-5)
			
		}

		private function volumeControlBarDownHandler(event:MouseEvent):void
		{

			volumeBar.x = mouseX - volumeBar.width / 2;
			if (mouseX <= volumeControlBar.x + volumeBar.width)
			{
				volumeBar.x = mouseX;
			}
			if (mouseX >= volumeControlBar.x + volumeControlBar.width)
			{

				volumeBar.x=volumeControlBar.x+(volumeControlBar.width-5);
			}

			volumeChangeHandler();
			volumeBarDownHandler();
		}

		public function get volume():Number
		{
			return _volume;
		}



	}

}