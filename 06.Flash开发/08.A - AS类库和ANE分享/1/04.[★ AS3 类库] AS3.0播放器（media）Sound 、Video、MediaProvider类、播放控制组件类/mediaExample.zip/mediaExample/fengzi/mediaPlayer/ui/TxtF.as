﻿
/*带背景框的文本*/

package fengzi.mediaPlayer.ui
{
	import flash.text.TextField;
	import flash.text.TextFieldAutoSize;
	import flash.text.TextFormat;
	public class TxtF extends TextField
	{
		private var ft:TextFormat;
		public function TxtF(w:uint=100):void
		{
			ft=new TextFormat();
			ft.font = "Verdana";
			ft.kerning = true;
			ft.leading = 2;
			ft.letterSpacing = 1;
			ft.size = 13;

			this.defaultTextFormat =ft;
			this.background = true;
			this.backgroundColor = 0x333333;
			this.border = true;
			this.borderColor = 0xcccccc;//边框颜色
			this.autoSize = TextFieldAutoSize.LEFT;
			this.multiline = true;//Boolean 指示文本字段是否为多行文本字段。 
			this.wordWrap = true;//Boolean 一个布尔值，指示文本字段是否自动换行
			this.selectable = false;//Boolean 一个布尔值，指示文本字段是否可选。 
			this.textColor = 0xffffff;//文字颜色
			this.width =w;
			
		}
		

	}
}