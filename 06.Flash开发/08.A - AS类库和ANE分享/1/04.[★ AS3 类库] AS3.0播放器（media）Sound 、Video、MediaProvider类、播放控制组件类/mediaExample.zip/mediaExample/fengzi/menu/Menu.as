﻿/**
* 播放（进度）控制类
* @author wu
* @date 3-12/2013
**/

package fengzi.menu
{

	import flash.events.ContextMenuEvent;
	import flash.ui.ContextMenu;
	import flash.ui.ContextMenuBuiltInItems;
	import flash.ui.ContextMenuItem;
	public class Menu
	{
		private var menu:ContextMenu=new ContextMenu();
		public function Menu(object:Object):void
		{
			menu.hideBuiltInItems();
			object.contextMenu=menu;
		}

		public function buildLinkMenu(title:String,ISeparatorBefore:Boolean,Event:Function=null):void
		{

			var item:ContextMenuItem=new ContextMenuItem(title,ISeparatorBefore);
			menu.customItems.push(item);

			item.separatorBefore=ISeparatorBefore;

			if (Event!=null) {
				item.addEventListener(ContextMenuEvent.MENU_ITEM_SELECT,mouseRelease);

			}

			function mouseRelease(event:ContextMenuEvent):void
			{

				Event();

			}

		}
	}
}