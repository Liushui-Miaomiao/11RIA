﻿
/*声控（SoundChannel）3D动画*/
package fengzi.visualization
{
	import caurina.transitions.Tweener;
    import org.papervision3d.scenes.Scene3D;
    import org.papervision3d.objects.DisplayObject3D;
    import org.papervision3d.cameras.Camera3D;
    import org.papervision3d.view.Viewport3D;
    import org.papervision3d.view.layer.BitmapEffectLayer;
    import org.papervision3d.render.BasicRenderEngine;
    import org.papervision3d.core.effects.utils.BitmapClearMode;
    import org.papervision3d.core.effects.BitmapLayerEffect;
    import org.papervision3d.core.effects.utils.BitmapDrawCommand;
	
	import flash.display.Sprite;
    import flash.utils.Timer;
	import flash.events.Event;
	import flash.events.TimerEvent;
	import flash.filters.BlurFilter;
	import flash.geom.ColorTransform;
    import flash.display.BlendMode;
    import flash.geom.Point;

    public class Pv3dCircle extends Sprite 
    {

        private static const W_SEGMENT:uint = 6;
        private static const H_SEGMENT:uint = 12;

        private static var _instance:Pv3dCircle;

        private var _player:Object;
        private var timer:Timer;
        private var scene:Scene3D;
        private var sphere:DisplayObject3D;
        private var rotY:Number = 0;
        private var rotZ:Number = 0;
        private var camera:Camera3D;
        private var viewport:Viewport3D;
        private var circles:Array;
        private var modeFlag:Boolean = false;
        public var bfx:BitmapEffectLayer;
        private var renderEngine:BasicRenderEngine;
		
		private var thisW:Number
		private var thisH:Number 

        public function Pv3dCircle(w:Number=720,h:Number=480):void
        {
			thisW=w;
			thisH=h;
            circles = [];
            _instance = this;
            scene = new Scene3D();
            camera = new Camera3D();
            viewport = new Viewport3D(w,h);
            addChild(viewport);
            renderEngine = new BasicRenderEngine();
            init();
			start()
        }

        public static function get instance():Pv3dCircle
        {
            return (_instance);
        }


        public function set player(value:Object):void
        {
            _player =value;
        }

        public function reset():void
        {
            removeEventListener(Event.ENTER_FRAME, renderHandler);
            timer.stop();
        }
		
		public function start():void
        {
            addEventListener(Event.ENTER_FRAME, renderHandler);
            timer.start();
        }

        private function init():void
        {
           bfx = new BitmapEffectLayer(viewport,thisW,thisH,true,0,BitmapClearMode.CLEAR_PRE);
			bfx.addEffect(new BitmapLayerEffect(new BlurFilter(8,8,1)));
			bfx.drawCommand = new BitmapDrawCommand(null,new ColorTransform(1,1,1,0.65),BlendMode.ADD);
			bfx.clippingPoint = new Point(0,-2);
			bfx.drawLayer.blendMode = BlendMode.OVERLAY;
			viewport.containerSprite.addLayer(bfx);
			sphere = scene.addChild(new DisplayObject3D  );
			for (var i:int = 0; i < W_SEGMENT * H_SEGMENT; i++) {
				var rX:Number = i % H_SEGMENT;
				var rY:Number = i / H_SEGMENT >> 0;

				var circle:DisplayObject3D = sphere.addChild(new Circle  );
				circle.rotationY = rX * (360 / H_SEGMENT);
				circle.rotationZ = rY * (180 / W_SEGMENT);
				circles.push(circle);
			}
            timer = new Timer(3000);
            timer.addEventListener(TimerEvent.TIMER, circlesHandler);
        }

        private function renderHandler(event:Event):void
        {
           var volume:Number = (_player.leftPeak + _player.rightPeak) / 2;
			sphere.z = Math.min(1500 - volume * 3000,sphere.z + 25);
			if (sphere.z < -800) {
				sphere.z = -800;
			}
			rotZ += (_player.leftPeak - 0.2) * 0.6;
			rotZ*=0.49;
			rotY += (_player.rightPeak - 0.1) * 0.4;
			rotY*=0.48;

			sphere.rotationY+=rotY;
			sphere.rotationX += (rotZ + rotY) * 0.3;

			sphere.x += (_player.leftPeak * 100 - 50 - sphere.x) * .1;
			sphere.y += (_player.rightPeak * 100 - 50 - sphere.y) * .1;
            renderEngine.renderScene(scene, camera, viewport);
        }

        private function circlesHandler(event:TimerEvent):void
        {
            var i:int;
			if (modeFlag) {
				for (i = 0; i < circles.length; i++) {
					Tweener.addTween(circles[i],{rotationY: i / (W_SEGMENT * H_SEGMENT) * 720 - 360,rotationZ: i / (W_SEGMENT * H_SEGMENT) * 180,time: 2,transition: "easeInOutQuad"});
				}
			} else {
				for (i = 0; i < circles.length; i++) {
					var rX:Number = (i % H_SEGMENT);
					var rY:Number = (i / H_SEGMENT >> 0);

					Tweener.addTween(circles[i],{rotationY: rX * (360 / H_SEGMENT),rotationZ: rY * (180 / W_SEGMENT),time: 2,transition: "easeInOutQuad"});
				}
			}
			modeFlag=! modeFlag;
		}

        


    }
}

import org.papervision3d.objects.DisplayObject3D;
import flash.display.Sprite;
import org.papervision3d.materials.MovieMaterial;
import org.papervision3d.objects.primitives.Plane;
import org.papervision3d.materials.ColorMaterial;
import fengzi.visualization.Pv3dCircle;

class Circle extends DisplayObject3D 
{

    private var dot1:DisplayObject3D;
    private var dot2:DisplayObject3D;
    private var dotE:DisplayObject3D;
    private var line1:DisplayObject3D;

    public function Circle():void
    {
        // Main Dot
		var s1:Sprite=new Sprite  ;
		s1.graphics.beginFill(0x0099EE,1);
		s1.graphics.drawCircle(0,0,50);
		s1.graphics.endFill();
		s1.graphics.beginFill(0x002244,1);
		s1.graphics.drawCircle(0,0,30);

		var s1Mat:MovieMaterial=new MovieMaterial(s1,true);
		s1Mat.doubleSided=true;

		dot1=addChild(new Plane(s1Mat,20,20));
		dot1.z=200;
		// Satellite Dot
		var s2:Sprite=new Sprite  ;
		s2.graphics.beginFill(0x0099EE,1);
		s2.graphics.drawCircle(0,0,20);

		var s2Mat:MovieMaterial=new MovieMaterial(s2,true);
		s2Mat.doubleSided=true;

		dot2=addChild(new Plane(s2Mat,10,10));
		dot2.z=300;
		dotE=addChild(new Plane(s2Mat,10,10));
		dotE.z=300;
		// Main line
		var l1Mat:ColorMaterial=new ColorMaterial(0x2299CC);
		l1Mat.doubleSided=true;
		line1=addChild(new Plane(l1Mat,100,1));
		line1.z=250;
		line1.rotationX=line1.rotationY=90;
        Pv3dCircle.instance.bfx.addDisplayObject3D(dotE);
    }

}
