package process
{
	import bigt.iterable.empty;
	import bigt.utils.StringUtils;
	
	import flash.events.EventDispatcher;
	import flash.events.IEventDispatcher;
	import flash.events.TimerEvent;
	import flash.utils.ByteArray;
	import flash.utils.Timer;
	import flash.utils.getTimer;
	
	import nochump.util.zip.ZipEntry;
	import nochump.util.zip.ZipOutput;
	import models.FileInfoWrapper;
	
	public class FilePackager extends EventDispatcher
	{
		public var pack:ByteArray;
		
		private var output:ZipOutput;
		
		public function FilePackager()
		{
			output = new ZipOutput();
			ZipOutput.CHARSET = "gbk";
		}
		
		
		/**
		 * 根据客户端操作系统, 设置使用的字符集. 默认为 'gbk'. <br/>
		 * 不正确的设置会导致压缩文件内压缩列表出现乱码
		 */
		public function set charset( chs:String ):void
		{
			ZipOutput.CHARSET = chs;
		}
		
		
		public function putFile( fileInfo:FileInfoWrapper, data:ByteArray ):void
		{
			if ( StringUtils.isEmpty(fileInfo.filename) || data.length <= 0 )
				throw new Error("文件名及文件数据皆不可为空!");
			
			var entry:ZipEntry = new ZipEntry(fileInfo.filename);
			if ( fileInfo.modificationDate )
				entry.time = fileInfo.modificationDate.time;
			output.putNextEntry(entry);
			output.write(data);
			output.closeEntry();
		}
		
		
		public function done():void
		{
			output.finish();
			this.pack = output.byteArray;
		}
		
	}
}