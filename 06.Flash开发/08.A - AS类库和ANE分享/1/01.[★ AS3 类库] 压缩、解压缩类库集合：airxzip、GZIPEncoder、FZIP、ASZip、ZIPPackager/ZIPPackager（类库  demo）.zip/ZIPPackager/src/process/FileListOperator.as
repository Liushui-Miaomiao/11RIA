package process
{
	import bigt.iterable.containsValue;
	import bigt.iterable.empty;
	import bigt.iterable.unique;
	
	import flash.events.EventDispatcher;
	import flash.events.IEventDispatcher;
	import flash.net.FileReference;
	
	import mx.collections.ArrayCollection;
	import events.FileListDataEvent;
	
	
	[Event(name="fileListDataAdd", type="events.FileListDataEvent")]
	/**
	 * 往压缩列表里添加重复文件时触发
	 */
	[Event(name="fileExist", type="events.FileListDataEvent")]
	public class FileListOperator extends EventDispatcher
	{
		private var data:ArrayCollection;
		
		
		/**
		 * @param fileListData 需要进行操作的文件列表数据
		 */
		public function FileListOperator( fileListData:ArrayCollection )
		{
			this.data = fileListData;
		}
		
		
		/**
		 * 为列表增加文件项目
		 * 
		 * @param value 要添加到列表的文件. 可以是单个的文件, 也可以是一个数组
		 */
		public function add( value:Object ):void
		{
			if (!data)
				data = new ArrayCollection();
			var e:FileListDataEvent;
			
			if ( value is Array ) 
			{
				var arr:Array = new Array();
				for each ( var i:Object in value )
				{
					if ( !containsValue( this.data, i, equals ) )
						arr.push(i);
					else{
						e = new FileListDataEvent( FileListDataEvent.FILE_EXIST );
						e.fileListData = i;
						dispatchEvent(e);
					}
				}
				data.source = arr.concat( data.source ); 
				e = new FileListDataEvent( FileListDataEvent.FILE_LIST_DATA_ADD );
				e.fileListData = arr;
			}else{
				if ( !containsValue( this.data, value, equals ) )
				{
					data.addItem(value);
					e = new FileListDataEvent( FileListDataEvent.FILE_LIST_DATA_ADD );
					e.fileListData = value;
				}else{
					e = new FileListDataEvent( FileListDataEvent.FILE_EXIST );
					e.fileListData = value;
				}
			}
			
			dispatchEvent(e);
			
			// 非完全性比较两个文件对象的相等性
			function equals( a:Object, b:Object ):Boolean
			{
				return a.name == b.name && a.size == b.size;
			}
		}
		
		
		/**
		 * 清空文件列表
		 */
		public function clearData():void
		{
			if ( empty( this.data ) )
				return;
			this.data.source = new Array();
		}
		
		
		/**
		 * 移除文件列表单项
		 */
		public function removeData( value:FileReference ):Boolean
		{
			var removedFlag:Boolean = false;
			for (var i:int = 0; i < this.data.length; i++) 
				if ( this.data[i] == value )
				{
					this.data.removeItemAt(i);
					removedFlag = true;
				}
			return removedFlag;
			
		}
									
		
		
		/*
		 * @private
		 * 用于 FileReference 简单排序的 compare 函数
		 *
		private function compareFileReference( a:Object, b:Object ):int
		{
			if ( a === b )
				return 0;
			if ( a.name > b.name )
				return 1;
			else if ( a.name == b.name ){
				if ( a.size > b.size )
					return 1;
				else if ( a.size == b.size )
					return 0;
				else
					return -1;
			}else
				return -1;
		}*/
	}
}