package process
{
	import bigt.utils.ArrayUtils;
	
	import flash.utils.ByteArray;
	
	import models.FileInfoWrapper;
	
	import nochump.util.zip.ZipEntry;
	import nochump.util.zip.ZipError;
	import nochump.util.zip.ZipFile;
	import nochump.util.zip.ZipOutput;

	public class FileExtracter
	{
		private var zip:ZipFile;
		
		public function FileExtracter( fileData:ByteArray )
		{
			ZipOutput.CHARSET = "gbk";
			try
			{
				zip = new ZipFile(fileData);
			} 
			catch( error:ZipError ) 
			{
				throw error;
			}
			
		}
		
		/**
		 * 根据客户端操作系统, 设置使用的字符集. 默认为 'gbk'. <br/>
		 * 不正确的设置会导致压缩文件内压缩列表出现乱码
		 */
		public function set charset( chs:String ):void
		{
			ZipOutput.CHARSET = chs;
		}
		
		
		public function extractFileList():Array
		{
			var entries:Array = this.zip.entries;
			var result:Array = new Array( entries.length );
			
			for (var i:int = 0; i < entries.length; i++) 
			{
				var entry:ZipEntry = entries[i] as ZipEntry;
				entry.name.position = 0;
				var filename:String = entry.name.readMultiByte( entry.name.length, ZipOutput.CHARSET );
				var fi:FileInfoWrapper = new FileInfoWrapper(filename);
				fi.modificationDate = new Date( entry.time );
				fi.size = entry.size;
				result[i] = fi;
			}
			return result;
		}
		
		
		public function getFileData( fileInfo:FileInfoWrapper ):ByteArray
		{
			var entry:ZipEntry = findCorrespondingZipEntry( fileInfo.filename );
			if (entry)
				return zip.getInput(entry);
			return null;
		}
		
		
		private function findCorrespondingZipEntry( filename:String ):ZipEntry
		{
			var comBa:ByteArray = new ByteArray();
			comBa.writeMultiByte( filename, ZipOutput.CHARSET );
			var entries:Array = this.zip.entries;
			for each (var entry:ZipEntry in entries) 
			{
				if ( ArrayUtils.eqByteArray( comBa, entry.name ) )
					return entry;
			}
			return null;
		}
		
	}
}