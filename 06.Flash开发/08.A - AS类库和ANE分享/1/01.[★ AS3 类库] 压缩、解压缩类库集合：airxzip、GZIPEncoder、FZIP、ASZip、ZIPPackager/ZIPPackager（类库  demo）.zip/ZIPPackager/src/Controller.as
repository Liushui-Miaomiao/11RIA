package
{
	import bigt.iterable.empty;
	
	import events.FileListDataEvent;
	
	import flash.events.Event;
	import flash.events.EventDispatcher;
	import flash.net.FileReference;
	import flash.utils.ByteArray;
	
	import models.AppModel;
	import models.FileInfoWrapper;
	
	import mx.collections.ArrayCollection;
	
	import nochump.util.zip.ZipError;
	
	import process.FileExtracter;
	import process.FileListOperator;
	import process.FilePackager;
	
	import spark.formatters.DateTimeFormatter;
	
	[Event(name="COMPLETE", type="flash.events.Event")]
	[Event(name="CANCEL", type="flash.events.Event")]
	
	public class Controller extends EventDispatcher
	{
		public static const PACKAGE_FILE_LIST:int = 1;
		public static const EXTRACT_FILE_LIST:int = 2;
		
		private var model:AppModel;
		// for log
		private var df:DateTimeFormatter = new DateTimeFormatter();
		
		public function Controller()
		{
			model = AppModel.getInstance();
			df.dateTimePattern = "HH:mm:ss";
		}
		
		
		public function addFiles( files:Array ):void
		{
			if ( empty(files) )
				return;
			var op:FileListOperator = new FileListOperator(model.packageFiles);
			op.addEventListener( FileListDataEvent.FILE_LIST_DATA_ADD, f );
			op.addEventListener( FileListDataEvent.FILE_EXIST, f1 );
			op.add(files);
			op.removeEventListener( FileListDataEvent.FILE_LIST_DATA_ADD, f );
			op.removeEventListener( FileListDataEvent.FILE_EXIST, f1 );
			
			function f( e:FileListDataEvent ):void
			{
				var obj:Object = e.fileListData;
				if ( obj is Array )
				{
					for (var i:int = 0; i < obj.length; i++) 
						if ( i >= obj.length - 1 )
							op.removeEventListener( FileListDataEvent.FILE_LIST_DATA_ADD, f );
					log( "将 " + obj.length + " 个文件添加到列表." );  
				}else
					log( "将文件: " + obj.name + " 添加到压缩列表." );
			}
			
			function f1( e:FileListDataEvent ):void
			{
				log("文件 " + e.fileListData.name + " 已经在列表中, 无法重复添加!");
			}
			
		}
		
		
		public function clearFiles( fileListType:int ):void
		{
			var op:FileListOperator;
			if ( fileListType == PACKAGE_FILE_LIST )
			{
				op = new FileListOperator( model.packageFiles );
				log("清除了压缩文件列表.");
			}
			
			if ( fileListType == EXTRACT_FILE_LIST )
			{
				op = new FileListOperator( model.extractFiles );
				log("清除了提取文件列表.");
			}
			
			op.clearData();
			
		}
		
		
		public function removeFile( f:FileReference ):Boolean
		{
			if ( empty( model.packageFiles ) || !f )
				return false;
			
			var op:FileListOperator = new FileListOperator( model.packageFiles );
			if ( op.removeData(f) )
			{
				this.log( "从压缩文件列表中移除了文件: " + f.name );
				return true;
			}else
				return false;
		}
		
		
		public function zipFiles():void
		{
			this.log( "开始压缩..." );
			var files:ArrayCollection = model.packageFiles;
			var packager:FilePackager = new FilePackager();
			var counter:int = 0;
			for (var i:int = 0; i < files.length; i++) 
			{
				files[i].addEventListener( Event.COMPLETE,
					function f(e:Event):void{
						var targetFile:FileReference = e.target as FileReference;
						targetFile.removeEventListener( Event.COMPLETE, f );
						var fi:FileInfoWrapper = new FileInfoWrapper(targetFile.name); 
						fi.modificationDate = targetFile.modificationDate;
						fi.size = targetFile.size;
						packager.putFile( fi, targetFile.data );
						if ( counter++ == files.length - 1 )
						{
							packager.done();
							log("压缩完成.");
							saveZipToDisk();
						}
				});
				FileReference(files[i]).load();
			}
			
			function saveZipToDisk():void
			{
				var file:FileReference = new FileReference();
				file.addEventListener( Event.COMPLETE, function f(e:Event):void{
					file.removeEventListener( Event.COMPLETE, f );
					log("磁盘写入成功.");
					dispatchEvent( new Event( Event.COMPLETE ) );
				});
				file.addEventListener( Event.CANCEL, function f1(e:Event):void{
					file.removeEventListener( Event.COMPLETE, f1 );
					dispatchEvent( new Event( Event.CANCEL ) );
				});
				file.addEventListener( Event.OPEN, function f2(e:Event):void{
					file.removeEventListener( Event.COMPLETE, f2 );
					log("开始写入磁盘.");
				});
					
				file.save( packager.pack, "compressedFile.zip" );
			} 
		}
		
		
		public function extractFileList( file:FileReference ):void
		{
			var extracter:FileExtracter;
			var source:Array;
			try
			{
				extracter = new FileExtracter( file.data );
				log( "解包: " + file.name );
				source = extracter.extractFileList();
				log( "共提取 " + source.length + "个文件." );
				model.extractData = file.data;
			} 
			catch(error:ZipError) 
			{
				log("选择的文件是无效的 ZIP 文件!");
				model.extractFiles = new ArrayCollection();
				model.extractData = null;
				return;
			}
			var listOp:FileListOperator = new FileListOperator( model.extractFiles );
			listOp.add(source);
		}
		
		
		public function saveFileToDisk( fileInfo:FileInfoWrapper ):void
		{
			model.extractData.position = 0;
			var extracter:FileExtracter = new FileExtracter( model.extractData );
			var data:ByteArray = extracter.getFileData(fileInfo);
			
			var writer:FileReference = new FileReference();
			writer.addEventListener( Event.COMPLETE, function f(e:Event):void{
				writer.removeEventListener( Event.COMPLETE, f );
				log("选择的项目另存为文件: " + writer.name );
				dispatchEvent( new Event( Event.COMPLETE ) );
			});
			writer.addEventListener( Event.CANCEL, function f2(e:Event):void{
				writer.removeEventListener( Event.CANCEL, f2 );
				dispatchEvent( new Event( Event.CANCEL ) );
			});
			writer.save( data, fileInfo.filename );
		}
		
		
		private function log( msg:String ):void
		{
			model.log += msg + "  " + df.format( new Date() ) + "\n";
		}
		
		/**
		 * 执行移除监听器等清理程序
		 */
		public function doClear():void{}
	}
}