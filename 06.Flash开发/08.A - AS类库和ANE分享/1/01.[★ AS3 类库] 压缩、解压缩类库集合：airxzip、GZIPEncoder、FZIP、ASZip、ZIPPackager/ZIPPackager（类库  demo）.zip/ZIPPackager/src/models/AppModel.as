package models
{
	import flash.events.EventDispatcher;
	import flash.events.IEventDispatcher;
	import flash.utils.ByteArray;
	
	import mx.collections.ArrayCollection;
	import mx.collections.IList;
	
	public class AppModel extends EventDispatcher
	{
		private static var _instance:AppModel;
		
		[Bindable]
		public var packageFiles:ArrayCollection;
		[Bindable]
		public var extractFiles:ArrayCollection;
		public var extractData:ByteArray;
		
		[Bindable]
		public var log:String = "";
		
		public function AppModel( sf:SingletonEnforcer )
		{
			this.packageFiles = new ArrayCollection();
			this.extractFiles = new ArrayCollection();
		}
		
		public static function getInstance():AppModel
		{
			if ( !_instance )
				_instance = new AppModel( new SingletonEnforcer() );
			return _instance;
		}
		
	}
}

class SingletonEnforcer{ public function SingletonEnforcer(){} }