package com.durej.PSDParser {
	import flash.utils.ByteArray;

	/**
	 * @author Slavomir Durej
	 */
	public class PSDChannelInfoVO {
		public var id:int=0;
		public var length:uint=0;

		public function PSDChannelInfoVO(fileData:ByteArray) {
			id=fileData.readShort();
			length=fileData.readUnsignedInt();
		}
	}
}
