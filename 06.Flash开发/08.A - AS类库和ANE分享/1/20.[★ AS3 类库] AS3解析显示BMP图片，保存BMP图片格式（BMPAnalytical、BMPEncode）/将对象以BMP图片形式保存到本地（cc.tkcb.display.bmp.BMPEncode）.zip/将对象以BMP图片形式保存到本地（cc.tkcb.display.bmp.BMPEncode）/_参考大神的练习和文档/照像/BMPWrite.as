﻿package  {
	import flash.utils.ByteArray;
	import flash.utils.Endian;
	import flash.display.BitmapData;
	public class BMPWrite {
		private var mydata:ByteArray;
		//文件数据
		private var mybitmap:BitmapData;
		//图像数据
		private var shulian:uint=0;
		//计数
		private var biWidth:uint;//BMP图像的宽度，单位像素
		private var biHeight:uint;//BMP图像的高度，单位像素
		
		private var wenjianchangdu:uint;//文件长度
		private var tuxianshujudaxiao:uint;//图像数据大小
		private var tuxianshujudizhi:uint;//图像数据地址
		private var Offset:uint;//每行偏移 
		
		public function BMPWrite() {
			// constructor code			
			this.mydata=new ByteArray();
			this.mydata.endian=Endian.LITTLE_ENDIAN;			;
		}
		//构造函数
		private function BITMAPFILEHEADER():void
		{
			this.biWidth=this.mybitmap.width;
			this.biHeight=this.mybitmap.height;
			var Offset:uint;//每行偏移
			Offset=(this.biWidth*3)&0x3;
			if(Offset>0){
				Offset=4-Offset;
			}
			//计算每行偏移
			this.tuxianshujudaxiao=this.biHeight*(this.biWidth*3+Offset);
			//计算位图数据的大小
			this.wenjianchangdu=54+this.tuxianshujudaxiao;
			//计算文件的长度
			this.mydata.writeUTFBytes("BM");
			//跳过文件长度
			this.mydata.writeUnsignedInt(this.wenjianchangdu);
			//写入文件的长度
			this.mydata.writeShort(0);
			this.mydata.writeShort(0);
			//跳过BMP图像数据的地址			
			this.tuxianshujudizhi=54;
			this.mydata.writeUnsignedInt(this.tuxianshujudizhi);
			//写入图像数据地址
		}//位图文件头
		private function BITMAPINFOHEADER():void
		{		
			this.mydata.writeUnsignedInt(40);
			this.mydata.writeUnsignedInt(this.mybitmap.width);
			this.mydata.writeUnsignedInt(this.mybitmap.height);
			this.mydata.writeShort(1);
			this.mydata.writeShort(24);
			this.mydata.writeUnsignedInt(0);
			//跳过BMP图像数据大小			
			this.mydata.writeUnsignedInt(this.tuxianshujudaxiao);
			//写入图像数据大小
			this.mydata.writeUnsignedInt(2834);
			this.mydata.writeUnsignedInt(2834);
			//72像素每英寸
			this.mydata.writeUnsignedInt(0);
			this.mydata.writeUnsignedInt(0);			
		}//位图信息头40个字节
		public function get byteData():ByteArray
		{
			if(this.mydata.length==0)throw new Error("未写入数据，文件数据为空!");
			return this.mydata;
		}
		//输出文件数据
		public function set saveData(pic:BitmapData):void
		{
			this.mybitmap=pic;
			this.mydata.clear();
			BITMAPFILEHEADER();
			BITMAPINFOHEADER();
			bitmapdata();
		}//设置保存数据
		private function bitmapdata():void
		{
			var i:uint,j:uint,p:uint,color:uint,r:uint,g:uint,b:uint,k:uint;			
			for(i=0;i<this.biHeight;i++){
				for(j=0;j<this.biWidth;j++)
				{					
					color=this.mybitmap.getPixel(j,this.biHeight-i-1);
					b=color&0xff;
					g=(color>>8)&0xff;
					r=color>>16;
					this.mydata.writeByte(b);
					this.mydata.writeByte(g);
					this.mydata.writeByte(r);					
					if(j==this.biWidth-1&&Offset!=0){						
						for(k=0;k<Offset;k++){
							this.mydata.writeByte(0);
						}
					}
				}
			}
		}
		//图像数据
	}
}
//写入BMP文件
//BMP文件格式：24位图像
		