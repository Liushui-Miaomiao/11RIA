﻿/**
 * com.voidelement.images.ico.ICODecoder  Class for ActionScript 3.0
 *
 * @author       Copyright (c) 2008 munegon
 * @version      1.0
 *
 * @link         http://www.voidelement.com/
 * @link         http://void.heteml.jp/blog/
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */



/*
 * 修 改 者：TKCB
 * 修者信息：身高（0.00167公里+）；体重（0.06吨±）；年龄（公元1990后）；籍贯（有兵马俑的地方）；星座（最后一个星座）；血型（万能型）；人生格言（The king come back.）。
 * 交流学习：加QQ群[AS3殿堂之路]（96759336），群里有无数主城、架构、妹子、LOL战友，欢迎交流讨论。
 * 联系方式：QQ（2414268040）；E-mail（tkcb@qq.com）；手机（15029932353)。
 * 个人网站：www.tkcb.cc（来这里关注我吧，这里有我所有的作品，分享的资料，我的介绍和动态，还有更多你想不到的）
 */

/* 
 * @version 版本创建时间和修改说明
 * v1.0.0 2017-2-16
 */

package cc.tkcb.display.ico
{
	import flash.display.BitmapData;
	
	import flash.utils.ByteArray;
	
	
	/**
	 * ICODecoder ICO格式解析类，用于解析ICO格式二进制数据，并且从中获取位图数据信息。 
	 * @author TKCB（www.tkcb.cc）
	 * @创建时间 未知
	 * @修改时间 2017-2-16
	 * @version 1.0.0
	 */
	public class ICODecoder
	{
		private static var _verbose: Boolean = false;

		private static function get verbose(): Boolean
		{
			return _verbose;
		}

		private static function set verbose(value: Boolean): void
		{
			_verbose = value;
		}


		private var _header: ICOFileHeader = null;

		public function get header(): ICOFileHeader
		{
			return _header;
		}



		private const image_arr: Array = [];

		/**
		 * コンストラクタ
		 */
		public function ICODecoder()
		{

		}


		/**
		 * デコード
		 *
		 * @param デコードしたいICOファイルのバイナリデータ
		 */
		public function decode(stream: ByteArray): Array
		{
			_header = new ICOFileHeader(stream);

			var info_arr: Array = [];
			for (var i: int = 0; i < header.num; ++i)
			{
				info_arr.push(new ICOInfoHeader(stream));
			}

			for (var j: int = 0; j < header.num; ++j)
			{
				var ih: ICOInfoHeader = info_arr[j];
				stream.position = ih.offset;
				image_arr.push(new ICOImageData(stream));
			}

			return image_arr;
		}


		public function getIcon(): BitmapData
		{
			for each(var ic: ICOImageData in image_arr)
			{
				if (ic.info.bitsPerPixel == 32 && ic.info.width == 48)
				{
					return ic.image;
				}
			}

			var bit: int = -1;
			var size: int = -1;
			var b: BitmapData = null;
			for each(ic in image_arr)
			{
				if (ic.info.width > size && ic.info.bitsPerPixel > bit)
				{
					b = ic.image;
					bit = ic.info.bitsPerPixel;
					size = ic.info.width;
				}
			}
			return b;
		}


		/**
		 * ログ出力
		 */
		public static function log(message: String): void
		{
			if (verbose)
			{
				trace(message);
			}
		}
	}
}