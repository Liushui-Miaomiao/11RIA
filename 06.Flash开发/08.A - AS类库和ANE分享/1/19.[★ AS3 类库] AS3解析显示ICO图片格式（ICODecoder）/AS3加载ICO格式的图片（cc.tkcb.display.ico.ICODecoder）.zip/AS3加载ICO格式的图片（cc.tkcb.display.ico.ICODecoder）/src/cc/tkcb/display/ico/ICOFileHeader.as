﻿/**
 * com.voidelement.images.ico.ICODecoder  Class for ActionScript 3.0
 *
 * @author       Copyright (c) 2008 munegon
 * @version      1.0
 *
 * @link         http://www.voidelement.com/
 * @link         http://void.heteml.jp/blog/
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND,
 * either express or implied. See the License for the specific language
 * governing permissions and limitations under the License.
 */

/*
 * 修 改 者：TKCB
 * 修者信息：身高（0.00167公里+）；体重（0.06吨±）；年龄（公元1990后）；籍贯（有兵马俑的地方）；星座（最后一个星座）；血型（万能型）；人生格言（The king come back.）。
 * 交流学习：加QQ群[AS3殿堂之路]（96759336），群里有无数主城、架构、妹子、LOL战友，欢迎交流讨论。
 * 联系方式：QQ（2414268040）；E-mail（tkcb@qq.com）；手机（15029932353)。
 * 个人网站：www.tkcb.cc（来这里关注我吧，这里有我所有的作品，分享的资料，我的介绍和动态，还有更多你想不到的）
 */

/* 
 * @version 版本创建时间和修改说明
 * v1.0.0 2017-2-16
 */

package cc.tkcb.display.ico
{
	import flash.errors.IOError;
	
	import flash.utils.ByteArray;
	import flash.utils.Endian;
	
	
	/**
	 * ICOFileHeader 
	 * @author TKCB（www.tkcb.cc）
	 * @创建时间 未知
	 * @修改时间 2017-2-16
	 * @version 1.0.0
	 */
	public class ICOFileHeader
	{
		private const FILE_HEADER_SIZE: uint = 6;


		private var _type: uint = 0;

		public function get type(): uint
		{
			return _type;
		}

		private var _num: uint = 0;

		public function get num(): uint
		{
			return _num;
		}


		public function ICOFileHeader(stream: ByteArray)
		{
			var bytes: ByteArray = new ByteArray();
			bytes.endian = Endian.LITTLE_ENDIAN;

			try
			{
				stream.readBytes(bytes, 0, FILE_HEADER_SIZE);

				if (bytes.readShort() != 0x00)
				{
					throw new VerifyError("invalid icon file header signature");
				}

				_type = bytes.readUnsignedShort();
				_num = bytes.readUnsignedShort();
			}
			catch (e: IOError)
			{
				throw new VerifyError("invalid file icon header size");
			}
		}
	}
}