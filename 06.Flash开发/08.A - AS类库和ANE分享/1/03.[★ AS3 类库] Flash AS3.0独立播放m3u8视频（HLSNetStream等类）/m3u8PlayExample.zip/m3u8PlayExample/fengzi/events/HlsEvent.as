﻿package fengzi.events
{
	import flash.events.Event;

	public class HlsEvent extends Event
	{

		public static const STATUS:String = "Status";

		public var data:Object;

		/*
		* 构造函数
		*/

		public function HlsEvent(type:String, object:Object,bubbles:Boolean = false, cancelable:Boolean = false)
		{
			super(type, bubbles, cancelable);
			data = object;
		}


		/*
		* clone方法必须重写
		*/
		override public function clone():Event
		{
			return new HlsEvent(type, data,bubbles, cancelable);
		}



	}
}