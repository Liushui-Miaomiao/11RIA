﻿/**
 *
 * *---------------------------*
 * |  *** HlsProvider封装 ***  |
 * *---------------------------*
 *
 * 编辑修改收录：fengzi（疯子、wu341、wgq341）
 *
 * 不会写代码，我是代码搬运工。
 *
 * 联系方式：QQ（493712833）。
 *
 *
 * 版权协议：请自觉遵守LGPL协议，欢迎修改、复制、转载、传播给更多需要的人。
 * 免责声明：任何因使用此软件导致的纠纷与软件/程序开发者无关。
 * 日   期： 2016.06.12
 *
 */

package fengzi.hlsVideo
{


	import org.mangui.hls.HLSSettings;
	import org.mangui.hls.event.HLSEvent;
	import org.mangui.hls.HLS;
	import fengzi.events.HlsEvent;
	import org.mangui.hls.constant.HLSPlayStates;

	import flash.display.Sprite;
	import flash.media.Video;
	import flash.media.SoundTransform;
	
	import flash.utils.Timer;
	import flash.events.TimerEvent;
	import flash.display.StageDisplayState;
	import flash.display.MovieClip;
	
	/**
	* Flash独立播放m3u8视频的简单例子
	* author 疯子（wgq341）
	* date 12/06/2016
	*/

	public class HlsProvider extends MovieClip
	{
		private var hls:HLS;//HLS对象
		private var video:Video = null;//创建 Video
		private var _videoWidth:Number = 0;
		private var _videoHeight:Number = 0;
		private var _position:Number = 0;//播放头
		private var _duration:Number = 0;//总时间
		private var _percent:Number = 0;
		private var _autoLoad:Boolean = false;//视频地址是否为空
		private var _bufferBoolean:Boolean = true;
		private var m3u8Url:String;//视频地址
		private var stransform:SoundTransform;

		private var _index:int = 0;
		//m3u8地址（可以是array,XMLList）
		private var url:*;
		private var _stage:*;
		public function HlsProvider(_stage,url:*):void
		{
			this._stage = _stage;
			this.url = url;
			stransform = new SoundTransform();
			initHls()
			
		}

		private function initHls():void
		{

			hls = new HLS();

			HLSSettings.maxBufferLength = 10;//最大缓存长度

			HLSSettings.seekMode = "KEYFRAME";//查找模式

			hls.stage = _stage;
			hls.addEventListener(HLSEvent.MANIFEST_LOADED, manifestLoadedHandler);
			//当前播放回调;
			hls.addEventListener(HLSEvent.MEDIA_TIME, mediaTimeHandler);
			//片段播放回调;
			hls.addEventListener(HLSEvent.FRAGMENT_PLAYING, fragmentPlayingHandler);
			//当前视频状态回调;
			hls.addEventListener(HLSEvent.PLAYBACK_STATE, playbackStateHandler);


			// Video
			video = new Video();
			addChild(video);


			video.smoothing = true;
			video.attachNetStream(hls.stream);


		}
		

		//播放的方法
		public function initPlay():void
		{
			m3u8Url = url[_index];
			if (m3u8Url != null)
			{
				_autoLoad = true;
				//解析m3u8文件，播放
				loadUrl(m3u8Url);
			}
		}


		private function loadUrl(url:String):void
		{
			//传入的是m3u8文件地址，不是视频地址。播放器会自动解析m3u8文件，加载相应视频片段。
			hls.load(url);

		}
		private function manifestLoadedHandler(event:HLSEvent):void
		{
			_duration = event.levels[hls.startlevel].duration;
			if (_autoLoad)
			{
				streamPlay(-1);
			}
		}
		private function streamPlay(_position:Number = -1):void
		{
			hls.stream.play(null, _position);
		}





		private function fragmentPlayingHandler(event:HLSEvent):void
		{
			//获取视频的宽度，高度
			_videoWidth = event.playMetrics.video_width;
			_videoHeight = event.playMetrics.video_height;
			//视频缩放
			setSize(video,_videoWidth,_videoHeight,stage.stageWidth,stage.stageHeight-54);

		}


		private function mediaTimeHandler(event:HLSEvent):void
		{
			//视频总长度
			_duration = event.mediatime.duration;
			//频播放的当前位置
			_position = event.mediatime.position;
			//缓冲
			_percent = event.mediatime.buffer;
			//缓冲长度:event.mediatime.backbuffer
			//是否填满缓冲区
			if (event.state == 'PLAYING_BUFFERING')
			{
				_bufferBoolean = true;
				dispatchEvent(new HlsEvent(HlsEvent.STATUS,"Hls.Buffering"));
			}
			else
			{
				_bufferBoolean = false;
				dispatchEvent(new HlsEvent(HlsEvent.STATUS,"Hls.Buffer"));
			}

			if (_position>=_duration-0.5)
			{
				dispatchEvent(new HlsEvent(HlsEvent.STATUS,"Hls.Next"));
				next();
			}


		}

		private function playbackStateHandler(event : HLSEvent):void
		{
			switch (event.state)
			{
				case HLSPlayStates.IDLE :
				case HLSPlayStates.PLAYING :
					dispatchEvent(new HlsEvent(HlsEvent.STATUS,"Hls.Play"));
					break;
				case HLSPlayStates.PAUSED :
					dispatchEvent(new HlsEvent(HlsEvent.STATUS,"Hls.Pause"));
					break;
				case HLSPlayStates.PLAYING_BUFFERING :
				case HLSPlayStates.PAUSED_BUFFERING :
					break;
				default :
					break;
			}
		}



		//可视对象缩放工具（好象不应该写在这里，主要是为了看起来方便）
		private function setSize(value:Object, preferredWidth:Number, preferredHeight:Number, width:Number, height:Number):void
		{
			if (preferredWidth / preferredHeight > width / height)
			{
				value.width = width;
				value.height = value.width / preferredWidth * preferredHeight;
			}
			else
			{
				value.height = height;
				value.width = value.height / preferredHeight * preferredWidth;
			}
			value.x = (width - value.width) / 2;
			value.y = (height - value.height) / 2;
		}







		/********** 以下是公开的方法（需要其他方法可以去 HLS 找）******************/
		//播放
		public function resume():void
		{
			hls.stream.resume();
			dispatchEvent(new HlsEvent(HlsEvent.STATUS,"Hls.Resume"));
		}

		//暂停
		public function pause():void
		{
			hls.stream.pause();
			dispatchEvent(new HlsEvent(HlsEvent.STATUS,"Hls.Pause"));
		}

		//停止
		public function stopped():void
		{
			hls.stream.close();
			dispatchEvent(new HlsEvent(HlsEvent.STATUS,"Hls.Stop"));
		}


		//seek
		public function seek(value:Number):void
		{
			hls.stream.seek(value);
		}



		//上一个
		public function prev():void
		{
			if (url is XMLList)
			{
				_index = _index > 0 ? _index - 1:_index = url.length() - 1;
			}
			if (url is Array)
			{
				_index = _index > 0 ? _index - 1:_index = url.length - 1;
			}
			initPlay();
			dispatchEvent(new HlsEvent(HlsEvent.STATUS,"Hls.Prev"));
		}
		//下一个
		public function next():void
		{
			if (url is XMLList)
			{
				_index = _index < url.length() - 1 ? _index + 1:_index = 0;
			}
			if (url is Array)
			{
				_index = _index < url.length - 1 ? _index + 1:_index = 0;
			}
			initPlay();
			dispatchEvent(new HlsEvent(HlsEvent.STATUS,"Hls.Next"));
		}


		//缩放视频
		public function stageResize():void
		{
			setSize(video,_videoWidth,_videoHeight,stage.stageWidth,stage.stageHeight-54);
		}


		//播放地址集合的ID索引
		public function get index():int
		{
			return _index;
		}

		public function set index(value:int):void
		{
			_index = value;
		}



		public function get playbackState():String
		{
			return hls.playbackState;
		}

		public function get seekState():String
		{
			return hls.seekState;
		}


		//类型
		public function get type():String
		{
			return hls.type;
		}



		//音量
		public function get volume():Number
		{
			return stransform.volume;
		}

		public function set volume(value:Number):void
		{
			stransform.volume = value;
			if (hls != null)
			{
				hls.stream.soundTransform = stransform;
			}
		}


		//总长度
		public function get duration():Number
		{
			if (hls)
			{
				return _duration;
			}
			return 0;
		}

		//播放的位置
		public function get position():Number
		{
			return _position;
		}
		//单节缓冲
		public function get percent():Number
		{
			return _percent;
		}

		public function get bufferLength():Number
		{
			return hls.stream.bufferLength;
		}


		//总长度的缓冲进度
		public function get percentLoaded():Number
		{
			return (_position + _percent) / _duration;
		}


		//填满缓冲区的布尔值
		public function get bufferBoolean():Boolean
		{
			return _bufferBoolean;
		}


		//播放进度
		public function get playheadPercentage():Number
		{
			return _position / _duration;
		}


		//视频宽度
		public function get videoWidth():Number
		{
			return _videoWidth;
		}


		//视频高度
		public function get videoHeight():Number
		{
			return _videoHeight;
		}





	}

}