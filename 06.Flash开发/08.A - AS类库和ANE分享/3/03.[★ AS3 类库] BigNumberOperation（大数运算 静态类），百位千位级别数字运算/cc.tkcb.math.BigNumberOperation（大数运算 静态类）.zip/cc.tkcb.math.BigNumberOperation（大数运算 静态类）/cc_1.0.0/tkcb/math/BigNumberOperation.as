﻿/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 2017 TKCB, tkcb@qq.com
 *
 * 
 * This is free software/program/code: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * 这是一个自由软件/程序/代码，您可以自由分发、修改其中的源代码或者重新发布它，
 * 新的任何修改后的重新发布版必须同样在遵守LGPL3或更后续的版本协议下发布。
 * 关于LGPL协议的细则请参考COPYING、COPYING.LESSER文件，
 * 你可以在文件夹中获得LGPL协议的副本，如果没有找到，请连接到 http://www.gnu.org/licenses/ 查看。
 *
 *
 * 作　　者：TKCB
 * 作者信息：身高（0.00167公里+）；体重（0.06吨±）；年龄（公元1990后）；籍贯（有兵马俑的地方）；星座（最后一个星座）；血型（万能型）；人生格言（The king come back.）。
 * 交流学习：加QQ群[AS3殿堂之路]（96759336），群里有无数主城、架构、妹子、LOL战友，欢迎交流讨论。
 * 联系方式：QQ（2414268040）；E-mail（tkcb@qq.com）；手机（15029932353)。
 * 作者网站：www.tkcb.cc（来这里关注我吧，这里有我所有的作品，分享的资料，我的介绍和动态，还有更多你想不到的）
 *
 * 
 * 获取软件/程序最新版本：www.tkcb.cc
 *
 *
 * 版权协议：请自觉遵守LGPL协议，欢迎复制、转载、传播给更多需要的人。
 * 免责声明：任何因使用此软件导致的纠纷与软件/程序开发者无关。
 */


/* 
 * @version 版本创建时间和修改说明
 * v1.0.0 2017-2-13
 */


package cc.tkcb.math
{
	/**
	 * BigNumberOperation 大数运算静态类，用于处理非常大的数字的计算问题（解决方案为字符串），可以进行加、减、乘、除、模运算，以及随机生成超大数字、判断是否数字、对比数字大小。
	 * @author TKCB（www.tkcb.cc）
	 * @创建时间 2017-2-13
	 * @修改时间 2017-2-13
	 * @version 1.0.0
	 */
	public class BigNumberOperation
	{
		//************************ ************************* 加法 ******************** *********** *** **////
		/**
		 * 加法，两个数字相加（不能有负数，可以是正数和小数）
		 * @param num1 数字1
		 * @param num2 数字2
		 * @return 相加的结果数字
		 */
		public static function add ( num1:String, num2:String ) : String
		{
			// 都是正数
			if ( num1.charAt(0) != "-" && num2.charAt(0) != "-" )
			{
				return addition( num1, num2 );
			}
			// 数字1为负数
			else if ( num1.charAt(0) == "-" && num2.charAt(0) != "-" )
			{
				num1 = num1.substr( 1, num1.length-1 );
				if ( contrastNumber( num1, num2 ) == 2 )
				{
					return subtract( num2, num1 );
				}
				else if ( contrastNumber( num1, num2 ) == 1 )
				{
					return "-" + subtract( num2, num1 );
				}
				else
				{
					return "0";
				}
			}
			// 数字2为负数
			else if ( num1.charAt(0) != "-" && num2.charAt(0) == "-" )
			{
				num2 = num2.substr( 1, num2.length-1 );
				if ( contrastNumber( num1, num2 ) == 1 )
				{
					return subtract( num1, num2 );
				}
				else if ( contrastNumber( num1, num2 ) == 2 )
				{
					return "-" + subtract( num2, num1 );
				}
				else
				{
					return "0";
				}
			}
			// 都是负数
			else
			{
				num1 = num1.substr( 1, num1.length-1 );
				num2 = num2.substr( 1, num2.length-1 );
				return "-" + addition( num1, num2 );
			}
		}
		
		/**
		 * 加法，两个数字相加（不能有负数，可以是正数和小数）
		 * @param num1 数字1
		 * @param num2 数字2
		 * @return 相加的结果数字
		 */
		private static function addition ( num1:String, num2:String ) : String
		{
			var i:int, len:int;
			
			// 给两个数字去除小数，然后将两个数字的位数设置为统一的大小位（不是长度一致）
			var dpArr : Array = setUnifiedDecimalPoint( num1, num2 );
			var dpArr1 : Array = dpArr[0];
			var dpArr2 : Array = dpArr[1];
			var dpNum1 : String = dpArr1[0];
			var dpNum2 : String = dpArr2[0];
			
			// 从最小的数字开始一位一位的计算
			var newNum : String = "";
			var bitNum1 : int;
			var bitNum2 : int;
			var bitNum3 : int;
			var carryNum : int = 0;		// 如果相加大于等于10，则进一位，此变量为1（进位的）
			var isForEndNum: int = 0;
			len = dpNum1.length < dpNum2.length ? dpNum1.length : dpNum2.length;
			for ( i = 1; i <= len; i++ )
			{
				bitNum1 = int( dpNum1.charAt(dpNum1.length - i) );
				bitNum2 = int( dpNum2.charAt(dpNum2.length - i) );
				bitNum3 = bitNum1 + bitNum2 + carryNum;
				
				if ( bitNum3 >= 10 )
				{
					bitNum3 = bitNum3 - 10;
					carryNum = 1;
				}
				else
				{
					carryNum = 0;
				}
				newNum = bitNum3 + newNum;
				if ( carryNum == 1 && i == len )
				{
					isForEndNum += 1;
					len += 1;
				}
			}
			
			// 补上没有计算完毕的数字（更多的大的数字）
			carryNum = isForEndNum;
			if ( dpNum1.length != dpNum2.length )
			{
				var tempNum : int;
				if ( dpNum1.length > dpNum2.length )
				{
					tempNum = dpNum1.length - dpNum2.length;
					newNum = dpNum1.substring( 0, tempNum - carryNum ) + newNum;
				}
				else
				{
					tempNum = dpNum2.length - dpNum1.length;
					newNum = dpNum2.substring( 0, tempNum - carryNum ) + newNum;
				}
			}
			
			// 加上小数点返回数字
			return addDecimalPoint( newNum, dpArr2[1] );
		}
		
		
		//************************ ************************* 减法 ******************** *********** *** **////
		/**
		 * 减法，两个数字相减
		 * @param num1 数字1
		 * @param num2 数字2
		 * @return 相减的结果数字
		 */
		public static function sub ( num1:String, num2:String ) : String
		{
			// 都是正数
			if ( num1.charAt(0) != "-" && num2.charAt(0) != "-" )
			{
				if ( contrastNumber( num1, num2 ) == 2 )
				{
					return "-" + subtract( num2, num1 );
				}
				else if ( contrastNumber( num1, num2 ) == 1 )
				{
					return subtract( num1, num2 );
				}
				else
				{
					return "0";
				}
			}
			// 数字1为负数
			else if ( num1.charAt(0) == "-" && num2.charAt(0) != "-" )
			{
				num1 = num1.substr( 1, num1.length-1 );
				return "-" + addition( num1, num2 );
			}
			// 数字2为负数
			else if ( num1.charAt(0) != "-" && num2.charAt(0) == "-" )
			{
				num2 = num2.substr( 1, num2.length-1 );
				return addition( num1, num2 );
			}
			// 都是负数
			else
			{
				num1 = num1.substr( 1, num1.length-1 );
				num2 = num2.substr( 1, num2.length-1 );
				if ( contrastNumber( num1, num2 ) == 2 )
				{
					return subtract( num2, num1 );
				}
				else if ( contrastNumber( num1, num2 ) == 1 )
				{
					return "-" + subtract( num1, num2 );
				}
				else
				{
					return "0";
				}
			}
		}
		
		/**
		 * 减法，两个数字相减（不能有负数，可以是正数和小数）
		 * @param num1 数字1
		 * @param num2 数字2
		 * @return 相减的结果数字
		 */
		private static function subtract ( num1:String, num2:String ) : String
		{
			var i:int, len:int;
			
			// 给两个数字去除小数，然后将两个数字的位数设置为统一的大小位（不是长度一致）
			var dpArr : Array = setUnifiedDecimalPoint( num1, num2 );
			var dpArr1 : Array = dpArr[0];
			var dpArr2 : Array = dpArr[1];
			
			// 并且将大的数字为1，小的数字为2，也就是确保后面的一系列计算是大数减去小数
			var bigNum : int;
			if ( contrastSize(dpArr1[0], dpArr2[0]) == 1 )
			{
				bigNum = 1;
			}
			else
			{
				bigNum = 2;
			}
			// 按照大小重新设置数字1和数字2对应的数字
			if ( bigNum == 2 )
			{
				dpArr1 = dpArr[1];
				dpArr2 = dpArr[0];
			}
			var dpNum1 : String = dpArr1[0];
			var dpNum2 : String = dpArr2[0];
			
			// 从最小的数字开始一位一位的计算
			var newNum : String = "";
			var bitNum1 : int;
			var bitNum2 : int;
			var bitNum3 : int;
			var carryNum : int = 0;		// 如果数字1的当前位不够减去数字2的当前位，则从前一位借1，则此变量为1
			var isForEnd : Boolean = false;
			len = dpNum1.length;
			for ( i = 1; i <= len; i++ )
			{
				// 对于上一位数字从本位借1的情况，进行特殊处理
				bitNum1 = int( dpNum1.charAt(dpNum1.length - i) ) - carryNum;
				if ( bitNum1 == -1 )
				{
					bitNum1 = 9;
					carryNum = 1;
				}
				else
				{
					carryNum = 0;
				}
				
				// 对于多余的位（因为第二个数字可能长度小于第一个数字），进行特殊处理
				if ( dpNum2.charAt(dpNum2.length - i) != "" )
				{
					bitNum2 = int( dpNum2.charAt(dpNum2.length - i ));
				}
				else
				{
					bitNum2 = 0;
				}
				
				// 对于本位数字不够大，进行借1处理
				if ( bitNum2 > bitNum1 )
				{
					carryNum = 1;
					bitNum1 = int("1" + bitNum1.toString());
				}
				bitNum3 = bitNum1 - bitNum2;
				
				// 对于最后一位如果是0，进行特殊处理
				if ( i == len )
				{
					if ( bitNum3 != 0 )
					{
						newNum = bitNum3 + newNum;
					}
					else
					{
						newNum = newNum;
					}
				}
				else
				{
					newNum = bitNum3 + newNum;
				}
			}
			
			// 加上小数点返回数字
			return addDecimalPoint( newNum, dpArr2[1] );
		}


		//************************ ************************* 乘法 ******************** *********** *** **////
		/**
		 * 乘法，两个数字相乘
		 * @param num1 数字1
		 * @param num2 数字2
		 * @return 相乘的结果数字
		 */
		public static function mul ( num1:String, num2:String ) : String
		{
			// 都是正数
			if ( num1.charAt(0) != "-" && num2.charAt(0) != "-" )
			{
				return multiply( num1, num2 );
			}
			// 数字1为负数
			else if ( num1.charAt(0) == "-" && num2.charAt(0) != "-" )
			{
				num1 = num1.substr( 1, num1.length-1 );
				return "-" + multiply( num1, num2 );
			}
			// 数字2为负数
			else if ( num1.charAt(0) != "-" && num2.charAt(0) == "-" )
			{
				num2 = num2.substr( 1, num2.length-1 );
				return "-" + multiply( num1, num2 );
			}
			// 都是负数
			else
			{
				num1 = num1.substr( 1, num1.length-1 );
				num2 = num2.substr( 1, num2.length-1 );
				return multiply( num1, num2 );
			}
		}
		
		/**
		 * 乘法，两个数字相乘（不能有负数，可以是正数和小数）
		 * @param num1 数字1
		 * @param num2 数字2
		 * @return 相乘的结果数字
		 */
		private static function multiply ( num1:String, num2:String ) : String
		{
			var i:int, len:int;
			var j:int, len2:int;
			
			// 给两个数字去除小数，然后将两个数字的位数设置为统一的大小位（不是长度一致）
			var dpArr : Array = setUnifiedDecimalPoint( num1, num2 );
			var dpArr1 : Array = dpArr[0];
			var dpArr2 : Array = dpArr[1];
			var dpNum1 : String = dpArr1[0];
			var dpNum2 : String = dpArr2[0];
			
			// 从最小的数字开始一位一位的计算
			var newNum : String;
			var newNum2 : String = "0";	// 这个是最终的数字，上面那个是临时合成的
			var bitNum1 : int;
			var bitNum2 : int;
			var bitNum3 : int;
			var carryNum : int = 0;		// 如果相加大于等于10，则进一位，此变量为1-8（进位的，之所以不是1-9是因为9*9最大才是“8”1）
			var isForEnd : Boolean;
			len2 = dpNum2.length;
			for ( j = 1; j <= len2; j++ )
			{
				newNum = "";
				isForEnd = false;
				len = dpNum1.length;
				for ( i = 1; i <= len; i++ )
				{
					bitNum1 = int( dpNum1.charAt(dpNum1.length - i) );
					bitNum2 = int( dpNum2.charAt(dpNum2.length - j) );
					bitNum3 = bitNum1 * bitNum2 + carryNum;
					if ( bitNum3 >= 10 )
					{
						carryNum = int( bitNum3.toString().charAt(0) );
						bitNum3 =int( bitNum3.toString().charAt(1) );
					}
					else
					{
						carryNum = 0;
					}
					newNum = bitNum3 + newNum;
					if ( carryNum != 0 && i == len && isForEnd == false )
					{
						isForEnd = true;
						len += 1;
					}
				}
				// 按照当前的进位，给前的临时值加上对应个数的“0”
				len = j;
				for ( i = 1; i < len; i++ )
				{
					newNum = newNum + "0";
				}
				newNum2 = addition( newNum, newNum2 );
			}
			
			// 加上小数点
			newNum2 = addDecimalPoint( newNum2, dpArr2[1]*2 );
			
			// 返回数字
			return newNum2;
		}


		//************************ ************************* 除法 ******************** *********** *** **////
		/**
		 * 除法，两个数字相除
		 * @param num1 数字1
		 * @param num2 数字2
		 * @param retain 最大保留多余位数，防止出现无线循环小数程序死循环，程序会按照传入的位数保留原数字1长度+isRetain位数的数字
		 * @return 相除的结果数字
		 */
		public static function div ( num1:String, num2:String, retain:int = 20 ) : String
		{
			// 都是正数
			if ( num1.charAt(0) != "-" && num2.charAt(0) != "-" )
			{
				return division( num1, num2 );
			}
			// 数字1为负数
			else if ( num1.charAt(0) == "-" && num2.charAt(0) != "-" )
			{
				num1 = num1.substr( 1, num1.length-1 );
				return "-" + division( num1, num2 );
			}
			// 数字2为负数
			else if ( num1.charAt(0) != "-" && num2.charAt(0) == "-" )
			{
				num2 = num2.substr( 1, num2.length-1 );
				return "-" + division( num1, num2 );
			}
			// 都是负数
			else
			{
				num1 = num1.substr( 1, num1.length-1 );
				num2 = num2.substr( 1, num2.length-1 );
				return division( num1, num2 );
			}
		}
		
		/**
		 * 除法，两个数字相除（不能有负数，可以是正数和小数）
		 * @param num1 数字1
		 * @param num2 数字2
		 * @param retain 最大保留多余位数，防止出现无线循环小数程序死循环，程序会按照传入的位数保留原数字1长度+isRetain位数的数字
		 * @return 相除的结果数字
		 */
		private static function division ( num1:String, num2:String, retain:int = 20 ) : String
		{
			var i:int, len:int;
			
			// 给两个数字去除小数，然后将两个数字的位数设置为统一的大小位（不是长度一致）
			var dpArr : Array = setUnifiedDecimalPoint( num1, num2 );
			
			var dpArr1 : Array = dpArr[0];
			var dpArr2 : Array = dpArr[1];
			var dpNum1 : String = dpArr1[0];
			var dpNum2 : String = dpArr2[0];
			
			// 防止出现“0/0=1”的情况
			if ( dpNum1 == dpNum2 && dpNum1 == "0" )
			{
				return "0";
			}
			
			// 防止出现两个数其中一个为“0”的情况
			if ( dpNum1 == "0" || dpNum2 == "0" )
			{
				return "0";
			}
			
			// 最大保留多余位数，对应的最大值为retain参数的值
			var maxRetain : int = 0;
			
			// 一遍遍的用数字1减去数字2，整个运算分为两个步骤（部分）
			// 第一个步骤数字数2远远小于数字1，需要数字2增大位数进行减法计算
			// 第二个步骤数字1小于数字2，需要数字1增大位数进行减法计算（如果数字1开始就小于数字2，则直接开始第二个步骤）
			var isOne : Boolean = contrastSize(dpNum1, dpNum2) == 1 ? true : false;	// 是否第一个步骤，true表示是第一个步骤，false表示是第二个步骤
			var quotientNum : String = "0";		// 这个是除法的商，也就是最终结果
			var additionNum : String;			// 每轮循环时候，商要增加的值
			var tempDPNum2 : String;			// 临时的数字2
			var multiple1 : int = 0;			// 数字1变大的倍数
			var multiple2 : int = 0;			// 数字2变大的倍数
			var special : Boolean = false;		// 特殊情况
			len = dpNum1.length;
			for ( ; ; )
			{
				// 第一个步骤
				if ( isOne )
				{
					multiple2 = 0;
					tempDPNum2 = dpNum2;
					
					// 数字1太大，为了快速减法，所以将两个数字长度调整到一致
					if ( dpNum1.length > dpNum2.length )
					{
						len = dpNum1.length - dpNum2.length;
						for ( i = 0; i < len; i++ )
						{
							tempDPNum2 += "0";
						}
						multiple2 = len;
						
						// 如果调整长度之后数字2大于数字1，则减去一位长度
						if ( contrastSize(dpNum1, tempDPNum2) == 2 )
						{
							tempDPNum2 = tempDPNum2.substr( 0, tempDPNum2.length-1 );
							multiple2 -= 1;
						}
					}
					
					// 根据减去的倍数，算出本轮循环“商”要增加的数值
					additionNum = "1";
					len = multiple2;
					for ( i = 0; i < len; i++ )
					{
						additionNum += "0";
					}
					
					// 减法计算出新的数字1，并增加“商”的值
					dpNum1 = subtract( dpNum1, tempDPNum2 );
					quotientNum = addition( quotientNum, additionNum );
					
					// 计算完毕结束循环，不是无限循环的情况
					if ( dpNum1 == "0" )
					{
						break;
					}
					
					// 数字2大
					if ( contrastSize(dpNum1, dpNum2) == 2 )
					{
						isOne = false;
						continue;
					}
				}
				// 第二个步骤
				else
				{
					multiple1 = 0;
					
					// 数字2大于数字1，增大数字1
					if ( contrastSize(dpNum1, dpNum2) == 2 )
					{
						len = dpNum2.length - dpNum1.length;
						for ( i = 0; i < len; i++ )
						{
							dpNum1 += "0";
						}
						multiple1 = len;
						maxRetain += len;
						// 如果调整长度之后数字2仍然大于数字1，则在增加一位
						if ( contrastSize(dpNum1, dpNum2) == 2 )
						{
							dpNum1 += "0";
							multiple1 += 1;
							maxRetain += 1;
						}
					}
					
					// 根据增加的倍数，算出本轮循环“商”要增加的位数
					additionNum = "1";
					len = multiple1;
					for ( i = 0; i < len; i++ )
					{
						quotientNum += "0";
					}
					
					// 特殊情况1，刚开始计算就出现0.00XXX这种，为了能正常计算，给最前面加1
					if ( quotientNum.charAt(0) == "0" && quotientNum.charAt(1) == "0" )
					{
						special = true;
						quotientNum = "1" + quotientNum.substring( 1 );
					}
					
					// 减法计算出新的数字1，并增加“商”的值
					dpNum1 = subtract( dpNum1, dpNum2 );
					quotientNum = addition( quotientNum, additionNum );
					
					// 计算完毕结束循环，不是无限循环的情况
					if ( dpNum1 == "0" )
					{
						break;
					}
					// 等于最大保留位数
					else if ( maxRetain >= retain && contrastSize(dpNum1, dpNum2) == 2 )
					{
						break;
					}
				}
			}
			
			// 特殊情况1
			if ( special )
			{
				quotientNum = quotientNum.substring( 1 );
				quotientNum = addition( quotientNum, "0" );
			}
			
			// 加上小数点
			quotientNum = addDecimalPoint( quotientNum,  maxRetain );
			
			// 返回数字
			return quotientNum;
		}


		//************************ ************************* 模运算 ******************** *********** *** **////
		/**
		 * 模运算，两个数字想除取余数（必须传入正确的数字）
		 * @param num1 数字1
		 * @param num2 数字2
		 * @return 模运算的结果数字
		 */
		public static function mod ( num1:String, num2:String ) : String
		{
			// 都是正数
			if ( num1.charAt(0) != "-" && num2.charAt(0) != "-" )
			{
				return modular( num1, num2 );
			}
			// 数字1为负数
			else if ( num1.charAt(0) == "-" && num2.charAt(0) != "-" )
			{
				num1 = num1.substr( 1, num1.length-1 );
				return "-" + modular( num1, num2 );
			}
			// 数字2为负数
			else if ( num1.charAt(0) != "-" && num2.charAt(0) == "-" )
			{
				num2 = num2.substr( 1, num2.length-1 );
				return modular( num1, num2 );
			}
			// 都是负数
			else
			{
				num1 = num1.substr( 1, num1.length-1 );
				num2 = num2.substr( 1, num2.length-1 );
				return "-" + modular( num1, num2 );
			}
		}
		
		/**
		 * 模运算，两个数字想除取余数（不能有负数，可以是正数和小数）
		 * @param num1 数字1
		 * @param num2 数字2
		 * @return 模运算的结果数字
		 */
		private static function modular ( num1:String, num2:String ) : String
		{
			var i:int, len:int;
			
			// 给两个数字去除小数，然后将两个数字的位数设置为统一的大小位（不是长度一致）
			var dpArr : Array = setUnifiedDecimalPoint( num1, num2 );
			
			var dpArr1 : Array = dpArr[0];
			var dpArr2 : Array = dpArr[1];
			var dpNum1 : String = dpArr1[0];
			var dpNum2 : String = dpArr2[0];
			
			// 防止出现“0/0=1”的情况
			if ( dpNum1 == dpNum2 && dpNum1 == "0" )
			{
				return "0";
			}
			
			// 防止出现两个数其中一个为“0”的情况
			if ( dpNum1 == "0" || dpNum2 == "0" )
			{
				return "0";
			}
			
			// 最大保留多余位数，对应的最大值为retain参数的值
			var maxRetain : int = 0;
			
			// 一遍遍的用数字1减去数字2，整个运算分为两个步骤（部分）
			// 第一个步骤数字数2远远小于数字1，需要数字2增大位数进行减法计算
			// 第二个步骤数字1小于数字2，需要数字1增大位数进行减法计算（如果数字1开始就小于数字2，则直接开始第二个步骤）
			var isOne : Boolean = contrastSize(dpNum1, dpNum2) == 1 ? true : false;	// 是否第一个步骤，true表示是第一个步骤，false表示是第二个步骤
			var quotientNum : String = "0";		// 这个是除法的商，也就是最终结果
			var additionNum : String;			// 每轮循环时候，商要增加的值
			var tempDPNum2 : String;			// 临时的数字2
			var multiple1 : int = 0;			// 数字1变大的倍数
			var multiple2 : int = 0;			// 数字2变大的倍数
			for ( ; ; )
			{
				// 第一个步骤
				if ( isOne )
				{
					multiple2 = 0;
					tempDPNum2 = dpNum2;
					
					// 数字1太大，为了快速减法，所以将两个数字长度调整到一致
					if ( dpNum1.length > dpNum2.length )
					{
						len = dpNum1.length - dpNum2.length;
						for ( i = 0; i < len; i++ )
						{
							tempDPNum2 += "0";
						}
						multiple2 = len;
						
						// 如果调整长度之后数字2大于数字1，则减去一位长度
						if ( contrastSize(dpNum1, tempDPNum2) == 2 )
						{
							tempDPNum2 = tempDPNum2.substr( 0, tempDPNum2.length-1 );
							multiple2 -= 1;
						}
					}
					
					// 根据减去的倍数，算出本轮循环“商”要增加的数值
					additionNum = "1";
					len = multiple2;
					for ( i = 0; i < len; i++ )
					{
						additionNum += "0";
					}
					
					// 减法计算出新的数字1，并增加“商”的值
					dpNum1 = subtract( dpNum1, tempDPNum2 );
					quotientNum = addition( quotientNum, additionNum );
					
					// 计算完毕结束循环，不是无限循环的情况
					if ( dpNum1 == "0" )
					{
						break;
					}
				}
					
				// 数字2大
				if ( contrastSize(dpNum1, dpNum2) == 2 )
				{
					break;
				}
			}
			
			// 加上小数点
			dpNum1 = addDecimalPoint( dpNum1,  dpArr2[1] );
			
			// 返回数字
			return dpNum1;
		}


		//************************ ************************* 随机生成超大数字 ******************** *********** *** **////
		/**
		 * 随机生成超大数字，可指定位数，以及是否生成小数，是否生成负数
		 * @param length 位数长度
		 * @param isDecimal 是否有可能生成小数
		 * @param isNegative 是否有可能生成负数
		 * @return 随机生成的超大数字
		 */
		public static function randomSuperNumber ( digit:int = 20, isDecimal:Boolean = true, isNegative:Boolean = true ) : String
		{
			// 随机生成的长达数字
			var num : String = "";
			
			// 此变量用于确保小数点只出现一次
			var point : Boolean = false;
			
			var i:int, len:int = digit;
			for ( i = 0; i < len; i++ )
			{
				// 有小数点
				if ( isDecimal )
				{
					// 在首位是0的情况下，增加小数点
					if ( i == 1 && num == "0" )
					{
						point = true;
						num += ".";
					}
					// 随机数字，但最后数字不会随机到0，这样保证不会出现小数点后数位都是0，这种没有意义的数字出现
					if ( (i+1) < len )
					{
						num += int(Math.random() * 10).toString();
					}
					else
					{
						num += int(Math.random() * 9 + 1).toString();
					}
					// 在任意位置随机出现小数点，但是不在最后出现
					if ( point == false && (i+1) < len && ((Math.random() * digit) < 1) )
					{
						point = true;
						num += ".";
					}
				}
				// 没有小数点
				else
				{
					if ( i == 0 )
					{
						num += int(Math.random() * 9 + 1).toString();
					}
					else
					{
						num += int(Math.random() * 10).toString();
					}
				}
			}
			
			// 有负数的可能
			if ( isNegative )
			{
				if ( Math.random() < 0.5)
				{
					num = "-" + num;
				}
			}
			
			return num;
		}


		//************************ ************************* 对比两个数字大小 ******************** *********** *** **////
		/**
		 * 对比两个数字的大小，返回0表示两个数字一样大，1表示第一个数字大，2表示第二个数字大，-1表示数字1或数字2不是数字
		 * @param num1 要对比的数字
		 * @param num2 要对比的数字
		 * @return -1或0或1或2
		 */
		public static function contrastNumber ( num1:String, num2:String ) : int
		{
			if ( isNumber(num1) && isNumber(num2) )
			{
				
				// 正数大于负数，数字1大
				if ( num1.charAt(0) != "-" && num2.charAt(0) == "-" )
				{
					return 1;
				}
				// 正数大于负数，数字2大
				else if ( num1.charAt(0) == "-" && num2.charAt(0) != "-" )
				{
					return 2;
				}
				
				// 同是正数或负数，负数的话，先去掉负号
				var isNegative : Boolean = false;
				if ( num1.charAt(0) == "-" && num2.charAt(0) == "-" )
				{
					isNegative = true;
					num1 = num1.substr( 1, num1.length-1 );
					num2 = num2.substr( 1, num2.length-1 );
				}
				// 给两个数字去除小数，然后将两个数字的位数设置为统一的大小位（不是长度一致）
				var dpArr : Array = setUnifiedDecimalPoint( num1, num2 );
				var dpNum1 : String = dpArr[0][0];
				var dpNum2 : String = dpArr[1][0];
				var cs : int = contrastSize( dpNum1, dpNum2 );
				if ( isNegative )
				{
					if ( cs == 1 )
					{
						cs = 2;
					}
					else if ( cs == 2 )
					{
						cs = 1;
					}
				}
				return cs;
			}
			else
			{
				return -1;
			}
		}

		/**
		 * 对比两个正整数，那个更大，返回0表示两个数字一样大，1表示第一个数字大，2表示第二个数字大
		 * @param num1 要对比的正整数
		 * @param num2 要对比的正整数
		 * @return 0或1或2
		 */
		private static function contrastSize ( num1:String, num2:String ) : int
		{
			var i:int, len:int;
			
			var bigNum : int = 0;
			
			// 第一个数字大
			if ( num1.length > num2.length )
			{
				bigNum = 1;
			}
			// 第二个数字大
			else if ( num1.length < num2.length )
			{
				bigNum = 2;
			}
			// 两个数字长度一样，进行每一位的大小判断
			else
			{
				len = num1.length;
				for ( i = 0; i < len; i++ )
				{
					// 第一个数字大
					if ( num1.charAt(i) > num2.charAt(i) )
					{
						bigNum = 1;
						break;
					}
					// 第二个数字大
					else if ( num1.charAt(i) < num2.charAt(i) )
					{
						bigNum = 2;
						break;
					}
					// 当前位一样大，继续进行判断
				}
			}
			
			return bigNum;
		}


		//************************ ************************* 判断字符串是否为数字 ******************** *********** *** **////
		/**
		 * 判断字符串是否为数字，true表示是正常的数字，false表示不是数字
		 * @param num 要进行判断的字符串
		 * @return 数组，0为该数字，1为小数点后的位数
		 */
		public static function isNumber ( num:String ) : Boolean
		{
			var re : RegExp;
			
			// 正整数
			re = /^\d+$/;
			if ( re.test( num ) )
			{
				return true;
			}
			// 负整数
			re = /^-\d+$/;
			if ( re.test( num ) )
			{
				return true;
			}
			// 正小数整数
			re = /^\d+\.\d+$/;
			if ( re.test( num ) )
			{
				return true;
			}
			// 负小数整数
			re = /^-\d+\.\d+$/;
			if ( re.test( num ) )
			{
				return true;
			}
			// “0”
			re = /^0$/;
			if ( re.test( num ) )
			{
				return true;
			}
			// “+0”
			re = /^+0$/;
			if ( re.test( num ) )
			{
				return true;
			}
			// “-0”
			re = /^-0$/;
			if ( re.test( num ) )
			{
				return true;
			}
			
			return false;
		}


		//************************ ************************* 公用方法 ******************** *********** *** **////
		/**
		 * 给两个数字去除小数，然后将两个数字的位数设置为统一的大小
		 * @param num1 要去除小数点的数字
		 * @param num2 要去除小数点的数字
		 * @return 二维数组，0为第一个数字的数组，1为第二个数字的数组
		 */
		private static function setUnifiedDecimalPoint ( num1:String, num2:String ) : Array
		{
			var i:int, len:int;
			
			var dpArr1 : Array = removeDecimalPoint( num1 );
			var dpArr2 : Array = removeDecimalPoint( num2 );
			
			if ( dpArr1[1] > dpArr2[1] )
			{
				len = dpArr1[1] - dpArr2[1];
				for ( i = 0; i < len; i++ )
				{
					 dpArr2[0] += "0";
					 dpArr2[1] += 1;
				}
			}
			else if ( dpArr1[1] < dpArr2[1] )
			{
				len = dpArr2[1] - dpArr1[1];
				for ( i = 0; i < len; i++ )
				{
					 dpArr1[0] += "0";
					 dpArr1[1] += 1;
				}
			}
			return [dpArr1, dpArr2];
		}

		/**
		 * 去除小数点，并返回该数字和对应的小数点后面的位数（请确保传入的是正确的数字）
		 * @param num 要去除小数点的数字
		 * @return 数组，0为该数字，1为小数点后的位数
		 */
		private static function removeDecimalPoint ( num:String ) : Array
		{
			// 小数位数
			var digit : int = num.indexOf(".");
			if ( digit == -1 )
			{
				digit = 0;
			}
			else
			{
				digit = num.length - digit - 1;
				
				// 去除小数点
				num = num.replace( ".", "" );
				
				// 去除前面多余的“0”
				if ( num.charAt(0) == "0" )
				{
					var i:int, len:int = num.length;
					for ( i = 1; i <= len; i++ )
					{
						if ( num.charAt(0) == "0" )
						{
							num = num.substring( 1 );
						}
						else
						{
							break;
						}
					}
				}
			}
			
			return [num, digit];
		}

		/**
		 * 通过传入的小数位，将数字还原为带有小数点的字符串形态
		 * @param num 要还原小数点的数字
		 * @param digit 小数的位数
		 * @return 数字
		 */
		private static function addDecimalPoint ( num:String, digit:int ) : String
		{
			var i:int, len:int;
			
			// 获取前、后的字符串
			var left : String = num.substring( 0, (num.length - digit) );
			var right : String = num.substring( (num.length - digit) );
			
			// 对0.XXX的小数进行特殊处理
			if ( left == "" )
			{
				left = "0.";
			}
			else
			{
				left += ".";
			}
			
			// 对0.0XXX的小数进行特殊处理
			if ( (digit - num.length) > 0 )
			{
				len = digit - num.length;
				for ( i = 1; i <= len; i++ )
				{
					left += "0";
				}
			}
			
			// 组合前后字符串
			if ( right.length != 0 )
			{
				num = left + right;
			}
			else
			{
				num = left;
			}
			
			// 防止出现“0.0”的情况
			if ( num == "0.0" )
			{
				num = "0";
			}
			
			// 去掉末尾多余的0
			if ( num.charAt(num.length - 1) == "0" && num.indexOf(".") != -1 )
			{
				len = num.length;
				for ( i = 1; i <= len; i++ )
				{
					if ( num.charAt(num.length - 1) == "0" )
					{
						num = num.substring( 0, num.length - 1 );
					}
					else if ( num.charAt(num.length - 1) == "." )
					{
						num = num.substring( 0, num.length - 1 );
						break;
					}
					else
					{
						break;
					}
				}
			}
			
			// 去掉末尾多余的.
			if ( num.charAt(num.length - 1) == "." )
			{
				num = num.substring( 0, num.length - 1 );
			}
			
			// 去头部多余的0
			if ( num.charAt(0) == "0" && num.charAt(1) != "." )
			{
				len = num.length;
				for ( i = 1; i <= len; i++ )
				{
					if ( num.charAt(1) == "." )
					{
						break;
					}
					else if ( num.charAt(0) == "0" && num.length > 1 )
					{
						num = num.substring( 1, num.length );
					}
					else
					{
						break;
					}
				}
			}
			
			return num;
		}
		
		
		
	}
}


