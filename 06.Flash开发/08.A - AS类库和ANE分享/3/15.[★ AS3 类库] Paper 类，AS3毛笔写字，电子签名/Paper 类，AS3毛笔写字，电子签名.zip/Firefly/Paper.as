﻿package Firefly {

	import flash.display.Bitmap;
	import flash.display.BitmapData;
	import flash.display.MovieClip;
	import flash.display.Sprite;
	import flash.events.Event;
	import flash.events.MouseEvent;
	import flash.filters.BlurFilter;

	public class Paper extends MovieClip {

		var _mc:Sprite;
		var bm:Bitmap;
		var bmd:BitmapData;
		var paper_mc:Sprite;
		var oldX:Number;
		var oldY:Number;
		var oldScale:Number;
		var brush_mc:Sprite;

		var defaultScale:Number = .8;//默认笔触的大小
		var cx:Number = .02;//粗细变化参数
		var brushMin:Number = .08;//最细笔触限制
		var brushAlpha:Number = .3;//笔刷浓度
		var brushBlur:Number = 2;//笔刷模糊
		var midu:Number = 1;//笔刷密度
		
		var bf:BlurFilter;
		public function Paper() {
			bf = new BlurFilter(brushBlur, brushBlur);
			_mc = new Brush();
			_mc.alpha = brushAlpha;
			_mc.scaleX = _mc.scaleY = defaultScale;
			_mc.filters = new Array(bf);
			paper_mc = new Sprite();
			addChild(paper_mc);
			paper_mc.addChild(_mc);
			brush_mc = new Sprite();
			paper_mc.addChild(brush_mc);
			_mc.visible = false;

			addEventListener(MouseEvent.MOUSE_DOWN, _mouseDown);
			addEventListener(MouseEvent.MOUSE_UP, _mouseUp);
			bmd = new BitmapData(this.width, this.height);
			bm = new Bitmap(bmd);
			bm.smoothing = true;
			addChild(bm);
			
			
		}

		private function _mouseUp(e:MouseEvent):void
		{
			_mc.visible = false;
			_mc.scaleX = _mc.scaleY = 1;
			stopDrag();
			removeEventListener(MouseEvent.MOUSE_MOVE, _addBrush);
		}

		private function _mouseDown(e:MouseEvent):void
		{
			oldX=_mc.x = mouseX;
			oldY = _mc.y = mouseY;
			oldScale = 1;
			_mc.startDrag(true);
			_mc.visible = true;
			
			addEventListener(MouseEvent.MOUSE_MOVE, _addBrush);
		}

		private function _addBrush(e:Event):void
		{
			//计算距离
			var disX:Number=mouseX-oldX;
			var disY:Number=mouseY-oldY;
			var dis:Number = Math.sqrt(disX * disX + disY * disY);
			//改变笔触的大小,越快越小
			if (dis > 0) {
				var scale:Number = defaultScale - dis * cx;
				if (scale > 1) {
					scale = 1;
				}else if (scale < brushMin) {
					scale = brushMin;
				}
				scale = (oldScale + scale) / 2;
				_mc.scaleY = _mc.scaleX = scale;
			}
			//填充
			var count:int = Math.floor(dis / midu);
			var scaleBili:Number = (oldScale-scale) / count;
			for (var i:int=0; i<count-1; i++) {
				var brush:Brush = new Brush();
				brush.filters = new Array(bf);
				brush.alpha = brushAlpha;
				brush.scaleX = brush.scaleY = oldScale-i * scaleBili;
				brush_mc.addChild(brush);
				brush.x=(disX/count)*(i+1)+oldX;
				brush.y=(disY/count)*(i+1)+oldY;

			}
			oldScale = scale;
			oldX = mouseX;
			oldY = mouseY;
			bmd.draw(paper_mc);
			//删除填充
			while (brush_mc.numChildren>0) {
				brush_mc.removeChildAt(0);
			}
		}
	}

}

