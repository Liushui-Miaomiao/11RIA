﻿package cc.tkcb.draw.monster.part
{
    import cc.tkcb.draw.monster.core.*;

    public class MEyes extends MPart
    {

        public function MEyes(param1:DNA, param2:uint, param3:Number = 30) : void
        {
            super(param1, param2, param3);
            return;
        }// end function

        override protected function draw() : void
        {
            dna.reset();
            graphics.clear();
            this.drawEyeBall(0);
            this.drawEyeBall(size << 1);
            return;
        }// end function

        private function drawEyeBall(param1:int) : void
        {
            var _loc_2:int = 0;
            var _loc_5:int = 0;
            graphics.lineStyle(1, 16777215);
            graphics.beginFill(16777215);
            _loc_2 = param1 + dna.param;
            var _loc_3:* = dna.param;
            var _loc_4:* = size + (dna.param >> 1);
            _loc_5 = size + dna.param >> 1;
            points = new Array();
            points.push({x:_loc_2, y:_loc_3});
            points.push({x:_loc_2 + _loc_4, y:_loc_3});
            points.push({x:_loc_2 + _loc_4, y:_loc_3 + _loc_5 + dna.param});
            points.push({x:_loc_2, y:_loc_3 + _loc_5});
            curveFromPoints();
            graphics.endFill();
            graphics.lineStyle(0, 16777215, 0);
            graphics.beginFill(dna.color);
            var _loc_6:* = (size >> 1) + _loc_2 + dna.param;
            var _loc_7:* = (size + dna.param >> 2) + _loc_3;
            var _loc_8:* = 6 + dna.param / 5;
            graphics.drawCircle(_loc_6, _loc_7, _loc_8);
            graphics.endFill();
            graphics.beginFill(0, 0.6);
            graphics.drawCircle(_loc_6 + (_loc_8 >> 3), _loc_7 + (_loc_8 >> 3), _loc_8 >> 1);
            graphics.endFill();
            graphics.beginFill(16777215, 0.4);
            graphics.drawCircle(_loc_6 + (_loc_8 >> 1), _loc_7 - (_loc_8 >> 1), _loc_8 >> 1);
            graphics.endFill();
            graphics.lineStyle(3, dna.color, 0.5);
            graphics.beginFill(skin);
            var _loc_9:* = _loc_3 + (size + dna.param >> 2);
            graphics.moveTo(_loc_2, _loc_9);
            graphics.curveTo(_loc_2 + (_loc_4 + dna.param >> 2), _loc_3 + (dna.param >> 1), _loc_2 + _loc_4, _loc_3);
            graphics.lineStyle(1, skin, 0);
            graphics.curveTo(_loc_2 + size, _loc_3 - (size >> 2), _loc_2 + (size >> 1), _loc_3 - (size >> 2));
            graphics.curveTo(_loc_2 - (size >> 2), _loc_3 - (size >> 2), _loc_2, _loc_9);
            return;
        }// end function

    }
}
