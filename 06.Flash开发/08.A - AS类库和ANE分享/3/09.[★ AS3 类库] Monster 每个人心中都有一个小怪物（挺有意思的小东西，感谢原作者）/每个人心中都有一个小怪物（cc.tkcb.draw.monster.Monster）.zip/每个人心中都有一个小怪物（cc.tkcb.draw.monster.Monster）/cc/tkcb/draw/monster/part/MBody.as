﻿package cc.tkcb.draw.monster.part
{
    import cc.tkcb.draw.monster.core.*;

    public class MBody extends MPart
    {

        public function MBody(param1:DNA, param2:uint, param3:Number = 60) : void
        {
            super(param1, param2, param3);
            return;
        }// end function

        override protected function draw() : void
        {
            dna.reset();
            points = new Array(16);
            var _loc_1:Number = 0;
            while (_loc_1 < 16)
            {
                
                points[_loc_1] = {};
                points[_loc_1].x = size + Math.sin(_loc_1 / 8 * Math.PI) * size + dna.param;
                points[_loc_1].y = size + Math.cos(_loc_1 / 8 * Math.PI) * (size * 1.4);
                _loc_1 = _loc_1 + 1;
            }
            graphics.clear();
            matrix.createGradientBox(size * (20 + dna.param) / 10, size * (20 + dna.param) / 10, dna.param / 90 * Math.PI, size / 2, size / 4);
            graphics.beginGradientFill("radial", [skin, getDarkenColor(skin)], [1, 1], [48, 255], matrix);
            curveFromPoints();
            graphics.endFill();
            return;
        }// end function

    }
}
