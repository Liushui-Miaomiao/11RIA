﻿package cc.tkcb.draw.monster.core
{
    import com.adobe.crypto.*;

    final public class DNA extends Object
    {
        private var _params:Array;
        private var _name:String;
        private var _hash:String;
        private var _count:uint = 0;
        private var _p:uint = 0;

        public function DNA(param1:String) : void
        {
            this._name = param1;
            this._hash = MD5.hash(param1);
            this.parseHash();
            return;
        }// end function

        private function parseHash() : void
        {
            this._params = this._hash.split("");
            var _loc_1:uint = 0;
            while (_loc_1 < 32)
            {
                
                this._params[_loc_1] = parseInt(this._params[_loc_1], 16) - 8;
                _loc_1 = _loc_1 + 1;
            }
            return;
        }// end function

        public function get color() : uint
        {
            var _loc_1:* = parseInt(this._hash.substr(this._count, 6), 16);
            this._count = this._count < 25 ? ((this._count + 1)) : (0);
            return _loc_1;
        }// end function

        public function reset() : void
        {
            this._p = 0;
            return;
        }// end function

        public function get param() : int
        {
            var _loc_1:* = this._params[this._p];
            this._p = this._p < 31 ? ((this._p + 1)) : (0);
            return _loc_1;
        }// end function

    }
}
