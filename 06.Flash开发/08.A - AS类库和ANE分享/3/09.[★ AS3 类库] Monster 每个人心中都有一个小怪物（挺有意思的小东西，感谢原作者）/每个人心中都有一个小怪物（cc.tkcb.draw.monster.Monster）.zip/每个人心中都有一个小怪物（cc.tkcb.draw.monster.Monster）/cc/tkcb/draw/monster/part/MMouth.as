﻿package cc.tkcb.draw.monster.part
{
    import cc.tkcb.draw.monster.core.*;

    public class MMouth extends MPart
    {

        public function MMouth(param1:DNA, param2:uint, param3:Number = 60) : void
        {
            super(param1, param2, param3);
            return;
        }// end function

        override protected function draw() : void
        {
            dna.reset();
            graphics.clear();
            points = new Array();
            points.push({x:dna.param, y:dna.param});
            points.push({x:size + dna.param, y:dna.param});
            points.push({x:size / 2 + dna.param, y:size / 2 + dna.param});
            graphics.beginFill(dna.color);
            matrix.createGradientBox(size, size / 4, (dna.param - 45) / 90 * Math.PI);
            var _loc_1:* = dna.color;
            graphics.beginGradientFill("linear", [_loc_1, getDarkenColor(_loc_1)], [1, 1], [0, 226], matrix);
            curveFromPoints();
            graphics.endFill();
            return;
        }// end function

    }
}
