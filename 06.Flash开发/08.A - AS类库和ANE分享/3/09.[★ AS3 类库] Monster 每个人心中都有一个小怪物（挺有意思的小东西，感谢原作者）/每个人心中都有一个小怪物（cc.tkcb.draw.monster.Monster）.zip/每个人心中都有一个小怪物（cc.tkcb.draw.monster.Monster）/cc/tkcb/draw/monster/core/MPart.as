﻿package cc.tkcb.draw.monster.core
{
    import flash.display.*;
    import flash.geom.*;

    public class MPart extends Sprite
    {
        protected var size:Number;
        protected var points:Array;
        protected var matrix:Matrix;
        protected var dna:DNA;
        protected var skin:uint;

        public function MPart(param1:DNA, param2:uint, param3:Number) : void
        {
            this.size = param3;
            this.dna = param1;
            this.skin = param2;
            this.points = new Array();
            this.matrix = new Matrix();
            this.draw();
            return;
        }// end function

        protected function draw() : void
        {
            return;
        }// end function

        protected function getDarkenColor(param1:uint, param2:uint = 40) : uint
        {
            var _loc_3:* = (param1 & 16711680) >> 16;
            var _loc_4:* = (param1 & 65280) >> 8;
            var _loc_5:* = param1 & 255;
            _loc_3 = _loc_3 - param2 < 0 ? (0) : (_loc_3 - param2);
            _loc_4 = _loc_4 - param2 < 0 ? (0) : (_loc_4 - param2);
            _loc_5 = _loc_5 - param2 < 0 ? (0) : (_loc_5 - param2);
            return _loc_3 << 16 | _loc_4 << 8 | _loc_5;
        }// end function

        protected function curveFromPoints() : void
        {
            var _loc_2:* = undefined;
            var _loc_3:Number = NaN;
            var _loc_1:* = this.points.length - 1;
            graphics.moveTo((this.points[0].x + this.points[_loc_1].x) / 2, (this.points[0].y + this.points[_loc_1].y) / 2);
            var _loc_4:uint = 0;
            while (_loc_4 < _loc_1)
            {
                
                _loc_2 = (this.points[_loc_4].x + this.points[(_loc_4 + 1)].x) / 2;
                _loc_3 = (this.points[_loc_4].y + this.points[(_loc_4 + 1)].y) / 2;
                graphics.curveTo(this.points[_loc_4].x, this.points[_loc_4].y, _loc_2, _loc_3);
                _loc_4 = _loc_4 + 1;
            }
            _loc_2 = (this.points[0].x + this.points[_loc_1].x) / 2;
            _loc_3 = (this.points[0].y + this.points[_loc_1].y) / 2;
            graphics.curveTo(this.points[_loc_1].x, this.points[_loc_1].y, _loc_2, _loc_3);
            return;
        }// end function

    }
}
