﻿package cc.tkcb.draw.monster.core
{
    import cc.tkcb.draw.monster.part.*;

    public class MSet extends MPart
    {
        private var eye:MEyes;
        private var mouth:MMouth;
        private var body:MBody;
        private var hair:MHair;

        public function MSet(param1:DNA) : void
        {
            super(param1, 0, 60);
            skin = dna.color;
            this.init();
            return;
        }// end function

        private function init() : void
        {
            this.eye = new MEyes(dna, skin);
            this.mouth = new MMouth(dna, skin);
            this.body = new MBody(dna, skin);
            this.hair = new MHair(dna, skin);
            dna.reset();
            this.hair.y = dna.param;
            this.body.y = size + this.hair.y + dna.param;
            this.eye.x = size / 3 + dna.param;
            this.eye.y = this.body.y + size + dna.param;
            this.mouth.x = size / 2 + dna.param;
            this.mouth.y = this.eye.y + size / 2 + dna.param;
            addChild(this.body);
            addChild(this.eye);
            addChild(this.mouth);
            addChild(this.hair);
            return;
        }// end function

    }
}
