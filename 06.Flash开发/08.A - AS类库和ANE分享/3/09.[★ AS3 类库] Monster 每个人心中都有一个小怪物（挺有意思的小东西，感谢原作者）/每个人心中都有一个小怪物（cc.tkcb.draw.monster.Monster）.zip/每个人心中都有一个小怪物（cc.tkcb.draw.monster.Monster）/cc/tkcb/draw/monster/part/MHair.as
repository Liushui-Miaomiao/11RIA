﻿package cc.tkcb.draw.monster.part
{
    import cc.tkcb.draw.monster.core.*;

    public class MHair extends MPart
    {

        public function MHair(param1:DNA, param2:uint, param3:Number = 60) : void
        {
            super(param1, param2, param3);
            return;
        }// end function

        override protected function draw() : void
        {
            dna.reset();
            points = new Array(24);
            var _loc_1:Number = 0;
            while (_loc_1 < 24)
            {
                
                points[_loc_1] = {};
                points[_loc_1].x = size + Math.sin(_loc_1 / 12 * Math.PI) * (size * (12 + dna.param / 2) / 10) + dna.param;
                points[_loc_1].y = size + Math.cos(_loc_1 / 12 * Math.PI) * (size * (8 + dna.param / 2) / 10) + dna.param;
                _loc_1 = _loc_1 + 1;
            }
            graphics.clear();
            matrix.createGradientBox(size * (24 + dna.param) / 10, size * (24 + dna.param) / 10, dna.param / 90 * Math.PI, size / 2, 0);
            var _loc_2:* = dna.color;
            graphics.beginGradientFill("radial", [_loc_2, getDarkenColor(_loc_2, 50)], [1, 1], [48, 255], matrix);
            curveFromPoints();
            graphics.endFill();
            return;
        }// end function

    }
}
