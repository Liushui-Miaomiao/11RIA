﻿/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 2018 TKCB, tkcb@qq.com
 *
 *
 * This is free software/program/code: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * 这是一个自由软件/程序/代码，您可以自由分发、修改其中的源代码或者重新发布它，
 * 新的任何修改后的重新发布版必须同样在遵守LGPL3或更后续的版本协议下发布。
 * 关于LGPL协议的细则请参考COPYING、COPYING.LESSER文件，
 * 你可以在文件夹中获得LGPL协议的副本，如果没有找到，请连接到 http://www.gnu.org/licenses/ 查看。
 *
 *
 * 作　　者：TKCB
 * 作者信息：身高（0.00167公里+）；体重（0.06吨±）；年龄（公元1990后）；籍贯（有兵马俑的地方）；星座（最后一个星座）；血型（万能型）；人生格言（The king come back.）。
 * 交流学习：加QQ群[AS3殿堂之路]（96759336），群里有无数主城、架构、妹子、LOL战友，欢迎交流讨论。
 * 联系方式：QQ（2414268040）；E-mail（tkcb@qq.com）；手机（15029932353)。
 * 作者网站：www.tkcb.cc（来这里关注我吧，这里有我所有的作品，分享的资料，我的介绍和动态，还有更多你想不到的）
 *
 *
 * 获取软件/程序最新版本：www.tkcb.cc
 *
 *
 * 版权协议：请自觉遵守LGPL协议，欢迎复制、转载、传播给更多需要的人。
 * 免责声明：任何因使用此软件导致的纠纷与软件/程序开发者无关。
 */

/*
 * @version 版本创建时间和修改说明
 * v1.0.0 2018-6-4
 */
package cc.tkcb.draw.monster
{
    import flash.display.Sprite;
	
    import cc.tkcb.draw.monster.core.DNA;
    import cc.tkcb.draw.monster.core.MSet;
	
	
	/**
	 * Monster 小怪兽绘制 类，用于生成每个人独一无二的小怪兽
	 * @author TKCB（www.tkcb.cc）
	 * @创建时间 2018-6-4
	 * @修改时间 2018-6-6
	 * @version 1.0.0
	 */
    public class Monster extends Sprite
    {
		//************************ ************************* 属性 ******************** *********** *** **////
        /** 小怪兽生成器 */
		private var ms : MSet;
		
        /** 小怪兽DNA */
		private var dna : DNA;
		
        /** DNA偏移值，可影响DNA的重新组合 */
		public var dnaDeviant : String;
		
        /** 是否开启日期DNA偏移，如果开启则每天的DNA偏移将都不一样，但同一天是一样的 */
		public static var isDate : Boolean = false;
		
        /** 日期DNA偏移 */
		private static var dnaDate : Date = new Date();
		
		
		//************************ ************************* 构造函数 ******************** *********** *** **////
        /**
		 * 构造函数
		 */
		public function Monster () : void
        {
			
        }
		
		
		//************************ ************************* 方法 ******************** *********** *** **////
		/**
		 * 绘制小怪兽
		 * @param dnaStr DNA字符串，不同的字符串会生成不一样的小怪兽
		 * @param dnaDeviantStr 可用于影响DNA组合的字符串，用于更加丰富DNA的变化
		 */
		public function draw ( dnaStr:String, dnaDeviantStr:String = "" ) : void
		{
			if ( ms != null )
			{
				removeChild( ms );
			}
			
			dnaDeviant = dnaDeviantStr;
			var newDNAStr : String = dnaStr + dnaDeviant;
			if ( isDate )
			{
				newDNAStr += dnaDate.fullYear.toString() + dnaDate.month.toString() + dnaDate.date.toString();
			}
			dna = new DNA( newDNAStr );
			ms = new MSet( dna );
			addChild( ms );
		}
    }
}
