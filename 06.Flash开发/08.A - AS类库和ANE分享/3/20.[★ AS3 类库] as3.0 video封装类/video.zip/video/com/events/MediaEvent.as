﻿package com.events
{
	import flash.events.Event;

	public class MediaEvent extends Event
	{

		public static const STATUS:String = "Status";

		public var data:Object;

		/*
		* 构造函数
		*/

		public function MediaEvent(type:String, object:Object,bubbles:Boolean = false, cancelable:Boolean = false)
		{
			super(type, bubbles, cancelable);
			data = object;
		}


		/*
		* clone方法
		*/
		override public function clone():Event
		{
			return new MediaEvent(type, data,bubbles, cancelable);
		}



	}
}