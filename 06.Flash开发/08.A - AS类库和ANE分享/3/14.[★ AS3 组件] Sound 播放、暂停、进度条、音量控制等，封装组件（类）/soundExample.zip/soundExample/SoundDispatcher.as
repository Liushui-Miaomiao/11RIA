﻿/**
* @sound封装类
* set url(value:*):void 声音地址（XMLList、Array、String）
* set autoPlay(value:Boolean):void 曲目随机、顺序循环
* initPlay():void 声音播放
* @author wu
* @date 19/10/12
**/

package 
{

	import flash.events.Event;
	import flash.events.EventDispatcher;
	import flash.events.SecurityErrorEvent;
	import flash.events.ProgressEvent;
	import flash.events.IOErrorEvent;
	import flash.media.Sound;
	import flash.media.SoundChannel;
	import flash.media.SoundTransform;
	import flash.net.URLRequest;



	public class SoundDispatcher extends EventDispatcher
	{

		static public const EVENT_PLAY:String = "event.play";

		private var sound:Sound;//声音对象
		private var soundChannel:SoundChannel=new SoundChannel();//声音通道对象
		private var _transform:SoundTransform=new SoundTransform();//分配给该声道的 SoundTransform 对象（控制音量）
		private var startTime:Number = 0;//当前播放的位置
		private var _playing:Boolean;//播放的布尔值
		private var _paused:Boolean;//暂停的布尔值
		private var _scrubbing:Boolean;//是否正在调用seek()的布尔值

		private var _url:*;
		private var _index:int = 0;
		private var _autoPlay:Boolean;
		private var arr:Array=new Array();

		public function set url(value:*):void
		{
			_url = value;
		}

		public function set autoPlay(value:Boolean):void
		{
			_autoPlay = value;
		}

		/************** 开始播放 *******************/
		public function initPlay():void
		{
			play(decode(_url));
			dispatchEvent(new Event(EVENT_PLAY));
		}

		//返回当前要播放的声音地址 String
		private function decode(value:*):String
		{
			var currentUrl:*;
			if (value is XMLList||value is XML)
			{
				if (_autoPlay)
				{
					_index =Math.random()*(value.length()-1);
				}
				currentUrl = value[_index];
			}
			else if (value is Array)
			{
				if (_autoPlay)
				{
					_index =Math.random()*(value.length-1);
				}
				currentUrl = value[_index];
			}
			else
			{
				currentUrl = value;
			}
			return currentUrl;
		}

		private function play(url:String):void
		{
			sound=new Sound();
			sound.load(new URLRequest(url));
			configureListeners(sound,true);
			soundChannel = sound.play();
			soundChannel.soundTransform = _transform;
			//播放完成
			soundChannel.addEventListener(Event.SOUND_COMPLETE,soundCompleteHandler);
			_playing = true;
			_paused = false;
			_scrubbing = false;
		}




		/********************** 声音加载事件 ****************/
		private function configureListeners(dispatcher:EventDispatcher,isListener:Boolean):void
		{
			if (isListener)
			{
				dispatcher.addEventListener(Event.ID3,id3Handler);
				dispatcher.addEventListener(ProgressEvent.PROGRESS,progressHandler);
				dispatcher.addEventListener(Event.COMPLETE,completeHandler);
				dispatcher.addEventListener(IOErrorEvent.IO_ERROR,ioErrorHandler);
				dispatcher.addEventListener(SecurityErrorEvent.SECURITY_ERROR,securityErrorHandler);
			}
			else
			{
				dispatcher.removeEventListener(Event.ID3,id3Handler);
				dispatcher.removeEventListener(ProgressEvent.PROGRESS,progressHandler);
				dispatcher.removeEventListener(Event.COMPLETE,completeHandler);
				dispatcher.removeEventListener(IOErrorEvent.IO_ERROR,ioErrorHandler);
				dispatcher.removeEventListener(SecurityErrorEvent.SECURITY_ERROR,securityErrorHandler);
			}
		}

		private function id3Handler(event:Event):void
		{
			dispatchEvent(new Event(Event.ID3));
		}

		private function progressHandler(event:ProgressEvent):void
		{
			dispatchEvent(new Event(ProgressEvent.PROGRESS));
		}

		private function ioErrorHandler(event:IOErrorEvent):void
		{
			dispatchEvent(new Event(IOErrorEvent.IO_ERROR));
		}

		private function completeHandler(event:Event):void
		{
			if (sound.length == 0)
			{
				dispatchEvent(new Event(IOErrorEvent.IO_ERROR));
			}
			dispatchEvent(new Event(Event.COMPLETE));
		}

		private function securityErrorHandler(event:SecurityErrorEvent):void
		{
			dispatchEvent(new Event(SecurityErrorEvent.SECURITY_ERROR));
		}



		/******************* 播放状态 ***************/

		//播放完成
		private function soundCompleteHandler(event:Event):void
		{

			if (! _scrubbing)
			{
				next();
				dispatchEvent(new Event(Event.SOUND_COMPLETE));
			}
		}

		//关闭声音（流）
		public function close():void
		{
			if (sound != null)
			{
				soundChannel.stop();
				try
				{
					sound.close();

				}
				catch (error:Error)
				{

				}
				configureListeners(sound,false);
				soundChannel.removeEventListener(Event.SOUND_COMPLETE,soundCompleteHandler);
				sound = null;
			}
		}

		//停止
		public function stop():void
		{
			startTime = 0;
			seek(startTime);
			soundChannel.stop();
			_playing = false;
		}

		//暂停
		public function pause():void
		{

			startTime = soundChannel.position;
			soundChannel.stop();
			_paused = true;
		}

		//播放
		public function resume():void
		{
			_playing = true;
			_paused = false;
			soundChannel.stop();
			seek(startTime);
		}

		//下一曲
		public function next():void
		{
			close();
			if (_url is XMLList)
			{
				if (! _autoPlay)
				{
					_index = _index < _url.length() - 1 ? _index + 1:_index = 0;
				}
			}
			if (_url is Array)
			{

				if (! _autoPlay)
				{
					_index = _index < _url.length - 1 ? _index + 1:_index = 0;
				}
			}
			initPlay();
		}

		//上一曲
		public function prev():void
		{
			close();
			if (_url is XMLList)
			{
				if (! _autoPlay)
				{
					_index = _index > 0 ? _index - 1:_index = _url.length() - 1;
				}
			}
			if (_url is Array)
			{

				if (! _autoPlay)
				{
					_index = _index > 0 ? _index - 1:_index = _url.length - 1;
				}
			}
			initPlay();
		}

		//拖动位置播放
		public function seek(value:Number):void
		{
			if (! _paused)
			{
				soundChannel.stop();
				soundChannel = sound.play(value);
				soundChannel.soundTransform = _transform;
				//播放完成
				soundChannel.addEventListener(Event.SOUND_COMPLETE,soundCompleteHandler);
				if (value > 0 && value >= duration)
				{
					next();
					dispatchEvent(new Event(Event.SOUND_COMPLETE));
				}
			}
			else
			{
				soundChannel.stop();
				soundChannel = sound.play(value);

			}
		}



		/**************** 公开的方法 ****************/

		//soundChannel对象
		public function get scoObject():Object
		{
			return soundChannel;
		}


		//音量
		public function get volume():Number
		{
			return _transform.volume;
		}


		public function set volume(value:Number):void
		{
			_transform.volume = value;
			if (soundChannel != null)
			{
				soundChannel.soundTransform = _transform;
			}
		}

		//声道、平衡
		public function get pan():Number
		{
			return _transform.pan;
		}
		public function set pan(value:Number):void
		{
			_transform.pan = value;
			if (soundChannel!=null)
			{
				soundChannel.soundTransform = _transform;
			}
		}
		

		public function get leftPeak():Number
		{
			return soundChannel.leftPeak;
		}

		public function get rightPeak():Number
		{
			return soundChannel.rightPeak;
		}

		

		//也加载字节
		public function get bytesLoaded():Number
		{
			return sound.bytesLoaded;
		}
		
		//总字节
		public function get bytesTotal():Number
		{
			return sound.bytesTotal;
		}

		//播放的位置
		public function get position():Number
		{
			return soundChannel.position;
		}

		//总长度
		public function get length():Number
		{
			return sound.length;
		}

		public function get duration():Number
		{
			return sound.length/(sound.bytesLoaded/sound.bytesTotal);
		}

		//ID3信息
		public function get ID3Info():Object
		{
			return sound.id3;
		}

		//播放状态
		public function get playing():Boolean
		{
			return _playing;
		}
		
		//暂停状态
		public function get paused():Boolean
		{
			return _paused;
		}

		//播放索引
		public function get index():int
		{
			return _index;
		}

		public function set index(value:int):void
		{
			_index = value;
		}

		//是否调用seek
		public function set scrubbing(value:Boolean):void
		{
			_scrubbing = value;
		}
		
		public function set playing(value:Boolean):void
		{
			_playing = value;
		}

		
		//END







	}

}