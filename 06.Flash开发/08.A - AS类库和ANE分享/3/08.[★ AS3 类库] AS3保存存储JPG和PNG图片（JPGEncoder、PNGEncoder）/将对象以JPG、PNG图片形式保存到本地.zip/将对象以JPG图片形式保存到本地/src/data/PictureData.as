﻿package data
{
	import flash.display.Bitmap;
	import flash.display.Loader;
	
	import flash.events.Event;
	import flash.events.EventDispatcher;
	
	import flash.net.URLRequest
	
	/**
	 * ...
	 * @author TKCB（QQ 2414268040、E-mail tkcb@qq.com）
	 */
	public class PictureData extends EventDispatcher
	{
		/** 位图对象 */
		public var bitmap:Bitmap = new Bitmap();
		
		/**
		 * 构造函数
		 */
		function PictureData() {
			var loa:Loader = new Loader();
			loa.contentLoaderInfo.addEventListener(Event.COMPLETE, bitmapLoader);
			loa.load(new URLRequest("image/图片.jpg"));
		}
		
		/* 图片加载完成 */
		private function bitmapLoader(eve:Event):void {
			bitmap = Bitmap(eve.target.loader.content);
			dispatchEvent(new Event(Event.COMPLETE));
		}
		
	}
}
