﻿package 
{
	import flash.display.MovieClip;
	import flash.display.Bitmap;
	import flash.display.BitmapData;
	import flash.display.Sprite;
	
	import flash.events.MouseEvent;
	
	import flash.net.FileReference;
	
	import flash.utils.ByteArray;
	
	import data.PictureData;
	
	import adobe.JPGEncoder;
	import flash.events.Event;
	
	/**
	 * ...
	 * @author TKCB（QQ 2414268040、E-mail tkcb@qq.com）
	 */
	public class SavePitrue extends Sprite 
	{
		private var bit:PictureData = new PictureData();	// 图片对象（模型）
		private var __mc:MovieClip;							// 舞台mc元件
		
		/**
		 * 构造函数
		 */
		function SavePitrue() {
			bit.addEventListener(Event.COMPLETE, loadComplete);
			__mc = mc;
			savePicture.addEventListener(MouseEvent.CLICK, sacePictureClick);
			saveMovieClip.addEventListener(MouseEvent.CLICK, saveMovieClipClick);
		}
		
		/** 图片加载完成，设置图片并显示 */
		private function loadComplete(eve:Event):void {
			bit.bitmap.x = 90;
			bit.bitmap.y = 70;
			bit.bitmap.scaleX = bit.bitmap.scaleY = 0.12;
			addChild(bit.bitmap);
		}
		
		/** 保存位图到本地 */
		private function sacePictureClick(eve:MouseEvent):void {
			var fil:FileReference = new FileReference();				// 用于保存文件
			var enc:JPGEncoder = new JPGEncoder(80);					// 用于对JPG图片进行编码
			var byte:ByteArray = enc.encode(bit.bitmap.bitmapData);		// 对位图进行编码
			fil.save(byte, "保存出来的图片（Picture）80.jpg");						//保存到磁盘
			byte.clear();
		}
		
		/** 保存MovieClip到本地 */
		private function saveMovieClipClick(eve:MouseEvent):void {
			var fil:FileReference = new FileReference();	// 用于保存文件
			var enc:JPGEncoder = new JPGEncoder(80);		// 用于对JPG图片进行编码，可以设置图片编码质量，100为最高，0为最低
			var bitmapData:BitmapData = new BitmapData(__mc.width, __mc.height);
			bitmapData.draw(__mc);
			var byte:ByteArray = enc.encode(bitmapData);	// 对位图进行编码
			fil.save(byte, "保存出来的图片（MovieClip）80.jpg");			//保存到磁盘
			byte.clear();
		}
	}
}