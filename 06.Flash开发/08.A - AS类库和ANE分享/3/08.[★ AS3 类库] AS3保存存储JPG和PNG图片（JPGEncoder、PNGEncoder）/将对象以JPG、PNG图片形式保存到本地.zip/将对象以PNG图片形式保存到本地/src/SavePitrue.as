﻿package 
{
	import flash.display.MovieClip;
	import flash.display.Bitmap;
	import flash.display.BitmapData;
	import flash.display.Sprite;
	
	import flash.events.MouseEvent;
	
	import flash.net.FileReference;
	
	import flash.utils.ByteArray;
	
	import com.tkcb.display.BitmapModel;
	
	import adobe.PNGEncoder;
	import flash.events.Event;
	
	/**
	 * ...
	 * @author TKCB（QQ 2414268040、E-mail tkcb@qq.com）
	 */
	public class SavePitrue extends Sprite 
	{
		private var bm:BitmapModel;		// 图片对象（模型）
		private var __mc:MovieClip;		// 舞台mc元件
		
		/**
		 * 构造函数
		 */
		function SavePitrue() {
			bm = new BitmapModel("image/图片.jpg");
			bm.addEventListener(Event.COMPLETE, loadComplete);
			
			__mc = mc;
			savePicture.addEventListener(MouseEvent.CLICK, sacePictureClick);
			saveMovieClip.addEventListener(MouseEvent.CLICK, saveMovieClipClick);
		}
		
		/** 图片加载完成，设置图片并显示 */
		private function loadComplete(eve:Event):void {
			bm.bitmap.x = 90;
			bm.bitmap.y = 70;
			bm.bitmap.scaleX = bm.bitmap.scaleY = 0.12;
			addChild(bm.bitmap);
		}
		
		/** 保存位图到本地 */
		private function sacePictureClick(eve:MouseEvent):void {
			var fil:FileReference = new FileReference();						// 用于保存文件
			var byte:ByteArray = PNGEncoder.encode(bm.bitmap.bitmapData);		// 对位图进行编码
			fil.save(byte, "保存出来的图片（Picture）.png");						//保存到磁盘
			byte.clear();
		}
		
		/** 保存MovieClip到本地 */
		private function saveMovieClipClick(eve:MouseEvent):void {
			var fil:FileReference = new FileReference();		// 用于保存文件
			var bitmapData:BitmapData = new BitmapData(__mc.width, __mc.height);
			bitmapData.draw(__mc);
			var ilen:int = bitmapData.width;
			var jlen:int = bitmapData.height;
			// 循环设置颜色透明度
			for (var i:int = 0; i < ilen; i++) {
				for (var j:int = 0; j < jlen; j++) {
					if (bitmapData.getPixel(i, j) == 0xFFFFFF) {
						bitmapData.setPixel32(i, j, 0x00000000);
					}
				}
			}
			var byte:ByteArray = PNGEncoder.encode(bitmapData);		// 对位图进行编码
			fil.save(byte, "保存出来的图片（MovieClip）.png");		//保存到磁盘
			byte.clear();
		}
	}
}