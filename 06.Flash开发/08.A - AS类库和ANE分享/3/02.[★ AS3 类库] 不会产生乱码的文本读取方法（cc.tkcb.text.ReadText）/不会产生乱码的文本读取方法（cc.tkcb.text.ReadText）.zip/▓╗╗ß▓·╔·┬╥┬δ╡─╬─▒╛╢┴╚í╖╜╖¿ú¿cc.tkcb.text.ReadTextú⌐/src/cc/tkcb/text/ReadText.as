﻿/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 2016-2018 TKCB, tkcb@qq.com
 *
 *
 * This is free software/program/code: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * 这是一个自由软件/程序/代码，您可以自由分发、修改其中的源代码或者重新发布它，
 * 新的任何修改后的重新发布版必须同样在遵守LGPL3或更后续的版本协议下发布。
 * 关于LGPL协议的细则请参考COPYING、COPYING.LESSER文件，
 * 你可以在文件夹中获得LGPL协议的副本，如果没有找到，请连接到 http://www.gnu.org/licenses/ 查看。
 *
 *
 * 作　　者：TKCB
 * 作者信息：身高（0.00167公里+）；体重（0.06吨±）；年龄（公元1990后）；籍贯（有兵马俑的地方）；星座（最后一个星座）；血型（万能型）；人生格言（The king come back.）。
 * 交流学习：加QQ群[AS3殿堂之路]（96759336），群里有无数主城、架构、妹子、LOL战友，欢迎交流讨论。
 * 联系方式：QQ（2414268040）；E-mail（tkcb@qq.com）；手机（15029932353)。
 * 作者网站：www.tkcb.cc（来这里关注我吧，这里有我所有的作品，分享的资料，我的介绍和动态，还有更多你想不到的）
 *
 *
 * 获取软件/程序最新版本：www.tkcb.cc
 *
 *
 * 版权协议：请自觉遵守LGPL协议，欢迎复制、转载、传播给更多需要的人。
 * 免责声明：任何因使用此软件导致的纠纷与软件/程序开发者无关。
 */


/* 
 * @version 版本创建时间和修改说明
 * v1.0.0 2017-11-26
 * v1.1.0 2018-8-13 对类做结构性调整，静态化，并且改变一些对外的API名称（功能上和以前保持一致）
 */

package cc.tkcb.text
{
	import flash.utils.ByteArray;	

	
	/**
	 * ReadText 不会产生乱码的读取文本的类，用于可能出现多种格式的情况，可用于某些情况下不能使用“System.useCodePage = true;”的情况
	 * @author TKCB（www.tkcb.cc）
	 * @创建时间 未知
	 * @修改时间 2018-8-13
	 * @version 1.1.0
	 */
	public class ReadText
	{
		//************************ ************************* 静态属性 ******************** *********** *** **////
		/** r\n转换为\n用到的正则表达式 */
		private static var reg : RegExp = /\r\n/g;
		
		
		//************************ ************************* 读取任意文本，获取字符串对象 ******************** *********** *** **////
		/**
		 * 读取任意文本，获取字符串对象
		 * @param textByte 文本文档的字节数组
		 * @param isRNSwitch 是否将\r\n转换为\n以便在Flash中使用和显示，默认是false，因为这样会破坏原有的格式
		 * @return 读取出来的字符串对象
		 */
		public static function getString ( textByte:ByteArray, isRNSwitch:Boolean = false ) : String
		{
			var type : String = getFileType( textByte );			
			var changdu : uint = textByte.length;
			var str : String = "";
			switch ( type )
			{
				case "ANSI" :			   
					textByte.position = 0;
					str = textByte.readMultiByte( changdu - textByte.position, "gb2312" );				
					break;
				
		        case "Unicode" :
		        case "Unicode big endian" :
		        case "UTF-8" :
					str = textByte.toString();
					break;
			}
			if ( isRNSwitch )
			{
				var reg : RegExp = /\r\n/g;
				str = str.replace( reg, "\n" );		
			}
			return str;
		}
		
		/**
		 * 获取文件的字符集类型（UTF-8、ANSI、Unicode、Unicode big endian）
		 * @param fileData 文本文档的字节数组
		 * @return 字符集类型
		 */
		private static function getFileType ( fileData:ByteArray ) : String
		{
			if ( fileData.length < 2 )
			{
				if ( fileData.length == 1 )
				{
					if ( fileData[0] < (0x80) )
					{
						return "UTF-8";
					}
					else
					{
						return "ANSI";
					}
				}
				if ( fileData.length == 0 )
				{
					return "ANSI";
				}
			}
			
			var b0 : int = fileData.readUnsignedByte();
			var b1 : int = fileData.readUnsignedByte();			  
			var fileType : String = "ANSI";
			if ( b0 == 0xFF && b1 == 0xFE )
			{
				fileType = "Unicode";
			}
			else if ( b0 == 0xFE && b1 == 0xFF )
			{
				fileType = "Unicode big endian";
			}
			else if ( b0 == 0xEF && b1 == 0xBB )
			{
				fileType = "UTF-8";
			}
			if ( fileType == "ANSI" )
			{
				fileType = NO_bom_UTF(fileData) ? "UTF-8" : "ANSI";
			}
			return fileType;
        }
		
		/**
		 * 跟据格式标签来判断格式
		 * @param bit 文本文档的字节数组
		 * @return 是否UTF-8格式，如果是返回true，否则返回false
		 */
		private static function NO_bom_UTF ( bit:ByteArray ) : Boolean
		{
			var panduan : Boolean = true;			
			var weizhi : int = 0;			
			while ( weizhi < bit.length )
			{
				// (10000000): 值小于0x80的为ASCII字符
				if ( bit[weizhi] < (0x80) )
				{
					weizhi++;
				}
				// (11000000): 值介于0x80与0xC0之间的为无效UTF-8字符 
				else if ( bit[weizhi] < (0xC0) )
				{
					panduan = false;
					break;
				}
				// (11100000): 此范围内为2字节UTF-8字符
				else if ( bit[weizhi] < (0xE0) )
				{
				    if ( weizhi >= bit.length-1 )
					{
						break;
					}
					if ( (bit[weizhi+1] < (0x80)) || (bit[weizhi+1] >= (0xC0)) )
					{
						panduan = false;
						break;
					}					
					weizhi += 2;
				}
				// (11110000): 此范围内为3字节UTF-8字符
				else if ( bit[weizhi] < (0xF0) )
				{
				    if ( weizhi >= bit.length-2 )
					{
						break;
					}
					if ( (bit[weizhi+1] < (0x80)) || (bit[weizhi+1] >= (0xC0)) )
					{
						panduan = false;
						break;
					}
					if ( (bit[weizhi+2] < (0x80)) || (bit[weizhi+2] >= (0xC0)) )
					{
						panduan = false;
						break;
					}					
					weizhi += 3;
				}
				else
				{
					panduan = false;
					break;
				}
			}
			return panduan;
		}
	}
	
	
}
