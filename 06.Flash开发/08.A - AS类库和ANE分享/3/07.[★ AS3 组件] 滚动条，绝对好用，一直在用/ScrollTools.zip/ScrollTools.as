﻿/**
 * ---------------------------------飞碟---------------------------------
 * 可视对象滚动控制类(每个ScrollTools只能控制一个可视对象)，所有操作必须在add之后;
 * 在次add其它对象，会移除之前的显示内容;
 *     再次添加时：eDirection 方向参数改变的话，如果滚动条是多了，可以再次调用scrollbar函数添加,如果是少了，需要先移除滚动条再添加;
 * 
 * 构造函数:
 *     ScrollTools:
 *       @param eUpErr -- 发生滚动大于此值时，鼠标抬起事件不会触发;
		 @param eOptimize -- 是否在可视对象数量多时优化显示(在滚动内容过多且子对象多的情况下优化将非常有用);
 * 
 * 回调:
 *     update -- 位置滚动后调用;
 *     mouseUp -- 内容MOUSE_UP事件触发时调用(必须有一个DisplayObject参数:事件出发对象);
 *     mouseMove -- 内容MOUSE_MOVE事件触发时调用(通过滚动条引起的内容滚动不会触发此事件);
 *     mouseMoveEnd -- 滚动结束回调;
 * 
 * 属性:
 *    positionX -- (只读属性，使用setPositionX方法设置)内容的横向位置，百分比数值(写入位置，不会出发位置变动的回调函数);
 *    positionY -- (只读属性，使用setPositionY方法设置)内容的纵向位置，百分比数值(写入位置，不会出发位置变动的回调函数);
 *    
 *    scrollPosi -- （滚动条属性）滚动条与可视窗的位置关系;
 *                  "inner" -- 在视图框内侧;
 *                  "outer" -- 在视图框外侧;
 *                  "full" -- 在视图框内外的中间;
 *                  其它 -- 格式（X_int,Y_int,XY_int）前面XY表示可设置X或Y或都设置，后面必须可转为int类型;
 * 
 * 方法:
 *    add -- (再次添加时可能需要手动设置滚动条)添加被控制的可视对象(此可视对象必须在显示列表);
 *		 @param eD -- 被控制的可视对象;
 *		 @param eW、eH -- 可视窗口的宽高;
 *		 @param eDw、eDh -- 不给出此参数以eD对象的宽高为准(此参数必须大于原对象的尺寸);
 *		 @param eDirection -- 滚动方向(默认为纵向)(1：纵向，-1：横向，0：纵向 + 横向);
 *		 @param eRelote -- 与其相关的滚动触发事件对象;
 *		 @param eTx -- 可视对象的起始X位置;
 *		 @param eTx -- 可视对象的起始Y位置;
 *		 @param eTx -- 可视区X位置与可视对象的错位;
 *		 @param eTx -- 可视区Y位置与可视对象的错位;
 *    
 *    remove -- 移除控制(移除后才可以控制其它的对象);
 *		 @param -- 返回被控制的对象(如果有);
 *		 
 *    scrollbar -- 滚动条的控制(要重新赋值滚动条的样式，需要先移除滚动条后方有效果);
 *		 @param eSt -- 滚动条显示状
 *		             -1：移除滚动条;
 *		             0 <= eSt <= 1：alpha值;
 *		 @param eW -- 滚动条的宽度(不是指的宽高的宽，纵向为宽，横向为高);
 *		 @param eBoX、eBoY -- (eBoX、eBuX或另一对必须成对给出)滚动槽对象(X是横向，Y是纵向，需要自己判断给出)（不给出为使用自己带）;
 *		 @param eBuX、eBuY -- 滚动条拖动按钮(X是横向，Y是纵向，需要自己判断给出)（不给出为使用自己带）;
 *		 @param eSty -- 自带滚动条的样式;
 *		           0：圆角滚动槽和按钮;
 *		           1：矩形;
 *		 @param eCoBg -- 自带滚动条的背景色;
 *		 @param eCoBu -- 自带滚动条的按钮色;
 *		 @param eInherit -- 是否继承上一个给出的滚动条的距离及错位属性;
 * 
 *    scrollErr -- 滚动条的错位设置(默认值int.MIN_VALUE为不设置);
 *		 @param ePx、eLx -- 设置横向滚动条的左右与长短的错位;
 *		 @param ePy、eLy -- 设置纵向滚动条的上下与长短的错位;
 * 
 *    dataSize -- 重新写入内容区域大小;
 *		 @param eW、eH -- 重新指定的大小;
 *		 @eToSize -- 指定内部改变内容的width,height值;
 *		 
 *    showSize -- 重新写入可视窗口大小;
 * 
 *    setPositionX -- 可以使用百分比赋值,也可以给出一个确切X位置;
 *           0 <= e <= 1 -- 代表着X位置的百分比;
 *           e > 1 -- 代表着确切的X位置;
 *       @param eScroll -- 是否写入滚动条按钮的位置(如果存在滚动条);
 *    setPositionY -- 可以使用百分比赋值,也可以给出一个确切Y位置;
 *           0 <= e <= 1 -- 代表着X位置的百分比;
 *           e > 1 -- 代表着确切的Y位置;
 *       @param eScroll -- 是否写入滚动条按钮的位置(如果存在滚动条);
 *    upScale -- 刷新父级容器缩放对ScrollTools滚动条定位的影响;
 * ---------------------------------飞碟---------------------------------
 */
package tools{
	import flash.display.DisplayObject;
	import flash.display.DisplayObjectContainer;
	import flash.display.Graphics;
	import flash.display.InteractiveObject;
	import flash.display.Shape;
	import flash.display.Sprite;
	import flash.display.Stage;
	import flash.events.Event;
	import flash.events.MouseEvent;
	import flash.filters.BevelFilter;
	
	public class ScrollTools{
		public var dataScroll:Boolean = true;
		private var rcurEvent:Boolean;
		private var rdateW:int;//滚动内容宽;
		private var rdateH:int;//滚动内容高;
		private var rmain:DisplayObject;
		private var relote:InteractiveObject;//可触发滚动的事件背景对象;
		private var roptimize:Boolean;//是否优化
		private var rupErr:int;//用于确定是否忽略鼠标抬起事件;
		private var rdirection:int;//滚动方向(1：纵向，-1：横向，0：纵向 + 横向);
		private var rdisV:Vector.<DisplayObject>;//用于优化存放可视对象的容器;
		private var rpositionX:Number = 0;//内容所在窗口的X位置(百分比数值);
		private var rpositionY:Number = 0;//内容所在窗口的Y位置(百分比数值);
		private var rmaskErrX:int;//可视区X位置与可视对象的错位;
		private var rmaskErrY:int;//可视区Y位置与可视对象的错位;
		private var rwinW:int;//窗口的宽;
		private var rwinH:int;//窗口的高;
		private var rtopX:int;//起始X位置;
		private var rtopY:int;//起始Y位置;
		//-----------------------滚动条--------------------------
		private var rscrollBu:uint;
		private var rscrollBg:uint;
		private var rscrollStyle:int;// 0：圆角滚动槽和按钮，1：矩形;      
		
		private var rscrollPosi:String;//滚动条与显示区域的远近;
		private var rposiErrX:int;//错位
		private var rlErrX:int;//配合错位的长短
		private var rposiErrY:int;//错位
		private var rlErrY:int;//配合错位的长短
		private var rscrollY:Sprite;
		private var rscrollX:Sprite;
		private var rbutErrX:Number = 0;//横向滚动条按钮起始位置的偏差;
		private var rbutErrY:Number = 0;//纵向滚动条按钮起始位置的偏差;
		private var rscroThick:int;//滚动条厚度;
		private var rsetBarX:Boolean;//滚动条对象是给出的，还是自带的;
		private var rsetBarY:Boolean;//滚动条对象是给出的，还是自带的;
		private var rscroAlpha:Number;//记录着滚动条的透明度;
		private var rbutL:Number;
		private var rbutMax:int;
		//-----------------------滚动条--------------------------
		
		//-----------------------运行的内部记录属性--------------------------
		
		private var rtoOpti:Boolean;//在roptimize == true时优化函数是否需要执行;
		private var rmainC:Boolean;//在改变rmain对象的交互属性前记录的其原始属性值;
		private var rmainE:Boolean;//在改变rmain对象的交互属性前记录的其原始属性值;
		private var rdownX:int;//鼠标按下位置X
		private var rdownY:int;//鼠标按下位置Y
		private var rmoveL:int;//rupErr用到的记录的移动距离;
		private var rdrag:DisplayObject;//记录的滚动条按钮;
		private var rtopScr:String;
		private var rcurObje:InteractiveObject;
		private var rparscaleX:Number = 1;
		private var rparscaleY:Number = 1;
		//-----------------------运行的内部记录属性--------------------------
		
		/**
		 * 可设的回调(在每次位置的变动时触发)，两个参数(X位置百分比，Y位置百分比);
		 */
		public var update:Function;
		/**
		 * 可设的回调(鼠标抬起时触发),参数(e:MouseEvent);
		 */
		public var mouseUp:Function;
		public var mouseMoveEnd:Function;
		public var mouseMove:Function;
		private var rrruning:Boolean;
		public function set runing(e:Boolean):void{
			if(rrruning == e) return;
			rrruning = e;
			if(rmain){
				var Int:InteractiveObject = rmain as InteractiveObject;
				if(Int){
					if(e) Int.addEventListener(MouseEvent.MOUSE_DOWN,rmouseE);
					else Int.removeEventListener(MouseEvent.MOUSE_DOWN,rmouseE);
				}
				if(relote){
					if(e) relote.addEventListener(MouseEvent.MOUSE_DOWN,rmouseE);
					else relote.removeEventListener(MouseEvent.MOUSE_DOWN,rmouseE);
				}
			}
		}
		public function set visible(e:Boolean):void{
			if(rscrollX){
				if(rscrollX.visible == e) return;
				else rscrollX.visible = e;
			}
			if(rscrollY){
				if(rscrollY.visible != e) rscrollY.visible = e;
			}
		}
		/**
		 * 百分比数;
		 * 内容的位置(写入位置，不会出发位置变动的回调函数);
		 */
		public function get positionX():Number{
			return rpositionX;
		}
		/**
		 * 百分比数值;
		 * 内容的位置(写入位置，不会出发位置变动的回调函数);
		 */
		public function get positionY():Number{
			return rpositionY;
		}
		/**
		 * 滚动条与显示区域的远近;
		 *    "inner" -- 在视图框内侧;
		 *    "outer" -- 在视图框外侧;
		 *    "full" -- 在视图框内外的中间;
		 *    其它 -- 格式（X_int,Y_int,XY_int）前面XY表示可设置X或Y或都设置，后面必须可转为int类型;
		 */
		public function get scrollPosi():String{
			return rscrollPosi;
		}
		public function set scrollPosi(e:String):void{
			if(rscrollPosi != e){
				rscrollPosi = e;
				if(rscrollY || rscrollX){
					var X:int = rtopX + rmaskErrX + rwinW;
					var Y:int = rtopY + rmaskErrY + rwinH;
					var Ts:String,setY:Boolean,setX:Boolean;
					setY = setX = true;
					if(e == "outer"){
						rtopScr = e;
						if(rscrollY) var Yto:int = X;
						if(rscrollX) var Xto:int = Y;
					}else if(e == "full"){
						rtopScr = e;
						if(rscrollY) Yto = X - (rscrollY.width >> 1);
						if(rscrollX) Xto = Y - (rscrollX.height >> 1);
					}else if(e == "inner"){
						rtopScr = e;
						if(rscrollY) Yto = X - rscrollY.width;
						if(rscrollX) Xto = Y - rscrollX.height;
					}else{
						if(rscrollY){
							setY = e.indexOf("Y") != -1;
							if(setY){
								Ts = e.slice(e.lastIndexOf("_") + 1);
								Yto = X + int(Ts);
							}
						}
						if(rscrollX){
							setX = e.indexOf("X") != -1;
							if(setX){
								Ts = e.slice(e.lastIndexOf("_") + 1);
								Xto = Y + int(Ts);
							}
						}
					}
					if(setY){
						if(rscrollY) rscrollY.x = Yto;
					}
					if(setX){
						if(rscrollX) rscrollX.y = Xto;
					}
				}
			}
		}
		public function get cacheV():Vector.<DisplayObject>{
			return rdisV;
		}
		/**
		 * 清空引用;
		 */
		public function clear():void{
			if(rscrollX){
				if(rscrollX.hasEventListener(MouseEvent.MOUSE_OVER)) rscrollX.removeEventListener(MouseEvent.MOUSE_OVER,roverE,true);
			}
			if(rscrollY){
				if(rscrollY.hasEventListener(MouseEvent.MOUSE_OVER)) rscrollY.removeEventListener(MouseEvent.MOUSE_OVER,roverE,true);
			}
			remove();
			scrollbar(-1);
		}
		/**
		 * 重新写入内容区域大小;
		 * @param eW、eH -- 重新指定的大小;
		 * @eToSize -- 指定内部改变内容的width,height值;
		 */
		public function dataSize(eW:int = 0,eH:int = 0,eToSize:Boolean = false):void{
			if(eW != 0 && rdateW != eW){
				if(eToSize) rmain.width = eW;
				rdateW = eW;
				var max:int = rwinW - rdateW;
				if(max >= 0){
					rpositionX = 0;
					rmain.x = rtopX;
				}else{
					var mL:int = rtopX + rwinW;
					if(rmain.x > rtopX) rmain.x = rtopX;
					else if(rmain.x + rmain.width < mL) rmain.x = mL - rmain.width;
					rpositionX = (rmain.x - rtopX) / max;
				}
				rsetScrollP(-1);
			}
			if(eH != 0 && rdateH != eH){
				if(eToSize) rmain.height = eH;
				rdateH = eH;
				max = rwinH - rdateH;
				if(max >= 0){
					rpositionY = 0;
					rmain.y = rtopY;
				}else{
					mL = rtopY + rwinH;
					if(rmain.y > rtopY) rmain.y = rtopY;
					else if(rmain.y + eH < mL) rmain.y = mL - rmain.height;
					rpositionY = (rmain.y - rtopY) / max;
				}
				rsetScrollP(1);
				if(roptimize) rupList();
			}
		}
		/**
		 * 重新写入可视窗口大小;
		 */
		public function showSize(eW:int = 0,eH:int = 0):void{
			var Par:DisplayObjectContainer = rmain.parent;
			var isSet:Boolean;
			isSet = eW != 0 && rwinW != eW;
			if(isSet){
				if(rscrollX) rscrollX.x += (eW - rwinW);
				rwinW = eW;
				var max:int = rwinW - rdateW;
				if(max >= 0){
					rpositionX = 0;
					rmain.x = rtopX;
				}else{
					var mL:int = rtopX + rwinW;
					if(rmain.x > rtopX) rmain.x = rtopX;
					else if(rmain.x + rmain.width < mL) rmain.x = mL - rmain.width;
					rpositionX = (rmain.x - rtopX) / max;
				}
			}
			if(eH != 0 && rwinH != eH){
				if(rscrollY) rscrollY.y += (eH - rwinH);
				isSet = true;
				rwinH = eH;
				max = rwinH - rdateH;
				if(max >= 0){
					rpositionY = 0;
					rmain.y = rtopY;
				}else{
					mL = rtopY + rwinH;
					if(rmain.y > rtopY) rmain.y = rtopY;
					else if(rmain.y + rmain.height < mL) rmain.y = mL - rmain.height;
					rpositionY = (rmain.y - rtopY) / max;
				}
				if(roptimize) rupList();
			}
			if(isSet){
				if(eW == 0) eW = rwinW;
				if(eH == 0) eH = rwinH;
				var mask:Shape = Par.getChildByName("ScrollTools_Mask") as Shape;
				var grap:Graphics = mask.graphics;
				grap.clear();
				grap.beginFill(0);
				grap.drawRect(0,0,eW,eH);
				grap.endFill();
				rupScroP();//刷新滚动条的位置
			}
		}
		/**
		 * 刷新滚动条的位置
		 */
		private function rupScroP():void{
			scrollErr(rposiErrX,rlErrX,rposiErrY,rlErrY);
			var posi:String = rscrollPosi;
			rscrollPosi = "";
			if(posi != "inner" && posi != "outer" && posi != "full"){
				if(!rtopScr) rtopScr = "inner";
				scrollPosi = rtopScr;
			}
			scrollPosi = posi;
			rsetScrollP(0);
			if(rscrollX || rscrollY){
				var Par:DisplayObjectContainer = rmain.parent;
				var I:int = Par.getChildIndex(rmain) + 1;
				if(rscrollX) Par.addChildAt(rscrollX,I);
				if(rscrollY) Par.addChildAt(rscrollY,I);
			}
		}
		/**
		 * 滚动条的错位设置(默认值int.MIN_VALUE为不设置);
		 * @param ePx、eLx -- 设置横向滚动条的左右与长短的错位;
		 * @param ePy、eLy -- 设置纵向滚动条的上下与长短的错位;
		 */
		public function scrollErr(ePx:int = int.MIN_VALUE,eLx:int = int.MIN_VALUE,ePy:int = int.MIN_VALUE,eLy:int = int.MIN_VALUE):void{
			var Xp:Boolean = ePx != int.MIN_VALUE,Xl:Boolean = eLx != int.MIN_VALUE,Yp:Boolean = ePy != int.MIN_VALUE,Yl:Boolean = eLy != int.MIN_VALUE;
			if(Xp || Xl){
				if(rdirection < 1){//横向
					if(rscrollX){
						if(Xp){
							rposiErrX = ePx;
							rscrollX.x = rtopX + ePx;
						}
						if(Xl){
							rlErrX = eLx;
							var box:DisplayObject = rscrollX.getChildByName("Bar_Box");
							var but:DisplayObject = rscrollX.getChildByName("Bar_But");
							if(rsetBarX){
								box.width = rwinW + eLx;
								but.scaleX = box.scaleX;
							}else{
								var Sp:Sprite = box as Sprite;
								var L:int = box.height;
								var grap:Graphics = Sp.graphics;
								grap.clear();
								grap.beginFill(rscrollBg);
								if(rscrollStyle == 0) grap.drawRoundRect(0,0,rwinW + eLx,L,L,L);
								else grap.drawRect(0,0,rwinW + eLx,L);
								grap.endFill();
								
								
								
								Sp = but as Sprite;
								
								var buL:int = rscroThick - rbutErrX;
								var bl:int = box.width * rbutL;
								if(bl < 10){
									bl = 10;
									if(bl > box.width) bl = box.width;
								}else if(bl > rbutMax){
									bl = rbutMax;
								}
								
								grap = Sp.graphics;
								grap.clear();
								grap.beginFill(rscrollBu);
								if(rscrollStyle == 0) grap.drawRoundRect(0,0,bl,buL,buL,buL);
								else grap.drawRect(0,0,bl,buL);
								grap.endFill();
								
							}
							var maL:int = box.width + rbutErrX;
							if(but.x + but.width > maL) but.x = maL - but.width;
						}
					}
				}
			}
			if(Yp || Yl){
				if(rdirection > -1){//纵向
					if(rscrollY){
						if(Yp){
							rposiErrY = ePy;
							rscrollY.y = rtopY + ePy;
						}
						if(Yl){
							rlErrY = eLy;
							box = rscrollY.getChildByName("Bar_Box");
							but = rscrollY.getChildByName("Bar_But");
							if(rsetBarY){
								box.height = rwinH + eLy;
								but.scaleY = box.scaleY;
							}else{
								Sp = box as Sprite;
								L = box.width;
								grap = Sp.graphics;
								grap.clear();
								grap.beginFill(rscrollBg);
								if(rscrollStyle == 0) grap.drawRoundRect(0,0,L,rwinH + eLy,L,L);
								else grap.drawRect(0,0,L,rwinH + eLy);
								grap.endFill();
								
								
								Sp = but as Sprite;
								
								buL = rscroThick - rbutErrY;
								bl = box.height * rbutL;
								if(bl < 10){
									bl = 10;
									if(bl > box.height) bl = box.height;
								}else if(bl > rbutMax){
									bl = rbutMax;
								}
								
								grap = Sp.graphics;
								grap.clear();
								grap.beginFill(rscrollBu);
								if(rscrollStyle == 0) grap.drawRoundRect(0,0,buL,bl,buL,buL);
								else grap.drawRect(0,0,buL,bl);
								grap.endFill();
							}
							maL = box.height + rbutErrY;
							if(but.y + but.height > maL) but.y = maL - but.height;
						}
					}
				}
			}
		}
		/**
		 * 滚动条的控制(要重新赋值滚动条的样式，需要先移除滚动条后方有效果);
		 * @param eSt -- 滚动条显示状
		 *             -1：移除滚动条;
		 *             0 <= eSt <= 1：alpha值;
		 * @param eW -- 滚动条的宽度(不是指的宽高的宽，纵向为宽，横向为高);
		 * @param eBoX、eBoY -- (eBoX、eBuX或另一对必须成对给出)滚动槽对象(X是横向，Y是纵向，需要自己判断给出)（不给出为使用自己带）;
		 * @param eBuX、eBuY -- 滚动条拖动按钮(X是横向，Y是纵向，需要自己判断给出)（不给出为使用自己带）;
		 * @param eSty -- 自带滚动条的样式;
		 *           0：圆角滚动槽和按钮;
		 *           1：矩形;
		 * @param eCoBg -- 自带滚动条的背景色;
		 * @param eCoBu -- 自带滚动条的按钮色;
		 * @param eInherit -- 是否继承上一个给出的滚动条的距离及错位属性;
		 */
		public function scrollbar(eSt:Number,eW:int = 10,eBoX:DisplayObjectContainer = null,eBuX:Sprite = null,eBoY:DisplayObjectContainer = null,eBuY:Sprite = null,eSty:int = 0,eCoBg:uint = 0xcccccc,eCoBu:uint = 0x666666,eInherit:Boolean = true,eButL:Number = .1,eButMax:int = 200):void{
			var has:Boolean = eSt >= 0,reSet:Boolean;
			if(has){
				rbutL = eButL;
				rbutMax = eButMax;
				rscroAlpha = eSt;
				var over:Boolean = rscroAlpha != 1;
				rscroThick = eW;
				rscrollStyle = eSty;
				rscrollBg = eCoBg;
				rscrollBu = eCoBu;
				var dc:DisplayObjectContainer = rmain.parent;
				if(!eBoX || !eBoY){
					var fw:Number = eW * .1;
					if(fw < 1) fw = 1;
					else if(fw > 3.5) fw = 3.5;
					var fArrO:Array = [new BevelFilter(fw,45,0,1,16777215,1,0,0,1,1)];
					var fArrU:Array = [new BevelFilter(fw,45,16777215,1,0,1,0,0,1,1)];
					var buL:int = eW - fw;
				}
				if(rdirection < 1){//横向
					if(rscrollX){
						if(rscrollX.alpha != eSt) rscrollX.alpha = eSt;
					}else{
						reSet = true;
						rscrollX = new Sprite();
						rscrollX.name = "Bar_X";
						rscrollX.mouseEnabled = false;
						rsetBarX = Boolean(eBoX);
						if(!rsetBarX){
							var sp:Sprite = new Sprite();
							var grap:Graphics = sp.graphics;
							grap.beginFill(eCoBg);
							if(eSty == 0) grap.drawRoundRect(0,0,rwinW,eW,eW,eW);
							else grap.drawRect(0,0,rwinW,eW);
							grap.endFill();
							eBoX = sp;
							eBoX.filters = fArrO;
						}else{
							eBoX.width = rwinW;
							eBoX.height = eW;
						}
						if(!rsetBarX){
							rbutErrX = fw;
							sp = new Sprite();
							sp.mouseChildren = false;
							var bl:int = eBoX.width * eButL;
							if(bl < 10){
								bl = 10;
								if(bl > eBoX.width) bl = eBoX.width;
							}else if(bl > eButMax){
								bl = eButMax;
							}
							grap = sp.graphics;
							grap.beginFill(eCoBu);
							if(eSty == 0) grap.drawRoundRect(0,0,bl,buL,buL,buL);
							else grap.drawRect(0,0,bl,buL);
							grap.endFill();
							sp.filters = fArrU;
							sp.x = sp.y = rbutErrX;
							eBuX = sp;
						}else{
							sp = eBuX;
							eBuX.scaleX = eBoX.scaleX;
							eBuX.scaleY = eBoX.scaleY;
						}
						sp.mouseChildren = false;
						sp.buttonMode = true;
						eBoX.mouseChildren = false;
						rscrollX.addChild(eBoX);
						rscrollX.addChild(eBuX);
						dc.addChild(rscrollX);
						rscrollX.x = rtopX + rmaskErrX;
						eBoX.name = "Bar_Box";
						eBuX.name = "Bar_But";
						if(eSt != 0) rscrollX.alpha = eSt;
						rscrollX.addEventListener(MouseEvent.MOUSE_DOWN,rscrollE);
					}
					if(over){
						if(!rscrollX.hasEventListener(MouseEvent.MOUSE_OVER)) rscrollX.addEventListener(MouseEvent.MOUSE_OVER,roverE,true);
					}else{
						if(rscrollX.hasEventListener(MouseEvent.MOUSE_OVER)) rscrollX.removeEventListener(MouseEvent.MOUSE_OVER,roverE,true);
					}
				}
				if(rdirection > -1){//纵向
					if(rscrollY){
						if(rscrollY.alpha != eSt) rscrollY.alpha = eSt;
					}else{
						reSet = true;
						dc = rmain.parent;
						rscrollY = new Sprite();
						rscrollY.name = "Bar_Y";
						rscrollY.mouseEnabled = false;
						rsetBarY = Boolean(eBoY);
						if(!rsetBarY){
							fArrO = [new BevelFilter(fw,45,0,1,16777215,1,0,0,1,1)];
							sp = new Sprite();
							grap = sp.graphics;
							grap.beginFill(eCoBg);
							if(eSty == 0) grap.drawRoundRect(0,0,eW,rwinH,eW,eW);
							else grap.drawRect(0,0,eW,rwinH);
							grap.endFill();
							eBoY = sp;
							eBoY.filters = fArrO;
						}
						if(!eBuY){
							buL = eW - fw;
							rbutErrY = fw;
							fArrU = [new BevelFilter(fw,45,16777215,1,0,1,0,0,1,1)];
							sp = new Sprite();
							sp.mouseChildren = false;
							bl = eBoY.height * eButL;
							if(bl < 10){
								bl = 10;
								if(bl > eBoY.height) bl = eBoY.height;
							}else if(bl > eButMax){
								bl = eButMax;
							}
							grap = sp.graphics;
							grap.beginFill(eCoBu);
							if(eSty == 0) grap.drawRoundRect(0,0,buL,bl,buL,buL);
							else grap.drawRect(0,0,buL,bl);
							grap.endFill();
							sp.filters = fArrU;
							sp.x = sp.y = rbutErrY;
							eBuY = sp;
						}else{
							sp = eBuY;
						}
						sp.mouseChildren = false;
						sp.buttonMode = true;
						eBoY.mouseChildren = false;
						rscrollY.addChild(eBoY);
						rscrollY.addChild(eBuY);
						dc.addChild(rscrollY);
						rscrollY.y = rtopY + rmaskErrY;
						eBoY.name = "Bar_Box";
						eBuY.name = "Bar_But";
						if(eSt != 0) rscrollY.alpha = eSt;
						rscrollY.addEventListener(MouseEvent.MOUSE_DOWN,rscrollE);
					}
					if(over){
						if(!rscrollY.hasEventListener(MouseEvent.MOUSE_OVER)) rscrollY.addEventListener(MouseEvent.MOUSE_OVER,roverE,true);
					}else{
						if(rscrollY.hasEventListener(MouseEvent.MOUSE_OVER)) rscrollY.removeEventListener(MouseEvent.MOUSE_OVER,roverE,true);
					}
				}
				if(reSet){
					if(eInherit){
						var posi:String = rscrollPosi;
						rscrollPosi = "";
						if(!posi){
							posi = rtopScr = "inner";
						}else if(posi != "inner" && posi != "outer" && posi != "full"){
							if(!rtopScr) rtopScr = "inner";
							scrollPosi = rtopScr;
						}
						scrollPosi = posi;
						scrollErr(rposiErrX,rlErrX,rposiErrY,rlErrY);
					}else{
						scrollPosi = rtopScr = "inner";
						rposiErrX = rlErrX = rposiErrY = rlErrY = 0;
					}
				}
			}else{
				if(rscrollX){
					rscrollX.removeEventListener(MouseEvent.MOUSE_DOWN,rscrollE);
					dc = rscrollX.parent;
					if(dc) dc.removeChild(rscrollX);
					rscrollX = null;
				}
				if(rscrollY){
					rscrollY.removeEventListener(MouseEvent.MOUSE_DOWN,rscrollE);
					dc = rscrollY.parent;
					if(dc) dc.removeChild(rscrollY);
					rscrollY = null;
				}
			}
		}
		/**
		 * 移除控制(移除后才可以控制其它的对象);
		 * @param -- 返回被控制的对象(如果有);
		 */
		public function remove():DisplayObject{
			var ds:DisplayObject = rmain;
			if(rmain){
				var Par:DisplayObjectContainer = rmain.parent;
				var ma:DisplayObject = Par.getChildByName("ScrollTools_Mask");
				if(rmain.mask == ma) rmain.mask = null;
				Par.removeChild(ma);
				if(rmain is InteractiveObject){
					var In:InteractiveObject = rmain as InteractiveObject;
					if(In.mouseEnabled != rmainE) In.mouseEnabled = rmainE;
					In.removeEventListener(MouseEvent.MOUSE_DOWN,rmouseE);
					if(rmain is DisplayObjectContainer){
						var dc:DisplayObjectContainer = rmain as DisplayObjectContainer;
						if(dc.mouseChildren != rmainC) dc.mouseChildren = rmainC;
					}
					rmain = null;
				}
				if(relote){
					relote.removeEventListener(MouseEvent.MOUSE_DOWN,rmouseE);
					relote = null;
				}
				if(roptimize){
					if(rdisV.length != 0) rdisV.length = 0;
				}
				rdateW = rdateH = rpositionX = rpositionY = rmaskErrX = rmaskErrY = rwinW = rwinH = rtopX = rtopY = rmoveL = 0;
				rtoOpti = false;
			}
			return ds;
		}
		/**
		 * 可以使用百分比赋值,也可以给出一个确切X位置;
		 * 0 <= e <= 1 -- 代表着X位置的百分比;
		 * e > 1 -- 代表着确切的X位置;
		 * @param eScroll -- 是否写入滚动条按钮的位置(如果存在滚动条);
		 */
		public function setPositionX(e:Number,eScroll:Boolean = true):void{
			if(rpositionX != e && rdirection < 1){
				if(e >= 0 && e <= 1){
					var max:int = rwinW - rdateW
					rmain.x = e * max + rtopX;
					rpositionX = e;
				}else{
					rsetP(e,int.MAX_VALUE,true,false);
				}
				if(eScroll) rsetScrollP(-1);
			}
		}
		/**
		 * 可以使用百分比赋值,也可以给出一个确切Y位置;
		 * 0 <= e <= 1 -- 代表着Y位置的百分比;
		 * e > 1 -- 代表着确切的Y位置;
		 * @param eScroll -- 是否写入滚动条按钮的位置(如果存在滚动条);
		 */
		public function setPositionY(e:Number,eScroll:Boolean = true):void{
			if(rpositionY != e && rdirection > -1){
				if(e >= 0 && e <= 1){
					var max:int = rwinH - rdateH
					rmain.y = e * max + rtopY;
					rpositionY = e;
					if(roptimize) rupList();
				}else{
					rsetP(int.MAX_VALUE,e,true,false);
				}
				if(eScroll) rsetScrollP(1);
			}
		}
		/**
		 * (再次添加时可能需要手动设置滚动条)添加被控制的可视对象(此可视对象必须在显示列表);
		 * @param eD -- 被控制的可视对象;
		 * @param eW、eH -- 可视窗口的宽高;
		 * @param eDw、eDh -- 不给出此参数以eD对象的宽高为准(此参数必须大于原对象的尺寸);
		 * @param eDirection -- 滚动方向(默认为纵向)(1：纵向，-1：横向，0：纵向 + 横向);
		 * @param eRelote -- 与其相关的滚动触发事件对象;
		 * @param eTx -- 可视对象的起始X位置;
		 * @param eTy -- 可视对象的起始Y位置;
		 * @param eErrX -- 可视区X位置与可视对象的错位;
		 * @param eErrY -- 可视区Y位置与可视对象的错位;
		 * @param eMask -- 用于给出非普通的遮罩;
		 */
		public function add(eD:DisplayObject,eW:int,eH:int,eDw:int = 0,eDh:int = 0,eDirection:int = 0,eRelote:InteractiveObject = null,eTx:int = 0,eTy:int = 0,eErrX:int = 0,eErrY:int = 0,eMask:DisplayObject = null):void{
			if(rmain) remove();
			rrruning = true;
			rmain = eD;
			rmain.x = eTx;
			rmain.y = eTy;
			if(eDw == 0) rdateW = eD.width;
			else rdateW = eDw;
			if(eDh == 0) rdateH = eD.height;
			else rdateH = eDh;
			relote = eRelote;
			rdirection = eDirection;
			rwinW = eW;
			rwinH = eH
			rtopX = eTx;
			rtopY = eTy;
			rmaskErrX = eErrX;
			rmaskErrY = eErrY;
			var Par:DisplayObjectContainer = eD.parent;
			if(!eMask){
				var mask:Shape = new Shape();
				var grap:Graphics = mask.graphics;
				grap.beginFill(0);
				grap.drawRect(0,0,eW,eH);
				grap.endFill();
				eMask = mask;
			}
			eMask.name = "ScrollTools_Mask";
			eMask.x = eTx + rmaskErrX;
			eMask.y = eTy + rmaskErrY;
			eD.mask = eMask;
			Par.addChild(eMask);
			if(eD is InteractiveObject){
				var In:InteractiveObject = eD as InteractiveObject;
				rmainE = In.mouseEnabled;
				In.addEventListener(MouseEvent.MOUSE_DOWN,rmouseE);
				rtoOpti = eD is DisplayObjectContainer;
				if(rtoOpti){
					rmainC = (eD as DisplayObjectContainer).mouseChildren;
				}
			}
			if(eRelote) eRelote.addEventListener(MouseEvent.MOUSE_DOWN,rmouseE);
			rupScroP();//刷新滚动条的位置
			if(roptimize) rupList();
		}
		/**
		 * 刷新父级容器缩放对ScrollTools滚动条定位的影响;
		 */
		public function upScale():void{
			if(rmain) rsetScale(rmain);
			function rsetScale(_e:DisplayObject):void{
				var _par:DisplayObject = _e.parent;
				if(_par && (_par is Stage) == false){
					if(_par.scaleX != 1) rparscaleX *= _par.scaleX;
					if(_par.scaleY != 1) rparscaleY *= _par.scaleY;
					rsetScale(_par);
				}
			}
		}
		/**
		 * 通过百分比设置滚动条按钮的位置;
		 */
		private function rsetScrollP(eTy:int = 0):void{
			var oS:String = "Bar_Box",uX:String = "Bar_But";
			if(eTy < 1){
				if(rscrollX){
					var Box:DisplayObject = rscrollX.getChildByName(oS);
					var But:DisplayObject = rscrollX.getChildByName(uX);
					var L:int = Box.width - But.width - rbutErrX;
					But.x = rbutErrX + L * rpositionX;
				}
			}
			if(eTy > -1){
				if(rscrollY){
					Box = rscrollY.getChildByName(oS);
					But = rscrollY.getChildByName(uX);
					L = Box.height - But.height - rbutErrY;
					But.y = rbutErrY + L * rpositionY;
				}
			}
		}
		/**
		 * 滚动条的侦听;
		 */
		private function rstageE(e:Event):void{
			var Par:DisplayObjectContainer = rdrag.parent;
			if(e.type == MouseEvent.MOUSE_MOVE){
				var eM:MouseEvent = e as MouseEvent;
				var Box:DisplayObject = Par.getChildByName("Bar_Box");
				if(Par.name == "Bar_Y"){
					var L:Number = (eM.stageY - rdownY);
					if(rparscaleY != 1) L = L / rparscaleY;
					if(L != 0){
						var P:Number = rdrag.y + L;
						var max:Number = Box.height - rdrag.height;
						if(P < rbutErrY) P = rbutErrY;
						else if(P + rdrag.height > Box.height) P = max;
						rdrag.y = P;
						L = max - rbutErrY;
						var N:Number = (P - rbutErrY) / L;
						setPositionY(N,false);
						rdownY = eM.stageY;
					}
				}else{
					L = eM.stageX - rdownX;
					if(rparscaleX != 1) L = L / rparscaleX
					if(L != 0){
						P = rdrag.x + L;
						max = Box.width - rdrag.width;
						if(P < rbutErrX) P = rbutErrX;
						else if(P + rdrag.width > Box.width) P = max;
						rdrag.x = P;
						L = max - rbutErrX;
						N = (P - rbutErrX) / L;
						setPositionX(N,false);
						rdownX = eM.stageX;
					}
				}
			}else{
				var Dc:DisplayObjectContainer = e.currentTarget as DisplayObjectContainer;
				Dc.removeEventListener(MouseEvent.MOUSE_UP,rstageE);
				Dc.removeEventListener(MouseEvent.MOUSE_MOVE,rstageE);
				Dc.removeEventListener(Event.MOUSE_LEAVE,rstageE);
				Dc.mouseChildren = true;
				rdrag = null;
				if(rscroAlpha != 1) Par.alpha = rscroAlpha;
			}
		}
		/**
		 * 滚动条侦听;
		 */
		private function rscrollE(e:MouseEvent):void{
			var In:InteractiveObject = e.target as InteractiveObject,Ty:String = e.type;
			var Par:DisplayObjectContainer = In.parent,Na:String = In.name;
			var isY:Boolean = Par.name == "Bar_Y",isBut:Boolean = Na == "Bar_But",isDown:Boolean = Ty == MouseEvent.MOUSE_DOWN;
			
			if(isBut){
				var Box:DisplayObject = Par.getChildByName("Bar_Box");
				var But:DisplayObject = In;
			}else{
				Box = In;
				But = Par.getChildByName("Bar_But");
			}
			if(isY) var ButL:int = But.height;
			else ButL = But.width;
			if(isBut){
				if(isDown){
					if(Par.hasEventListener(MouseEvent.MOUSE_OUT)) Par.removeEventListener(MouseEvent.MOUSE_OUT,roverE,true)
					rdownX = e.stageX;
					rdownY = e.stageY;
					In.stage.mouseChildren = false;
					In.stage.addEventListener(MouseEvent.MOUSE_UP,rstageE);
					In.stage.addEventListener(MouseEvent.MOUSE_MOVE,rstageE);
					In.stage.addEventListener(Event.MOUSE_LEAVE,rstageE);
					rdrag = In;
				}
			}else{
				if(isDown){
					In.addEventListener(MouseEvent.MOUSE_UP,rscrollE);
					In.addEventListener(MouseEvent.MOUSE_OUT,rscrollE);
				}else{
					In.removeEventListener(MouseEvent.MOUSE_UP,rscrollE);
					In.removeEventListener(MouseEvent.MOUSE_OUT,rscrollE);
					if(Ty == MouseEvent.MOUSE_UP){
						if(isY){
							var PN:Number = e.localY / In.height;
							setPositionY(PN,true);
						}else{
							PN = e.localX / In.width;
							setPositionX(PN,true);
						}
					}
				}
			}
		}
		private function roverE(e:MouseEvent):void{
			var Ty:String = e.type,AN:Number;
			var In:InteractiveObject = e.currentTarget as InteractiveObject;
			if(Ty == MouseEvent.MOUSE_OVER){
				AN = 1;
				In.addEventListener(MouseEvent.MOUSE_OUT,roverE,true);
			}else{
				AN = rscroAlpha;
				In.removeEventListener(MouseEvent.MOUSE_OUT,roverE,true);
			}
			In.alpha = AN;
		}
		private function rmouseE(e:MouseEvent):void{
			var In:InteractiveObject = e.target as InteractiveObject,Ty:String = e.type,stY:int = e.stageY,stX:int = e.stageX;
			var tr:Boolean = rdirection > -1,td:Boolean = rdirection < 1;
			if(Ty == MouseEvent.MOUSE_MOVE){
				if(tr) var mY:int = stY - rdownY;
				if(td) var mX:int = stX - rdownX;
				if(mY != 0 || mX != 0){
					if(rupErr != 0) rmoveL = rmoveL + Math.abs(mY) + Math.abs(mX);
					if(rmoveL > rupErr) In.stage.mouseChildren = false;
					rsetP(mX,mY,false,true);
					if(mY != 0) rsetScrollP(1);
					if(mX != 0) rsetScrollP(-1);
					if(tr) rdownY = stY;
					if(td) rdownX = stX;
					
					if(mouseMove != null){
						if(mouseMove.length > 0) mouseMove(e);
						else mouseMove();
					}
				}
			}else{
				if(relote) var isBg:Boolean = In.name == relote.name;
				var Be:Boolean = Ty == MouseEvent.MOUSE_DOWN;
				var dc:DisplayObjectContainer = In.stage;
				if(Be){
					rmoveL = 0;
					rcurObje = In;
					if(tr) rdownY = stY;
					if(td) rdownX = stX;
					if(dataScroll) dc.addEventListener(MouseEvent.MOUSE_MOVE,rmouseE,false,0,true);
					dc.addEventListener(MouseEvent.MOUSE_UP,rmouseE,false,0,true);
				}else if(Ty == MouseEvent.MOUSE_UP){
					if(!dc.mouseChildren) dc.mouseChildren = true;
					if(dc.hasEventListener(MouseEvent.MOUSE_MOVE)){
						dc.removeEventListener(MouseEvent.MOUSE_MOVE,rmouseE);
						dc.removeEventListener(MouseEvent.MOUSE_UP,rmouseE);
					}
					if(rmoveL <= rupErr){
						if(mouseUp != null){
							if(mouseUp.length == 2) mouseUp(e,rcurObje);
							else mouseUp(rcurObje);
						}
					}else if(mouseMoveEnd != null){
						mouseMoveEnd();
					}
				}
			}
		}
		
		/**
		 * eX -- X位滚动(rdirection < 1);
		 * eY -- Y位滚动(rdirection > -1);
		 * eTy -- false：eY、eX值为相对增加值，true：eY、eX直接表示XY的值;
		 * eToE -- 在达到事件触发条件时，是否触发事件;
		 * eScroll -- 是否写入滚动条按钮的位置;
		 */
		private function rsetP(eX:int = int.MAX_VALUE,eY:int = int.MAX_VALUE,eTy:Boolean = false,eToE:Boolean = true):void{
			var Na:Number,Nb:Number,toE:Boolean;
			if(rdirection > -1){
				if(eY != int.MAX_VALUE){
					if(rdateH != rwinH){
						var max:int = rtopY + rwinH;
						if(!eTy) eY = rmain.y + eY;
						
						if(rdateH < rwinH){
							if(eY < rtopY){
								eY = rtopY;
							}else{
								if(eY + rdateH > max) eY = max - rdateH;
							}
						}else{
							if(eY > rtopY){
								eY = rtopY;
							}else{
								if(eY + rdateH < max) eY = max - rdateH;
							}
						}
						if(rmain.y != eY){
							rmain.y = eY;
							Na = rmain.y - rtopY;
							Nb = rwinH - rdateH;
							rpositionY = Na / Nb;
							if(rpositionY < 0) rpositionY = 0;
							toE = true;
							if(update != null) update();
						}
					}else if(rmain.y != rtopY){
						rmain.y = rtopY;
					}
				}
			}
			if(rdirection < 1){
				if(eX != int.MAX_VALUE){
					if(rdateW != rwinW){
						max = rtopX + rwinW;
						if(!eTy) eX = rmain.x + eX;
						
						if(rdateW < rwinW){
							if(eX < rtopX){
								eX = rtopX;
							}else{
								if(eX + rdateW > max) eX = max - rdateW;
							}
						}else{
							if(eX > rtopX){
								eX = rtopX;
							}else{
								if(eX + rdateW < max) eX = max - rdateW;
							}
						}
						if(rmain.x != eX){
							rmain.x = eX;
							Na = rmain.x - rtopX;
							Nb = rwinW - rdateW
							rpositionX = Na / Nb;
							if(rpositionX < 0) rpositionX = 0;
							toE = true;
						}
					}else if(rmain.x != rtopX){
						rmain.x = rtopX;
					}
				}
			}
			if(toE){
				if(eToE){
					if(roptimize) rupList();
				}
			}
		}
		//刷新列表用以优化(roptimize属性决定是否触发);
		private function rupList():void{
			if(rtoOpti){
				var dc:DisplayObjectContainer = rmain as DisplayObjectContainer;
				var l:int = dc.numChildren,ds:DisplayObject;
				var curY:int = dc.y - rtopY,Y:int;
				while(--l > -1){
					ds = dc.getChildAt(l);
					Y = ds.y + curY;
					if(Y < -ds.height || Y > rwinH) rdisV.push(dc.removeChild(ds));
				}
				l = rdisV.length;
				if(l > 0){
					while(--l > -1){
						ds = rdisV[l];
						Y = ds.y + curY;
						if(Y >= -ds.height && Y <= rwinH) dc.addChild(rdisV.splice(l,1)[0]);
					}
				}
			}
		}
		/**
		 * @param eUpErr -- 发生滚动大于此值时，鼠标抬起事件不会触发;
		 * @param eOptimize -- 是否在可视对象数量多时优化显示(在滚动内容过多且子对象多的情况下优化将非常有用);
		 * @param eDscr -- 被控制的对象本身是否可用鼠标控制滚动
		 */
		public function ScrollTools(eUpErr:int = 0,eOptimize:Boolean = false,eDscr:Boolean = true){
			this.dataScroll = eDscr;
			roptimize = eOptimize;
			if(eOptimize) rdisV = new Vector.<DisplayObject>();
			rupErr = eUpErr;
		}
	}
}