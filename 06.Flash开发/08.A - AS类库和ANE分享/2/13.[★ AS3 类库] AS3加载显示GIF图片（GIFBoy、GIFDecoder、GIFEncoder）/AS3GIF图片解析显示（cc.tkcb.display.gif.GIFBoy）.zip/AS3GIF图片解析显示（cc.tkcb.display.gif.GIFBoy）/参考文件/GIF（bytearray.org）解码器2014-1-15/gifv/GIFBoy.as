﻿
package gifv {
	import flash.display.Bitmap;
	import flash.display.BitmapData;
	import flash.events.TimerEvent;
	import flash.utils.ByteArray;
	import flash.utils.Timer;

	public class GIFBoy extends Bitmap {

		public var updateFunc:Function=null;
		public var firstFunc:Function=null;

		//timer
		private const myTimer:Timer=new Timer(1000 / 10, 0);

		private var index:int=0;
		private var totle:uint=0;
		private var inited:Boolean=false;

		//datas
		private const gifDecoder:GIFDecoder=new GIFDecoder();
		private var aFrames:Array=[];
		private var aDelays:Array=[];

		public function GIFBoy() {
		}

		/**
		 * read data
		 */
		public function loadBytes(gBytes:ByteArray):void {
			try {
				gifDecoder.firstFunc=firstView;
				var st:int=gifDecoder.read(gBytes);

				if (st != GIFDecoder.STATUS_OK) {
					dispatchEvent(new GIFEvent(GIFEvent.FAIL));
				} else {
					myTimer.start();
					myTimer.addEventListener(TimerEvent.TIMER, update)
				}

			} catch (e:Error) {
				dispatchEvent(new GIFEvent(GIFEvent.FAIL));
			}
		}

		/**
		 * info
		 */
		public function getCurrent():int {
			return index;
		}

		public function getFrames():int {
			return totle;
		}

		public function isInited():Boolean {
			return inited;
		}
		
		public function getFrame(i:int):BitmapData{
			return aFrames[i];
		}

		public function dispose():void {
			this.bitmapData=null;
			myTimer.stop();
			for each (var b:BitmapData in aFrames) {
				if(b){
					b.dispose();
				}
			}

			aFrames=null;
			aDelays=null;
			totle=0;
		}

		private function firstView(w:int, h:int):void {
			this.bitmapData=gifDecoder.getImage();
			firstFunc(w, h);

			if (updateFunc != null) {
				updateFunc();
			}
		}

		private function update(pEvt:TimerEvent):void {
			if (!inited) {
				try {
					inited=gifDecoder.readFrame();
					totle=gifDecoder.getFrameCount();
				} catch (e:Error) {
					dispatchEvent(new GIFEvent(GIFEvent.OK));
				}

				if (inited) {
					var st:int=gifDecoder.end();
					if (st != GIFDecoder.STATUS_OK) {
						dispatchEvent(new GIFEvent(GIFEvent.FAIL));
					}

					for (var i:int=0; i < totle; i++) {
						aFrames[i]=gifDecoder.getFrame(i);
						aDelays[i]=gifDecoder.getDelay(i);
					}

					dispatchEvent(new GIFEvent(GIFEvent.OK));

					index=0;
				}
			} else {
				var delay:int=aDelays[index];
				if (myTimer.delay != delay) {
					myTimer.delay=delay;
				}

				renderFrame(index);
				index=(index + 1) % totle;

				if (updateFunc != null) {
					updateFunc();
				}
			}
		}

		private function renderFrame(index:int):void {
			if (!inited) {
				return;
			}
			var b:BitmapData=aFrames[index];
			if (b) {
				this.bitmapData=b;
			}
		}
	}
}
