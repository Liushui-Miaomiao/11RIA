﻿/**
 * [开源项目]as3时间处理工具类
 * <br/>
 * <strong>开发版本</strong> v20120321.4
 * <br/>
 * <strong>起点时间</strong> 2011.09.23
 * <br/>
 * <strong>语言版本</strong> as3.0 Flashplayer10
 * <br/>
 * <strong>作者</strong> xuechong
 * <br/>
 * <strong>QQ</strong> 632801102
 * <br/><br/>
 * 函数列表：
 * <br/>
 * dayNum                 得到指定的两个公历日期之间相差的天数  <br/>
 * alreadyOverDay         指定的一年之内已经过了多少天了(算上当天)
 * oneHour                一小时，即60分钟之内的秒数转化
 * oneDay                 一天之内，即24小时之内的秒数转化
 * anyMinutes             不限制在60分钟之内，只要是00:00格式的就行
 * anyHours               不限制在24小时之内，只要是00:00:00格式的就行
 * anyDays                所有时间的秒数转化
 * isLeapYear             是否为闰年
 * greMonthManyDays       指定公历年的某个月多少天
 * manyWorkWeekDay        指定某公历年月内有几天工作日
 * addDateNum             指定公历日期加上一定天数得到新日期
 * delWeekendDaysAllNum   指定日期加上一定天数，返回加上后又减去周六日的总天数后的新日期
 * minusDateNum           指定日期减去一定天数，返回减去后的新日期
 * seqWeekOfMonth         指定公历日期所在周是当月的第几周
 * seqWeekOfYear          指定公历日期所在周是当年的第几周
 * objToTimeFormat        时间Date对象转化为标准时间格式YYYYMMDDHHMMSS
 * yearAnimals            根据指定农历年份获得对应农历的生肖
 * greToLunarArray        返回某公历年月日对应的农历年月日
 * cyclical               获得指定农历年份的天干地支
 * */

/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 2017 TKCB, tkcb@qq.com
 *
 * 
 * This is free software/program/code: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * 这是一个自由软件/程序/代码，您可以自由分发、修改其中的源代码或者重新发布它，
 * 新的任何修改后的重新发布版必须同样在遵守LGPL3或更后续的版本协议下发布。
 * 关于LGPL协议的细则请参考COPYING、COPYING.LESSER文件，
 * 你可以在文件夹中获得LGPL协议的副本，如果没有找到，请连接到 http://www.gnu.org/licenses/ 查看。
 *
 *
 * 修 改 者：TKCB
 * 改者信息：身高（0.00167公里+）；体重（0.06吨±）；年龄（公元1990后）；籍贯（有兵马俑的地方）；星座（最后一个星座）；血型（万能型）；人生格言（The king come back.）。
 * 交流学习：加QQ群[AS3殿堂之路]（96759336），群里有无数主城、架构、妹子、LOL战友，欢迎交流讨论。
 * 联系方式：QQ（2414268040）；E-mail（tkcb@qq.com）；手机（15029932353)。
 * 改者网站：www.tkcb.cc（来这里关注我吧，这里有我所有的作品，分享的资料，我的介绍和动态，还有更多你想不到的）
 *
 * 
 * 获取软件/程序最新版本：www.tkcb.cc
 *
 *
 * 版权协议：请自觉遵守LGPL协议，欢迎复制、转载、传播给更多需要的人。
 * 免责声明：任何因使用此软件导致的纠纷与软件/程序开发者无关。
 */

/* 
 * @version 版本创建时间和修改说明
 * v1.0.0 2016-9-26
 */

package cc.tkcb.date
{
	import cc.tkcb.date.chunbai.AfterDateHandler;
	import cc.tkcb.date.chunbai.AfterDateNoWeekend;
	import cc.tkcb.date.chunbai.AmountDay;
	import cc.tkcb.date.chunbai.BeforeDataHandler;
	import cc.tkcb.date.chunbai.DateAnimal;
	import cc.tkcb.date.chunbai.GreToLunarDate;
	import cc.tkcb.date.chunbai.MusicTimer;
	import cc.tkcb.date.chunbai.TianganDizhi;
	
	
	/**
	 * DateUtil 时间处理工具类
	 * @author chunbai（修改者TKCB（www.tkcb.cc））
	 * @创建时间 位置
	 * @修改时间 2016-9-26
	 * @version 1.0.0
	 */
	public class DateUtil
	{
		public function DateUtil ()
		{
			//trace(dayNum("19881008", "20120315"));    //8559
			//trace(alreadyOverDay("20120315"));    //75,291

			//trace(oneHour(200));    //03:20
			//trace(oneDay(20000));    //05:33:20
			//trace(anyMinutes(1234567));    //20576:07
			//trace(anyHours(1234567));    //342:56:07
			//trace(anyDays(1234567));    //14-06:56:07

			//trace(isLeapYear(2012));    //true
			//trace(greMonthManyDays(2012, 2));    //29
			//trace(manyWorkWeekDay(2012, 3));    //22
			//trace(addDateNum(1988, 10, 8, 8560));    //2012/3/16
			//trace(delWeekendDaysAllNum(2012, 3, 20, 5));    //2012/3/27
			//trace(minusDateNum(2012, 3, 20, 8564));    //1988/10/8

			//trace(seqWeekOfMonth(2012, 3, 20));     //4
			//trace(seqWeekOfYear(2012, 3, 20));    //12

			//trace(objToTimeFormat(new Date()));    //20120320150356

			//trace(yearAnimals(1988));    //龙
			//trace(greToLunarArray(2012, 3, 20));    //2012,2,28,148,1359,40996,0
			//trace(cyclical(2012));    //壬辰
		}

		/**
		 * 得到指定的两个公历日期之间相差的天数 <br/>
		 * 虽然名字为from和to， 两个参数所代表的开始和结束年份没有先后顺序
		 * @param $fromFormatDayStr 开始日期，格式如19881008
		 * @param $toFormatDayStr 结束日期，格式如20120315
		 * @return (int) 相差天数
		 * */
		public static function dayNum ($fromFormatDayStr:String, $toFormatDayStr:String):int
		{
			return AmountDay.manyDayNum($fromFormatDayStr, $toFormatDayStr);
		}

		/**
		 * 指定的一年之内已经过了多少天了(算上当天) <br/>
		 * 要保证dayStr参数的格式和实际含义正确，如不能出现20100229
		 * @param $dayFormatStr 指定的日期，格式如20120315
		 * @return (Array) [0]表示已经过了多少天，[1]表示还剩下多少天
		 * */
		public static function alreadyOverDay ($dayFormatStr:String):Array
		{
			return AmountDay.alreadyOverDay($dayFormatStr);
		}

		/**
		 * 一小时，即60分钟之内的秒数转化 <br/>
		 * 例如：oneHour(3599)     //59:59    //59分钟加59秒
		 * @param $second 描述，其范围是 0 <= $second < 3600
		 * @return (String) 标准指定的时间格式(1小时内)
		 * */
		public static function oneHour ($second:int):String
		{
			return MusicTimer.oneHour($second);
		}

		/**
		 * 一天之内，即24小时之内的秒数转化 <br/>
		 * 如oneDay(86399) //23:59:59    //23小时加59分钟加59秒
		 * @param $second 其范围是 0 <= $second < 86400
		 * @return (String) 标准指定的时间格式(1天内)
		 * */
		public static function oneDay ($second:int):String
		{
			return MusicTimer.oneDay($second);
		}

		/**
		 * 不限制在60分钟之内，只要是00:00格式的就行 <br/>
		 * 如anyMinutes(1234567)     //20576:07   //20576分钟加7秒
		 * @param $second 指定秒数
		 * @return (String) 标准指定的时间格式(XX:XX)
		 * */
		public static function anyMinutes ($second:int):String
		{
			return MusicTimer.anyMinutes($second);
		}

		/**
		 * 不限制在24小时之内，只要是00:00:00格式的就行 <br/>
		 * 如anyHours(1234567)    //342:56:07    //342小时加56分钟加7秒
		 * @param $second 指定秒数
		 * @return (String) 标准指定的时间格式(XX:XX:XX)
		 * */
		public static function anyHours ($second:int):String
		{
			return MusicTimer.anyHours($second);
		}

		/**
		 * 所有时间的秒数转化 <br/>
		 * 如anyDays(1234567)    //14-06:56:07    //14天加6小时加56分钟加7秒
		 * @param $second 其范围是 $second >= 0
		 * @return (String) 标准指定的时间格式(DD-DD:XX:XX)
		 * */
		public static function anyDays ($second:int):String
		{
			return MusicTimer.anyDays($second);
		}

		/**
		 * 是否为公历闰年 <br/>
		 * @param $greYear dayStr标准格式为YYYY，如2010
		 * @return (Boolean) 是润年返回true，不是润年返回false
		 * */
		public static function isLeapYear ($greYear:int):Boolean
		{
			if (($greYear % 4 == 0 && $greYear % 100 != 0) || $greYear % 400 == 0)
			{
				return true;
			}
			else
			{
				return false;
			}
		}

		/**
		 * 指定公历年的某个月有多少天
		 * @param $greYear 年份，如2012
		 * @param $greMonth 月份，如2
		 * @return (int) 指定公历年月的天数
		 * */
		public static function greMonthManyDays ($greYear:int, $greMonth:int):int
		{
			const DAYS_IN_MONTH:Array = [31,28,31,30,31,30,31,31,30,31,30,31];
			var manyDayNum:int = DAYS_IN_MONTH[$greMonth - 1];
			if (isLeapYear2() && $greMonth == 2)
			{
				manyDayNum++;
			}
			function isLeapYear2 ():Boolean
			{
				if (($greYear % 4 == 0 && $greYear % 100 != 0) || $greYear % 400 == 0)
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			return manyDayNum;
		}

		/**
		 * 指定某公历年月内有几天工作日
		 * @param $greYear 公历年份
		 * @param $greMonth 公历月份
		 * @reutrn (int) 返回指定月份工作日的天数
		 * */
		public static function manyWorkWeekDay ($greYear:int, $greMonth:int):int
		{
			var restWeekNum:int = 0;
			var date:Date = new Date($greYear,$greMonth - 1);
			var firstDayWeekNum:Number = date.getDay();//每月的1号是星期几
			var manyDaysNum:int = greMonthManyDays($greYear,$greMonth);
			if (firstDayWeekNum >= 1 && firstDayWeekNum <= 5)
			{
				var numDateNum:int = 27 - firstDayWeekNum;
				if (manyDaysNum == 31)
				{
					if (numDateNum == 22)
					{
						restWeekNum = 10;
					}
					else if (numDateNum == 23)
					{
						restWeekNum = 9;
					}
					else
					{
						restWeekNum = 8;
					}
				}
				else if (manyDaysNum == 30)
				{
					if (numDateNum == 22)
					{//这一号是星期五
						restWeekNum = 9;
					}
					else
					{
						restWeekNum = 8;
					}
				}
				else
				{//每月有28天或29天
					restWeekNum = 8;
				}
			}
			else if (firstDayWeekNum == 6)
			{//周六
				restWeekNum = 10;
				if (manyDaysNum == 28)
				{
					restWeekNum = 8;
				}
				else if (manyDaysNum == 29)
				{
					restWeekNum = 9;
				}
			}
			else if (firstDayWeekNum == 0)
			{//周日
				if (manyDaysNum != 28)
				{
					restWeekNum = 9;
				}
				else
				{
					restWeekNum = 8;
				}
			}
			/*一个公历月有多少天*/
			function greMonthManyDays ():Number
			{
				const DAYS_IN_MONTH:Array = [31,28,31,30,31,30,31,31,30,31,30,31];
				var manyDayNum:Number = DAYS_IN_MONTH[$greMonth - 1];
				if (isLeapYear3() && $greMonth == 2)
				{
					manyDayNum++;
				}
				return manyDayNum;
			}
			/*是否为闰年*/
			function isLeapYear3 ():Boolean
			{
				if (($greYear % 4 == 0 && $greYear % 100 != 0) || $greYear % 400 == 0)
				{
					return true;
				}
				else
				{
					return false;
				}
			}
			return manyDaysNum - restWeekNum;
		}

		/**
		 * 指定公历日期加上一定天数得到新日期 <br/>
		 * 如addDateNum(1988, 10, 8, 7992));    //2010/8/26
		 * @param $greYear 公历年份
		 * @param $greMonth 公历月份
		 * @param $greDay 公历日期
		 * @param $manyDay 加的天数
		 * @return (String) 年/月/日
		 * */
		public static function addDateNum ($greYear:Number, $greMonth:Number, $greDay:Number, $manyDay:Number):String
		{
			return AfterDateHandler.addDateNum($greYear, $greMonth, $greDay, $manyDay);
		}

		/**
		 * 指定日期加上一定天数，返回加上后又减去周六日的总天数后的新日期 <br/>
		 * 如delWeekendDaysAllNum(2012, 3, 20, 5);    //2012/3/27
		 * @param $greYear 公历年份
		 * @param $greMonth 公历月份
		 * @param $greDay 公历日期
		 * @param $manyDay 加的天数
		 * @return (String) 年/月/日
		 * */
		public static function delWeekendDaysAllNum ($greYear:Number, $greMonth:Number, $greDay:Number, $addManyDaysNum:Number):String
		{
			return AfterDateNoWeekend.delWeekendDaysAllNum($greYear, $greMonth, $greDay, $addManyDaysNum);
		}

		/**
		 * 指定日期减去一定天数，返回减去后的新日期 <br/>
		 * 如minusDateNum(2012, 3, 20, 8564);    //
		 * @param $greYear 公历年份
		 * @param $greMonth 公历月份
		 * @param $greDay 公历日期
		 * @param $manyDay 减去的天数
		 * @return (String) 返回减后的日期:年/月/日
		 * */
		public static function minusDateNum ($greYear:Number, $greMonth:Number, $greDay:Number, $manyDay:Number):String
		{
			return BeforeDataHandler.minusDateNum($greYear, $greMonth, $greDay, $manyDay);
		}

		/**
		 * 指定公历日期所在周是当月的第几周 <br/>
		 * 如seqWeekOfMonth(2012, 3, 20);     //4
		 * @param $greYear 公历年份
		 * @param $greMonth 公历月份
		 * @param $greDay 公历日期
		 * @return (Number) 返回当月内的周序列
		 * */
		public static function seqWeekOfMonth ($greYear:Number, $greMonth:Number, $greDay:Number):Number
		{
			var date:Date = new Date($greYear,$greMonth - 1,$greDay);
			var diff:Number = date.getDate() - 1;
			date.setDate (1);
			var dateWeek:Number = 7 - date.getDay();
			if (diff > dateWeek)
			{
				diff -=  dateWeek;
				var dateMod:Number = diff % 7;
				if (dateMod > 0)
				{
					return (diff - dateMod) / 7 + 2;
				}
				else
				{
					return diff / 7 + 1;
				}
			}
			else
			{
				return 1;
			}
		}

		/**
		 * 指定公历日期所在周是当年的第几周 <br/>
		 * 如seqWeekOfYear(2012, 3, 20);    //12
		 * @param $greYear 公历年份
		 * @param $greMonth 公历月份
		 * @param $greDay 公历日期
		 * @return (Number) 返回当年内的周序列
		 * */
		public static function seqWeekOfYear ($greYear:Number, $greMonth:Number, $greDay:Number):Number
		{
			var date:Date = new Date($greYear,$greMonth - 1,$greDay);
			var startDate:Date = new Date($greYear,0,1);
			var diff:Number = date.valueOf() - startDate.valueOf();
			var d:Number = Math.round(diff / 86400000);
			return Math.ceil((d + ((startDate.getDay() + 1) - 1)) / 7);
		}

		/**
		 * 时间Date对象转化为标准时间格式YYYYMMDDHHMMSS <br/>
		 * 如objToTimeFormat(new Date());    //20120320150356
		 * @param $date 指定的日期对象
		 * @return (String) 返回标准时间格式
		 * */
		public static function objToTimeFormat2 ($date:Date):String
		{
			var yearStr:String = String($date.fullYear);
			var monthStr:String = String($date.month + 1);
			var dateStr:String = String($date.date);
			var hourStr:String = String($date.hours);
			var minutesStr:String = String($date.minutes);
			var secondStr:String = String($date.seconds);
			if ($date.month < 9)
			{
				monthStr = "0" + monthStr;
			}
			if ($date.date < 10)
			{
				dateStr = "0" + dateStr;
			}
			if ($date.hours < 10)
			{
				hourStr = "0" + hourStr;
			}
			if ($date.minutes < 10)
			{
				minutesStr = "0" + minutesStr;
			}
			if ($date.seconds < 10)
			{
				secondStr = "0" + secondStr;
			}
			return yearStr + monthStr + dateStr + hourStr + minutesStr + secondStr;
		}

		/**
		 * 根据指定农历年份获得对应农历的生肖 <br/>
		 * 如yearAnimals(1988);    //龙
		 * @param $greYear 指定农历年份
		 * @return (String) 生肖动物名称
		 * */
		public static function yearAnimals ($lunarYear:int):String
		{
			return DateAnimal.yearAnimals($lunarYear);
		}

		/**
		 * 返回某公历年月日对应的农历年月日 <br/>
		 * 如greToLunarArray(2012, 3, 20);    //2012,2,28,148,1359,40996,0
		 * @param $greYear 公历年份
		 * @param $greMonth 公历月份
		 * @param $greDay 公历日期
		 * @return (Array) 返回指定公历年月日对应的农历年月日
		 * */
		public static function greToLunarArray ($greYear:int, $greMonth:int, $greDay:int):Array
		{
			return GreToLunarDate.greToLunarArray($greYear, $greMonth, $greDay);
		}

		/**
		 * 获得指定农历年份的天干地支 <br/>
		 * 注:传入农历年份返回干支(此农历年份要大于等于1864) <br/>
		 * 如cyclical(2012);    //壬辰
		 * @param $lunarYear 指定的农历年份
		 * @return (String) 指定农历年份的天干地支
		 * */
		public static function cyclical ($lunarYear:int):String
		{
			return TianganDizhi.cyclical($lunarYear);
		}
		
		//************************ ************************* TKCB添加的 ******************** *********** *** **////
		/**
		 * 时间Date对象转化为标准时间格式YYYYMMDD
		 * @param date 指定的日期
		 * @return 格式化后的时间字符串
		 */
		public static function objToTimeFormat1 ( date:Date ) : String
		{
			var year : int = date.fullYear;
			var month : int = date.month + 1;
			var day : int = date.date;
			
			var dateStr : String = year + "";
			
			if ( month < 10 ) dateStr += "0" + month;
			else dateStr += month;
			
			if ( day < 10 ) dateStr += "0" + day;
			else dateStr += day;
			
			return dateStr;
		}
		
		/**
		 * 时间Date对象转化为常用的格式
		 * @param date 指定的日期
		 * @param split 分割时间的字符或字符串，通常为“_”，也可以是""的字符串
		 * @return 格式化后的时间字符串
		 */
		public static function objToTimeFormat3 ( date:Date, split:String = "_" ) : String
		{
			var year : int = date.fullYear;
			var month : int = date.month + 1;
			var day : int = date.date;
			var hour : int = date.hours;
			var minute : int = date.minutes;
			var seconds : int = date.seconds;
			
			var dateStr : String = year + "";
			
			if ( month < 10 ) dateStr += split + "0" + month;
			else dateStr += split + month;
			
			if ( day < 10 ) dateStr += split+ "0" + day;
			else dateStr += split + day;
			
			if ( hour < 10 ) dateStr += split+ "0" + hour;
			else dateStr += split + hour;
			
			if ( minute < 10 ) dateStr += split+ "0" + minute;
			else dateStr += split + minute;
			
			if ( seconds < 10 ) dateStr += split+ "0" + seconds;
			else dateStr += split + seconds;
			return dateStr;
		}
		
		/**
		 * 时间Date对象转化为常用的中文格式
		 * @param date 指定的日期
		 * @param split 分割时间的字符或字符串，通常为“-”
		 * @param split2 分割时间的字符或字符串，通常为“ ”
		 * @param split3 分割时间的字符或字符串，通常为“:”
		 * @param split4 分割时间的字符或字符串，通常为“ ”
		 * @return 格式化后的时间字符串
		 */
		public static function objToTimeFormat4 ( date:Date, split:String = "-", split2:String = " ", split3:String = ":", split4:String = " " ) : String
		{
			var year : int = date.fullYear;
			var month : int = date.month + 1;
			var day : int = date.date;
			var hour : int = date.hours;
			var minute : int = date.minutes;
			var seconds : int = date.seconds;
			var dayNum : int = date.day;
			
			var dateStr : String = year + "";
			
			if ( month < 10 ) dateStr += split + "0" + month;
			else dateStr += split + month;
			
			if ( day < 10 ) dateStr += split + "0" + day;
			else dateStr += split + day;
			
			if ( hour < 10 ) dateStr += split2 + "0" + hour;
			else dateStr += split2 + hour;
			
			if ( minute < 10 ) dateStr += split3 + "0" + minute;
			else dateStr += split3 + minute;
			
			if ( seconds < 10 ) dateStr += split3 + "0" + seconds;
			else dateStr += split3 + seconds;
			
			var dayStr : String = "";
			switch ( dayNum )
			{
				case 0:
					dayStr = "日";
					break;
				case 1:
					dayStr = "一";
					break;
				case 2:
					dayStr = "二";
					break;
				case 3:
					dayStr = "三";
					break;
				case 4:
					dayStr = "四";
					break;
				case 5:
					dayStr = "五";
					break;
				case 6:
					dayStr = "六";
					break;
			}
			dateStr += split4 + "星期" + dayStr;
			
			return dateStr;
		}
		
		/**
		 * 时间Date对象转化为常用的中文格式
		 * @param date 指定的日期
		 * @param split 分割时间的字符或字符串，通常为“-”
		 * @param split2 分割时间的字符或字符串，通常为“ ”
		 * @return 格式化后的时间字符串
		 */
		public static function objToTimeFormat5 ( date:Date, split:String = "_", split2:String = " " ) : String
		{
			var year : int = date.fullYear;
			var month : int = date.month + 1;
			var day : int = date.date;
			var dayNum : int = date.day;
			
			var dateStr : String = year + "";
			
			if ( month < 10 ) dateStr += split + "0" + month;
			else dateStr += split + month;
			
			if ( day < 10 ) dateStr += split + "0" + day;
			else dateStr += split + day;
			
			var dayStr : String = "";
			switch ( dayNum )
			{
				case 0:
					dayStr = "日";
					break;
				case 1:
					dayStr = "一";
					break;
				case 2:
					dayStr = "二";
					break;
				case 3:
					dayStr = "三";
					break;
				case 4:
					dayStr = "四";
					break;
				case 5:
					dayStr = "五";
					break;
				case 6:
					dayStr = "六";
					break;
			}
			dateStr += split2 + "星期" + dayStr;
			
			return dateStr;
		}
		
		/**
		 * 得到当前系统时间是否大于指定的时间，通常用作限制软件使用时间
		 * @param year 年
		 * @param month 月
		 * @param day 日
		 * @param hour 时
		 * @param minute 分
		 * @return 返回限制时间是否到期，true为到期，false为没有到期
		 */
		public static function limitDate ( year:uint = 2012, month:uint = 12, day:uint = 12, hour:uint = 0, minute:uint = 0 ) : Boolean
		{
			/// 获取年、月、日、时、分是否大于限制时间，大于则返回true，小于则返回false
			var date:Date = new Date();
			var yeBoo:Boolean = date.fullYear > year;
			var moBoo:Boolean = (date.month + 1) > month;
			var daBoo:Boolean = date.date > day;
			var hoBoo:Boolean = date.hours > hour;
			var miBoo:Boolean = date.minutes > minute;
			if (yeBoo)
			{
				return true;
			}
			else if (date.fullYear == year && moBoo)
			{
				return true;
			}
			else if (date.fullYear == year && ((date.month + 1) == month) && daBoo)
			{
				return true;
			}
			else if (date.fullYear == year && ((date.month + 1) == month) && date.date == day && hoBoo)
			{
				return true;
			}
			else if (date.fullYear == year && ((date.month + 1) == month) && date.date == day && date.hours == hour && miBoo)
			{
				return true;
			}
			else
			{
				return false;
			}
		}
	}
}