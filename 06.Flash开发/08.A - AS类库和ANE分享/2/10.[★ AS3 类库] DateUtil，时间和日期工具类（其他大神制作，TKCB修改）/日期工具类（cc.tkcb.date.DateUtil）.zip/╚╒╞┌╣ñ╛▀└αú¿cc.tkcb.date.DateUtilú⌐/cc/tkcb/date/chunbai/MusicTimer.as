﻿package cc.tkcb.date.chunbai
{
	/**@author xuechong 2010/04/09-17:06  actionScript3.0*/

	public class MusicTimer
	{
		public function MusicTimer ()
		{
		}


		/**11111111111111111111111111111111111111111
		 * 一小时，即60分钟之内的秒数转化，
		 * 参数miao的范围是 0 <= miao < 3600
		 * 例如：oneHour(3599)     //59:59    //59分钟加59秒
		 * 
		 * 
		 * 
		 **/
		public static function oneHour (miao:int):String
		{//miao大于等于0秒小于3600秒：输出的标准格式例如08:20
			var timeFormatStr:String;
			if (miao >= 0 && miao < 3600)
			{
				if (miao < 60)
				{//小于60秒
					if (miao < 10)
					{//小于10秒

						timeFormatStr = "00:0" + miao;
					}
					else
					{
						timeFormatStr = "00:" + miao;
					}
				}
				else
				{//大于等于60秒
					var fenzhong:Number = Math.floor(miao / 60);
					if (fenzhong < 10)
					{//大于等于60秒，小于10分钟
						if (fenzhong < 2)
						{
							if ((miao - 60 * fenzhong) < 10)
							{
								timeFormatStr = "0" + fenzhong + ":" + "0" + (miao - 60 * fenzhong);
							}
							else
							{
								timeFormatStr = "0" + fenzhong + ":" + (miao - 60 * fenzhong);
							}
						}
						else if (fenzhong < 3)
						{
							if ((miao - 60 * fenzhong) < 10)
							{
								timeFormatStr = "0" + fenzhong + ":" + "0" + (miao - 60 * fenzhong);
							}
							else
							{
								timeFormatStr = "0" + fenzhong + ":" + (miao - 60 * fenzhong);
							}
						}
						else if (fenzhong < 4)
						{
							if ((miao - 60 * fenzhong) < 10)
							{
								timeFormatStr = "0" + fenzhong + ":" + "0" + (miao - 60 * fenzhong);
							}
							else
							{
								timeFormatStr = "0" + fenzhong + ":" + (miao - 60 * fenzhong);
							}
						}
						else if (fenzhong < 5)
						{
							if ((miao - 60 * fenzhong) < 10)
							{
								timeFormatStr = "0" + fenzhong + ":" + "0" + (miao - 60 * fenzhong);
							}
							else
							{
								timeFormatStr = "0" + fenzhong + ":" + (miao - 60 * fenzhong);
							}
						}
						else if (fenzhong < 6)
						{
							if ((miao - 60 * fenzhong) < 10)
							{
								timeFormatStr = "0" + fenzhong + ":" + "0" + (miao - 60 * fenzhong);
							}
							else
							{
								timeFormatStr = "0" + fenzhong + ":" + (miao - 60 * fenzhong);
							}
						}
						else if (fenzhong < 7)
						{
							if ((miao - 60 * fenzhong) < 10)
							{
								timeFormatStr = "0" + fenzhong + ":" + "0" + (miao - 60 * fenzhong);
							}
							else
							{
								timeFormatStr = "0" + fenzhong + ":" + (miao - 60 * fenzhong);
							}
						}
						else if (fenzhong < 8)
						{
							if ((miao - 60 * fenzhong) < 10)
							{
								timeFormatStr = "0" + fenzhong + ":" + "0" + (miao - 60 * fenzhong);
							}
							else
							{
								timeFormatStr = "0" + fenzhong + ":" + (miao - 60 * fenzhong);
							}
						}
						else if (fenzhong < 9)
						{
							if ((miao - 60 * fenzhong) < 10)
							{
								timeFormatStr = "0" + fenzhong + ":" + "0" + (miao - 60 * fenzhong);
							}
							else
							{
								timeFormatStr = "0" + fenzhong + ":" + (miao - 60 * fenzhong);
							}
						}
						else if (fenzhong < 10)
						{
							if ((miao - 60 * fenzhong) < 10)
							{
								timeFormatStr = "0" + fenzhong + ":" + "0" + (miao - 60 * fenzhong);
							}
							else
							{
								timeFormatStr = "0" + fenzhong + ":" + (miao - 60 * fenzhong);
							}
						}
					}
					else
					{//大于等于10分钟小于1小时
						if ((miao - 60 * fenzhong) < 10)
						{
							timeFormatStr = fenzhong + ":" + "0" + (miao - 60 * fenzhong);
						}
						else
						{
							timeFormatStr = fenzhong + ":" + (miao - 60 * fenzhong);
						}
					}
				}
			}
			else if (miao < 0)
			{//秒数小于0
				timeFormatStr = "秒数不应为负数！";
			}
			else
			{//秒数等于大于3600
				timeFormatStr = "秒数不应超过3600秒！";
			}
			return timeFormatStr;
		}

		/**222222222222222222222222222222222222222222222222222222
		 * 一天之内，即24小时之内的秒数转化，
		 * 参数miao的范围是 0 <= miao < 86400
		 * 例如：oneDay(86399) //23:59:59    //23小时加59分钟加59秒
		 * 
		 * 
		 * 
		 **/
		public static function oneDay (miao:int):String
		{
			var timeFormatStr:String = "00:00:00";
			if (miao >= 0 && miao < 3600)
			{
				if (miao < 60)
				{//小于60秒
					if (miao < 10)
					{//小于10秒
						timeFormatStr = "00:00:0" + miao;
					}
					else
					{
						timeFormatStr = "00:00:" + miao;
					}
				}
				else
				{//大于等于60秒
					var fenzhong:Number = Math.floor(miao / 60);
					if (fenzhong < 10)
					{//大于等于60秒，小于10分钟
						if (fenzhong < 2)
						{
							if ((miao - 60 * fenzhong) < 10)
							{
								timeFormatStr = "00:0" + fenzhong + ":" + "0" + (miao - 60 * fenzhong);
							}
							else
							{
								timeFormatStr = "00:0" + fenzhong + ":" + (miao - 60 * fenzhong);
							}
						}
						else if (fenzhong < 3)
						{
							if ((miao - 60 * fenzhong) < 10)
							{
								timeFormatStr = "00:0" + fenzhong + ":" + "0" + (miao - 60 * fenzhong);
							}
							else
							{
								timeFormatStr = "00:0" + fenzhong + ":" + (miao - 60 * fenzhong);
							}
						}
						else if (fenzhong < 4)
						{
							if ((miao - 60 * fenzhong) < 10)
							{
								timeFormatStr = "00:0" + fenzhong + ":" + "0" + (miao - 60 * fenzhong);
							}
							else
							{
								timeFormatStr = "00:0" + fenzhong + ":" + (miao - 60 * fenzhong);
							}
						}
						else if (fenzhong < 5)
						{
							if ((miao - 60 * fenzhong) < 10)
							{
								timeFormatStr = "00:0" + fenzhong + ":" + "0" + (miao - 60 * fenzhong);
							}
							else
							{
								timeFormatStr = "00:0" + fenzhong + ":" + (miao - 60 * fenzhong);
							}
						}
						else if (fenzhong < 6)
						{
							if ((miao - 60 * fenzhong) < 10)
							{
								timeFormatStr = "00:0" + fenzhong + ":" + "0" + (miao - 60 * fenzhong);
							}
							else
							{
								timeFormatStr = "00:0" + fenzhong + ":" + (miao - 60 * fenzhong);
							}
						}
						else if (fenzhong < 7)
						{
							if ((miao - 60 * fenzhong) < 10)
							{
								timeFormatStr = "00:0" + fenzhong + ":" + "0" + (miao - 60 * fenzhong);
							}
							else
							{
								timeFormatStr = "00:0" + fenzhong + ":" + (miao - 60 * fenzhong);
							}
						}
						else if (fenzhong < 8)
						{
							if ((miao - 60 * fenzhong) < 10)
							{
								timeFormatStr = "00:0" + fenzhong + ":" + "0" + (miao - 60 * fenzhong);
							}
							else
							{
								timeFormatStr = "00:0" + fenzhong + ":" + (miao - 60 * fenzhong);
							}
						}
						else if (fenzhong < 9)
						{
							if ((miao - 60 * fenzhong) < 10)
							{
								timeFormatStr = "00:0" + fenzhong + ":" + "0" + (miao - 60 * fenzhong);
							}
							else
							{
								timeFormatStr = "00:0" + fenzhong + ":" + (miao - 60 * fenzhong);
							}
						}
						else if (fenzhong < 10)
						{
							if ((miao - 60 * fenzhong) < 10)
							{
								timeFormatStr = "00:0" + fenzhong + ":" + "0" + (miao - 60 * fenzhong);
							}
							else
							{
								timeFormatStr = "00:0" + fenzhong + ":" + (miao - 60 * fenzhong);
							}
						}
					}
					else
					{//大于等于10分钟
						if ((miao - 60 * fenzhong) < 10)
						{
							timeFormatStr = "00:" + fenzhong + ":" + "0" + (miao - 60 * fenzhong);
						}
						else
						{
							timeFormatStr = "00:" + fenzhong + ":" + (miao - 60 * fenzhong);
						}
					}
				}
			}
			else if (miao < 0)
			{
				timeFormatStr = "秒数不应为负数！";
			}
			else if (miao < 86400)
			{
				var xiaoshi:Number = Math.floor(miao / 3600);
				var shiStr:String = "";
				miao = miao - xiaoshi * 3600;
				if (xiaoshi < 10)
				{
					shiStr = "0" + xiaoshi;
				}
				else if (xiaoshi >= 10 && xiaoshi < 24)
				{
					shiStr = String(xiaoshi);
				}
				if (miao < 60)
				{//小于60秒
					if (miao < 10)
					{//小于10秒
						timeFormatStr = shiStr + ":00:0" + miao;
					}
					else
					{
						timeFormatStr = shiStr + ":00:" + miao;
					}
				}
				else
				{//大于等于60秒
					var fenzhong2:Number = Math.floor(miao / 60);
					if (fenzhong2 < 10)
					{//大于等于60秒，小于10分钟
						if (fenzhong2 < 2)
						{
							if ((miao - 60 * fenzhong2) < 10)
							{
								timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + "0" + (miao - 60 * fenzhong2);
							}
							else
							{
								timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + (miao - 60 * fenzhong2);
							}
						}
						else if (fenzhong2 < 3)
						{
							if ((miao - 60 * fenzhong2) < 10)
							{
								timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + "0" + (miao - 60 * fenzhong2);
							}
							else
							{
								timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + (miao - 60 * fenzhong2);
							}
						}
						else if (fenzhong2 < 4)
						{
							if ((miao - 60 * fenzhong2) < 10)
							{
								timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + "0" + (miao - 60 * fenzhong2);
							}
							else
							{
								timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + (miao - 60 * fenzhong2);
							}
						}
						else if (fenzhong2 < 5)
						{
							if ((miao - 60 * fenzhong2) < 10)
							{
								timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + "0" + (miao - 60 * fenzhong2);
							}
							else
							{
								timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + (miao - 60 * fenzhong2);
							}
						}
						else if (fenzhong2 < 6)
						{
							if ((miao - 60 * fenzhong2) < 10)
							{
								timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + "0" + (miao - 60 * fenzhong2);
							}
							else
							{
								timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + (miao - 60 * fenzhong2);
							}
						}
						else if (fenzhong2 < 7)
						{
							if ((miao - 60 * fenzhong2) < 10)
							{
								timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + "0" + (miao - 60 * fenzhong2);
							}
							else
							{
								timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + (miao - 60 * fenzhong2);
							}
						}
						else if (fenzhong2 < 8)
						{
							if ((miao - 60 * fenzhong2) < 10)
							{
								timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + "0" + (miao - 60 * fenzhong2);
							}
							else
							{
								timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + (miao - 60 * fenzhong2);
							}
						}
						else if (fenzhong2 < 9)
						{
							if ((miao - 60 * fenzhong2) < 10)
							{
								timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + "0" + (miao - 60 * fenzhong2);
							}
							else
							{
								timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + (miao - 60 * fenzhong2);
							}
						}
						else if (fenzhong2 < 10)
						{
							if ((miao - 60 * fenzhong2) < 10)
							{
								timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + "0" + (miao - 60 * fenzhong2);
							}
							else
							{
								timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + (miao - 60 * fenzhong2);
							}
						}
					}
					else
					{//大于等于10分钟
						if ((miao - 60 * fenzhong2) < 10)
						{
							timeFormatStr = shiStr + ":" + fenzhong2 + ":" + "0" + (miao - 60 * fenzhong2);
						}
						else
						{
							timeFormatStr = shiStr + ":" + fenzhong2 + ":" + (miao - 60 * fenzhong2);
						}
					}
				}
			}
			return timeFormatStr;
		}


		/**
		 * ========================================================
		 * ========================================================
		 * ====================计时累计秒数函数=======================
		 * ========================================================*/

		/**33333333333333333333333333333333333333333
		 * 不限制在60分钟之内，只要是00:00格式的就行
		 * 例如：    anyMinutes(1234567)     //20576:07   //20576分钟加7秒
		 **/
		public static function anyMinutes (miao:int):String
		{
			var timeFormatStr:String;
			if (miao < 60)
			{//小于60秒
				if (miao < 10)
				{//小于10秒
					timeFormatStr = "00:0" + miao;
				}
				else
				{
					timeFormatStr = "00:" + miao;
				}
			}
			else
			{//大于等于60秒
				var fenzhong:Number = Math.floor(miao / 60);
				if (fenzhong < 10)
				{//大于等于60秒，小于10分钟
					if (fenzhong < 2)
					{
						if ((miao - 60 * fenzhong) < 10)
						{
							timeFormatStr = "0" + fenzhong + ":" + "0" + (miao - 60 * fenzhong);
						}
						else
						{
							timeFormatStr = "0" + fenzhong + ":" + (miao - 60 * fenzhong);
						}
					}
					else if (fenzhong < 3)
					{
						if ((miao - 60 * fenzhong) < 10)
						{
							timeFormatStr = "0" + fenzhong + ":" + "0" + (miao - 60 * fenzhong);
						}
						else
						{
							timeFormatStr = "0" + fenzhong + ":" + (miao - 60 * fenzhong);
						}
					}
					else if (fenzhong < 4)
					{
						if ((miao - 60 * fenzhong) < 10)
						{
							timeFormatStr = "0" + fenzhong + ":" + "0" + (miao - 60 * fenzhong);
						}
						else
						{
							timeFormatStr = "0" + fenzhong + ":" + (miao - 60 * fenzhong);
						}
					}
					else if (fenzhong < 5)
					{
						if ((miao - 60 * fenzhong) < 10)
						{
							timeFormatStr = "0" + fenzhong + ":" + "0" + (miao - 60 * fenzhong);
						}
						else
						{
							timeFormatStr = "0" + fenzhong + ":" + (miao - 60 * fenzhong);
						}
					}
					else if (fenzhong < 6)
					{
						if ((miao - 60 * fenzhong) < 10)
						{
							timeFormatStr = "0" + fenzhong + ":" + "0" + (miao - 60 * fenzhong);
						}
						else
						{
							timeFormatStr = "0" + fenzhong + ":" + (miao - 60 * fenzhong);
						}
					}
					else if (fenzhong < 7)
					{
						if ((miao - 60 * fenzhong) < 10)
						{
							timeFormatStr = "0" + fenzhong + ":" + "0" + (miao - 60 * fenzhong);
						}
						else
						{
							timeFormatStr = "0" + fenzhong + ":" + (miao - 60 * fenzhong);
						}
					}
					else if (fenzhong < 8)
					{
						if ((miao - 60 * fenzhong) < 10)
						{
							timeFormatStr = "0" + fenzhong + ":" + "0" + (miao - 60 * fenzhong);
						}
						else
						{
							timeFormatStr = "0" + fenzhong + ":" + (miao - 60 * fenzhong);
						}
					}
					else if (fenzhong < 9)
					{
						if ((miao - 60 * fenzhong) < 10)
						{
							timeFormatStr = "0" + fenzhong + ":" + "0" + (miao - 60 * fenzhong);
						}
						else
						{
							timeFormatStr = "0" + fenzhong + ":" + (miao - 60 * fenzhong);
						}
					}
					else if (fenzhong < 10)
					{
						if ((miao - 60 * fenzhong) < 10)
						{
							timeFormatStr = "0" + fenzhong + ":" + "0" + (miao - 60 * fenzhong);
						}
						else
						{
							timeFormatStr = "0" + fenzhong + ":" + (miao - 60 * fenzhong);
						}
					}
				}
				else
				{//大于等于10分钟小于1小时
					if ((miao - 60 * fenzhong) < 10)
					{
						timeFormatStr = fenzhong + ":" + "0" + (miao - 60 * fenzhong);
					}
					else
					{
						timeFormatStr = fenzhong + ":" + (miao - 60 * fenzhong);
					}
				}
			}
			return timeFormatStr;
		}

		/**4444444444444444444444444444444444444444444444444444444444444
		 * 不限制在24小时之内，只要是00:00:00格式的就行
		 * 例如： anyHours(1234567)    //342:56:07    //342小时加56分钟加7秒
		 * 
		 **/
		public static function anyHours (miao:int):String
		{
			var timeFormatStr:String = "00:00:00";
			if (miao >= 0 && miao < 3600)
			{
				if (miao < 60)
				{//小于60秒
					if (miao < 10)
					{//小于10秒
						timeFormatStr = "00:00:0" + miao;
					}
					else
					{
						timeFormatStr = "00:00:" + miao;
					}
				}
				else
				{//大于等于60秒
					var fenzhong:Number = Math.floor(miao / 60);
					if (fenzhong < 10)
					{//大于等于60秒，小于10分钟
						if (fenzhong < 2)
						{
							if ((miao - 60 * fenzhong) < 10)
							{
								timeFormatStr = "00:0" + fenzhong + ":" + "0" + (miao - 60 * fenzhong);
							}
							else
							{
								timeFormatStr = "00:0" + fenzhong + ":" + (miao - 60 * fenzhong);
							}
						}
						else if (fenzhong < 3)
						{
							if ((miao - 60 * fenzhong) < 10)
							{
								timeFormatStr = "00:0" + fenzhong + ":" + "0" + (miao - 60 * fenzhong);
							}
							else
							{
								timeFormatStr = "00:0" + fenzhong + ":" + (miao - 60 * fenzhong);
							}
						}
						else if (fenzhong < 4)
						{
							if ((miao - 60 * fenzhong) < 10)
							{
								timeFormatStr = "00:0" + fenzhong + ":" + "0" + (miao - 60 * fenzhong);
							}
							else
							{
								timeFormatStr = "00:0" + fenzhong + ":" + (miao - 60 * fenzhong);
							}
						}
						else if (fenzhong < 5)
						{
							if ((miao - 60 * fenzhong) < 10)
							{
								timeFormatStr = "00:0" + fenzhong + ":" + "0" + (miao - 60 * fenzhong);
							}
							else
							{
								timeFormatStr = "00:0" + fenzhong + ":" + (miao - 60 * fenzhong);
							}
						}
						else if (fenzhong < 6)
						{
							if ((miao - 60 * fenzhong) < 10)
							{
								timeFormatStr = "00:0" + fenzhong + ":" + "0" + (miao - 60 * fenzhong);
							}
							else
							{
								timeFormatStr = "00:0" + fenzhong + ":" + (miao - 60 * fenzhong);
							}
						}
						else if (fenzhong < 7)
						{
							if ((miao - 60 * fenzhong) < 10)
							{
								timeFormatStr = "00:0" + fenzhong + ":" + "0" + (miao - 60 * fenzhong);
							}
							else
							{
								timeFormatStr = "00:0" + fenzhong + ":" + (miao - 60 * fenzhong);
							}
						}
						else if (fenzhong < 8)
						{
							if ((miao - 60 * fenzhong) < 10)
							{
								timeFormatStr = "00:0" + fenzhong + ":" + "0" + (miao - 60 * fenzhong);
							}
							else
							{
								timeFormatStr = "00:0" + fenzhong + ":" + (miao - 60 * fenzhong);
							}
						}
						else if (fenzhong < 9)
						{
							if ((miao - 60 * fenzhong) < 10)
							{
								timeFormatStr = "00:0" + fenzhong + ":" + "0" + (miao - 60 * fenzhong);
							}
							else
							{
								timeFormatStr = "00:0" + fenzhong + ":" + (miao - 60 * fenzhong);
							}
						}
						else if (fenzhong < 10)
						{
							if ((miao - 60 * fenzhong) < 10)
							{
								timeFormatStr = "00:0" + fenzhong + ":" + "0" + (miao - 60 * fenzhong);
							}
							else
							{
								timeFormatStr = "00:0" + fenzhong + ":" + (miao - 60 * fenzhong);
							}
						}
					}
					else
					{//大于等于10分钟
						if ((miao - 60 * fenzhong) < 10)
						{
							timeFormatStr = "00:" + fenzhong + ":" + "0" + (miao - 60 * fenzhong);
						}
						else
						{
							timeFormatStr = "00:" + fenzhong + ":" + (miao - 60 * fenzhong);
						}
					}
				}
			}
			else if (miao < 0)
			{
				timeFormatStr = "秒数不应为负数！";
			}
			else
			{//大于1小时
				var xiaoshi:Number = Math.floor(miao / 3600);
				var shiStr:String = "";
				miao = miao - xiaoshi * 3600;
				if (xiaoshi < 10)
				{
					shiStr = "0" + xiaoshi;
				}
				else if (xiaoshi >= 10)
				{
					shiStr = String(xiaoshi);
				}
				if (miao < 60)
				{//小于60秒
					if (miao < 10)
					{//小于10秒
						timeFormatStr = shiStr + ":00:0" + miao;
					}
					else
					{
						timeFormatStr = shiStr + ":00:" + miao;
					}
				}
				else
				{//大于等于60秒
					var fenzhong2:Number = Math.floor(miao / 60);
					if (fenzhong2 < 10)
					{//大于等于60秒，小于10分钟
						if (fenzhong2 < 2)
						{
							if ((miao - 60 * fenzhong2) < 10)
							{
								timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + "0" + (miao - 60 * fenzhong2);
							}
							else
							{
								timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + (miao - 60 * fenzhong2);
							}
						}
						else if (fenzhong2 < 3)
						{
							if ((miao - 60 * fenzhong2) < 10)
							{
								timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + "0" + (miao - 60 * fenzhong2);
							}
							else
							{
								timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + (miao - 60 * fenzhong2);
							}
						}
						else if (fenzhong2 < 4)
						{
							if ((miao - 60 * fenzhong2) < 10)
							{
								timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + "0" + (miao - 60 * fenzhong2);
							}
							else
							{
								timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + (miao - 60 * fenzhong2);
							}
						}
						else if (fenzhong2 < 5)
						{
							if ((miao - 60 * fenzhong2) < 10)
							{
								timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + "0" + (miao - 60 * fenzhong2);
							}
							else
							{
								timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + (miao - 60 * fenzhong2);
							}
						}
						else if (fenzhong2 < 6)
						{
							if ((miao - 60 * fenzhong2) < 10)
							{
								timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + "0" + (miao - 60 * fenzhong2);
							}
							else
							{
								timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + (miao - 60 * fenzhong2);
							}
						}
						else if (fenzhong2 < 7)
						{
							if ((miao - 60 * fenzhong2) < 10)
							{
								timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + "0" + (miao - 60 * fenzhong2);
							}
							else
							{
								timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + (miao - 60 * fenzhong2);
							}
						}
						else if (fenzhong2 < 8)
						{
							if ((miao - 60 * fenzhong2) < 10)
							{
								timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + "0" + (miao - 60 * fenzhong2);
							}
							else
							{
								timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + (miao - 60 * fenzhong2);
							}
						}
						else if (fenzhong2 < 9)
						{
							if ((miao - 60 * fenzhong2) < 10)
							{
								timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + "0" + (miao - 60 * fenzhong2);
							}
							else
							{
								timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + (miao - 60 * fenzhong2);
							}
						}
						else if (fenzhong2 < 10)
						{
							if ((miao - 60 * fenzhong2) < 10)
							{
								timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + "0" + (miao - 60 * fenzhong2);
							}
							else
							{
								timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + (miao - 60 * fenzhong2);
							}
						}
					}
					else
					{//大于等于10分钟
						if ((miao - 60 * fenzhong2) < 10)
						{
							timeFormatStr = shiStr + ":" + fenzhong2 + ":" + "0" + (miao - 60 * fenzhong2);
						}
						else
						{
							timeFormatStr = shiStr + ":" + fenzhong2 + ":" + (miao - 60 * fenzhong2);
						}
					}
				}
			}
			return timeFormatStr;
		}


		/**555555555555555555555555555555555555555555555555
		 * 所有时间的秒数转化，
		 * 参数miao的范围是 miao >= 0
		 * 例如：anyDays(1234567)    //14-06:56:07    //14天加6小时加56分钟加7秒
		 * 
		 * 
		 * 
		 **/
		public static function anyDays (miao:int):String
		{
			var timeFormatDayStr:String;
			var dayStr:String;
			var hourNum:int;
			var hourStr:String;
			if (miao >= 86400)
			{
				var dayNum:int = Math.floor(miao / 86400);
				dayStr = dayNum + "-";
				var dayIn:int = miao - dayNum * 86400;
				var timeFormatStr:String = "00:00:00";
				if (dayIn >= 0 && dayIn < 3600)
				{
					if (dayIn < 60)
					{//小于60秒
						if (dayIn < 10)
						{//小于10秒
							timeFormatStr = "00:00:0" + dayIn;
						}
						else
						{
							timeFormatStr = "00:00:" + dayIn;
						}
					}
					else
					{//大于等于60秒
						var fenzhong:Number = Math.floor(dayIn / 60);
						if (fenzhong < 10)
						{//大于等于60秒，小于10分钟
							if (fenzhong < 2)
							{
								if ((dayIn - 60 * fenzhong) < 10)
								{
									timeFormatStr = "00:0" + fenzhong + ":" + "0" + (dayIn - 60 * fenzhong);
								}
								else
								{
									timeFormatStr = "00:0" + fenzhong + ":" + (dayIn - 60 * fenzhong);
								}
							}
							else if (fenzhong < 3)
							{
								if ((dayIn - 60 * fenzhong) < 10)
								{
									timeFormatStr = "00:0" + fenzhong + ":" + "0" + (dayIn - 60 * fenzhong);
								}
								else
								{
									timeFormatStr = "00:0" + fenzhong + ":" + (dayIn - 60 * fenzhong);
								}
							}
							else if (fenzhong < 4)
							{
								if ((dayIn - 60 * fenzhong) < 10)
								{
									timeFormatStr = "00:0" + fenzhong + ":" + "0" + (dayIn - 60 * fenzhong);
								}
								else
								{
									timeFormatStr = "00:0" + fenzhong + ":" + (dayIn - 60 * fenzhong);
								}
							}
							else if (fenzhong < 5)
							{
								if ((dayIn - 60 * fenzhong) < 10)
								{
									timeFormatStr = "00:0" + fenzhong + ":" + "0" + (dayIn - 60 * fenzhong);
								}
								else
								{
									timeFormatStr = "00:0" + fenzhong + ":" + (dayIn - 60 * fenzhong);
								}
							}
							else if (fenzhong < 6)
							{
								if ((dayIn - 60 * fenzhong) < 10)
								{
									timeFormatStr = "00:0" + fenzhong + ":" + "0" + (dayIn - 60 * fenzhong);
								}
								else
								{
									timeFormatStr = "00:0" + fenzhong + ":" + (dayIn - 60 * fenzhong);
								}
							}
							else if (fenzhong < 7)
							{
								if ((dayIn - 60 * fenzhong) < 10)
								{
									timeFormatStr = "00:0" + fenzhong + ":" + "0" + (dayIn - 60 * fenzhong);
								}
								else
								{
									timeFormatStr = "00:0" + fenzhong + ":" + (dayIn - 60 * fenzhong);
								}
							}
							else if (fenzhong < 8)
							{
								if ((dayIn - 60 * fenzhong) < 10)
								{
									timeFormatStr = "00:0" + fenzhong + ":" + "0" + (dayIn - 60 * fenzhong);
								}
								else
								{
									timeFormatStr = "00:0" + fenzhong + ":" + (dayIn - 60 * fenzhong);
								}
							}
							else if (fenzhong < 9)
							{
								if ((dayIn - 60 * fenzhong) < 10)
								{
									timeFormatStr = "00:0" + fenzhong + ":" + "0" + (dayIn - 60 * fenzhong);
								}
								else
								{
									timeFormatStr = "00:0" + fenzhong + ":" + (dayIn - 60 * fenzhong);
								}
							}
							else if (fenzhong < 10)
							{
								if ((dayIn - 60 * fenzhong) < 10)
								{
									timeFormatStr = "00:0" + fenzhong + ":" + "0" + (dayIn - 60 * fenzhong);
								}
								else
								{
									timeFormatStr = "00:0" + fenzhong + ":" + (dayIn - 60 * fenzhong);
								}
							}
						}
						else
						{//大于等于10分钟
							if ((miao - 60 * fenzhong) < 10)
							{
								timeFormatStr = "00:" + fenzhong + ":" + "0" + (dayIn - 60 * fenzhong);
							}
							else
							{
								timeFormatStr = "00:" + fenzhong + ":" + (dayIn - 60 * fenzhong);
							}
						}
					}
				}
				else if (dayIn < 0)
				{
					timeFormatStr = "秒数不应为负数！";
				}
				else if (dayIn < 86400)
				{
					var xiaoshi:Number = Math.floor(dayIn / 3600);
					var shiStr:String = "";
					dayIn = dayIn - xiaoshi * 3600;
					if (xiaoshi < 10)
					{
						shiStr = "0" + xiaoshi;
					}
					else if (xiaoshi >= 10 && xiaoshi < 24)
					{
						shiStr = String(xiaoshi);
					}
					if (dayIn < 60)
					{//小于60秒
						if (dayIn < 10)
						{//小于10秒
							timeFormatStr = shiStr + ":00:0" + dayIn;
						}
						else
						{
							timeFormatStr = shiStr + ":00:" + dayIn;
						}
					}
					else
					{//大于等于60秒
						var fenzhong2:Number = Math.floor(dayIn / 60);
						if (fenzhong2 < 10)
						{//大于等于60秒，小于10分钟
							if (fenzhong2 < 2)
							{
								if ((dayIn - 60 * fenzhong2) < 10)
								{
									timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + "0" + (dayIn - 60 * fenzhong2);
								}
								else
								{
									timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + (dayIn - 60 * fenzhong2);
								}
							}
							else if (fenzhong2 < 3)
							{
								if ((dayIn - 60 * fenzhong2) < 10)
								{
									timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + "0" + (dayIn - 60 * fenzhong2);
								}
								else
								{
									timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + (dayIn - 60 * fenzhong2);
								}
							}
							else if (fenzhong2 < 4)
							{
								if ((dayIn - 60 * fenzhong2) < 10)
								{
									timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + "0" + (dayIn - 60 * fenzhong2);
								}
								else
								{
									timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + (dayIn - 60 * fenzhong2);
								}
							}
							else if (fenzhong2 < 5)
							{
								if ((dayIn - 60 * fenzhong2) < 10)
								{
									timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + "0" + (dayIn - 60 * fenzhong2);
								}
								else
								{
									timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + (dayIn - 60 * fenzhong2);
								}
							}
							else if (fenzhong2 < 6)
							{
								if ((dayIn - 60 * fenzhong2) < 10)
								{
									timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + "0" + (dayIn - 60 * fenzhong2);
								}
								else
								{
									timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + (dayIn - 60 * fenzhong2);
								}
							}
							else if (fenzhong2 < 7)
							{
								if ((dayIn - 60 * fenzhong2) < 10)
								{
									timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + "0" + (dayIn - 60 * fenzhong2);
								}
								else
								{
									timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + (dayIn - 60 * fenzhong2);
								}
							}
							else if (fenzhong2 < 8)
							{
								if ((dayIn - 60 * fenzhong2) < 10)
								{
									timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + "0" + (dayIn - 60 * fenzhong2);
								}
								else
								{
									timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + (dayIn - 60 * fenzhong2);
								}
							}
							else if (fenzhong2 < 9)
							{
								if ((dayIn - 60 * fenzhong2) < 10)
								{
									timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + "0" + (dayIn - 60 * fenzhong2);
								}
								else
								{
									timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + (dayIn - 60 * fenzhong2);
								}
							}
							else if (fenzhong2 < 10)
							{
								if ((dayIn - 60 * fenzhong2) < 10)
								{
									timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + "0" + (dayIn - 60 * fenzhong2);
								}
								else
								{
									timeFormatStr = shiStr + ":0" + fenzhong2 + ":" + (dayIn - 60 * fenzhong2);
								}
							}
						}
						else
						{//大于等于10分钟
							if ((dayIn - 60 * fenzhong2) < 10)
							{
								timeFormatStr = shiStr + ":" + fenzhong2 + ":" + "0" + (dayIn - 60 * fenzhong2);
							}
							else
							{
								timeFormatStr = shiStr + ":" + fenzhong2 + ":" + (dayIn - 60 * fenzhong2);
							}
						}
					}
				}
			}
			else
			{
				if (miao >= 0 && miao < 3600)
				{
					if (miao < 60)
					{//小于60秒
						if (miao < 10)
						{//小于10秒
							timeFormatStr = "00:00:0" + miao;
						}
						else
						{
							timeFormatStr = "00:00:" + miao;
						}
					}
					else
					{//大于等于60秒
						var fenzhong3:Number = Math.floor(miao / 60);
						if (fenzhong3 < 10)
						{//大于等于60秒，小于10分钟
							if (fenzhong3 < 2)
							{
								if ((miao - 60 * fenzhong3) < 10)
								{
									timeFormatStr = "00:0" + fenzhong3 + ":" + "0" + (miao - 60 * fenzhong3);
								}
								else
								{
									timeFormatStr = "00:0" + fenzhong3 + ":" + (miao - 60 * fenzhong3);
								}
							}
							else if (fenzhong3 < 3)
							{
								if ((miao - 60 * fenzhong3) < 10)
								{
									timeFormatStr = "00:0" + fenzhong3 + ":" + "0" + (miao - 60 * fenzhong3);
								}
								else
								{
									timeFormatStr = "00:0" + fenzhong3 + ":" + (miao - 60 * fenzhong3);
								}
							}
							else if (fenzhong3 < 4)
							{
								if ((miao - 60 * fenzhong3) < 10)
								{
									timeFormatStr = "00:0" + fenzhong3 + ":" + "0" + (miao - 60 * fenzhong3);
								}
								else
								{
									timeFormatStr = "00:0" + fenzhong3 + ":" + (miao - 60 * fenzhong3);
								}
							}
							else if (fenzhong3 < 5)
							{
								if ((miao - 60 * fenzhong3) < 10)
								{
									timeFormatStr = "00:0" + fenzhong3 + ":" + "0" + (miao - 60 * fenzhong3);
								}
								else
								{
									timeFormatStr = "00:0" + fenzhong3 + ":" + (miao - 60 * fenzhong3);
								}
							}
							else if (fenzhong3 < 6)
							{
								if ((miao - 60 * fenzhong3) < 10)
								{
									timeFormatStr = "00:0" + fenzhong3 + ":" + "0" + (miao - 60 * fenzhong3);
								}
								else
								{
									timeFormatStr = "00:0" + fenzhong3 + ":" + (miao - 60 * fenzhong3);
								}
							}
							else if (fenzhong3 < 7)
							{
								if ((miao - 60 * fenzhong3) < 10)
								{
									timeFormatStr = "00:0" + fenzhong3 + ":" + "0" + (miao - 60 * fenzhong3);
								}
								else
								{
									timeFormatStr = "00:0" + fenzhong3 + ":" + (miao - 60 * fenzhong3);
								}
							}
							else if (fenzhong3 < 8)
							{
								if ((miao - 60 * fenzhong3) < 10)
								{
									timeFormatStr = "00:0" + fenzhong3 + ":" + "0" + (miao - 60 * fenzhong3);
								}
								else
								{
									timeFormatStr = "00:0" + fenzhong3 + ":" + (miao - 60 * fenzhong3);
								}
							}
							else if (fenzhong3 < 9)
							{
								if ((miao - 60 * fenzhong3) < 10)
								{
									timeFormatStr = "00:0" + fenzhong3 + ":" + "0" + (miao - 60 * fenzhong3);
								}
								else
								{
									timeFormatStr = "00:0" + fenzhong3 + ":" + (miao - 60 * fenzhong3);
								}
							}
							else if (fenzhong3 < 10)
							{
								if ((miao - 60 * fenzhong3) < 10)
								{
									timeFormatStr = "00:0" + fenzhong3 + ":" + "0" + (miao - 60 * fenzhong3);
								}
								else
								{
									timeFormatStr = "00:0" + fenzhong3 + ":" + (miao - 60 * fenzhong3);
								}
							}
						}
						else
						{//大于等于10分钟
							if ((miao - 60 * fenzhong3) < 10)
							{
								timeFormatStr = "00:" + fenzhong3 + ":" + "0" + (miao - 60 * fenzhong3);
							}
							else
							{
								timeFormatStr = "00:" + fenzhong3 + ":" + (miao - 60 * fenzhong3);
							}
						}
					}
				}
				else if (miao < 0)
				{
					timeFormatStr = "秒数不应为负数！";
				}
				else
				{
					var xiaoshiC:Number = Math.floor(miao / 3600);
					var shiStrC:String = "";
					miao = miao - xiaoshiC * 3600;
					if (xiaoshiC < 10)
					{
						shiStrC = "0" + xiaoshiC;
					}
					else if (xiaoshiC >= 10 && xiaoshiC < 24)
					{
						shiStrC = String(xiaoshiC);
					}
					if (miao < 60)
					{//小于60秒
						if (miao < 10)
						{//小于10秒
							timeFormatStr = shiStrC + ":00:0" + miao;
						}
						else
						{
							timeFormatStr = shiStrC + ":00:" + miao;
						}
					}
					else
					{//大于等于60秒
						var fenzhong4:Number = Math.floor(miao / 60);
						if (fenzhong4 < 10)
						{//大于等于60秒，小于10分钟
							if (fenzhong4 < 2)
							{
								if ((miao - 60 * fenzhong4) < 10)
								{
									timeFormatStr = shiStrC + ":0" + fenzhong4 + ":" + "0" + (miao - 60 * fenzhong4);
								}
								else
								{
									timeFormatStr = shiStrC + ":0" + fenzhong4 + ":" + (miao - 60 * fenzhong4);
								}
							}
							else if (fenzhong4 < 3)
							{
								if ((miao - 60 * fenzhong4) < 10)
								{
									timeFormatStr = shiStrC + ":0" + fenzhong4 + ":" + "0" + (miao - 60 * fenzhong4);
								}
								else
								{
									timeFormatStr = shiStrC + ":0" + fenzhong4 + ":" + (miao - 60 * fenzhong4);
								}
							}
							else if (fenzhong4 < 4)
							{
								if ((miao - 60 * fenzhong4) < 10)
								{
									timeFormatStr = shiStrC + ":0" + fenzhong4 + ":" + "0" + (miao - 60 * fenzhong4);
								}
								else
								{
									timeFormatStr = shiStrC + ":0" + fenzhong4 + ":" + (miao - 60 * fenzhong4);
								}
							}
							else if (fenzhong4 < 5)
							{
								if ((miao - 60 * fenzhong4) < 10)
								{
									timeFormatStr = shiStrC + ":0" + fenzhong4 + ":" + "0" + (miao - 60 * fenzhong4);
								}
								else
								{
									timeFormatStr = shiStrC + ":0" + fenzhong4 + ":" + (miao - 60 * fenzhong4);
								}
							}
							else if (fenzhong4 < 6)
							{
								if ((miao - 60 * fenzhong4) < 10)
								{
									timeFormatStr = shiStrC + ":0" + fenzhong4 + ":" + "0" + (miao - 60 * fenzhong4);
								}
								else
								{
									timeFormatStr = shiStrC + ":0" + fenzhong4 + ":" + (miao - 60 * fenzhong4);
								}
							}
							else if (fenzhong4 < 7)
							{
								if ((miao - 60 * fenzhong4) < 10)
								{
									timeFormatStr = shiStrC + ":0" + fenzhong4 + ":" + "0" + (miao - 60 * fenzhong4);
								}
								else
								{
									timeFormatStr = shiStrC + ":0" + fenzhong4 + ":" + (miao - 60 * fenzhong4);
								}
							}
							else if (fenzhong4 < 8)
							{
								if ((miao - 60 * fenzhong4) < 10)
								{
									timeFormatStr = shiStrC + ":0" + fenzhong4 + ":" + "0" + (miao - 60 * fenzhong4);
								}
								else
								{
									timeFormatStr = shiStrC + ":0" + fenzhong4 + ":" + (miao - 60 * fenzhong4);
								}
							}
							else if (fenzhong4 < 9)
							{
								if ((miao - 60 * fenzhong4) < 10)
								{
									timeFormatStr = shiStrC + ":0" + fenzhong4 + ":" + "0" + (miao - 60 * fenzhong4);
								}
								else
								{
									timeFormatStr = shiStrC + ":0" + fenzhong4 + ":" + (miao - 60 * fenzhong4);
								}
							}
							else if (fenzhong4 < 10)
							{
								if ((miao - 60 * fenzhong4) < 10)
								{
									timeFormatStr = shiStrC + ":0" + fenzhong4 + ":" + "0" + (miao - 60 * fenzhong4);
								}
								else
								{
									timeFormatStr = shiStrC + ":0" + fenzhong4 + ":" + (miao - 60 * fenzhong4);
								}
							}
						}
						else
						{//大于等于10分钟
							if ((miao - 60 * fenzhong4) < 10)
							{
								timeFormatStr = shiStrC + ":" + fenzhong4 + ":" + "0" + (miao - 60 * fenzhong4);
							}
							else
							{
								timeFormatStr = shiStrC + ":" + fenzhong4 + ":" + (miao - 60 * fenzhong4);
							}
						}
					}
				}
				dayStr = "0" + "-";
			}
			timeFormatDayStr = dayStr + timeFormatStr;
			return timeFormatDayStr;
		}

	}
}