package  
{
	import flash.geom.Rectangle;
	import flash.display.Bitmap;
	import flash.display.StageScaleMode;
	import flash.display.BitmapData;
	import flash.events.Event;
	import flash.net.URLRequest;
	import flash.display.Loader;
	import flash.display.Sprite;

	/**
	 * @author Administrator
	 */
	public class TestCpu_Carmark extends Sprite
	{

		public function TestCpu_Carmark(): void
		{ 
			stage.scaleMode = StageScaleMode.NO_SCALE;
			this.scrollRect = new Rectangle(0, 0, 800, 600 );
			var loader: Loader = new Loader();
			loader.load(new URLRequest("touhou.jpg" ) );
			
			loader.contentLoaderInfo.addEventListener(Event.COMPLETE, onLoaded );
		}

		private function onLoaded(e: Event): void
		{
			var bmd: BitmapData = BitmapData(e.target.content.bitmapData );
			trace("bitmapdata loaded : " + bmd .width + "," + bmd .height );
			//addChild(new Bitmap(bmd ) );
			var cm: CarmackBMP = new CarmackBMP(bmd, 800, 600, 50, 50 ); 
			cm.setPositon(0, 0 );  
			addChild(cm ); 
			//
			this.addEventListener(Event.ENTER_FRAME, onEnterFrame );
			function onEnterFrame(e: Event): void
			{
				cm.scroll(- 1, 0 );
			}
		}
	}
}
