﻿/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 2017 TKCB, tkcb@qq.com
 *
 *
 * This is free software/program/code: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * 这是一个自由软件/程序/代码，您可以自由分发、修改其中的源代码或者重新发布它，
 * 新的任何修改后的重新发布版必须同样在遵守LGPL3或更后续的版本协议下发布。
 * 关于LGPL协议的细则请参考COPYING、COPYING.LESSER文件，
 * 你可以在文件夹中获得LGPL协议的副本，如果没有找到，请连接到 http://www.gnu.org/licenses/ 查看。
 *
 *
 * 作　　者：TKCB
 * 作者信息：身高（0.00167公里+）；体重（0.06吨±）；年龄（公元1990后）；籍贯（有兵马俑的地方）；星座（最后一个星座）；血型（万能型）；人生格言（The king come back.）。
 * 交流学习：加QQ群[AS3殿堂之路]（96759336），群里有无数主城、架构、妹子、LOL战友，欢迎交流讨论。
 * 联系方式：QQ（2414268040）；E-mail（tkcb@qq.com）；手机（15029932353)。
 * 作者网站：www.tkcb.cc（来这里关注我吧，这里有我所有的作品，分享的资料，我的介绍和动态，还有更多你想不到的）
 *
 *
 * 获取软件/程序最新版本：www.tkcb.cc
 *
 *
 * 版权协议：请自觉遵守LGPL协议，欢迎复制、转载、传播给更多需要的人。
 * 免责声明：任何因使用此软件导致的纠纷与软件/程序开发者无关。
 */


/* 
 * @version 版本创建时间和修改说明
 * v1.0.0 2017-10-16
 * v1.1.0 2017-10-18 增加对64进制的支持，采用【0-9 a-z A-Z _ $】这64个字符作为64进制的组成，这样有利于更短的数字压缩、存储、传输、显示等等
 * v1.2.0 2017-10-18 升级机制，添加对94进制的支持，更加强大
 */
 
package cc.tkcb.utils
{
	
	 /**
	 * NumberTool 数字扩展工具 静态类，包括一些常用的扩展功能，任意进制的转换等等
	 * @author TKCB（www.tkcb.cc）
	 * @创建时间 2017-10-16
	 * @修改时间 2017-10-18
	 * @version 1.2.0
	 */
	public class NumberTool
	{
		//************************ ************************* 数字任意进制（2、8、10、16、32、64、94）之间的转换 ******************** *********** *** **////
		/**
		 * 数字的进制转换，可以将（2/8/10/16/32/64/94）等进制之间进行任意转换，因为牵扯到32进制转换，所以转换后的返回值为String类型
		 * 因为AS3虽然没有现成的转换，不过我们可以结合使用parseInt和toString处完成各种进制的转换..
		 * 其中parseInt是把2/8/10/16/32/64/94进制转换成10进制，然后再使用toString把10进制转换成2/8/10/16/32/64/94进制
		 * @param num 要转换的数字，可以是String形式，也可以是数字（Number、int、uint）
		 * @param radix 当前要转换的数字的基进制数，例如，传入的数字是0xFF6600，则此基进制数为16；如果传入的数字是123456789，则此基进制数为10
		 * @param target 目标进制数，要将当前数字转换为的目标进制数（2/8/10/16/32/64/94）
		 */
		public static function numberHexSwitch ( num:*, radix:uint, target:uint ) : String
		{
			var newNum : Number;
			
			// 2/8/10/16/32进制之间的任意转换
			if ( radix <= 32 && target <= 32 )
			{
				// 如果是文本
				if ( num is String )
				{
					newNum = parseInt( num, radix );	// 把2~32进制转换为10进制
				}
				else if ( isNaN(num) == false )
				{
					newNum = num;						// 因为本身已经是数字了
				}
				return newNum.toString( target ); 		// 把10进制转换为2~32进制
			}
			// 大于32进制转换（64、94）
			else
			{
				// 0-9 为10进制，a-f 为16进制，g-v 为32进制，w-$ 为64进制，!-,为94进制
				var hex94 : String = "0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ_$!@#%&?-*=|<{[()]}>;:.^`~'\"\\/+,";
				var i:int, len:int;
				var tempStr : String;
				var tempNum : Number;
				var tempNum2 : Number;
				var tempNum3 : Number;
				var newStr : String;
				
				// radix 基进制数为大于32进制
				if ( radix > 32 && target <= 32 )
				{
					// 先将大的进制转换为10进制
					newNum = 0;
					len = num.length;
					for ( i = 0; i < len; i++ )
					{
						tempStr = num.charAt( num.length - i - 1 );
						tempNum = hex94.indexOf( tempStr );
						newNum += tempNum * Math.pow( radix, i );
					}
					return newNum.toString( target ); 		// 把10进制转换为2~32进制
				}
				// target 目标进制数为大于32进制
				else if ( radix <= 32 && target > 32 )
				{
					tempNum = parseInt( num, radix );  	// 把2~32进制转换为10进制
					
					// 将10进制的数字不断除以64/94，获得每次的余数作为当前位数的值，商如果大于等于64/94继续循环，如果小于64/94停止循环，返回64/94进制值
					newStr = "";
					for ( i = 0; i < 1; i-- )
					{
						tempNum2 = tempNum % target;		// 余数
						tempNum3 = int(tempNum / target);	// 商
						tempStr = hex94.charAt( tempNum2 );
						newStr = tempStr + newStr;
						if ( tempNum3 >= target )
						{
							tempNum = tempNum3;
						}
						else
						{
							tempStr = hex94.charAt( tempNum3 );
							newStr = tempStr + newStr;
							break;
						}
					}
					return newStr;
				}
				// 两个都是大于32进制
				else
				{
					// 先将大的进制转换为10进制
					newNum = 0;
					len = num.length;
					for ( i = 0; i < len; i++ )
					{
						tempStr = num.charAt( num.length - i - 1 );
						tempNum = hex94.indexOf( tempStr );
						newNum += tempNum * Math.pow( radix, i );
					}
					
					tempNum = newNum;
					trace( tempNum );
					
					// 将10进制的数字不断除以64/94，获得每次的余数作为当前位数的值，商如果大于等于64/94继续循环，如果小于64/94停止循环，返回64/94进制值
					newStr = "";
					for ( i = 0; i < 1; i-- )
					{
						tempNum2 = tempNum % target;		// 余数
						tempNum3 = int(tempNum / target);	// 商
						tempStr = hex94.charAt( tempNum2 );
						newStr = tempStr + newStr;
						if ( tempNum3 >= target )
						{
							tempNum = tempNum3;
						}
						else
						{
							tempStr = hex94.charAt( tempNum3 );
							newStr = tempStr + newStr;
							break;
						}
					}
					return newStr;
				}
			}
		}
	}
}


