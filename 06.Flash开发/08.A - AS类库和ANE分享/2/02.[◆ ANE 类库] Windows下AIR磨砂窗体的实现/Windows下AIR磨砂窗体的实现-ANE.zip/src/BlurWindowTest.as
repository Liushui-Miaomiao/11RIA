package
{
	import flash.display.Sprite;
	import flash.events.Event;
	
	public class BlurWindowTest extends Sprite
	{
		public function BlurWindowTest()
		{
			addEventListener(Event.ADDED_TO_STAGE, onAddToStage);
		}
		
		private function onAddToStage(event:Event):void{
			var bw:BlurWindow = new BlurWindow();
			if(bw.bindWindow(stage.nativeWindow)){
				bw.apply(5, 5);
			}
			
			graphics.beginFill(0xFFFFFF, 0.5);
			graphics.drawRoundRect(10, 10, stage.stageWidth - 20, stage.stageHeight - 20, 5, 5);
			graphics.endFill();
		}
	}
}