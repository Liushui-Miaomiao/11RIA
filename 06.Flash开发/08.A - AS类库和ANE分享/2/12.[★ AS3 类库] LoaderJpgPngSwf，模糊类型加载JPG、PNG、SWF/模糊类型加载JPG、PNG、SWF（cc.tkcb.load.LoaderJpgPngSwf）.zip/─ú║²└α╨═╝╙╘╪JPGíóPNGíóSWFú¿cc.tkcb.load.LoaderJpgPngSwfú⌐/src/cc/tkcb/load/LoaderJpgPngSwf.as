﻿/*
 * DO NOT ALTER OR REMOVE COPYRIGHT NOTICES OR THIS HEADER.
 *
 * Copyright 2017 TKCB, tkcb@qq.com
 *
 * 
 * This is free software/program/code: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * If not, see <http://www.gnu.org/licenses/>.
 *
 *
 * 这是一个自由软件/程序/代码，您可以自由分发、修改其中的源代码或者重新发布它，
 * 新的任何修改后的重新发布版必须同样在遵守LGPL3或更后续的版本协议下发布。
 * 关于LGPL协议的细则请参考COPYING、COPYING.LESSER文件，
 * 你可以在文件夹中获得LGPL协议的副本，如果没有找到，请连接到 http://www.gnu.org/licenses/ 查看。
 *
 *
 * 作　　者：TKCB
 * 作者信息：身高（0.00167公里+）；体重（0.06吨±）；年龄（公元1990后）；籍贯（有兵马俑的地方）；星座（最后一个星座）；血型（万能型）；人生格言（The king come back.）。
 * 交流学习：加QQ群[AS3殿堂之路]（96759336），群里有无数主城、架构、妹子、LOL战友，欢迎交流讨论。
 * 联系方式：QQ（2414268040）；E-mail（tkcb@qq.com）；手机（15029932353)。
 * 作者网站：www.tkcb.cc（来这里关注我吧，这里有我所有的作品，分享的资料，我的介绍和动态，还有更多你想不到的）
 *
 * 
 * 获取软件/程序最新版本：www.tkcb.cc
 *
 *
 * 版权协议：请自觉遵守LGPL协议，欢迎复制、转载、传播给更多需要的人。
 * 免责声明：任何因使用此软件导致的纠纷与软件/程序开发者无关。
 */

/* 
 * @version 版本创建时间和修改说明
 * v1.0.0 2017-6-28
 * v1.0.1 2017-6-29 继续完成代码
 */
 
package cc.tkcb.load
{
	import flash.display.Sprite;
	import flash.display.MovieClip;
	import flash.display.Loader;
	import flash.display.Bitmap;
	
	import flash.events.Event;
	import flash.events.IOErrorEvent;
	
	import flash.net.URLRequest;
	
	
	/**
	 * LoaderJpgPngSwf 模糊类型加载JPG、PNG、SWF为同一个显示对象，并且有一些额外的属性，并且仅支持加载程序目录内的图片和swf
	 * @author TKCB（www.tkcb.cc）
	 * @创建时间 2017-6-28
	 * @修改时间 2017-6-29
	 * @version 1.0.1
	 */
	public class LoaderJpgPngSwf extends Sprite
	{
		//************************ ************************* 静态属性 ******************** *********** *** **////
		/** 文件类型，jpg */
		public static const FILE_TYPE_JPG : String = "jpg";
		
		/** 文件类型，png */
		public static const FILE_TYPE_PNG : String = "png";
		
		/** 文件类型，swf */
		public static const FILE_TYPE_SWF : String = "swf";
		
		/** 对象类型，Bitmap */
		public static const OBJECT_TYPE_BITMAP : String = "Bitmap";
		
		/** 对象类型，MovieClip */
		public static const OBJECT_TYPE_MOVIE_CLIP : String = "MovieClip";
		
		/** 对象类型，Sprite */
		public static const OBJECT_TYPE_SPRITE : String = "Sprite";
		
		
		
		//************************ ************************* 属性 ******************** *********** *** **////
		/** jps对象，图片和swf通用对象 */
		public var jps : *;
		
		/** 文件类型，只有这三个字符串：jpg、png、swf */
		public var fileType : String;
		
		/** 对象类型，Bitmap、MovieClip、Sprite */
		public var objectType : String;
		
		/** Loader对象 */
		private var loader : Loader;
		
		/** URL字符串 */
		private var urlStr : String;
		
		/** 加载完成回调函数 */
		private var complete : Function;
		
		
		
		//************************ ************************* 构造函数 ******************** *********** *** **////
		/**
		 * 构造函数
		 */
		public function LoaderJpgPngSwf ()
		{
			
		}
		
		
		//************************ ************************* 加载 ******************** *********** *** **////
		/**
		 * 加载图片或swf
		 * @param url 用于加载的URL地址
		 * @param onComplete 加载完成时调用的回调函数
		 */
		public function load ( url:String, onComplete:Function ) : void
		{
			urlStr = url;
			complete = onComplete;
			
			loader = new Loader();
			loader.contentLoaderInfo.addEventListener( IOErrorEvent.IO_ERROR, loadIOError );
			loader.contentLoaderInfo.addEventListener( Event.COMPLETE, loadComplete );
			fileType = LoaderJpgPngSwf.FILE_TYPE_JPG;
			loader.load( new URLRequest(urlStr + ".jpg") );
		}
		
		/**
		 * 加载异常，找不到URL
		 */
		private function loadIOError ( eve:IOErrorEvent ) : void
		{
			if ( fileType == LoaderJpgPngSwf.FILE_TYPE_JPG )
			{
				fileType = LoaderJpgPngSwf.FILE_TYPE_PNG;
				loader.load( new URLRequest(urlStr + ".png") );
			}
			else if ( fileType == LoaderJpgPngSwf.FILE_TYPE_PNG )
			{
				fileType = LoaderJpgPngSwf.FILE_TYPE_SWF;
				loader.load( new URLRequest(urlStr + ".swf") );
			}
		}
		
		/**
		 * 加载完成
		 */
		private function loadComplete ( eve:Event ) : void
		{
			loader.contentLoaderInfo.removeEventListener( IOErrorEvent.IO_ERROR, loadIOError );
			loader.contentLoaderInfo.removeEventListener( Event.COMPLETE, loadComplete );
			
			if ( fileType == LoaderJpgPngSwf.FILE_TYPE_JPG || fileType == LoaderJpgPngSwf.FILE_TYPE_PNG )
			{
				jps = loader.content as Bitmap;
				jps.smoothing = true;
				objectType = LoaderJpgPngSwf.OBJECT_TYPE_BITMAP;
			}
			else if ( loader.content is MovieClip )
			{
				jps = loader.content as MovieClip;
				objectType = LoaderJpgPngSwf.OBJECT_TYPE_MOVIE_CLIP;
			}
			else if ( loader.content is Sprite )
			{
				jps = loader.content as Sprite;
				objectType = LoaderJpgPngSwf.OBJECT_TYPE_SPRITE;
			}
			
			addChild( jps );
			
			// 调用回调函数
			complete();
		}
		
	}
}


