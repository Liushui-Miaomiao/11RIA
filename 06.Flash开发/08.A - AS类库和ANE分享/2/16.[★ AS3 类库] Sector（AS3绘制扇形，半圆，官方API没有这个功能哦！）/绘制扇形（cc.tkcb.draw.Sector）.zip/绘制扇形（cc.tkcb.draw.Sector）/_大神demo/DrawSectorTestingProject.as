﻿package
{
	import flash.display.Graphics;
	import flash.display.Sprite;
	import flash.display.StageAlign;
	import flash.display.StageScaleMode;
	import flash.events.Event;
	
	
	/**
	 * [description]
	 * @author Jave.Lin
	 * @date 2013-10-11
	 **/
	public class DrawSectorTestingProject extends Sprite
	{
		private static const TWO_PI:Number = Math.PI * 2;
		private var s1:Sprite;
		private var angle:Number = 0;
		private var addAngle:Number = Math.PI / 180;
		private var s2:Sprite;
		private var s3:Sprite;
		private var s4:Sprite;
		
		public function DrawSectorTestingProject()
		{
			stage.color = 0x888888;
			stage.frameRate = 60;
			stage.align = StageAlign.TOP_LEFT;
			stage.scaleMode = StageScaleMode.NO_SCALE;
			
			s1 = new Sprite();
			addChild(s1);
			s1.x = 200;
			s1.y = 200;
			drawSector(s1.graphics, 100, 0, Math.PI + Math.PI / 4, 0, 0, true);
			
			s2 = new Sprite();
			addChild(s2);
			s2.x = 400;
			s2.y = 200;
			drawSector(s2.graphics, 100, 0, angle);
			
			s3 = new Sprite();
			addChild(s3);
			s3.x = 600;
			s3.y = 200;
			drawSector(s3.graphics, 100, 0, TWO_PI, 0, 0, true, 0xffff00, .5, false);
			
			s4 = new Sprite();
			addChild(s4);
			s4.x = 800;
			s4.y = 200;
			drawSector(s4.graphics, 100, Math.PI / 4, TWO_PI - Math.PI / 4, 0, 0, true, 0x00ff00, .5, false);
			
			addEventListener(Event.ENTER_FRAME, onEnterFrame);
		}
		
		private function onEnterFrame(e:Event):void
		{
			angle += addAngle;
			s1.graphics.clear();
			drawSector(s1.graphics, 100, 0, angle, 0, 0, false, 0xff0000, 1, false, true);
			
			s2.graphics.clear();
			drawSector(s2.graphics, 100, 0, angle, 0, 0, false, 0x00ffff, 1, true, true);
		}
		
		public static function drawSector(
			g:Graphics, radius:Number, fromAngle:Number, angle:Number, x:Number = 0, y:Number = 0,
			isFill:Boolean = true, fillColor:uint = 0xff0000, fillAlpha:Number = 1, isClockwise:Boolean = true, isShowEdge:Boolean = true, isShowAssistPoint:Boolean = false):void
		{
			if(isFill) g.beginFill(fillColor, fillAlpha);
			if(isShowEdge) g.lineStyle(1, fillColor);
			
			while(angle < 0) angle += TWO_PI;;
			while(angle > TWO_PI) angle -= TWO_PI;;
			
			if(Math.abs(angle) >= TWO_PI) g.drawCircle(x, y, radius);
			else
			{
				g.moveTo(x, y);
				
				var sx:Number = x + Math.cos(fromAngle) * radius;
				var sy:Number = y + Math.sin(fromAngle) * radius;
				g.lineTo(sx, sy);
				
				var count:int = Math.ceil(angle * 4 / Math.PI);
				var perAngle:Number = angle / count;
				var angleMid:Number;
				var bx1:Number;
				var by1:Number;
				var bx:Number;
				var by:Number;
				var cx:Number;
				var cy:Number;
				var divValue:Number = Math.cos(perAngle * .5);
				
				for (var i:int = 0; i < count; i++) 
				{
					if(isClockwise)
					{
						fromAngle +=  perAngle;
						angleMid = fromAngle - perAngle * .5;
					}
					else
					{
						fromAngle -=  perAngle;
						angleMid = fromAngle + perAngle * .5;
					}
					bx1 = radius * Math.cos(angleMid);
					by1 = radius * Math.sin(angleMid);
					bx= x + bx1 / divValue;
					by= y + by1 / divValue;
					cx = x + radius * Math.cos(fromAngle);
					cy = y + radius * Math.sin(fromAngle);
					g.curveTo(bx, by, cx, cy);
					
				}
				
				g.lineTo(x, y);
			}
			
			if(isFill) g.endFill();
		}
	}
}
