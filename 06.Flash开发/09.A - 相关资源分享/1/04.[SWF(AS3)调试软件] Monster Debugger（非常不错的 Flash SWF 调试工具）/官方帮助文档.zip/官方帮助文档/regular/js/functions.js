$(function() {
	$(".gallery").imageScroller({animation:'fade'});
});