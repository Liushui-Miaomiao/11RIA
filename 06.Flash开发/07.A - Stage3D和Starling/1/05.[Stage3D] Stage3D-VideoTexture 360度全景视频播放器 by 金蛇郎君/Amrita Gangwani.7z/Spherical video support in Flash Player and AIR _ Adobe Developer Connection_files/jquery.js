if(typeof jQuery == 'undefined')
{
	var cdn = (typeof adobe != 'undefined') ? adobe.http.cdnprefix(null) : '';
	document.write('<script src="'+cdn+'/include/script/jquery/js/jquery.js"></script>');
}
