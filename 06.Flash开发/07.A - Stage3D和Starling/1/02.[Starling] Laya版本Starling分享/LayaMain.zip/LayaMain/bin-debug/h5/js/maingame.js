﻿
(function(window,document,Laya){
	var __un=Laya.un,__uns=Laya.uns,__static=Laya.static,__class=Laya.class,__getset=Laya.getset,__newvec=Laya.__newvec;

	var AutoBitmap=laya.ui.AutoBitmap,ClassUtils=laya.utils.ClassUtils,Dictionary=laya.utils.Dictionary;
	var Ease=laya.utils.Ease,Event=laya.events.Event,EventData=laya.ani.bone.EventData,Handler=laya.utils.Handler;
	var Input=laya.display.Input,Keyboard=laya.events.Keyboard,Loader=laya.net.Loader,MovieClip=laya.ani.swf.MovieClip;
	var Node=laya.display.Node,Particle2D=laya.particle.Particle2D,ParticleSetting=laya.particle.ParticleSetting;
	var Point=laya.maths.Point,Rectangle=laya.maths.Rectangle,Skeleton=laya.ani.bone.Skeleton,Socket=laya.net.Socket;
	var Sound=laya.media.Sound,SoundManager=laya.media.SoundManager,Sprite=laya.display.Sprite,Stage=laya.display.Stage;
	var Stat=laya.utils.Stat,Styles=laya.ui.Styles,Templet=laya.ani.bone.Templet,Text=laya.display.Text,Texture=laya.resource.Texture;
	var Tween=laya.utils.Tween,UIUtils=laya.ui.UIUtils,WebGL=laya.webgl.WebGL;
	Laya.__package('starling.utils');
	starling.utils.rad2deg=function(rad){
		return rad / Math.PI *180.0;
	}


	Laya.__package('starling.utils');
	starling.utils.deg2rad=function(deg){
		return deg / 180.0 *Math.PI;
	}


	//class com.MyClass.NetTools.Net_SocketCMD
	var Net_SocketCMD=(function(){
		function Net_SocketCMD(cmd,__dic发送方式,__dic接收方式){
			this.CMD=0;
			this._dic发送方式=false;
			this._dic接收方式=false;
			this.dic_发送参数=null;
			this.dic_接收参数=null;
			this.have监听=false;
			this.Arr_Fun=[];
			this.Arr_自毁=[];
			this.Arr_参数=null;
			this.Hrecive=null;
			this.Type=null;
			(__dic发送方式===void 0)&& (__dic发送方式=true);
			(__dic接收方式===void 0)&& (__dic接收方式=true);
			this._dic发送方式=__dic发送方式;
			this._dic接收方式=__dic接收方式;
			this.CMD=cmd;
			this.Hrecive=Handler.create(this,this.recivedF,null,false);
		}

		__class(Net_SocketCMD,'com.MyClass.NetTools.Net_SocketCMD');
		var __proto=Net_SocketCMD.prototype;
		__proto.func_添加监听=function(f,_一次性){
			if(this.have监听==false){
				MgsSocket.getInstance().addCmdListener(this.CMD,this.Hrecive);
				this.have监听=true;
			}
			this.Arr_Fun.push(f);
			this.Arr_自毁.push(_一次性);
		}

		__proto.func_删除监听=function(f){
			var po=this.Arr_Fun.indexOf(f);
			if(po !=-1){
				this.Arr_Fun.splice(po,1);
				this.Arr_自毁.splice(po,1);
			}
			if(this.Arr_Fun.length==0){
				MgsSocket.getInstance().removeCmdListener(this.CMD,this.Hrecive);
				this.have监听=false;
			}
		}

		__proto.recivedF=function(b){
			var b2=new MyByteArray(this.CMD);
			b2.readF(b);
			var f;
			if(this._dic接收方式){
				if(b2.Arr_val.length > 0)this.dic_接收参数=b2.Arr_val[0];
				for(var i=0;i<this.Arr_Fun.length;i++){
					if(this.Arr_Fun==null)return;
					f=this.Arr_Fun[i];
					if(this.Arr_自毁[i]==true){
						this.func_删除监听(this.Arr_Fun[i]);
						i--
					}
					if((f instanceof laya.utils.Handler ))(f).runWith(this.dic_接收参数);
					else f(this.dic_接收参数);
					if(this.Arr_Fun==null)return;
				}
				this.dic_接收参数=null;
			}
			else{
				this.Arr_参数=b2.Arr_val;
				for(i=0;i<this.Arr_Fun.length;i++){
					if(this.Arr_Fun==null)return;
					f=this.Arr_Fun[i];
					if(this.Arr_自毁[i]==true){
						this.func_删除监听(this.Arr_Fun[i]);
						i--
					}
					if((f instanceof laya.utils.Handler ))(f).runWith(this.Arr_参数);
					else f(this.Arr_参数);
					if(this.Arr_Fun==null)return;
				}
			}
		}

		__proto.writeValue_Dic=function(key,val){
			if(this._dic发送方式==false)throw new Error("不能使用该方法");
			if(this.dic_发送参数==null)this.dic_发送参数=new Dictionary();
			this.dic_发送参数.set(key,val);
		}

		__proto.writeValueF_Arr=function(_参数){
			if(this._dic发送方式==true)throw new Error("不能使用该方法");
			this.Arr_参数=_参数.concat();
		}

		__proto.sendF=function(_带随机头){
			(_带随机头===void 0)&& (_带随机头=true);
			if(this.Type==null){
				if(MgsSocket.getInstance().now状态==null){
					Config.Log("Socket未连接！");
					return;
				}
				if(MgsSocket.getInstance().now状态=="关闭"){
					Config.Log("已断网");
					return;
				}
			}
			else{
			}
			if(this._dic发送方式==false){
				var b;
				if(this.Arr_参数 !=null){
					b=new MyByteArray();
					b.writeF(this.Arr_参数);
				}
				if(_带随机头)MgsSocket.getInstance().sendMessage(this.CMD,b,true,this.Type);
				else MgsSocket.getInstance().sendMessage(this.CMD,b,false,this.Type);
				return;
			}
			if(this.dic_发送参数 !=null){
				b=new MyByteArray();
				b.writeF(this.dic_发送参数);
			}
			if(_带随机头)MgsSocket.getInstance().sendMessage(this.CMD,b,true,this.Type);
			else MgsSocket.getInstance().sendMessage(this.CMD,b,false,this.Type);
		}

		__proto.destroyF=function(){
			if(this.have监听==true){
				MgsSocket.getInstance().removeCmdListener(this.CMD,this.Hrecive);
				this.have监听=false;
			}
			this.Arr_Fun=null;
			this.dic_发送参数=null;
			this.dic_接收参数=null;
			this.Hrecive.clear();
		}

		return Net_SocketCMD;
	})()


	//class com.MyClass.ByteArray
	var ByteArray=(function(){
		function ByteArray(){
			this.classDic={};
			this._length=0;
			this._objectEncoding_=0;
			this._position_=0;
			this._allocated_=8;
			this._data_=null;
			this._littleEndian_=false;
			this._byteView_=null;
			this._strTable=null;
			this._objTable=null;
			this._traitsTable=null;
			this.___resizeBuffer(this._allocated_);
		}

		__class(ByteArray,'com.MyClass.ByteArray');
		var __proto=ByteArray.prototype;
		__proto.clear=function(){
			this._strTable=[];
			this._objTable=[];
			this._traitsTable=[];
			this._position_=0;
			this.length=0;
		}

		__proto.ensureWrite=function(lengthToEnsure){
			if (this._length < lengthToEnsure)this.length=lengthToEnsure;
		}

		__proto.readBoolean=function(){
			return (this.readByte ()!=0);
		}

		__proto.readByte=function(){
			return this._data_.getInt8 (this._position_++);
		}

		__proto.readBytes=function(bytes,offset,length){
			(offset===void 0)&& (offset=0);
			(length===void 0)&& (length=0);
			if (offset < 0 || length < 0){
				throw "Read error - Out of bounds";
			}
			if (length==0)length=this._length-this._position_;
			bytes.ensureWrite (offset+length);
			bytes._byteView_.set (this._byteView_.subarray(this._position_,this._position_+length),offset);
			bytes.position=offset;
			this._position_+=length;
			if (bytes.position+length > bytes.length)bytes.length=bytes.position+length;
		}

		__proto.readDouble=function(){
			var double=this._data_.getFloat64 (this._position_,this._littleEndian_);
			this._position_+=8;
			return double;
		}

		__proto.readFloat=function(){
			var float=this._data_.getFloat32 (this._position_,this._littleEndian_);
			this._position_+=4;
			return float;
		}

		__proto.readFullBytes=function(bytes,pos,len){
			this.ensureWrite (len);
			for(var i=pos;i < pos+len;i++){
				this._data_.setInt8 (this._position_++,bytes.get(i));
			}
		}

		__proto.readInt=function(){
			var tInt=this._data_.getInt32 (this._position_,this._littleEndian_);
			this._position_+=4;
			return tInt;
		}

		__proto.readShort=function(){
			var short=this._data_.getInt16 (this._position_,this._littleEndian_);
			this._position_+=2;
			return short;
		}

		__proto.readUnsignedByte=function(){
			return this._data_.getUint8 (this._position_++);
		}

		__proto.readUnsignedInt=function(){
			var uInt=this._data_.getUint32 (this._position_,this._littleEndian_);
			this._position_+=4;
			return int(uInt);
		}

		//add by ch.ji 解决读取整数时读到负整数的问题
		__proto.readUnsignedShort=function(){
			var uShort=this._data_.getUint16 (this._position_,this._littleEndian_);
			this._position_+=2;
			return uShort;
		}

		__proto.readUTF=function(){
			return this.readUTFBytes (this.readUnsignedShort ());
		}

		__proto.readUnicode=function(length){
			var value="";
			var max=this._position_+length;
			var c1=0,c2=0;
			while (this._position_ < max){
				c2=this._byteView_[this._position_++];
				c1=this._byteView_[this._position_++];
				value+=String.fromCharCode(c1<<8 | c2);
			}
			return value;
		}

		__proto.readMultiByte=function(length,charSet){
			if(charSet=="UNICODE" || charSet=="unicode"){
				return this.readUnicode(length);
			}
			return this.readUTFBytes (length);
		}

		__proto.readUTFBytes=function(len){
			(len===void 0)&& (len=-1);
			var value="";
			var max=this._position_+len;
			var c=0,c2=0,c3=0;
			while (this._position_ < max){
				c=this._data_.getUint8 (this._position_++);
				if (c < 0x80){
					if (c !=0){
						value+=String.fromCharCode (c);
					}
					}else if (c < 0xE0){
					value+=String.fromCharCode (((c & 0x3F)<< 6)| (this._data_.getUint8 (this._position_++)& 0x7F));
					}else if (c < 0xF0){
					c2=this._data_.getUint8 (this._position_++);
					value+=String.fromCharCode (((c & 0x1F)<< 12)| ((c2 & 0x7F)<< 6)| (this._data_.getUint8 (this._position_++)& 0x7F));
					}else {
					c2=this._data_.getUint8 (this._position_++);
					c3=this._data_.getUint8 (this._position_++);
					value+=String.fromCharCode (((c & 0x0F)<< 18)| ((c2 & 0x7F)<< 12)| ((c3 << 6)& 0x7F)| (this._data_.getUint8 (this._position_++)& 0x7F));
				}
			}
			return value;
		}

		__proto.toString=function(){
			var cachePosition=this._position_;
			this._position_=0;
			var value=this.readUTFBytes (this.length);
			this._position_=cachePosition;
			return value;
		}

		__proto.writeBoolean=function(value){
			this.writeByte (value ? 1 :0);
		}

		__proto.writeByte=function(value){
			this.ensureWrite (this._position_+1);
			this._data_.setInt8 (this._position_,value);
			this._position_+=1;
		}

		__proto.writeBytes=function(bytes,offset,length){
			(offset===void 0)&& (offset=0);
			(length===void 0)&& (length=0);
			if (offset < 0 || length < 0)throw "writeBytes error - Out of bounds";
			if(length==0)length=bytes.length-offset;
			this.ensureWrite (this._position_+length);
			this._byteView_.set(bytes._byteView_.subarray (offset,offset+length),this._position_);
			this._position_+=length;
		}

		__proto.writeArrayBuffer=function(arraybuffer,offset,length){
			(offset===void 0)&& (offset=0);
			(length===void 0)&& (length=0);
			if (offset < 0 || length < 0)throw "writeArrayBuffer error - Out of bounds";
			if(length==0)length=arraybuffer.byteLength-offset;
			this.ensureWrite (this._position_+length);
			var uint8array=new Uint8Array(arraybuffer);
			this._byteView_.set(uint8array.subarray (offset,offset+length),this._position_);
			this._position_+=length;
		}

		__proto.writeDouble=function(x){
			this.ensureWrite (this._position_+8);
			this._data_.setFloat64 (this._position_,x,this._littleEndian_);
			this._position_+=8;
		}

		__proto.writeFloat=function(x){
			this.ensureWrite (this._position_+4);
			this._data_.setFloat32 (this._position_,x,this._littleEndian_);
			this._position_+=4;
		}

		__proto.writeInt=function(value){
			this.ensureWrite (this._position_+4);
			this._data_.setInt32 (this._position_,value,this._littleEndian_);
			this._position_+=4;
		}

		__proto.writeShort=function(value){
			this.ensureWrite (this._position_+2);
			this._data_.setInt16 (this._position_,value,this._littleEndian_);
			this._position_+=2;
		}

		__proto.writeUnsignedInt=function(value){
			this.ensureWrite (this._position_+4);
			this._data_.setUint32 (this._position_,value,this._littleEndian_);
			this._position_+=4;
		}

		__proto.writeUnsignedShort=function(value){
			this.ensureWrite (this._position_+2);
			this._data_.setUint16 (this._position_,value,this._littleEndian_);
			this._position_+=2;
		}

		__proto.writeUTF=function(value){
			value=value+"";
			this.writeUnsignedShort (this._getUTFBytesCount(value));this.writeUTFBytes (value);
		}

		__proto.writeUnicode=function(value){
			value=value+"";
			this.ensureWrite (this._position_+value.length*2);
			var c=0;
			for(var i=0,sz=value.length;i<sz;i++){
				c=value.charCodeAt(i);
				this._byteView_[this._position_++]=c&0xff;
				this._byteView_[this._position_++]=c>>8;
			}
		}

		__proto.writeMultiByte=function(value,charSet){
			value=value+"";
			if(charSet=="UNICODE" || charSet=="unicode"){
				return this.writeUnicode(value);
			}
			this.writeUTFBytes(value);
		}

		__proto.writeUTFBytes=function(value){
			value=value+"";
			this.ensureWrite(this._position_+value.length*4);
			for (var i=0,sz=value.length;i < sz;i++){
				var c=value.charCodeAt(i);
				if (c <=0x7F){
					this.writeByte (c);
					}else if (c <=0x7FF){
					this.writeByte (0xC0 | (c >> 6));
					this.writeByte (0x80 | (c & 63));
					}else if (c <=0xFFFF){
					this.writeByte(0xE0 | (c >> 12));
					this.writeByte(0x80 | ((c >> 6)& 63));
					this.writeByte(0x80 | (c & 63));
					}else {
					this.writeByte(0xF0 | (c >> 18));
					this.writeByte(0x80 | ((c >> 12)& 63));
					this.writeByte(0x80 | ((c >> 6)& 63));
					this.writeByte(0x80 | (c & 63));
				}
			}
			this.length=this._position_;
		}

		__proto.__fromBytes=function(inBytes){
			this._byteView_=new Uint8Array(inBytes.getData ());
			this.length=this._byteView_.length;
			this._allocated_=this.length;
		}

		__proto.__get=function(pos){
			return this._data_.getUint8(pos);
		}

		__proto._getUTFBytesCount=function(value){
			var count=0;
			value=value+"";
			for (var i=0,sz=value.length;i < sz;i++){
				var c=value.charCodeAt(i);
				if (c <=0x7F){
					count+=1;
					}else if (c <=0x7FF){
					count+=2;
					}else if (c <=0xFFFF){
					count+=3;
					}else {
					count+=4;
				}
			}
			return count;
		}

		__proto._byteAt_=function(index){
			return this._byteView_[index];
		}

		__proto._byteSet_=function(index,value){
			this.ensureWrite (index+1);
			this._byteView_[index]=value;
		}

		//this._position_+=1;
		__proto.uncompress=function(algorithm){
			(algorithm===void 0)&& (algorithm="zlib");
			var inflate=new Zlib.Inflate(this._byteView_);
			this._byteView_=inflate.decompress();
			this._data_=new DataView(this._byteView_ .buffer);;
			this._allocated_=this._length=this._byteView_.byteLength;
			this._position_=0;
		}

		__proto.compress=function(algorithm){
			(algorithm===void 0)&& (algorithm="zlib");
			var deflate=new Zlib.Deflate(this._byteView_);
			this._byteView_=deflate.compress();
			this._data_=new DataView(this._byteView_.buffer);;
			this._position_=this._allocated_=this._length=this._byteView_.byteLength;
		}

		__proto.___resizeBuffer=function(len){
			try{
				var newByteView=new Uint8Array(len);
				if (this._byteView_!=null){
					if (this._byteView_.length <=len)newByteView.set (this._byteView_);
					else newByteView.set (this._byteView_.subarray (0,len));
				}
				this._byteView_=newByteView;
				this._data_=new DataView(newByteView.buffer);
			}
			catch (err){
				throw "___resizeBuffer err:"+len;
			}
		}

		__proto.__getBuffer=function(){
			this._data_.buffer.byteLength=this.length;
			return this._data_.buffer;
		}

		__proto.__set=function(pos,v){
			this._data_.setUint8 (pos,v);
		}

		__proto.setUint8Array=function(data){
			this._byteView_=data;
			this._data_=new DataView(data.buffer);
			this._length=data.byteLength;
			this._position_=0;
		}

		/**从字节数组中读取一个以 AMF 序列化格式进行编码的对象 **/
		__proto.readObject=function(){
			this._strTable=[];
			this._objTable=[];
			this._traitsTable=[];
			return this.readObject2();
		}

		__proto.readObject2=function(){
			var type=this.readByte();
			return this.readObjectValue(type);
		}

		__proto.readObjectValue=function(type){
			var value;
			switch (type){
				case 1:
					break ;
				case 6:
					value=this.__readString();
					break ;
				case 4:
					value=this.readInterger();
					break ;
				case 2:
					value=false;
					break ;
				case 3:
					value=true;
					break ;
				case 10:
					value=this.readScriptObject();
					break ;
				case 9:
					value=this.readArray();
					break ;
				case 5:
					value=this.readDouble();
					break ;
				case 12:
					value=this.readByteArray();
					break ;
				default :
					console.log("Unknown object type tag!!!"+type);
				}
			return value;
		}

		__proto.readByteArray=function(){
			var ref=this.readUInt29();
			if ((ref & 1)==0){
				return this.getObjRef(ref >> 1);
			}
			else{
				var len=(ref >> 1);
				var ba=new ByteArray();
				this._objTable.push(ba);
				this.readBytes(ba,0,len);
				return ba;
			}
		}

		__proto.readInterger=function(){
			var i=this.readUInt29();
			i=(i << 3)>> 3;
			return parseInt(i+"");
		}

		__proto.getStrRef=function(ref){
			return this._strTable[ref];
		}

		__proto.getObjRef=function(ref){
			return this._objTable[ref];
		}

		__proto.__readString=function(){
			var ref=this.readUInt29();
			if ((ref & 1)==0){
				return this.getStrRef(ref >> 1);
			};
			var len=(ref >> 1);
			if (0==len){
				return "";
			};
			var str=this.readUTFBytes(len);
			this._strTable.push(str);
			return str;
		}

		__proto.readTraits=function(ref){
			var ti;
			if ((ref & 3)==1){
				ti=this.getTraitReference(ref >> 2);
				return ti.propoties?ti:{obj:{}};
			}
			else{
				var externalizable=((ref & 4)==4);
				var isDynamic=((ref & 8)==8);
				var count=(ref >> 4);
				var className=this.__readString();
				ti={};
				ti.className=className;
				ti.propoties=[];
				ti.dynamic=isDynamic;
				ti.externalizable=externalizable;
				if(count>0){
					for(var i=0;i<count;i++){
						var propName=this.__readString();
						ti.propoties.push(propName);
					}
				}
				this._traitsTable.push(ti);
				return ti;
			}
		}

		__proto.readScriptObject=function(){
			var ref=this.readUInt29();
			if ((ref & 1)==0){
				return this.getObjRef(ref >> 1);
			}
			else{
				var objref=this.readTraits(ref);
				var className=objref.className;
				var externalizable=objref.externalizable;
				var obj;
				var propName;
				var pros=objref.propoties;
				if(className&&className!=""){
					var rst=ClassUtils.getRegClass(className);
					if(rst){
						obj=new rst();
						}else{
						obj={};
					}
					}else{
					obj={};
				}
				this._objTable.push(obj);
				if(pros){
					for(var d=0;d<pros.length;d++){
						obj[pros[d]]=this.readObject2();
					}
				}
				if(objref.dynamic){
					for (;;){
						propName=this.__readString();
						if (propName==null || propName.length==0)break ;
						obj[propName]=this.readObject2();
					}
				}
				return obj;
			}
		}

		__proto.readArray=function(){
			var ref=this.readUInt29();
			if ((ref & 1)==0){
				return this.getObjRef(ref >> 1);
			};
			var obj=null;
			var count=(ref >> 1);
			var propName;
			for (;;){
				propName=this.__readString();
				if (propName==null || propName.length==0)break ;
				if (obj==null){
					obj={};
					this._objTable.push(obj);
				}
				obj[propName]=this.readObject2();
			}
			if (obj==null){
				obj=[];
				this._objTable.push(obj);
				var i=0;
				for (i=0;i < count;i++){
					obj.push(this.readObject2());
				}
				}else {
				for (i=0;i < count;i++){
					obj[i.toString()]=this.readObject2();
				}
			}
			return obj;
		}

		/**
		*AMF 3 represents smaller integers with fewer bytes using the most
		*significant bit of each byte. The worst case uses 32-bits
		*to represent a 29-bit number,which is what we would have
		*done with no compression.
		*<pre>
		*0x00000000-0x0000007F :0xxxxxxx
		*0x00000080-0x00003FFF :1xxxxxxx 0xxxxxxx
		*0x00004000-0x001FFFFF :1xxxxxxx 1xxxxxxx 0xxxxxxx
		*0x00200000-0x3FFFFFFF :1xxxxxxx 1xxxxxxx 1xxxxxxx xxxxxxxx
		*0x40000000-0xFFFFFFFF :throw range exception
		*</pre>
		*
		*@return A int capable of holding an unsigned 29 bit integer.
		*@throws IOException
		*@exclude
		*/
		__proto.readUInt29=function(){
			var value=0;
			var b=this.readByte()& 0xFF;
			if (b < 128){
				return b;
			}
			value=(b & 0x7F)<< 7;
			b=this.readByte()& 0xFF;
			if (b < 128){
				return (value | b);
			}
			value=(value | (b & 0x7F))<< 7;
			b=this.readByte()& 0xFF;
			if (b < 128){
				return (value | b);
			}
			value=(value | (b & 0x7F))<< 8;
			b=this.readByte()& 0xFF;
			return (value | b);
		}

		//============================================================================================
		__proto.writeObject=function(o){
			this._strTable=[];
			this._objTable=[];
			this._traitsTable=[];
			this.writeObject2(o);
		}

		__proto.writeObject2=function(o){
			if(o==null){
				this.writeAMFNull();
				return;
			};
			var type=typeof(o);
			if("string"===type){
				this.writeAMFString(o);
			}
			else if("boolean"===type){
				this.writeAMFBoolean(o);
			}
			else if("number"===type){
				if(String(o).indexOf(".")!=-1){
					this.writeAMFDouble(o);
				}
				else{
					this.writeAMFInt(o);
				}
			}
			else if("object"===type){
				if((o instanceof Array)){
					this.writeArray(o);
				}
				else if((o instanceof com.MyClass.ByteArray )){
					this.writeAMFByteArray(o);
				}
				else{
					this.writeCustomObject(o);
				}
			}
		}

		__proto.writeAMFNull=function(){
			this.writeByte(1);
		}

		__proto.writeAMFString=function(s){
			this.writeByte(6);
			this.writeStringWithoutType(s);
		}

		__proto.writeStringWithoutType=function(s){
			if (s.length==0){
				this.writeUInt29(1);
				return;
			};
			var ref=this._strTable.indexOf(s);
			if(ref>=0){
				this.writeUInt29(ref << 1);
				}else{
				var utflen=this._getUTFBytesCount(s);
				this.writeUInt29((utflen << 1)| 1);
				this.writeUTFBytes(s);
				this._strTable.push(s);
			}
		}

		__proto.writeAMFInt=function(i){
			if (i >=ByteArray.INT28_MIN_VALUE && i <=0x0FFFFFFF){
				i=i & 0x1FFFFFFF;
				this.writeByte(4);
				this.writeUInt29(i);
				}else {
				this.writeAMFDouble(i);
			}
		}

		__proto.writeAMFDouble=function(d){
			this.writeByte(5);
			this.writeDouble(d);
		}

		__proto.writeAMFBoolean=function(b){
			if (b)
				this.writeByte(3);
			else
			this.writeByte(2);
		}

		__proto.writeCustomObject=function(o){
			this.writeByte(10);
			var refNum=this._objTable.indexOf(o);
			if(refNum!=-1){
				this.writeUInt29(refNum << 1);
			}
			else{
				this._objTable.push(o);
				var traitsInfo=new Object();
				traitsInfo.className=this.getAliasByObj(o);
				traitsInfo.dynamic=false;
				traitsInfo.externalizable=false;
				traitsInfo.properties=[];
				for(var prop in o){
					if((typeof (o[prop])=='function'))continue ;
					traitsInfo.properties.push(prop);
					traitsInfo.properties.sort();
				};
				var tRef=ByteArray.getTraitsInfoRef(this._traitsTable,traitsInfo);
				var count=traitsInfo.properties.length;
				var i=0;
				if(tRef>=0){
					this.writeUInt29((tRef << 2)| 1);
					}else{
					this._traitsTable.push(traitsInfo);
					this.writeUInt29(3 | (traitsInfo.externalizable ? 4 :0)| (traitsInfo.dynamic ? 8 :0)| (count << 4));
					this.writeStringWithoutType(traitsInfo.className);
					for(i=0;i<count;i++){
						this.writeStringWithoutType(traitsInfo.properties[i]);
					}
				}
				for(i=0;i<count;i++){
					this.writeObject2(o[traitsInfo.properties[i]]);
				}
			}
		}

		/**
		*获取实例的注册别名
		*@param obj
		*@return
		*/
		__proto.getAliasByObj=function(obj){
			var tClassName=ClassUtils.getRegClass(obj);
			if(tClassName==null || tClassName=="")return "";
			var tClass=ClassUtils.getClass(tClassName);
			if(tClass==null)return "";
			var tkey;
			for(tkey in this.classDic){
				if(this.classDic[tkey]==tClass){
					return tkey;
				}
			}
			return "";
		}

		__proto.writeArray=function(value){
			this.writeByte(9);
			var len=value.length;
			var ref=this._objTable.indexOf(value);
			if(ref>-1){
				this.writeUInt29(len<<1);
			}
			else{
				this.writeUInt29((len << 1)| 1);
				this.writeStringWithoutType("");
				for (var i=0;i < len;i++){
					this.writeObject2(value[i]);
				}
				this._objTable.push(value);
			}
		}

		__proto.writeAMFByteArray=function(ba){
			this.writeByte(12);
			var ref=this._objTable.indexOf(ba);
			if(ref>=0){
				this.writeUInt29(ref << 1);
				}else{
				var len=ba.length;
				this.writeUInt29((len << 1)| 1);
				this.writeBytes(ba,0,len);
			}
		}

		__proto.writeMapAsECMAArray=function(o){
			this.writeByte(9);
			this.writeUInt29((0 << 1)| 1);
			var count=0,key;
			for (key in o){
				count++;
				this.writeStringWithoutType(key);
				this.writeObject2(o[key]);
			}
			this.writeStringWithoutType("");
		}

		__proto.writeUInt29=function(ref){
			if (ref < 0x80){
				this.writeByte(ref);
				}else if (ref < 0x4000){
				this.writeByte(((ref >> 7)& 0x7F)| 0x80);
				this.writeByte(ref & 0x7F);
				}else if (ref < 0x200000){
				this.writeByte(((ref >> 14)& 0x7F)| 0x80);
				this.writeByte(((ref >> 7)& 0x7F)| 0x80);
				this.writeByte(ref & 0x7F);
				}else if (ref < 0x40000000){
				this.writeByte(((ref >> 22)& 0x7F)| 0x80);
				this.writeByte(((ref >> 15)& 0x7F)| 0x80);
				this.writeByte(((ref >> 8)& 0x7F)| 0x80);
				this.writeByte(ref & 0xFF);
				}else {
				console.log("Integer out of range: "+ref);
			}
		}

		/**
		*@exclude
		*/
		__proto.getTraitReference=function(ref){
			return this._traitsTable[ref];
		}

		// Getters & Setters
		__getset(0,__proto,'bytesAvailable',function(){
			return this.length-this._position_;
		});

		__getset(0,__proto,'position',function(){
			return this._position_;
			},function(pos){
			if (pos < this._length)
				this._position_=pos < 0?0:pos;
			else{
				this._position_=pos;
				this.length=pos;
			}
		});

		__getset(0,__proto,'endian',function(){
			return this._littleEndian_ ? "littleEndian" :"bigEndian";
			},function(endianStr){
			this._littleEndian_=(endianStr=="littleEndian");
		});

		__getset(0,__proto,'length',function(){
			return this._length;
			},function(value){
			this.___resizeBuffer (this._allocated_=value);
			this._length=value;
		});

		ByteArray.__ofBuffer=function(buffer){
			var bytes=new ByteArray ();
			bytes.length=bytes.allocated=buffer.byteLength;
			bytes.data=new DataView(buffer);
			bytes.byteView=new Uint8Array(buffer);
			return bytes;
		}

		ByteArray.getTraitsInfoRef=function(arr,ti){
			var i=0,len=arr.length;
			for(i=0;i<len;i++){
				if (ByteArray.equalsTraitsInfo(ti,arr[i]))return i;
			}
			return-1;
		}

		ByteArray.equalsTraitsInfo=function(ti1,ti2){
			if (ti1==ti2){
				return true;
			}
			if (!ti1.className===ti2.className){
				return false;
			}
			if(ti1.properties.length !=ti2.properties.length){
				return false;
			};
			var len=ti1.properties.length;
			var prop;
			ti1.properties.sort();ti2.properties.sort();
			for(var i=0;i<len;i++){
				if(ti1.properties[i] !=ti2.properties[i]){
					return false;
				}
			}
			return true;
		}

		ByteArray.BIG_ENDIAN="bigEndian";
		ByteArray.LITTLE_ENDIAN="littleEndian";
		ByteArray.UNDEFINED_TYPE=0;
		ByteArray.NULL_TYPE=1;
		ByteArray.FALSE_TYPE=2;
		ByteArray.TRUE_TYPE=3;
		ByteArray.INTEGER_TYPE=4;
		ByteArray.DOUBLE_TYPE=5;
		ByteArray.STRING_TYPE=6;
		ByteArray.XML_TYPE=7;
		ByteArray.DATE_TYPE=8;
		ByteArray.ARRAY_TYPE=9;
		ByteArray.OBJECT_TYPE=10;
		ByteArray.AVMPLUSXML_TYPE=11;
		ByteArray.BYTEARRAY_TYPE=12;
		ByteArray.EMPTY_STRING="";
		ByteArray.UINT29_MASK=0x1FFFFFFF;
		ByteArray.INT28_MAX_VALUE=0x0FFFFFFF;
		ByteArray.INT28_MIN_VALUE=-268435456;
		return ByteArray;
	})()


	//class com.MyClass.Config
	var Config=(function(){
		function Config(){};
		__class(Config,'com.MyClass.Config');
		Config.initF=function(){
			Config.onResizeF(null);
		}

		Config.initStarling=function(f){
			Config.onResizeF(null);
			Tool_Function.onRunFunction(f);
		}

		Config.onResizeF=function(e){
			Config._屏幕宽=Config.mStage.width;
			Config._屏幕高=Config.mStage.height;
			Config.Log("屏幕宽高="+Config._屏幕宽+"x"+Config._屏幕高);
			var sx=Config._屏幕宽/Config.stageW;
			var sy=Config._屏幕高/Config.stageH;
			if(Config.适配方式==1){
				Config.stageRec=new Rectangle(0,0,Config._屏幕宽,Config._屏幕高);
				Config.stageRec.x=0;
				Config.stageRec.y=0;
				Config.stageScale=[sx,sy];
			}
			else if(Config.适配方式==2){
				Config.stageScale=sx>sy?sx:sy;
				Config.stageRec=new Rectangle(0,0,Config.stageW *Config.stageScale,Config.stageH *Config.stageScale);
				Config.stageScaleInfo={"屏幕w":Config._屏幕宽 / com.MyClass.Config.stageScale,"屏幕h":Config._屏幕高 /com.MyClass.Config.stageScale};
			}
			else{
				Config.stageScale=sx<sy?sx:sy;
				var x0=Tool_Function.on强制转换((Config._屏幕宽-Config.stageW *Config.stageScale)/2);
				var y0=Tool_Function.on强制转换((Config._屏幕高-Config.stageH *Config.stageScale)/2);
				Config.stageRec=new Rectangle(x0,y0,Config.stageW *Config.stageScale,Config.stageH *Config.stageScale);
			}
			if(e==null)return;
			if(MainManager._instence)MainManager._instence.MEM.dispatchF("Stage尺寸改变");
		}

		Config.closeStarling=function(){}
		Config.on重启=function(){}
		Config.Log=function(__arg){
			var arg=arguments;
			if(arg.length==0)return;
			var i=0;
			var str="";
			while(i<arg.length){
				if(str.length>0)str+="  ";
				str+=toStringF(arg[i]);
				i++;
			}
			console.log(str);
			function toStringF (obj){
				var str="";
				if((typeof obj=='string')|| ((typeof obj=='number')&& Math.floor(obj)==obj)|| ((typeof obj=='number')&& Math.floor(obj)==obj)|| (typeof obj=='number')|| obj==null || (typeof obj=='boolean'))str+=obj;
				else if((obj instanceof Array)){
					str+="[";
					for(var i=0;i<obj.length;i++){
						if(i>0)str+=", ";
						str+=toStringF(obj[i]);
					}
					str+="]";
				}
				else if((obj instanceof Dictionary)){
					str+="{";
					i=0;
					for(var j=0;j<(obj).keys.length;j++){
						var key=obj.keys[j];
						if(i>0)str+=", ";
						str+=toStringF(key)+"::"+toStringF(obj.get(key));
						i++;
					}
					str+="}";
				}
				else if((typeof obj=='object')){
					str+="{";
					i=0;
					for(key in obj){
						if(i>0)str+=", ";
						str+=toStringF(key)+"::"+toStringF(obj[key]);
						i++;
					}
					str+="}";
				}
				else{
					str+="实例::"+obj;
				}
				return str;
			}
		}

		Config.on直接关闭=function(){}
		Config.Fun重启=null
		Config.mainClassInstance=null
		Config.PF=null
		Config.ClassFunction=null
		Config.stageW=960;
		Config.stageH=540;
		Config._屏幕宽=0;
		Config._屏幕高=0;
		Config.stageRec=null
		Config.stageScale=null
		Config.stageScaleInfo=null
		Config.playSpeedTrue=30;
		Config.swfFPS=30;
		Config.SoundVol=0.5;
		Config.mStage=null
		Config.Main平台="Laya";
		Config.Platform=null
		Config.适配方式=0;
		Config.设备信息=null
		Config.Event_Stage尺寸改变="Stage尺寸改变";
		Config.Set_后台暂停指令=true;
		return Config;
	})()


	//class com.MyClass.Effect.MyEffect_WindowAppear_Scale
	var MyEffect_WindowAppear_Scale=(function(){
		function MyEffect_WindowAppear_Scale(mc,f){
			this.Fun=null;
			this.MC=null;
			this.W=0;
			this.H=0;
			this._x0=0;
			this._y0=0;
			this.S=0.2;
			this.time=0.2;
			this.MC=mc;
			this.Fun=f;
			this.W=Config.stageW;
			this.H=Config.stageH;
			this._x0=this.MC.x;
			this._y0=this.MC.y;
			this.MC.scaleX=this.MC.scaleY=this.S;
			this.MC.x+=this.W *(1-this.S)/ 2;
			this.MC.y+=this.H *(1-this.S)/ 2;
			this.MC.alpha=0.1;
			Tween.to(this.MC,{x :this._x0,y:this._y0 ,scaleX:1,scaleY:1,alpha:1},this.time *1000);
		}

		__class(MyEffect_WindowAppear_Scale,'com.MyClass.Effect.MyEffect_WindowAppear_Scale');
		var __proto=MyEffect_WindowAppear_Scale.prototype;
		__proto.Tover=function(){
			this.MC.scaleX=this.MC.scaleY=1;
			this.MC.x=this._x0;
			this.MC.y=this._y0;
			Tool_Function.onRunFunction(this.Fun);
		}

		return MyEffect_WindowAppear_Scale;
	})()


	//class com.MyClass.MainManager
	var MainManager=(function(){
		function MainManager(){
			this.MEM=null;
			this.MTM=null;
			this.Time=0;
			this.pause=false;
			this.inEnter=false;
			this.Dic_upFun=[];
			this.Arr_waiteRemove=null;
			this.Dic_enterFun=new Dictionary();
			this.Dic_delayFun=new Dictionary();
		}

		__class(MainManager,'com.MyClass.MainManager');
		var __proto=MainManager.prototype;
		__proto.init=function(stage){
			MySourceManager.getInstance();
			Config.mStage=stage;
			this.MEM=new MyEventManager();
			this.MTM=new MyTweenerManager();
			if(stage){
				LayerManager.getInstence().init(stage);
				LayerStarlingManager.instance=new LayerStarlingManager();
				LayerStarlingManager.instance.init(stage);
				Laya.timer.frameLoop(1,this,this.enterF,null,false);
			}
		}

		__proto.enterF=function(){
			if(this.pause==true){
				return;
			}
			this.inEnter=true;
			this.Time++;
			for(var i=0;i<this.Dic_enterFun.keys.length;i++){
				var f=this.Dic_enterFun.get(this.Dic_enterFun.keys[i]);
				if(f!=null){
					if((f instanceof laya.utils.Handler )){
						(f).run();
						}else{
						f(val);
					}
				}
			}
			for(i=0;i<this.Dic_delayFun.keys.length;i++){
				var arr=this.Dic_delayFun.get(this.Dic_delayFun.keys[i]);
				if(arr[1] <=0){
					var fun=arr[0];
					var val=arr[2];
					if((fun instanceof laya.utils.Handler )){
						if(val==null)(fun).run();
						else (fun).runWith(val);
						}else{
						if(val==null)fun();
						else fun(val);
					}
					this.remove_delayFunction(fun);
					i--;
				}
				else{
					arr[1]-=1;
				}
			}
			this.inEnter=false;
			if(this.Arr_waiteRemove !=null){
				for(i=0;i<this.Arr_waiteRemove.length;i++){
					this.removeEnterFrameFun(this.Arr_waiteRemove[i]);
				}
				this.Arr_waiteRemove=null;
			}
		}

		__proto.addEnterFrameFun=function(fun){
			if(fun==null)return;
			if((fun instanceof laya.utils.Handler )&& (fun).once==true){
				(fun).once=false;
			}
			this.Dic_enterFun.set(fun,fun);
		}

		__proto.removeEnterFrameFun=function(fun){
			if(this.inEnter==true){
				if(this.Arr_waiteRemove==null)this.Arr_waiteRemove=[];
				this.Arr_waiteRemove.push(fun);
				}else{
				for(var i=0;i<this.Dic_enterFun.keys.length;i++){
					var f=this.Dic_enterFun.keys[i];
					if((f instanceof laya.utils.Handler )){
						if(fun==null || ((fun instanceof laya.utils.Handler )&& fun==f)){
							this.Dic_enterFun.remove(f);
							(f).clear();
							i--;
							}else if(fun==null || ((typeof fun=='function')&& (f).method==fun)){
							this.Dic_enterFun.remove(f);
							(f).clear();
							i--;
						}
						}else if((typeof f=='function')){
						if(fun==null || ((typeof fun=='function')&& fun==f)){
							this.Dic_enterFun.remove(f);
							i--;
							}else if(fun==null || ((fun instanceof laya.utils.Handler )&& (fun).method==f)){
							this.Dic_enterFun.remove(f);
							i--;
						}
					}
				}
			}
			if((fun instanceof laya.utils.Handler )){
				(fun).clear();
			}
		}

		__proto.add_delayFunction=function(fun,delay,val){
			if((fun instanceof laya.utils.Handler )&& (fun).once==false){
				(fun).once=true;
			}
			if(delay==0){
				if((fun instanceof laya.utils.Handler )){
					if(val==null)(fun).run();
					else (fun).runWith(val);
					}else if((typeof fun=='function')){
					if(val==null)fun();
					else fun(val);
					}else{
					console.log("mm中，delay未知的fun==",fun);
				}
				return;
			}
			this.Dic_delayFun.set(fun,[fun,delay,val]);
		}

		__proto.remove_delayFunction=function(fun){
			for(var i=0;i<this.Dic_delayFun.keys.length;i++){
				var f=this.Dic_delayFun.keys[i];
				if((f instanceof laya.utils.Handler )){
					if(fun==null || ((fun instanceof laya.utils.Handler )&& fun==f)){
						this.Dic_delayFun.remove(fun);
						(f).clear();
						i--;
						}else if(fun==null || ((typeof fun=='function')&& (f).method==fun)){
						this.Dic_delayFun.remove(fun);
						(f).clear();
						i--;
					}
					}else if((typeof f=='function')){
					if(fun==null || ((typeof fun=='function')&& fun==f)){
						this.Dic_delayFun.remove(fun);
						i--;
						}else if(fun==null || ((fun instanceof laya.utils.Handler )&& (fun).method==f)){
						this.Dic_delayFun.remove(fun);
						i--;
					}
				}
			}
			if((fun instanceof laya.utils.Handler )){
				(fun).clear();
			}
		}

		__proto.addStageUpFun=function(f){
			if(this.Dic_upFun.length==0){}
				if(this.Dic_upFun.indexOf(f)==-1)this.Dic_upFun.push(f);
		}

		__proto.removeStageUpFun=function(f){
			var i=this.Dic_upFun.indexOf(f);
			if(i !=-1){
				this.Dic_upFun.splice(i,1);
				if(this.Dic_upFun.length==0){}
					}
		}

		// LayerStarlingManager.getInstence().stage.removeEventListener(MouseEvent.MOUSE_UP,upF);
		__proto.upF=function(e){
			for(var i=this.Dic_upFun.length-1;i>=0;i--){
				this.Dic_upFun[i]();
			}
		}

		__proto.destroyF=function(){
			this.remove_delayFunction(null);
			this.removeEnterFrameFun(null);
			if(this.MTM){
				this.MTM.stopAll();
				this.MTM=null;
			}
			Laya.timer.clear(this,this.enterF);
			LayerStarlingManager.instance.destroyF();
			this.MEM.destroyF();this.MEM=null;
			com.MyClass.MainManager._instence=null;
		}

		__proto.clearF=function(){
			this.remove_delayFunction(null);
			this.removeEnterFrameFun(null);
			if(this.MTM){
				this.MTM.stopAll();
				this.MTM=null;
			}
			this.MTM=new MyTweenerManager();
		}

		MainManager.getInstence=function(){
			if(com.MyClass.MainManager._instence==null)MainManager._instence=new MainManager();
			return MainManager._instence;
		}

		MainManager._instence=null
		return MainManager;
	})()


	//class com.MyClass.MainManagerOne
	var MainManagerOne=(function(){
		function MainManagerOne(){
			this.MM=null;
			this.Arr_EnterFrame=[];
			this.Dic_Delay=new Dictionary();
			if(MainManager._instence==null)throw new Error("无法新建");
			this.MM=MainManager._instence;
		}

		__class(MainManagerOne,'com.MyClass.MainManagerOne');
		var __proto=MainManagerOne.prototype;
		__proto.addEnterFrameFun=function(fun){
			if(this.Arr_EnterFrame.indexOf(fun)==-1){
				this.Arr_EnterFrame.push(fun);
				this.MM.addEnterFrameFun(fun);
			}
		}

		__proto.removeEnterFrameFun=function(fun){
			var index=this.Arr_EnterFrame.indexOf(fun);
			if(index !=-1){
				this.Arr_EnterFrame.splice(index,1);
				this.MM.removeEnterFrameFun(fun);
			}
		}

		__proto.add_delayFunction=function(fun,delay,val){
			this.remove_delayFunction(fun);
			var h=Handler.create(this,this.tmpFunction,[fun,val]);
			this.Dic_Delay.set(fun,h);
			this.MM.add_delayFunction(h,delay);
		}

		__proto.tmpFunction=function(fun,val){
			if((fun instanceof laya.utils.Handler )){
				if(val==null)(fun).run();
				else (fun).runWith(val);
				}else{
				if(val==null)fun();
				else fun(val);
			}
		}

		__proto.remove_delayFunction=function(f){
			if(this.Dic_Delay==null)return;
			var h=this.Dic_Delay.get(f);
			if(h==null)return;
			this.MM.remove_delayFunction(h);
			this.Dic_Delay.remove(f);
		}

		__proto.destroyF=function(){
			var _$this=this;
			var i=0;
			for(i=0;i<this.Arr_EnterFrame.length;i++){
				this.removeEnterFrameFun(this.Arr_EnterFrame[i--]);
			}
			this.Arr_EnterFrame=null;
			if(this.Dic_Delay){
				Tool_DictionUtils.on遍历Dic(this.Dic_Delay,function(key,val){
					_$this.remove_delayFunction(key);
				});
				this.Dic_Delay.clear();
			}
			this.Dic_Delay=null;
			this.MM=null;
		}

		return MainManagerOne;
	})()


	//class com.MyClass.MyEventManager
	var MyEventManager=(function(){
		function MyEventManager(){
			this.DIC_Listener=null;
			this.DIC_Listener=new Dictionary();
		}

		__class(MyEventManager,'com.MyClass.MyEventManager');
		var __proto=MyEventManager.prototype;
		__proto.dispatchF=function(type,val){
			var dic=this.DIC_Listener.get(type);
			if(dic !=null){
				for(var i=0;i<dic.keys.length;i++){
					var id=dic.keys[i];
					var arr2=dic.get(id);
					var f=arr2[0];
					if(val!=null && arr2[2]!=null){
						if((f instanceof laya.utils.Handler )){
							(f).runWith([arr2[2],val]);
							}else{
							f(arr2[2],val);
						}
						}else if(val!=null){
						if((f instanceof laya.utils.Handler )){
							(f).runWith(val);
							}else{
							f(val);
						}
						}else if(arr2[2]!=null){
						if((f instanceof laya.utils.Handler )){
							(f).runWith(arr2[2]);
							}else{
							f(arr2[2]);
						}
						}else{
						if((f instanceof laya.utils.Handler )){
							(f).run();
							}else{
							f();
						}
					}
					if(arr2[1]==true)this.removeListenF(type,id);
				}
			}
		}

		__proto.addListenF=function(type,fun,val,onece){
			(onece===void 0)&& (onece=false);
			if((fun instanceof laya.utils.Handler )&& (fun).once!=onece){
				(fun).once=onece;
			};
			var dic;
			if(this.DIC_Listener.get(type)==null){
				dic=new Dictionary();
				dic.set(fun,[fun,onece,val]);
				this.DIC_Listener.set(type,dic);
			}
			else{
				dic=this.DIC_Listener.get(type);
				dic.set(fun,[fun,onece,val]);
			}
		}

		__proto.removeListenF=function(type,fun){
			var dic;
			if(this.DIC_Listener.get(type)!=null){
				if(fun==null){
					this.DIC_Listener.remove(type);
				}
				else{
					dic=this.DIC_Listener.get(type);
					for(var i=0;i<dic.keys.length;i++){
						var f=dic.keys[i];
						if((f instanceof laya.utils.Handler )){
							if((fun instanceof laya.utils.Handler )&& f==fun){
								dic.remove(f);
								i--;
								(f).clear();
								}else if((typeof fun=='function')&& (f).method==fun){
								dic.remove(f);
								i--;
								(f).clear();
							}
						}
						else if((typeof fun=='function')){
							if((typeof f=='function')&& f==fun){
								dic.remove(f);
								i--;
								}else if((fun instanceof laya.utils.Handler )&& (fun).method==f){
								dic.remove(f);
								i--;
							}
						}
						if((fun instanceof laya.utils.Handler ))(fun).clear();
					}
					if(dic.keys.length==0){
						this.DIC_Listener.remove(type);
					}
				}
			}
		}

		// trace(type+"，MEM删除事件后产度="+dic.keys.length);
		__proto.haveListener=function(type){
			var num=0;
			if(this.DIC_Listener.get(type)!=null){
				var dic=this.DIC_Listener.get(type);
				for(var i=0;i<dic.keys.length;i++){
					num++;
				}
			}
			return num;
		}

		__proto.destroyF=function(){
			this.DIC_Listener.clear();
		}

		return MyEventManager;
	})()


	//class com.MyClass.MyEventManagerOne
	var MyEventManagerOne=(function(){
		function MyEventManagerOne(){
			this.Dic_Listener=null;
			if(MainManager._instence==null)throw new Error("无法新建");
			this.Dic_Listener=new Dictionary();
		}

		__class(MyEventManagerOne,'com.MyClass.MyEventManagerOne');
		var __proto=MyEventManagerOne.prototype;
		__proto.dispatchF=function(type,val){
			if(MainManager._instence)MainManager._instence.MEM.dispatchF(type,val);
		}

		__proto.haveListener=function(type){
			if(MainManager._instence==null)return false;
			return MainManager._instence.MEM.haveListener(type);
		}

		__proto.addListenerF=function(type,fun,val,onece){
			(onece===void 0)&& (onece=false);
			if(MainManager._instence==null)return;
			if(this.Dic_Listener.get(type)==null){
				MainManager._instence.MEM.addListenF(type,Handler.create(this,this.onEventF),type,false);
				this.Dic_Listener.set(type,[]);
			}
			this.Dic_Listener.get(type).push([fun,val,onece]);
		}

		__proto.onEventF=function(type,value){
			var arr=this.Dic_Listener.get(type);
			if(arr==null || arr.length==0){
				MainManager._instence.MEM.removeListenF(type,this.onEventF);
				return;
			}
			for(var i=0;i<arr.length;i++){
				var _arr=arr[i];
				var f=_arr[0];
				var val=_arr[1];
				var onece=_arr[2];
				if((typeof f=='function')){
					if(val==null && value==null)f();
					else if(val==null)f(value);
					else if(value==null)f(val);
					else f(val,value);
					}else{
					if(val==null && value==null)(f).run();
					else if(val==null)(f).runWith(value);
					else if(value==null)(f).runWith(val);
					else (f).runWith([val,value]);
				}
				if(onece==true){
					arr.splice(i--,1);
				}
			}
			if(arr.length==0){
				MainManager._instence.MEM.removeListenF(type,this.onEventF);
				this.Dic_Listener.remove(type);
			}
		}

		__proto.removeListenerF=function(type,fun){
			if(MainManager._instence==null)return;
			var arr=this.Dic_Listener.get(type);
			if(arr==null || arr.length==0)return;
			for(var i=0;i<arr.length;i++){
				var _arr=arr[i];
				var f=_arr[0];
				if((f instanceof laya.utils.Handler )){
					if((fun instanceof laya.utils.Handler )&& fun==f){
						arr.splice(i--,1);
						(f).clear();
						}else if((typeof fun=='function')&& (f).method==fun){
						arr.splice(i--,1);
						(f).clear();
					}
					}else if((typeof f=='function')){
					if((typeof fun=='function')&& fun==f){
						arr.splice(i--,1);
						}else if((fun instanceof laya.utils.Handler )&& (fun).method==f){
						arr.splice(i--,1);
					}
				}
				if((fun instanceof laya.utils.Handler ))(fun).clear();
			}
			if(arr.length==0){
				MainManager._instence.MEM.removeListenF(type,this.onEventF);
				this.Dic_Listener.remove(type);
			}
		}

		__proto.destroyF=function(){
			if(MainManager._instence==null)return;
			for(var i=0;i<this.Dic_Listener.keys.length;i++){
				var type=this.Dic_Listener.keys[i];
				MainManager._instence.MEM.removeListenF(type,this.onEventF);
			}
			this.Dic_Listener.clear();
		}

		return MyEventManagerOne;
	})()


	//class com.MyClass.MyKeyboardManager
	var MyKeyboardManager=(function(){
		function MyKeyboardManager(s){
			this.S=null;
			this.Dic={};
			this.Funs_Down={};
			this.Funs_Up={};
			this.Funs_组合键=null;
			this.Dic_stop冒泡={};
			this.pause=false;
			this.noKeyEvent=false;
			this.Dic转换=null;
			this.S=s;
			this.Funs_Down["Every"]=[];
			this.Funs_Up["Every"]=[];
			if(this.S){
				this.S.on("keydown",this,this.keyDown);
				this.S.on("keyup",this,this.keyUP);
			}
		}

		__class(MyKeyboardManager,'com.MyClass.MyKeyboardManager');
		var __proto=MyKeyboardManager.prototype;
		__proto._手动Down=function(key){
			if(this.pause)return;
			if(this.Dic[key]==null || this.Dic[key]==false){
				this.Dic[key]=true;
				var arr=this.Funs_Down["Every"];
				for(var i=0;i<arr.length;i++){
					Tool_Function.onRunFunction(arr[i],key);
				}
				if(this.Funs_Down[key]==null)return;
				arr=this.Funs_Down[key];
				for(i=0;i<arr.length;i++){
					Tool_Function.onRunFunction(arr[i]);
				}
			}
		}

		__proto._手动Up=function(key){
			if(this.pause)return;
			if(this.Dic[key]==null || this.Dic[key]==true){
				this.Dic[key]=false;
				var arr=this.Funs_Up["Every"];
				for(var i=0;i<arr.length;i++){
					Tool_Function.onRunFunction(arr[i],key);
				}
				if(this.Funs_Up[key]==null)return;
				arr=this.Funs_Up[key];
				for(i=0;i<arr.length;i++){
					Tool_Function.onRunFunction(arr[i]);
				}
			}
		}

		__proto._全部up=function(){
			for(var key in this.Dic){
				this.Dic[key]=false;
			}
		}

		__proto.keyDown=function(e){
			if(this.noKeyEvent || e==null)return;
			var key=e["keyCode"];
			if(this.Dic转换 && this.Dic转换[key])key=this.Dic转换[key];
			this._手动Down(key);
		}

		__proto.keyUP=function(e){
			if(this.noKeyEvent || e==null)return;
			var key=e.keyCode;
			if(this.Dic转换 && this.Dic转换[key])key=this.Dic转换[key];
			this._手动Up(key);
		}

		__proto.isDown=function(key){
			if(this.Dic[key]==null)return false;
			return this.Dic[key];
		}

		__proto.add转换Key=function(keyCode,key){
			if(this.Dic转换==null)this.Dic转换={};
			this.Dic转换[keyCode]=key;
		}

		__proto.addFunctionListener=function(key,f,type){
			(type===void 0)&& (type="down");
			if(f==null){
				console.log("keybord错误的参数");
				return;
			};
			var dic;
			if(type=="down")dic=this.Funs_Down;
			else if(type=="up")dic=this.Funs_Up;
			else{
				console.log("keybord错误的参数");
				return;
			}
			if(key==null){
				var arr=dic["Every"];
				if(arr.indexOf(f)==-1)arr.push(f);
				return;
			}
			if(dic[key]==null)dic[key]=[];
			arr=dic[key];
			if(arr.indexOf(f)==-1)arr.push(f);
		}

		__proto.removeFunctionListener=function(key,f,type){
			(type===void 0)&& (type="down");
			if(f==null){
				console.log("keybord错误的参数");
				return;
			};
			var dic;
			if(type=="down")dic=this.Funs_Down;
			else if(type=="up")dic=this.Funs_Up;
			else{
				console.log("错误的参数");
				return;
			}
			if(key==null){
				var arr=dic["Every"];
				var index=arr.indexOf(f);
				if(index !=-1)arr.splice(index,1);
				return;
			}
			if(dic[key]==null)return;
			arr=dic[key];
			index=arr.indexOf(f);
			if(index !=-1)arr.splice(index,1);
		}

		__proto.add组合按键监听=function(keys,f){
			var _$this=this;
			if(this.Funs_组合键==null)this.Funs_组合键={};
			var lastKey=keys[keys.length-1];
			if(this.Funs_组合键[lastKey]==null){
				this.Funs_组合键[lastKey]=[];
				this.addFunctionListener(lastKey,function(){
					for(var i=0;i<_$this.Funs_组合键[lastKey].length;i++){
						var keys=_$this.Funs_组合键[lastKey][i][0];
						var f=_$this.Funs_组合键[lastKey][i][1];
						var suc=true;
						for(var j=0;j<keys.length-1;j++){
							var needKey=(typeof (keys[j])=='string')?keys[j]:String.fromCharCode(keys[j]);
							if(_$this.isDown(keys[j])==false){
								suc=false;break ;
							}
						}
						if(suc)f();
					}
				});
			}
			this.Funs_组合键[lastKey].push([keys,f]);
		}

		__proto.stop冒泡=function(key,val){
			(val===void 0)&& (val=true);
			this.Dic_stop冒泡[key]=val;
		}

		__proto.destroyF=function(){
			if(this.S){
				this.S.offAll();
			}
		}

		return MyKeyboardManager;
	})()


	//class com.MyClass.MySourceManager
	var MySourceManager=(function(){
		function MySourceManager(){
			this.Dic_Num={};
			this.Dic_have={};
			this.Dic_swf={};
			this.Dic_zmc=null;
			this.Dic_pic=null;
			this.FunLoadOver=null;
			this.Arr_waite=null;
			this.Arr_waiteArrs=[];
		}

		__class(MySourceManager,'com.MyClass.MySourceManager');
		var __proto=MySourceManager.prototype;
		__proto.addTexture=function(arr,f){
			for(var i=0;i<arr.length;i++){
				if(arr[i]==null)continue ;
				var name=arr[i][0];
				if(name==null)continue ;
				if(this.Dic_Num[name]==null)this.Dic_Num[name]=0;
				this.Dic_Num[name]++;
			}
			if(this.Arr_waite && this.Arr_waite.length > 0){
				this.Arr_waiteArrs.push([arr,f]);
				return;
			}
			this.FunLoadOver=f;
			this.Arr_waite=[];
			for(i=0;i<arr.length;i++){
				if(arr[i]==null)continue ;
				this.Arr_waite.push(arr[i]);
			}
			MainManager._instence.add_delayFunction(Handler.create(this,this.loadNextF),2,true);
		}

		__proto.removeTexture=function(name){
			if(name==null)return;
			if(--this.Dic_Num[name] > 0)return;
			this.onRemoveF(name);
		}

		__proto.onRemoveF=function(name){
			var swf=this.Dic_swf[name];
			swf.destroyF();
			delete this.Dic_swf[name];
			delete this.Dic_have[name];
		}

		__proto.removeTextures=function(arr){
			while(arr.length > 0){
				if(arr[0]!=null)this.removeTexture(arr[0][0]);
				arr.shift();
			}
		}

		__proto.loadNextF=function(first){
			var _$this=this;
			(first===void 0)&& (first=false);
			if(first==false)this.Arr_waite.shift();
			if(this.Arr_waite.length==0){
				this.Arr_waite=null;
				var tmpF=this.FunLoadOver;
				this.FunLoadOver=null;
				if((tmpF instanceof laya.utils.Handler ))(tmpF).run();
				else tmpF();
				if(this.Arr_waiteArrs.length > 0){
					this.Arr_waite=this.Arr_waiteArrs[0][0];
					this.FunLoadOver=this.Arr_waiteArrs[0][1];
					this.Arr_waiteArrs.shift();
					this.loadNextF(true);
				}
				return;
			};
			var name=this.Arr_waite[0][0];
			if(this.Dic_have[name] !=null){
				MainManager.getInstence().MEM.dispatchF("加载进度",[]);
				MainManager._instence.add_delayFunction(Handler.create(this,this.loadNextF),2);
				return;
			};
			var Type=this.Arr_waite[0][1];
			if(Type=="png" || Type=="jpg" || Type=="net"){
				if(this.Arr_waite[0][0]==null){
					this.onWantNextF("pic");
					return;
				}
				if(this.Dic_pic==null){this.Dic_pic={};};
				var Add=this.Arr_waite[0][2];
				if(Add==null){
					Add="";
					}else{
					if(Add.charAt(Add.length-1)!="/")Add+="/";
				}
				if(Add.indexOf("Pic/")!=0)Add="Pic/"+Add;
				if(MySourceManager.DirMain!=null){
					Add=MySourceManager.DirMain+"/"+Add;
				}
				if(Add.indexOf(".")==-1){
					Add+=this.Arr_waite[0][0]+"."+Type;
				}
				Laya.loader.load(Add,Handler.create(this,function(){
					var t=Laya.loader.getRes(Add);
					_$this.Dic_pic[_$this.Arr_waite[0][0]]=t;
					console.log("pic加载成功："+_$this.Arr_waite[0][0]+"："+t);
					_$this.onWantNextF("swf");
				}));
			}
			else if(Type=="swf"){
				if(this.Arr_waite[0][0]==null){
					this.onWantNextF("swf");
					return;
				}
				Add=this.Arr_waite[0][2];
				if(Add==null){
					Add=name+"/";
					}else{
					if(Add.charAt(Add.length-1)!="/")Add+="/";
				}
				if(Add.indexOf("assets/")!=0)Add="assets/"+Add;
				if(MySourceManager.DirMain!=null){
					Add=MySourceManager.DirMain+"/"+Add;
				};
				var swf=new MyLayaAIR_SWF(Add+name+".json",Handler.create(null,onSwfLoaded));
				function onSwfLoaded (suc){
					if(suc==false){
						Config.Log("加载swf："+Add+"失败！");
						}else{
						_$this.Dic_have[name]=true;
						_$this.Dic_swf[name]=swf;
					}
					_$this.onWantNextF("swf");
				}
			}
			else if(Type=="zmc"){
				Add=this.Arr_waite[0][2];
				if(Add==null){
					Add=name+"/";
					}else{
					if(Add.charAt(Add.length-1)!="/")Add+="/";
				}
				if(Add.indexOf("assets/")!=0)Add="assets/"+Add;
				if(MySourceManager.DirMain!=null){
					Add=MySourceManager.DirMain+"/"+Add;
				};
				var mz=new MyZMovieClip(Add+name+".sk",Handler.create(null,onZMCLoaded));
				function onZMCLoaded (suc){
					if(suc==false){
						Config.Log("加载zmc："+Add+"失败！");
						}else{
						_$this.Dic_have[name]=true;
						if(_$this.Dic_zmc==null){_$this.Dic_zmc={};}
							_$this.Dic_zmc[name]=mz;
					}
					_$this.onWantNextF("zmc");
				}
			}
			else if(Type=="mp3" || Type=="wav"){
				var sm=SoundManagerMy.getInstance();
				Add="";
				if(this.Arr_waite[0].length==3)Add=this.Arr_waite[0][2];
				if(com.MyClass.MySourceManager.DirMain){
					Add=com.MyClass.MySourceManager.DirMain+"/"+Add;
				};
				var arr=[this.Arr_waite[0][0],Add,Type];
				sm.addSounds([arr],Handler.create(this,this.onWantNextF));
			}
			else{
				console.log("暂时不支持加载非swf文件");
			}
		}

		__proto.onWantNextF=function(type){
			if(this.Arr_waite==null && this.FunLoadOver==null)return;
			MainManager.getInstence().MEM.dispatchF("加载进度",[]);
			MainManager._instence.add_delayFunction(Handler.create(this,this.loadNextF),2);
		}

		__proto.getSwf=function(name){
			return this.Dic_swf[name];
		}

		__proto.getImgFromSwf=function(swfName,imgname){
			var swf=this.Dic_swf[swfName];
			if(swf==null){
				console.log("没有SWF："+swfName);
				return null;
			}
			return swf.getImage(imgname);
		}

		__proto.getS9FromSwf=function(swfName,s9name){
			var swf=this.Dic_swf[swfName];
			if(swf==null){
				return null;
			}
			return swf.getS9Image(s9name);
		}

		__proto.getSprFromSwf=function(swfName,sprname){
			var swf=this.Dic_swf[swfName];
			if(swf==null)return null;
			return swf.getSprite(sprname);
		}

		__proto.getMcFromSwf=function(swfName,mcname){
			var swf=this.Dic_swf[swfName];
			if(swf==null){
				if(this.Dic_zmc[swfName]){
					var mc=this.Dic_zmc[swfName];
					var nmc=new MyZMovieClip(mc.URL,null);
					nmc.initF();
					return nmc;
				}
				return null;
			}
			return swf.getMc(mcname);
		}

		__proto.getObjFromSwf=function(swfName,objName){
			if(swfName==null || objName==null)return null;
			if(objName.indexOf("img_")==0)return this.getImgFromSwf(swfName,objName);
			if(objName.indexOf("spr_")==0)return this.getSprFromSwf(swfName,objName);
			if(objName.indexOf("mc_")==0)return this.getMcFromSwf(swfName,objName);
			if(objName.indexOf("s9_")==0)return this.getS9FromSwf(swfName,objName);
			return null;
		}

		__proto.getTexture=function(name){
			if(this.Dic_pic==null){
				return null;
			}
			return this.Dic_pic[name];
		}

		__proto.destroyF=function(){
			for(var n in this.Dic_Num){
				this.removeTexture(n);
			}
			com.MyClass.MySourceManager.instance=null;
		}

		MySourceManager.getInstance=function(){
			if(MySourceManager.instance==null)MySourceManager.instance=new MySourceManager();
			return MySourceManager.instance;
		}

		MySourceManager.DirMain=null
		MySourceManager.ClassManager=null
		MySourceManager.instance=null
		return MySourceManager;
	})()


	//class com.MyClass.MySourceManagerOne
	var MySourceManagerOne=(function(){
		function MySourceManagerOne(){
			this.SM=null;
			this.Arr_source=null;
			this.haveCheck重复=false;
			this.Busy=false;
			this.Arr_waite=[];
			this.LView=null;
			this.Fun=null;
			this.SM=MySourceManager.instance;
			if(this.SM==null)throw new Error("无法新建");
		}

		__class(MySourceManagerOne,'com.MyClass.MySourceManagerOne');
		var __proto=MySourceManagerOne.prototype;
		__proto.addSource=function(arr,f,needLoadingMC){
			if(this.Busy){
				this.Arr_waite.push([arr,f,needLoadingMC]);
				return;
			}
			this.Busy=true;
			this.Fun=f;
			if(this.Arr_source==null)this.Arr_source=arr.concat();
			else this.Arr_source=this.Arr_source.concat(arr);
			if(MySourceManagerOne.Arrwaite!=null){
				for(var i=0;i<MySourceManagerOne.Arrwaite.length;i++){
					(MySourceManagerOne.Arrwaite [i]).on去掉资源(this.Arr_source);
					(MySourceManagerOne.Arrwaite [i]).destroyF();
				}
				MySourceManagerOne.Arrwaite=null;
			}
			this.SM.addTexture(arr,Handler.create(this,this.addOver));
			if((typeof needLoadingMC=='number')){
				this.LView=new LoadingView(arr.length,needLoadingMC);
			}
			else if(needLoadingMC==true){
				this.LView=new LoadingView(arr.length);
			}
		}

		__proto.addOver=function(){
			if(this.LView){
				this.LView.destroyF();
				this.LView=null;
			}
			if((this.Fun instanceof laya.utils.Handler )){
				(this.Fun).run();
				}else if((typeof this.Fun=='function')){
				this.Fun();
			}else{}
			this.Fun=null;
			this.Busy=false;
			if(this.Arr_waite.length > 0){
				var arr=this.Arr_waite[0];
				this.Arr_waite.shift();
				this.addSource(arr[0],arr[1],arr[2]);
			}
		}

		__proto.deleteSourceFromArray=function(arr){
			this.SM.removeTextures(arr);
			for(var j=0;j<arr.length;j++){
				var item=arr[j];
				for(var i=0;i<this.Arr_source.length;i++){
					if(this.Arr_source[i][0]==item)this.Arr_source.removeAt(i--);
				}
			}
		}

		__proto.getSwf=function(name){
			return this.SM.getSwf(name);
		}

		__proto.getImgFromSwf=function(swfName,imgname){
			return this.SM.getImgFromSwf(swfName,imgname);
		}

		__proto.getS9FromSwf=function(swf,s9name){
			return this.SM.getS9FromSwf(swf,s9name);
		}

		__proto.getSprFromSwf=function(swfName,sprname){
			return this.SM.getSprFromSwf(swfName,sprname);
		}

		__proto.getMcFromSwf=function(swfName,mcname){
			return this.SM.getMcFromSwf(swfName,mcname);
		}

		__proto.getObjFromSwf=function(swfName,objName){
			if(objName.indexOf("img_")==0)return this.getImgFromSwf(swfName,objName);
			if(objName.indexOf("spr_")==0)return this.getSprFromSwf(swfName,objName);
			if(objName.indexOf("mc_")==0)return this.getMcFromSwf(swfName,objName);
			if(objName.indexOf("s9_")==0)return this.getS9FromSwf(swfName,objName);
			return null;
		}

		__proto.on去掉资源=function(source){
			this.haveCheck重复=true;
			if(this.Arr_source==null)return;
			var arr不重复=[];
			for(var i=0;i<this.Arr_source.length;i++){
				var item=this.Arr_source[i];
				var index=i;
				if(item==null)/*no*/this.  return;
				var re=false;
				for(var j=0;j<source.length;j++){
					var item2=source[j];
					if(Tool_ArrayUtils.判断相等(item,item2)==true){
						re=true;
						break ;
					}
				}
				if(re==false){
					this.Arr_source[index]=null;
					arr不重复.push(item);
				}
			}
			if(arr不重复.length>0)this.SM.removeTextures(arr不重复);
		}

		__proto.destroyF=function(){
			if(this.LView){
				this.LView.destroyF();
				this.LView=null;
			}
			if(this.haveCheck重复==false){
				this.haveCheck重复=true;
				MySourceManagerOne.on缓存F(this);
				return;
			}
			if(this.Arr_source){
				this.SM.removeTextures(this.Arr_source);
			}
			this.SM=null;
		}

		MySourceManagerOne.on缓存F=function(mso){
			if(mso==null || mso.Arr_source==null || mso.Arr_source.length==0)return;
			if(MySourceManagerOne.Arrwaite==null)MySourceManagerOne.Arrwaite=[];
			if(MySourceManagerOne.Arrwaite.indexOf(mso)==-1)MySourceManagerOne.Arrwaite.push(mso);
		}

		MySourceManagerOne.Arrwaite=null
		return MySourceManagerOne;
	})()


	//class com.MyClass.MyTweenerManager
	var MyTweenerManager=(function(){
		function MyTweenerManager(){
			this.DIC_Tween=null;
			this.Pause=false;
			this.MM=MainManager.getInstence();
			this.DIC_Tween=new Dictionary();
			this.MM.addEnterFrameFun(Handler.create(this,this.actionF));
		}

		__class(MyTweenerManager,'com.MyClass.MyTweenerManager');
		var __proto=MyTweenerManager.prototype;
		__proto.actionF=function(){
			if(this.Pause)return;
			for (var i=0;i< this.DIC_Tween.keys.length;i++){
				var id=this.DIC_Tween.keys[i];
				var t=this.DIC_Tween.get(id);
				t.moveF();
			}
		}

		__proto.newTween=function(mc,t){
			if(this.DIC_Tween.get(mc)==null){
				if(t==null)return;
			}
			this.DIC_Tween.set(mc,t);
			if(t==null){
				this.DIC_Tween.remove(mc);
			}
		}

		__proto.stopAll=function(){
			this.DIC_Tween.clear();
		}

		return MyTweenerManager;
	})()


	//class com.MyClass.MyView.BTNControllerStarling
	var BTNControllerStarling=(function(){
		function BTNControllerStarling(L,arr,Fclick,Fdown,Fup,fnone){
			this.Layer=null;
			this.Arr_Btn=[];
			this.Arr_Mc=[];
			this.now=-1;
			this.FunClick=null;
			this.FunUp=null;
			this.FunDown=null;
			this.FunClickNone=null;
			this.down=0;
			this.pause=false;
			this.冒泡方式=null;
			this.Min滑动距离=2;
			this._允许滑动=true;
			this._允许滑动选择=true;
			this.auto清理=false;
			this.can鼠标滑过=false;
			this.autoChangeFrame=true;
			this.startX=0;
			this.startY=0;
			this.Layer=L;
			Tool_Function.onTouchable(this.Layer);
			this.FunClick=Fclick;
			if(this.FunClick)this.FunClick.once=false;
			this.FunDown=Fdown;
			this.FunUp=Fup;
			this.FunClickNone=fnone;
			for(var i=0;i<arr.length;i++){
				if(arr[i]==null)continue ;
				var btn;
				if(((arr[i])instanceof com.MyClass.MyView.BTN_Starling )){
					btn=arr[i];
				}
				else{
					btn=new BTN_Starling(arr[i],null,null,null);
				}
				btn.ID=i;
				btn.FClick=Handler.create(this,this.onClickF);
				this.Arr_Btn[i]=btn;
			}
		}

		__class(BTNControllerStarling,'com.MyClass.MyView.BTNControllerStarling');
		var __proto=BTNControllerStarling.prototype;
		__proto.setValue=function(str,val){
			this[str]=val;
		}

		__proto.getValue=function(want){
			return this[want];
		}

		__proto.onClickF=function(n){
			if(this.FunClick!=null){
				this.FunClick.runWith(n);
			}
		}

		__proto.checkIn=function(lx,ly){
			return-1;
		}

		__proto.changeFrame=function(num,f){
			if(this.autoChangeFrame==false)return;
			if(num >=0){
				if(((this.Arr_Btn[num])instanceof com.MyClass.MyView.BTN_Starling ))(this.Arr_Btn [num]).onChangeFrame(f);
			}
		}

		__proto.pauseF=function(b){
			this.pause=b;
			this.stopF();
		}

		__proto.removeIndex=function(n){
			this.Arr_Btn.removeAt(n);
			this.Arr_Mc.removeAt(n);
		}

		__proto.stopF=function(){
			if(this.down==true){
				this.down=0;
				this.changeFrame(this.now,1);
				this.now=-1;
			}
		}

		__proto.destroyF=function(){
			if(this.Layer){
				if(this.auto清理)this.Layer=Tool_ObjUtils.getInstance().destroyF_One(this.Layer);
				else this.Layer=null;
			}
			if(this.auto清理){
				this.Arr_Btn=Tool_ObjUtils.getInstance().destroyF_One(this.Arr_Btn);
			}
			else this.Arr_Btn=null;
			if(this.FunClick){
				this.FunClick.clear();
				this.FunClick=null;
			}
			if(this.FunDown){
				this.FunDown.clear();
				this.FunDown=null;
			}
			if(this.FunUp){
				this.FunUp.clear();
				this.FunUp=null;
			}
			if(this.FunClickNone){
				this.FunClickNone.clear();
				this.FunClickNone=null;
			}
		}

		BTNControllerStarling.冒泡_禁止="禁止";
		BTNControllerStarling.冒泡_触发禁止="触发禁止";
		return BTNControllerStarling;
	})()


	//class com.MyClass.MyView.LayerManager
	var LayerManager=(function(){
		function LayerManager(){
			this.stage=null;
			this.viewLayer=null;
			this.topLayer=null;
		}

		__class(LayerManager,'com.MyClass.MyView.LayerManager');
		var __proto=LayerManager.prototype;
		__proto.init=function(s){
			this.stage=s;
			this.viewLayer=new Sprite();
			s.addChild(this.viewLayer);
			this.topLayer=new Sprite();
			s.addChild(this.topLayer);
		}

		// MainManager._instence.MEM.addListenF(Config.Event_Stage尺寸改变,onResizeF);
		__proto.onResizeF=function(){
			this.onChangeF(this.viewLayer);
			this.onChangeF(this.topLayer);
		}

		__proto.onChangeF=function(spr){
			if(spr==null)return;
			if(Config.适配方式==0){
				spr.scaleX=Config.stageScale;
				spr.scaleY=Config.stageScale;
				spr.x=Config.stageRec.x;
				spr.y=Config.stageRec.y;
			}
			else if(Config.适配方式==1){
				spr.scaleX=Config.stageScale[0];
				spr.scaleY=Config.stageScale[1];
				spr.x=Config.stageRec.x;
				spr.y=Config.stageRec.y;
			}
			else if(Config.适配方式==2){
				spr.scaleX=Config.stageScale;
				spr.scaleY=Config.stageScale;
				spr.x=int((Config._屏幕宽-Config.stageW *Config.stageScale)/2);
				spr.y=int((Config._屏幕高-Config.stageH *Config.stageScale)/2);
			}
		}

		__proto.destroyF=function(){
			if(this.stage==null)return;
			this.stage.removeChild(this.viewLayer);
			this.stage.removeChild(this.topLayer);
			this.viewLayer=null;
			this.topLayer=null;
			LayerManager._instence=null;
		}

		LayerManager.getInstence=function(){
			if(LayerManager._instence==null)LayerManager._instence=new LayerManager();
			return LayerManager._instence;
		}

		LayerManager._instence=null
		return LayerManager;
	})()


	//class com.MyClass.MyView.LayerStarlingManager
	var LayerStarlingManager=(function(){
		function LayerStarlingManager(){
			this.stage=null;
			this.LayerView=null;
			this.LayerTop=null;
		}

		__class(LayerStarlingManager,'com.MyClass.MyView.LayerStarlingManager');
		var __proto=LayerStarlingManager.prototype;
		__proto.init=function(s){
			this.stage=s;
			this.LayerView=new Sprite();
			s.addChild(this.LayerView);
			this.LayerTop=new Sprite();
			s.addChild(this.LayerTop);
		}

		__proto.onResizeF=function(){
			this.onChangeF(this.LayerView);
			this.onChangeF(this.LayerTop);
		}

		__proto.onChangeF=function(spr){
			if(spr==null)return;
		}

		__proto.destroyF=function(){
			if(this.stage==null)return;
			this.stage.removeChild(this.LayerView);
			this.stage.removeChild(this.LayerTop);
			this.LayerView=null;
			this.LayerTop=null;
			LayerStarlingManager.instance=null;
		}

		LayerStarlingManager.instance=null
		return LayerStarlingManager;
	})()


	//class com.MyClass.MyView.MyLayaAIR_SWF
	var MyLayaAIR_SWF=(function(){
		function MyLayaAIR_SWF(url_Json,FLoaded){
			this.URL_Swf=null;
			this.Dic_NameFrame={};
			this.Dic_ParticleSetting=null;
			this._swfDatas=null;
			this.FunLoaded=null;
			var _$this=this;
			this.URL_Swf=url_Json;
			this.FunLoaded=FLoaded;
			Config.Log("加载Atlas：",url_Json);
			var mem=MainManager.getInstence().MEM;
			var hanProgress=Handler.create(null,onAtlasProgress,null,false);
			Laya.loader.load(url_Json,Handler.create(null,onLoaded),hanProgress,"atlas");
			function onAtlasProgress (per){
				mem.dispatchF("加载进度",per *0.8);
			}
			function onLoaded (){
				hanProgress.clear();
				var atlas=Loader.getAtlas(url_Json);
				var data=Loader.getRes(url_Json);
				if(data==null){
					Config.Log("加载url_Json报错！");
					_$this.onLoadEndF(false);
					return;
				};
				var frames=data.frames;
				var name;
				var str;
				var count=0;
				for (name in frames){
					var t=Laya.loader.getRes(atlas[count++]);
					if(name.indexOf(".")>=0)str=name.slice(0,name.lastIndexOf("."));
					_$this.Dic_NameFrame[str]=t;
				};
				var urlBytes=url_Json.split(".")[0]+".bytes";
				_$this.onLoadBytes(url_Json);
			}
		}

		__class(MyLayaAIR_SWF,'com.MyClass.MyView.MyLayaAIR_SWF');
		var __proto=MyLayaAIR_SWF.prototype;
		__proto.onLoadBytes=function(url_Json){
			var _$this=this;
			var mem=MainManager.getInstence().MEM;
			var url_bytes=url_Json.split(".")[0]+".bytes";
			Config.Log("加载bytes文件："+url_bytes);
			var data=Loader.getRes(url_bytes);
			if (data){
				initData(data);
				}else {
				var l=new Loader();
				l.once("complete",null,function(data){
					l.offAll();
					initData(data);
				});
				l.once("error",null,function(err){
					Config.Log("加载Bytes报错！");
					_$this.onLoadEndF(false);
				});
				l.on("progress",null,function(per){
					if(per!=1){
						mem.dispatchF("加载进度",0.8+per *0.2);
					}
				});
				l.load(url_bytes,"arraybuffer");
			}
			function initData (data){
				var bytes=new ByteArray();
				bytes.writeArrayBuffer(data);
				bytes.position=0;
				try{
					bytes.uncompress();
					}catch(e){
					Config.Log("解压报错！"+e.message);
					return;
				};
				var str=new String(bytes);
				_$this._swfDatas=JSON.parse(str);
				if(_$this._swfDatas["particle"] !=null){
					var arrAll=[];
					for(var key in _$this._swfDatas["particle"]){
						if(_$this._swfDatas["particle"][key] !=null){
							arrAll.push(key);
						}
					}
					if(arrAll.length > 0){
						_$this.onLoad粒子资源(arrAll);
						return;
					}
				}
				_$this.onLoadEndF(true);
			}
		}

		__proto.onLoad粒子资源=function(arr){
			var key=arr[0];
			key=key.substr(8);
			Laya.loader.load("assets/Particles/"+key+".part",Handler.create(this,this.onParticleLoadOne,[arr]),null,"json");
		}

		__proto.onParticleLoadOne=function(arr,settings){
			var key=arr.shift();
			if(this.Dic_ParticleSetting==null){
				this.Dic_ParticleSetting={};
			}
			this.Dic_ParticleSetting[key]=settings;
			if(arr.length==0){
				this.onLoadEndF(true);
				}else{
				this.onLoad粒子资源(arr);
			}
		}

		__proto.onLoadEndF=function(suc){
			Tool_Function.onRunFunction(this.FunLoaded,suc);
			this.FunLoaded=null;
		}

		__proto.createFuns=function(objData){
			var strName;
			if((objData instanceof Array))strName=objData[0];
			else strName=objData;
			if(strName.indexOf("img")==0)return this.getImage(strName);
			if(strName.indexOf("spr")==0)return this.getSprite(strName);
			if(strName.indexOf("mc")==0)return this.getMc(strName);
			if(strName.indexOf("s9")==0)return this.getS9Image(strName);
			if(strName.indexOf("text")==0)return this.createTextField(objData);
			if(strName.indexOf("particle")==0)return this.creatParticle(objData[0]);
			return null;
		}

		__proto.getObject=function(strName){
			if(strName.indexOf("img_")==0)return this.getImage(strName);
			if(strName.indexOf("spr_")==0)return this.getSprite(strName);
			if(strName.indexOf("mc_")==0)return this.getMc(strName);
			if(strName.indexOf("s9_")==0)return this.getS9Image(strName);
			return null;
		}

		__proto.getImage=function(strName){
			if (this.Dic_NameFrame[strName]!=null){
				var t=this.Dic_NameFrame[strName];
				var image=new SwfImage();
				image.graphics.drawTexture(t,0,0);
				var imageData=this._swfDatas["img"][strName];
				image.classLink=strName;
				image.pivotX=imageData[0];
				image.pivotY=imageData[1];
				image.autoSize=true;
				image.w0=image.width;
				image.h0=image.height;
				image.autoSize=false;
				return image;
			}
			Config.Log("没有image:"+strName);
			return null;
		}

		__proto.getS9Image=function(strName){
			if (this.Dic_NameFrame[strName]!=null){
				var scale9Data=this._swfDatas["s9"][strName];
				var t=this.Dic_NameFrame[strName];
				var image=new MYLayaAIR_S9Image();
				image.source=t;
				var imageData=this._swfDatas["img"][strName];
				image.classLink=strName;
				image.sizeGrid=scale9Data[0]+","+scale9Data[1]+","+scale9Data[2]+","+scale9Data[3];
				return image;
			}
			Config.Log("没有S9:"+strName);
			return null;
		}

		__proto.getSprite=function(strName){
			if(this._swfDatas["spr"]==null || this._swfDatas["spr"][strName]==null){
				Config.Log("没有Sprite:"+strName);
				return null;
			};
			var sprData=this._swfDatas["spr"][strName];
			var sprite=new SwfSprite();
			var length=sprData.length;
			var objData;
			var display;
			var i=0;
			if(!(((sprData[0])instanceof Array)))i=1;
			for (;i < length;i++){
				objData=sprData[i];
				display=this.createFuns(objData);
				if(display==null)continue ;
				display.name=objData[9];
				display.pos(objData[2],objData[3]);
				if(objData[1] !="s9"){
					display.scaleX=objData[4];
					display.scaleY=objData[5];
				}
				display.skewX=-objData[6];
				display.skewY=objData[7];
				display.alpha=objData[8];
				sprite.addChild(display);
			}
			sprite.setSpriteData(sprData);
			sprite.classLink=strName;
			return sprite;
		}

		__proto.getMc=function(strName){
			if(this._swfDatas["mc"]==null || this._swfDatas["mc"][strName]==null){
				Config.Log("没有MC:"+strName);
				return null;
			};
			var movieClipData=this._swfDatas["mc"][strName];
			if(movieClipData==null)return null;
			var objectCountData=movieClipData["objCount"];
			var displayObjects={};
			var displayObjectArray;
			var type;
			var count=0;
			var fun;
			for(var objName in objectCountData){
				type=objectCountData[objName][0];
				count=objectCountData[objName][1];
				displayObjectArray=displayObjects[objName]==null ? [] :displayObjects[objName];
				for (var i=0;i < count;i++){
					displayObjectArray.push(this.createFuns(objName));
				}
				displayObjects[objName]=displayObjectArray;
			};
			var mc=new SwfMovieClip(movieClipData["frames"],movieClipData["labels"],displayObjects,this);
			if(movieClipData["重复"]!=null)mc.on缓存重复帧(movieClipData["重复"]);
			if(movieClipData["meta"]!=null)mc.setMetaData(movieClipData["meta"]);
			mc.loop=movieClipData["loop"];
			mc.classLink=strName;
			return mc;
		}

		__proto.createTextField=function(data){
			var textfield=new Text();
			var w=2;
			var h=2;
			var txt="";
			if(data){
				w=data[10];
				h=data[11];
				txt=data[18];
				textfield.fontSize=data[14];
				textfield.color=data[13];
			}
			textfield.width=w;
			textfield.height=h;
			if(txt.length>0)textfield.text=txt;
			return textfield;
		}

		__proto.creatParticle=function(_name){
			if(this.Dic_ParticleSetting[_name]==null){
				return null;
			};
			var sp=new Particle2D(this.Dic_ParticleSetting[_name]);
			sp.emitter.start();
			sp.play();
			return sp;
		}

		__proto.destroyF=function(){
			Loader.clearRes(this.URL_Swf);
		}

		MyLayaAIR_SWF.dataKey_Sprite="spr";
		MyLayaAIR_SWF.dataKey_Image="img";
		MyLayaAIR_SWF.dataKey_MovieClip="mc";
		MyLayaAIR_SWF.dataKey_TextField="text";
		MyLayaAIR_SWF.dataKey_Scale9="s9";
		MyLayaAIR_SWF.dataKey_粒子="particle";
		return MyLayaAIR_SWF;
	})()


	//class com.MyClass.MyView.MyMouseEventStarling
	var MyMouseEventStarling=(function(){
		function MyMouseEventStarling(tar){
			this.MC=null;
			this.TouchID=0;
			this.Dic_Click=null;
			this.Dic_Slide=null;
			this.isDown=false;
			this.pausing=false;
			this.stop冒泡=false;
			this._开始移动距离=10;
			this.FunEnter=null;
			this.MC=tar;
			Tool_Function.onTouchable(this.MC);
			this.MC.on("mousedown",this,this.mouseHandler);
			this.MC.on("mouseup",this,this.mouseHandler);
			this.MC.on("mousemove",this,this.mouseHandler);
			this.MC.autoSize=true;
			this.MC.width=this.MC.width;
			this.MC.height=this.MC.height;
			this.MC.autoSize=false;
		}

		__class(MyMouseEventStarling,'com.MyClass.MyView.MyMouseEventStarling');
		var __proto=MyMouseEventStarling.prototype;
		// trace("添加事件：",MC);
		__proto.destroyF=function(){
			this.MC.offAll();
			this.MC=null;
			MainManager.getInstence().removeEnterFrameFun(this.enterFrameF);
		}

		__proto.setValue=function(str,val){
			switch (str){
				case "点击":
					this.newDicClick();
					this.Dic_Click["down"]=false;
					(val).once=false;
					this.Dic_Click["fun_click"]=val;
					break ;
				case "down事件":
					this.newDicClick();
					(val).once=false;
					this.Dic_Click["fun_down"]=val;
					break ;
				case "up事件":
					this.newDicClick();
					(val).once=false;
					this.Dic_Click["fun_up"]=val;
					break ;
				case "滑动":
					this.Dic_Slide={};
					this.Dic_Slide["初始x"]=this.MC.x;
					this.Dic_Slide["初始y"]=this.MC.y;
					this.Dic_Slide["上次x"]=this.MC.x;
					this.Dic_Slide["上次y"]=this.MC.y;
					this.Dic_Slide["开始移动"]=false;
					this.Dic_Slide["开始移动距离"]=this._开始移动距离;
					this.Dic_Slide["满足滑动速度"]=1;
					(val).once=false;
					this.Dic_Slide["fun"]=val;
					break ;
				case "停止本次":this.upF(null);break ;
				case "暂停":this.pausing=val;break ;
				case "停止冒泡":this.stop冒泡=true;break ;
				default :this[str]=val;break ;
				}
		}

		__proto.newDicClick=function(){
			if(this.Dic_Click)return;
			this.Dic_Click={};
			this.Dic_Click["关闭点击距离"]=20;
		}

		/**
		*鼠标响应事件处理
		*/
		__proto.mouseHandler=function(e){
			var p={};
			p["globalX"]=Laya.stage.mouseX;
			p["globalY"]=Laya.stage.mouseY;
			var pl=this.MC.globalToLocal(new Point(p["globalX"],p["globalY"]));
			p["x"]=pl.x;
			p["y"]=pl.y;
			switch (e.type){
				case "mousedown":this.downF(p);break ;
				case "mouseup":this.upF(p);break ;
				case "mousemove":this.moveF(p);break ;
				}
		}

		__proto.onRunF=function(f,arg){
			if((f instanceof laya.utils.Handler )){
				if(arg==null || arg.length==0)(f).run();
				else (f).runWith(arg);
				}else if((typeof f=='function')){
				(f).apply(null,arg);
			}
		}

		__proto.downF=function(p){
			if(this.pausing==true)return;
			if(this.isDown==true)return;
			this.isDown=true;
			if(this.Dic_Click !=null){
				this.Dic_Click["down"]=true;
				this.Dic_Click["起点x"]=p.globalX;
				this.Dic_Click["起点y"]=p.globalY;
				if(this.Dic_Click["fun_down"] !=null)this.onRunF(this.Dic_Click["fun_down"],[p]);
			}
			if(this.Dic_Slide !=null){
				this.Dic_Slide["起点x"]=p.globalX;
				this.Dic_Slide["起点y"]=p.globalY;
				this.Dic_Slide["上次x"]=p.globalX;
				this.Dic_Slide["上次y"]=p.globalY;
				this.Dic_Slide["开始移动"]=false;
				this.Dic_Slide["x速度"]=0;
				this.Dic_Slide["y速度"]=0;
				this.Dic_Slide["计时"]=0;
				if(this.FunEnter==null)this.FunEnter=Handler.create(this,this.enterFrameF);
				MainManager.getInstence().addEnterFrameFun(this.FunEnter);
			}
		}

		__proto.upF=function(p){
			if(this.pausing==true)return;
			if(this.isDown==false)return;
			if(p !=null && this.Dic_Click !=null){
				if((this.Dic_Slide==null || this.Dic_Slide["开始移动"]==false)&& this.Dic_Click["down"]==true && this.Dic_Click["开始移动"]!=true){
					if(this.Dic_Click["fun_up"] !=null)this.onRunF(this.Dic_Click["fun_up"],[p]);
					if(this.Dic_Click["fun_click"] !=null)this.onRunF(this.Dic_Click["fun_click"],[p]);
				}
				this.Dic_Click["down"]=false;
				this.Dic_Click["开始移动"]=false;
			}
			if(this.Dic_Slide !=null && this.Dic_Slide["开始移动"]==true && p!=null){
				var lx=p.globalX;
				var ly=p.globalY;
				var dic={};
				dic["类型"]="滑动";
				if(Math.abs(this.Dic_Slide["x速度"])>=this.Dic_Slide["满足滑动速度"])dic["x"]=this.Dic_Slide["x速度"];
				else dic["x"]=0;
				if(Math.abs(this.Dic_Slide["y速度"])>=this.Dic_Slide["满足滑动速度"])dic["y"]=this.Dic_Slide["y速度"];
				else dic["y"]=0;
				dic["gx"]=lx;
				dic["gy"]=ly;
				this.onRunF(this.Dic_Slide["fun"],[dic]);
				MainManager.getInstence().removeEnterFrameFun(this.FunEnter);
				this.FunEnter.clear();
				this.FunEnter=null;
			}
			else if(this.Dic_Slide !=null){
				dic={};
				dic["类型"]="滑动";
				dic["x"]=0;
				dic["y"]=0;
				this.onRunF(this.Dic_Slide["fun"],[dic]);
				MainManager.getInstence().removeEnterFrameFun(this.FunEnter);
				this.FunEnter.clear();
				this.FunEnter=null;
			}
			this.isDown=false;
		}

		__proto.moveF=function(p){
			if(this.pausing==true || p==null)return;
			var lx=p.globalX;
			var ly=p.globalY;
			if(this.isDown==false || this.Dic_Slide==null){
				if(this.Dic_Click && this.Dic_Click["开始移动"] !=true){
					var L=(lx-this.Dic_Click["起点x"])*(lx-this.Dic_Click["起点x"])+(ly-this.Dic_Click["起点y"])*(ly-this.Dic_Click["起点y"]);
					L=Math.sqrt(L);
					if(L > this._开始移动距离)this.Dic_Click["开始移动"]=true;
				}
				return;
			}
			this.Dic_Slide["计时"]=3;
			var dic={};
			if(this.Dic_Slide["开始移动"]==false){
				L=(lx-this.Dic_Slide["起点x"])*(lx-this.Dic_Slide["起点x"])+(ly-this.Dic_Slide["起点y"])*(ly-this.Dic_Slide["起点y"]);
				L=Math.sqrt(L);
				if(L > this.Dic_Slide["开始移动距离"]){
					this.Dic_Slide["开始移动"]=true;
				}
			}
			if(this.Dic_Slide["开始移动"]==true){
				if(this.Dic_Click !=null && this.Dic_Click["down"]==true){
					L=(lx-this.Dic_Slide["起点x"])*(lx-this.Dic_Slide["起点x"])+(ly-this.Dic_Slide["起点y"])*(ly-this.Dic_Slide["起点y"]);
					L=Math.sqrt(L);
					if(L > this.Dic_Click["关闭点击距离"]){
						this.Dic_Click["down"]=false;
					}
				}
				dic["类型"]="移动";
				if(lx !=0)dic["x"]=lx-this.Dic_Slide["上次x"];
				else dic["x"]=0;
				if(ly !=0)dic["y"]=ly-this.Dic_Slide["上次y"];
				else dic["y"]=0;
				if(dic["x"]==0)this.Dic_Slide["x速度"]=0;
				else if((this.Dic_Slide["x速度"] > 0 && dic["x"] > 0)|| (this.Dic_Slide["x速度"] < 0 && dic["x"] < 0))
				this.Dic_Slide["x速度"]=(this.Dic_Slide["x速度"]+dic["x"])/ 2;
				else
				this.Dic_Slide["x速度"]=dic["x"] / 2;
				if(dic["y"]==0)this.Dic_Slide["y速度"]=0;
				else if((this.Dic_Slide["y速度"] > 0 && dic["y"] > 0)|| (this.Dic_Slide["y速度"] < 0 && dic["y"] < 0))
				this.Dic_Slide["y速度"]=(this.Dic_Slide["y速度"]+dic["y"])/ 2;
				else
				this.Dic_Slide["y速度"]=dic["y"] / 2;
				this.Dic_Slide["上次x"]=lx;
				this.Dic_Slide["上次y"]=ly;
				dic["gx"]=lx;
				dic["gy"]=ly;
				this.onRunF(this.Dic_Slide["fun"],[dic]);
			}
		}

		__proto.enterFrameF=function(){
			if(this.pausing==true)return;
			if(this.isDown==false)return;
			this.Dic_Slide["计时"]-=1;
			if(this.Dic_Slide["计时"] <=0){
				this.Dic_Slide["计时"]=0;
				this.Dic_Slide["x速度"]=0;
				this.Dic_Slide["y速度"]=0;
			}
		}

		return MyMouseEventStarling;
	})()


	//class com.MyClass.MyView.MyViewBtnController
	var MyViewBtnController=(function(){
		function MyViewBtnController(spr,f){
			this.sprView=null;
			this.FunClick=null;
			this.Dic_Btn=new Dictionary();
			this.sprView=spr;
			this.FunClick=f;
			if(this.FunClick.once==true)this.FunClick.once=false;
			for(var i=0;i<this.sprView.numChildren;i++){
				var child=spr.getChildAt(i);
				var strName=child.name;
				if(strName && strName.indexOf("btn_")==0){
					var btn=new BTN_Starling(child,new Handler(this,this.onClickF,[(child).name]),null,null);
					btn.name=strName;
					this.Dic_Btn.set(strName,btn);
				}
			}
		}

		__class(MyViewBtnController,'com.MyClass.MyView.MyViewBtnController');
		var __proto=MyViewBtnController.prototype;
		__proto.onClickF=function(tar){
			if(this.FunClick){
				this.FunClick.runWith(tar);
			}
		}

		__proto.getBtnByName=function(_name){
			return this.Dic_Btn.get(_name);
		}

		__proto.destroyF=function(){
			this.FunClick.clear();
			this.Dic_Btn=Tool_ObjUtils.getInstance().destroyF_One(this.Dic_Btn);
		}

		return MyViewBtnController;
	})()


	//class com.MyClass.MyView.MyViewTXController
	var MyViewTXController=(function(){
		function MyViewTXController(spr){
			this.Dic_TX={};
			this.Dic_TXI={};
			this.Dic_Hide={};
			this.Dic_Listener=null;
			for(var i=0;i<spr.numChildren;i++){
				var obj=spr.getChildAt(i);
				if(obj.name==null)continue ;
				var strName=obj.name;
				if(strName.indexOf("tx_")==0 && (obj instanceof laya.display.Text )){
					this.Dic_TX[strName]=obj;
				}
				else if(strName.indexOf("txi_")==0){
					var tx=MyTextInput.getNewOne(spr,strName);
					this.Dic_TXI[tx.Name]=tx;
					if((obj instanceof laya.display.Text ))tx.text=(obj).text;
					Tool_ObjUtils.getInstance().destroyF_One(obj);
					i--;
				}
			}
		}

		__class(MyViewTXController,'com.MyClass.MyView.MyViewTXController');
		var __proto=MyViewTXController.prototype;
		/***********获得文本对象 ***********/
		__proto.get动态文本=function(strName){
			return this.Dic_TX[strName];
		}

		__proto.get输入文本=function(strName){
			return this.Dic_TXI[strName];
		}

		/***********获得或修改文本文字 ***********/
		__proto.get文字=function(strName){
			if(this.Dic_TX[strName])return (this.Dic_TX[strName]).text;
			if(this.Dic_TXI[strName])return (this.Dic_TXI[strName]).text;
			var n;
			for(n in this.Dic_TX){
				if(n.indexOf(strName)==0)return this.Dic_TX[n].text;
			}
			for(n in this.Dic_TXI){
				if(n.indexOf(strName)==0)return this.Dic_TXI[n].text;
			}
			return null;
		}

		__proto.set文字=function(strName,txt){
			if(this.Dic_TX[strName])(this.Dic_TX[strName]).text=txt;
			if(this.Dic_TXI[strName])(this.Dic_TXI[strName]).text=txt;
			var n;
			if(strName=="tx_"){
				for(n in this.Dic_TX){
					this.Dic_TX[n].text=txt;
				}
			}
			else if(strName=="txi_"){
				for(n in this.Dic_TXI){
					this.Dic_TXI[n].text=txt;
				}
			}
		}

		__proto.addChangeEventListener=function(strName,f){}
		__proto.onChangeEvent=function(tar){}
		__proto.onHide输入文本=function(real){
			var n;
			for(n in this.Dic_TXI){
				if(this.Dic_TXI[n]==null)continue ;
				if(real==false){
					if(this.Dic_Hide[n] !=true)continue ;
					}else{
					if(this.Dic_Hide[n]==true)continue ;
				}
				this.Dic_Hide[n]=real;
				(this.Dic_TXI [n]).setValue("隐藏",real);
			}
		}

		__proto.destroyF=function(){
			this.Dic_Listener=null;
			this.Dic_TX=Tool_ObjUtils.getInstance().destroyF_One(this.Dic_TX);
			this.Dic_TXI=Tool_ObjUtils.getInstance().destroyF_One(this.Dic_TXI);
		}

		return MyViewTXController;
	})()


	//class com.MyClass.NetTools.CmdRand
	var CmdRand=(function(){
		function CmdRand(){
			this._seed=0;
			this.seed=0;
			this.lastSeed=0;
		}

		__class(CmdRand,'com.MyClass.NetTools.CmdRand');
		var __proto=CmdRand.prototype;
		__proto.next=function(){
			this.lastSeed=this._seed;
			do{
				this._seed^=(this._seed<<21);
				this._seed^=(this._seed>>21);
				this._seed^=(this._seed<<4);
			}
			while(this._seed==0 || this.seed==this._seed);
			this.seed=this._seed;
			return this._seed;
		}

		__proto.setSeed=function(n){
			this._seed=n;
			this.lastSeed=n;
		}

		CmdRand.getInstance=function(){
			if(CmdRand.instance==null)
				CmdRand.instance=new CmdRand();
			return CmdRand.instance;
		}

		CmdRand.instance=null
		return CmdRand;
	})()


	//class com.MyClass.NetTools.MgsSocket
	var MgsSocket=(function(){
		function MgsSocket(){
			this.CMDLENGTH=2;
			this.SEEDLength=4;
			this.CMD心跳=0;
			this.Fun_connect=null;
			this.IP=null;
			this.PORT=0;
			this.socket=null;
			this.timeLimite=8;
			this.isListening=false;
			this._cmdDict=null;
			this.Seed=null;
			this.SaveBuf=null;
			this.SaveCMD=-1;
			this.now状态=null;
			this.need断网事件=false;
			this.Fun收到重连指令=null;
			this.on超时Handler=null;
			this._pause=false;
			this.Arr_WaiteReceiveCMD=null;
			this.Arr_WaiteSendCMD=null;
			this.Seed=CmdRand.getInstance();
			this.socket=new Socket();
			this._cmdDict=new Dictionary();
			this.on超时Handler=Handler.create(this,this.onTimeWrongF,null,false);
		}

		__class(MgsSocket,'com.MyClass.NetTools.MgsSocket');
		var __proto=MgsSocket.prototype;
		__proto.getSocket=function(type){
			if(type==null)return this.socket;
			return null
		}

		__proto.connectF=function(ip,port){
			if(ip!=null)this.IP=ip;
			if(port!=0)this.PORT=port;
			this.addListeners();
			this.now状态="正在连接";
			if(!this.socket.connected){
				this.socket.connect(this.IP,this.PORT);
			}
		}

		/**
		*配置socket监听事件
		*
		*/
		__proto.addListeners=function(){
			if(this.isListening)return;
			this.isListening=true;
			this.socket.on("open",this,this.connectHandler,null);
			this.socket.on("close",this,this.closeHandler,null);
			this.socket.on("error",this,this.ioErrorHandler,null);
			this.socket.on("message",this,this.socketDataHandler,null);
		}

		/**
		*删除socket监听事件
		*
		*/
		__proto.removeListeners=function(){
			this.isListening=false;
			this.socket.offAll();
		}

		__proto.connectHandler=function(event){
			console.log("socket连接成功！");
			this.now状态="连接";
			if(this.Fun_connect !=null){
				if((this.Fun_connect instanceof laya.utils.Handler ))this.Fun_connect.runWith(true);
				else this.Fun_connect(true);
				this.Fun_connect=null;
			}
		}

		/**
		*当服务端关闭后触发
		*@param event
		*
		*/
		__proto.closeHandler=function(event){
			Config.Log("socket已关闭!" ,this.need断网事件==false||"发送断网监听");
			this.now状态=null;
			if(this.need断网事件==true){
				MainManager.getInstence().MEM.dispatchF("网络断开！");
			}
		}

		__proto.closeSocket=function(){
			if(this.socket!=null && this.socket.connected)this.socket.close();
			this.closeHandler(null);
		}

		/**
		*IO异常
		*@param event
		*
		*/
		__proto.ioErrorHandler=function(event){
			console.log("socket io错误");
			if(this.Fun_connect !=null){
				if((this.Fun_connect instanceof laya.utils.Handler ))this.Fun_connect.runWith(false);
				else this.Fun_connect(false);
				this.Fun_connect=null;
			}
		}

		/**
		*收到服务端发送数据触发
		*@param event
		*
		*/
		__proto.socketDataHandler=function(message){
			if ((typeof message=='string')){
				console.log("收到String消息：length=",message.length);
				var arr=(message).split(",");
				var buf=new ByteArray();
				for(var i=0;i<arr.length;i++){
					buf.writeByte(Tool_Function.on强制转换(arr[i]));
				}
				buf.position=0;
				this.getBytes(buf);
			}
			else if ((message instanceof ArrayBuffer)){
				console.log("收到ArrayBuffer消息：",message);
				buf=new ByteArray();
				buf.writeBytes(message);
				buf.position=0;
				this.getBytes(buf);
			}
			this.socket.input.clear();
		}

		__proto.getBytes=function(buf){
			var l=buf.readInt();
			var cmd=buf.readShort();
			var realData=new ByteArray();
			buf.readBytes(realData,0,buf.bytesAvailable);
			this.receiveCommand(cmd,realData);
			realData=null;
			buf=null;
		}

		__proto.receiveCommand=function(cmd,dataBytes){
			if(cmd==this.CMD心跳){
				var c=new Net_SocketCMD(this.CMD心跳,false,false);
				c.sendF(false);
				return;
			}
			if(this.pause==true){
				if(this.Arr_WaiteReceiveCMD==null)this.Arr_WaiteReceiveCMD=[];
				this.Arr_WaiteReceiveCMD.push([cmd,dataBytes]);
				return;
			}
			console.log("收到cmd:"+cmd);
			var hander=this._cmdDict.get(cmd);
			if(hander!=null){
				var l=hander.length;
				for (var i=0;i<l;i++){
					if(i>=hander.length)break ;
					var val=hander[i];
					if(val==null)continue ;
					Tool_Function.onRunFunction(val,dataBytes);
				}
				for (i=0;i<hander.length;i++){
					if(hander[i]==null)hander.splice(i--,1);
				}
			}
			if(cmd==this.SaveCMD){
				this.SaveCMD=-1;
				this.SaveBuf=null;
				MainManager._instence.remove_delayFunction(this.on超时Handler);
				if(this.Arr_WaiteSendCMD!=null && this.Arr_WaiteSendCMD.length > 0){
					var tmp=this.Arr_WaiteSendCMD.shift();
					console.log("发送缓存指令："+tmp[0]);
					this.sendMessage(tmp[0],tmp[1],tmp[2],tmp[3]);
					}else{
					if(this.Fun收到重连指令){
						Tool_Function.onRunFunction(this.Fun收到重连指令);
						this.Fun收到重连指令=null;
					}
				}
			}
		}

		/**
		*添加某个消息号的监听
		*@param cmd 消息号
		*@param args 传两个参数，0为处理函数 1为需要填充的数据对象
		*
		*/
		__proto.addCmdListener=function(cmd,hander){
			var arr=this._cmdDict.get(cmd);
			if (arr==null){
				arr=[];
				this._cmdDict.set(cmd,arr);
			}
			arr.push(hander);
		}

		/**
		*移除 消息号监听
		*@param cmd
		*
		*/
		__proto.removeCmdListener=function(cmd,listener){
			var handers=this._cmdDict.get(cmd);
			if (handers !=null && handers.length > 0){
				var length=handers.length;
				for (var i=(length-1);i >=0;i--){
					if(((handers[i])instanceof Array)){
						var index=(handers[i]).indexOf(listener);
						if(index >=0){
							handers[i][index]=null;
						}
					}
					else if (listener==handers[ i]){
						handers[i]=null;
					}
				}
			}
		}

		//从数组中删除元素
		__proto.sendMessage=function(cmd,content,needRandom,type){
			(needRandom===void 0)&& (needRandom=true);
			if(this.SaveCMD !=-1 && needRandom==true){
				if(this.Arr_WaiteSendCMD==null)this.Arr_WaiteSendCMD=[];
				console.log("缓存指令"+cmd);
				this.Arr_WaiteSendCMD.push([cmd,content,needRandom,type]);
				return;
			};
			var contentLen=0;
			if(content !=null){
				contentLen=content.length;
			};
			var lastSaveBuf=this.SaveBuf;
			this.SaveBuf=new ByteArray();
			this.SaveBuf.writeInt(contentLen+this.CMDLENGTH+this.SEEDLength);
			if(needRandom){
				var cmdSeed=CmdRand.getInstance().next();
				this.SaveBuf.writeInt(cmdSeed);
			}
			else this.SaveBuf.writeInt(0);
			this.SaveBuf.writeShort(cmd);
			if(content !=null){
				this.SaveBuf.writeBytes(content,0,content.length);
			}
			this.sendF(type);
			if(needRandom==false){
				this.SaveBuf=lastSaveBuf;
				}else{
				this.SaveCMD=cmd;
				if(this.timeLimite>0 && MainManager._instence!=null){
					MainManager._instence.add_delayFunction(this.on超时Handler,this.timeLimite *Config.playSpeedTrue);
				}
			}
		}

		__proto.onTimeWrongF=function(){
			Config.Log("超时关闭socket！",this.SaveCMD,this.SaveBuf!=null);
			if(this.SaveCMD==-1 || this.SaveBuf==null){
				return;
			}
			this.closeSocket();
		}

		__proto.sendF=function(type){
			if(this.socket.connected==false){
				this.closeHandler(null);
				return;
			}
			if(type==null){
				if(this.SaveBuf==null)return;
				this.SaveBuf.position=0;
				for (var i=0;i < this.SaveBuf.length;i++){
					this.socket.output.writeByte(this.SaveBuf.readByte());
				}
				this.SaveBuf.position=0;
				this.socket.flush();
			}
			else{
				console.log("暂未支持h5的mysocket");
			}
		}

		__proto.onSend缓存=function(f){
			if(this.SaveCMD==-1){
				if(f)Tool_Function.onRunFunction(f);
				return;
			}
			Config.Log("发送缓存指令：",this.SaveCMD,this.SaveBuf!=null);
			this.Fun收到重连指令=f;
			MainManager._instence.add_delayFunction(this.on超时Handler,this.timeLimite *Config.playSpeedTrue);
			this.sendF(null);
		}

		__proto.destroyF=function(){
			this.removeListeners();
			if(this.socket!=null && this.socket.connected)this.socket.close();
			this._cmdDict=new Dictionary();
			MgsSocket._mgsSocket=null;
			this.on超时Handler.clear();
		}

		__getset(0,__proto,'pause',function(){
			return this._pause;
			},function(value){
			this._pause=value;
			if(value==false){
				if(this.Arr_WaiteReceiveCMD){
					while(this.Arr_WaiteReceiveCMD.length>0){
						this.receiveCommand(this.Arr_WaiteReceiveCMD[0][0],this.Arr_WaiteReceiveCMD[0][1]);
						this.Arr_WaiteReceiveCMD.shift();
					}
				}
				this.Arr_WaiteReceiveCMD=null;
			}
		});

		MgsSocket.getInstance=function(){
			if(MgsSocket._mgsSocket==null){
				MgsSocket._mgsSocket=new MgsSocket();
			}
			return MgsSocket._mgsSocket;
		}

		MgsSocket.Event_Close="网络断开";
		MgsSocket._mgsSocket=null
		return MgsSocket;
	})()


	//class com.MyClass.SoundManagerMy
	var SoundManagerMy=(function(){
		function SoundManagerMy(){
			this.DirPath="Sound";
			this.pause=0;
			this.mute=false;
			this.Fun=null;
			this.Arr_now=null;
			this.Arr_waite=null;
			this.isLoading=false;
			this.Dic_fullName={};
		}

		__class(SoundManagerMy,'com.MyClass.SoundManagerMy');
		var __proto=SoundManagerMy.prototype;
		__proto.addSounds=function(arr,f){
			if(this.isLoading==true){
				if(this.Arr_waite==null)this.Arr_waite=[];
				this.Arr_waite.push({"arr":arr,"f":f});
				return;
			}
			this.Arr_now=arr;
			this.Fun=f;
			this.nextF(true);
		}

		__proto.nextF=function(first){
			(first===void 0)&& (first=false);
			this.isLoading=true;
			if(first==false){
				this.Arr_now.shift();
				if(this.Arr_now.length==0){
					Tool_Function.onRunFunction(this.Fun);
					this.Fun=null;
					this.Arr_now=null;
					if(this.Arr_waite==null || this.Arr_waite.length==0){
						this.isLoading=false;
						}else{
						var waite=this.Arr_waite.shift();
						this.Arr_now=waite["arr"];
						this.Fun=waite["f"];
						this.nextF(true);
					}
					return;
				}
			}
			if(this.Arr_now[0]==null){
				this.nextF();
				return;
			};
			var name=this.Arr_now[0][0];
			var fullName;
			var dir=this.Arr_now[0][1];
			if(dir==null || dir.length==0){
				fullName=name;
			}
			else if(dir.charAt(dir.length-1)=="/"){
				fullName=dir+name;
				}else{
				fullName=dir+"/"+name;
			}
			fullName=this.DirPath+"/"+fullName+".wav";
			this.Dic_fullName[name]=fullName;
			this.nextF();
		}

		//@@@@@@@@@@@@@@@@@@@@@@播放@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@
		__proto.getFullName=function(name){
			return this.Dic_fullName[name];
		}

		__proto.playMusic=function(name,vol,stopF,sTime,loop,fadeTime){
			(vol===void 0)&& (vol=-1);
			(sTime===void 0)&& (sTime=0);
			(loop===void 0)&& (loop=9999);
			(fadeTime===void 0)&& (fadeTime=0);
			name=this.getFullName(name);
			if(name){
				SoundManager.playMusic(name,0,stopF);
			}
		}

		__proto.playSound=function(name,vol){
			(vol===void 0)&& (vol=1);
			name=this.getFullName(name);
			if(name){
				SoundManager.playSound(name);
			}
		}

		__proto.setVol=function(vol,name){
			SoundManager.soundVolume=vol;
		}

		/*
		*@fadeTime 缓出时间（毫秒）
		*/
		__proto.stopMusic=function(name,fadeTime){
			(fadeTime===void 0)&& (fadeTime=0);
			SoundManager.stopMusic();
		}

		__proto.removeSound=function(id){}
		__proto.stopAll=function(){
			SoundManager.stopAll();
		}

		__proto.haveSound=function(name){
			return true;
		}

		__proto.destroyF=function(){
			com.MyClass.SoundManagerMy.instance=null;
			SoundManagerMy.nowMic=null;
			SoundManagerMy.countBackNum=0;
		}

		SoundManagerMy.getInstance=function(){
			if(com.MyClass.SoundManagerMy.instance==null){
				com.MyClass.SoundManagerMy.instance=new SoundManagerMy();
			}
			return com.MyClass.SoundManagerMy.instance;
		}

		SoundManagerMy.nowMic=null
		SoundManagerMy.countBackNum=0;
		SoundManagerMy.soundVal=1;
		SoundManagerMy.instance=null
		return SoundManagerMy;
	})()


	//class com.MyClass.Tools.AlertSmall
	var AlertSmall=(function(){
		function AlertSmall(str){
			this.INFO=null;
			this.mcBack=null;
			this.mt=null;
			this.mme=null;
			this.INFO=str;
			this.mcBack=MySourceManager.getInstance().getMcFromSwf("SWF_Default","mc_AlertSmall");
			if(this.mcBack==null){
				return;
			}
			LayerStarlingManager.instance.LayerView.addChild(this.mcBack);
			this.mt=new MyViewTXController(this.mcBack);
			this.mt.set文字("tx_info","");
			this.mcBack.FunComp=Handler.create(this,this.stopF);
			this.mcBack.play();
		}

		__class(AlertSmall,'com.MyClass.Tools.AlertSmall');
		var __proto=AlertSmall.prototype;
		__proto.stopF=function(){
			if(this.mcBack==null)return;
			this.mcBack.stop();
			this.mt.set文字("tx_info",this.INFO);
			this.mme=new MyMouseEventStarling(this.mcBack);
			this.mme.setValue("点击",Handler.create(this,this.clickF));
			MainManager.getInstence().add_delayFunction(Handler.create(this,this.clickF),Config.playSpeedTrue *2);
		}

		__proto.clickF=function(e){
			if(this.mcBack==null)return;
			this.mcBack=Tool_ObjUtils.getInstance().destroyF_One(this.mcBack);
			this.mt=Tool_ObjUtils.getInstance().destroyF_One(this.mt);
			this.mme=Tool_ObjUtils.getInstance().destroyF_One(this.mme);
			com.MyClass.Tools.AlertSmall.removeF();
		}

		AlertSmall.showF=function(str){
			if(AlertSmall.Vec_info==null)AlertSmall.Vec_info=[];
			if(str !=null)AlertSmall.Vec_info.push(str);
			AlertSmall.nextF();
		}

		AlertSmall.clearAllF=function(){
			AlertSmall.Vec_info=null;
			if(AlertSmall.NowMC)AlertSmall.NowMC.clickF(null);
		}

		AlertSmall.removeF=function(){
			AlertSmall.NowMC=null;
			AlertSmall.nextF();
		}

		AlertSmall.nextF=function(){
			if(AlertSmall.Vec_info==null)return;
			if(AlertSmall.NowMC !=null)return;
			if(AlertSmall.Vec_info.length==0){
				AlertSmall.Vec_info=null;return;
			}
			try{
				AlertSmall.NowMC=new AlertSmall(AlertSmall.Vec_info[0]);
				AlertSmall.Vec_info.shift();
				if(AlertSmall.Vec_info.length==0)AlertSmall.Vec_info=null;
				}catch(e){
				AlertSmall.Vec_info=null;
			}
		}

		AlertSmall.Vec_info=null
		AlertSmall.NowMC=null
		return AlertSmall;
	})()


	//class com.MyClass.Tools.AlertWindow
	var AlertWindow=(function(){
		function AlertWindow(str,viewText,fok,okVal,haveno,fno,noVal,强制org,不弹出){
			this.MSO=null;
			this.Layer2=null;
			this.Spr=null;
			this.BC2=null;
			this.BtnOK=null;
			this.BtnNO=null;
			this.FOK=null;
			this.FNO=null;
			this.ValOK=null;
			this.ValNO=null;
			this.HaveNO=false;
			this.mc透明=null;
			this.Busy=false;
			this.simple=false;
			(haveno===void 0)&& (haveno=false);
			(强制org===void 0)&& (强制org=false);
			(不弹出===void 0)&& (不弹出=false);
			MyTextInput.onHideF(true);
			this.FOK=fok;this.ValOK=okVal;
			this.FNO=fno;this.ValNO=noVal;
			this.HaveNO=haveno;
			this.initStarlingVer(str,viewText,不弹出);
		}

		__class(AlertWindow,'com.MyClass.Tools.AlertWindow');
		var __proto=AlertWindow.prototype;
		__proto.tover=function(){
			this.Busy=false;
		}

		__proto.clickF=function(n){
			if(this.Busy)return;
			MyTextInput.onHideF(false);
			if(this.Layer2){
				if(this.Layer2.parent)this.Layer2.parent.removeChild(this.Layer2);
				this.Layer2=null;
			}
			if(this.BC2){
				this.BC2.destroyF();this.BC2=null;
			}
			this.MSO=null;
			if(n==0 && this.FOK !=null){
				if(this.ValOK!=null)Tool_Function.onRunFunction(this.FOK,this.ValOK);
				else Tool_Function.onRunFunction(this.FOK);
			}
			else if(n==1 && this.FNO !=null){
				if(this.ValNO!=null)Tool_Function.onRunFunction(this.FNO,this.ValNO);
				else Tool_Function.onRunFunction(this.FNO);
			}
			this.FOK=null;
			this.FNO=null;
			if(this.simple==false){
				com.MyClass.Tools.AlertWindow.Instance=null;
				if(com.MyClass.Tools.AlertWindow.Arr_Waite.length > 0){
					var arr=AlertWindow.Arr_Waite[0];
					AlertWindow.Arr_Waite.splice(0,1);
					com.MyClass.Tools.AlertWindow.showF(arr[0],arr[1],arr[2],arr[3],arr[4],arr[5],arr[6]);
				}
			}
		}

		//-------------------------------------------------------------------------
		__proto.initStarlingVer=function(str,viewText,不弹出){
			this.MSO=new MySourceManagerOne();
			this.Spr=this.MSO.getSprFromSwf("SWF_Default","spr_AlertWin");
			if(this.Spr==null){
				this.clickF(0);
				return;
			}
			this.Layer2=new starling.display.Sprite();
			LayerStarlingManager.instance.LayerTop.addChild(this.Layer2);
			this.Layer2.addChild(this.Spr);
			var TX;
			TX=this.Spr.getChildByName("t1");
			TX.text=str;
			if(viewText && viewText["title"]){
				TX=this.Spr.getChildByName("tx_title");
				TX.text=viewText["title"];
			}
			this.BtnOK=this.Spr.getChildByName("b1");
			this.BtnNO=this.Spr.getChildByName("b2");
			TX=this.BtnOK.getChildByName("tx_ok");
			if(viewText && viewText["ok"])TX.text=viewText["ok"];
			else TX.text="确定";
			if(this.HaveNO==false){
				this.BtnNO.parent.removeChild(this.BtnNO);
				this.BtnNO=null;
				this.BtnOK.x=(this.Spr.width-this.BtnOK.width)>>1;
				this.BC2=new BTNControllerStarling(this.Spr,[this.BtnOK],Handler.create(this,this.clickF));
			}
			else{
				TX=this.BtnNO.getChildByName("tx_ok");
				if(viewText && viewText["no"])TX.text=viewText["no"];
				else TX.text="取消";
				this.BC2=new BTNControllerStarling(this.Spr,[this.BtnOK,this.BtnNO],Handler.create(this,this.clickF));
			}
			this.mc透明=this.MSO.getImgFromSwf("SWF_Default","img_透明");
			if(this.mc透明){
				this.mc透明.width=Config.stageW;
				this.mc透明.height=Config.stageH;
				this.Layer2.addChildAt(this.mc透明,0);
			}
			this.BC2.冒泡方式="禁止";
			if(不弹出)return;
			var eff=new MyEffect_WindowAppear_Scale(this.Spr,Handler.create(this,this.tover));
			this.Busy=false;
		}

		AlertWindow.showF=function(str,viewText,fok,okVal,haveno,fno,noVal){
			(haveno===void 0)&& (haveno=false);
			if(AlertWindow.Instance !=null){
				AlertWindow.Arr_Waite.push([str,viewText,fok,okVal,haveno,fno,noVal]);
				return;
			}
			AlertWindow.Instance=new AlertWindow(str,viewText,fok,okVal,haveno,fno,noVal);
		}

		AlertWindow.showSimpleF=function(str,viewText,fok,okVal,haveno,fno,noVal,强制org,不弹出){
			(haveno===void 0)&& (haveno=false);
			(强制org===void 0)&& (强制org=true);
			(不弹出===void 0)&& (不弹出=false);
			var a=new AlertWindow(str,viewText,fok,okVal,haveno,fno,noVal,强制org,不弹出);
			a.simple=true;
		}

		AlertWindow.clearF=function(){
			AlertWindow.Arr_Waite=[];
			if(AlertWindow.Instance){
				AlertWindow.Instance.clickF(-1);AlertWindow.Instance=null;
			}
		}

		AlertWindow.Instance=null
		AlertWindow.Arr_Waite=[];
		return AlertWindow;
	})()


	//class com.MyClass.Tools.MyCheaterNum
	var MyCheaterNum=(function(){
		function MyCheaterNum(){}
		__class(MyCheaterNum,'com.MyClass.Tools.MyCheaterNum');
		var __proto=MyCheaterNum.prototype;
		__proto.initByDic=function(dic){}
		__proto.setValue=function(name,val){}
		__proto.getValue=function(name){
			return null;
		}

		__proto.checkF=function(name,val2){
			return true;
		}

		return MyCheaterNum;
	})()


	//class com.MyClass.Tools.MyCheaterNumMultiple
	var MyCheaterNumMultiple=(function(){
		function MyCheaterNumMultiple(num){
			this.Arr_Num=[];
			if(num<1)num=1;
			while(num-->=0){
				var cn=new MyCheaterNum();
				this.Arr_Num.push(cn);
			}
		}

		__class(MyCheaterNumMultiple,'com.MyClass.Tools.MyCheaterNumMultiple');
		var __proto=MyCheaterNumMultiple.prototype;
		__proto.initByDic=function(dic){
			this.Arr_Num.forEach(function(cn,index,arr){
				cn.initByDic(dic);
			});
		}

		__proto.setValue=function(name,val){
			this.Arr_Num.forEach(function(cn,index,arr){
				cn.setValue(name,val);
			});
		}

		__proto.getValue=function(name){
			return (this.Arr_Num[0]).getValue(name);
		}

		__proto.checkF=function(name,val2){
			for(var i=0;i<this.Arr_Num.length;i++){
				var cn=this.Arr_Num[i];
				var suc=cn.checkF(name,val2);
				if(suc==false){
					return false;
				}
			}
			return true;
		}

		return MyCheaterNumMultiple;
	})()


	//class com.MyClass.Tools.MyLocalStorage
	var MyLocalStorage=(function(){
		function MyLocalStorage(){};
		__class(MyLocalStorage,'com.MyClass.Tools.MyLocalStorage');
		MyLocalStorage.getF=function(name){
			return LSOManager.get(name);
		}

		MyLocalStorage.setF=function(name,val){
			LSOManager.put(name,val);
		}

		return MyLocalStorage;
	})()


	//class com.MyClass.Tools.MyNetAlertWindow
	var MyNetAlertWindow=(function(){
		function MyNetAlertWindow(dic){
			console.log("收到弹窗！");
			try{
				if(dic["纯代码"]){
					return;
				}
				if(dic["小弹窗"]){
					AlertSmall.showF(dic["小弹窗"]);
					return;
				};
				var 标题=null;
				if(dic["标题"])标题=dic["标题"];
				var haveNo=false;
				if(dic["haveNo"]==true)haveNo=true;
				if(dic["强制ORG"]==true)AlertWindow.showSimpleF(dic["内容"],标题,resaultF,true,haveNo,resaultF,false);
				else AlertWindow.showF(dic["内容"],标题,resaultF,true,haveNo,resaultF,false);
				}catch (e){
				console.log("弹窗错误:"+e.message);
			}
			function resaultF (bol){}
		}

		__class(MyNetAlertWindow,'com.MyClass.Tools.MyNetAlertWindow');
		return MyNetAlertWindow;
	})()


	//class com.MyClass.Tools.MyPools
	var MyPools=(function(){
		function MyPools(){
			this.Dic={};
			this.Dic_Fun={};
			this.Dic_Max={};
		}

		__class(MyPools,'com.MyClass.Tools.MyPools');
		var __proto=MyPools.prototype;
		/**
		*注册一个缓存池
		**/
		__proto.registF=function(Name,fun,max){
			(max===void 0)&& (max=50);
			if(this.Dic[Name] !=null){
				this.removeF(Name);
			}
			this.Dic[Name]=[];
			this.Dic_Fun[Name]=fun;
			this.Dic_Max[Name]=max;
		}

		/**
		*从缓存池中获取一个元素，没有则执行Fun获取
		**/
		__proto.getFromPool=function(Name,__arg){
			var arg=[];for(var i=1,sz=arguments.length;i<sz;i++)arg.push(arguments[i]);
			if(this.Dic[Name]==null){
				return null;
			}
			if(this.Dic[Name].length==0){
				if(this.Dic_Fun[Name]!=null){
					return Tool_Function.onRunFunction.apply(null,[this.Dic_Fun[Name]].concat(arg));
					}else{
					return null;
				}
			}
			return this.Dic[Name].shift();
		}

		/**
		*还回一个
		**/
		__proto.returnToPool=function(Name,one){
			if(this.Dic[Name]==null || this.Dic[Name].length >=this.Dic_Max[Name]){
				one=Tool_ObjUtils.getInstance().destroyF_One(one);
				return;
			}
			this.Dic[Name].push(one);
		}

		/**
		*删除一个缓存池
		**/
		__proto.removeF=function(Name){
			if(this.Dic[Name] !=null){
				Tool_ObjUtils.getInstance().destroyF_One(this.Dic[Name]);
				delete this.Dic[Name];
				if(this.Dic_Fun[Name] && Tool_Function.isTypeOf(this.Dic_Fun[Name],Function)==false){
					this.Dic_Fun[Name].clear();
				}
				delete this.Dic_Fun[Name];
			}
		}

		__proto.destroyF=function(){
			MyPools.instance=null;
			if(this.Dic==null){return;}
				for(var Name in this.Dic){
				this.removeF(Name);
			}
			this.Dic=null;
			this.Dic_Fun=null;
		}

		MyPools.getInstance=function(){
			if(MyPools.instance==null){MyPools.instance=new MyPools();}
				return MyPools.instance;
		}

		MyPools.instance=null
		return MyPools;
	})()


	//class com.MyClass.Tools.MyTween
	var MyTween=(function(){
		function MyTween(mc,fover,val,frun,val2){
			this.role=null;
			this.FunOver=null;
			this.FunVal=null;
			this.FunRun=null;
			this.FunVal2=null;
			this.type=null;
			this.FR=1;
			this.canX=false;
			this.canY=false;
			this.spdXYMax=30;
			this.FirstX=0;
			this.FirstY=0;
			this.spd_x_now=NaN;
			this.spd_y_now=NaN;
			this.endX0=0;
			this.endX1=0;
			this.endY0=0;
			this.endY1=0;
			this.a_X=NaN;
			this.a_Y=NaN;
			this.moreX=0;
			this.moreY=0;
			this.secondLimite=0.5;
			this.secondLimiteBack=0.15;
			this.canOut=false;
			this.spdAlph=NaN;
			this.endAlph=NaN;
			this.spdScal=NaN;
			this.endScal=NaN;
			this.spdRo=0;
			this.endRo=0;
			this.Arr_参数=null;
			this.Arr_参数End=null;
			this.Arr_参数Spd=null;
			this.role=mc;
			this.FunOver=fover;
			if(this.FunOver)this.FunOver.once=true;
			this.FunVal=val;
			this.FunRun=frun;
			if(this.FunRun)this.FunRun.once=false;
			this.FunVal2=val2;
		}

		__class(MyTween,'com.MyClass.Tools.MyTween');
		var __proto=MyTween.prototype;
		__proto.initXYLine=function(spdX0,spdY0,_endX0,_endX1,_endY0,_endY1,cx,cy,canout){
			(canout===void 0)&& (canout=true);
			this.type="xy";
			this.canOut=canout;
			if(spdX0 > this.spdXYMax)spdX0=this.spdXYMax;
			else if(spdX0 <-this.spdXYMax)spdX0=-this.spdXYMax;
			if(spdY0 > this.spdXYMax)spdY0=this.spdXYMax;
			else if(spdY0 <-this.spdXYMax)spdY0=-this.spdXYMax;
			this.spd_x_now=spdX0;this.FirstX=spdX0;
			this.spd_y_now=spdY0;this.FirstY=spdY0;
			this.endX0=_endX0;this.endX1=_endX1;
			this.endY0=_endY0;this.endY1=_endY1;
			if(spdX0 !=0 && Math.abs(spdX0)/ this.FR > this.secondLimite)this.FR=Math.abs(spdX0)/ this.secondLimite;
			if(spdY0 !=0 && Math.abs(spdY0)/ this.FR > this.secondLimite)this.FR=Math.abs(spdY0)/ this.secondLimite;
			this.FR=this.FR / Config.playSpeedTrue;
			this.moreX=0;
			this.moreY=0;
			this.canX=cx;
			if(this.canX==true){
				if(this.spd_x_now > 0)this.a_X=-this.FR;
				else if(this.spd_x_now < 0)this.a_X=this.FR;
				else{
					if(this.role.x > this.endX1){
						this.moreX=this.role.x-this.endX1;
						this.spd_x_now=-this.moreX / (this.secondLimiteBack *Config.playSpeedTrue);
					}
					else if(this.role.x < this.endX0){
						this.moreX=this.role.x-this.endX0;
						this.spd_x_now=-this.moreX / (this.secondLimiteBack *Config.playSpeedTrue);
					}
					else{
						this.stopF();
						return;
					}
				}
			}
			this.canY=cy;
			if(this.canY==true){
				if(this.spd_y_now > 0)this.a_Y=-this.FR;
				else if(this.spd_y_now < 0)this.a_Y=this.FR;
				else{
					if(this.role.y > this.endY1){
						this.moreY=this.role.y-this.endY1;
						this.spd_y_now=-this.moreY / (this.secondLimiteBack *Config.playSpeedTrue);
					}
					else if(this.role.y < this.endY0){
						this.moreY=this.role.y-this.endY0;
						this.spd_y_now=-this.moreY / (this.secondLimiteBack *Config.playSpeedTrue);
					}
					else{
						this.stopF();
						return;
					}
				}
			}
			MainManager.getInstence().MTM.newTween(this.role,this);
		}

		__proto.initMCChange=function(spdx,endx,spdy,endy,spdalph,endalph,_spdScal,_endScal,_spdRo,_endRo){
			(_spdRo===void 0)&& (_spdRo=0);
			(_endRo===void 0)&& (_endRo=0);
			this.type="元件变化";
			this.spd_x_now=spdx;
			this.endX0=endx;
			this.spd_y_now=spdy;
			this.endY0=endy;
			this.spdAlph=spdalph;
			this.endAlph=endalph;
			this.spdScal=_spdScal;
			this.endScal=_endScal;
			this.spdRo=_spdRo;
			this.endRo=_endRo;
			MainManager.getInstence().MTM.newTween(this.role,this);
		}

		__proto.init指定参数Change=function(_参数,_end,_spd){
			this.type="指定参数";
			this.Arr_参数=_参数;
			this.Arr_参数End=_end;
			this.Arr_参数Spd=_spd;
			MainManager.getInstence().MTM.newTween(this.role,this);
		}

		__proto.moveF=function(){
			if(this.role==null)return;
			switch (this.type){
				case "xy":this.xyMove();break ;
				case "元件变化":this.mcChange();break ;
				case "指定参数":this.on指定参数F();break ;
				}
		}

		__proto.xyMove=function(){
			var overx=true;
			var overy=true;
			if(this.canX==true){
				overx=false;
				this.role.x+=this.spd_x_now;
				if(this.moreX !=0){
					if(this.moreX > 0){
						if(this.role.x <=this.endX1){
							this.role.x=this.endX1;
							overx=true;
						}
					}
					else{
						if(this.role.x >=this.endX0){
							this.role.x=this.endX0;
							overx=true;
						}
					}
				}
				else{
					if(this.FirstX > 0){
						if(this.spd_x_now+this.a_X <=0){
							if(this.role.x > this.endX1){
								if(this.canOut){
									this.moreX=this.role.x-this.endX1;
									this.spd_x_now=-this.moreX / (this.secondLimiteBack *Config.playSpeedTrue);
								}
								else{
									this.role.x=this.endX1;overx=true;
								}
							}
							else overx=true;
						}
						else{
							if(this.role.x > this.endX1){
								if(this.canOut)this.spd_x_now+=this.a_X;
								else{
									this.role.x=this.endX1;overx=true;
								}
							}
							this.spd_x_now+=this.a_X;
						}
					}
					else if(this.FirstX < 0){
						if(this.spd_x_now+this.a_X>=0){
							if(this.role.x < this.endX0){
								if(this.canOut){
									this.moreX=this.role.x-this.endX0;
									this.spd_x_now=-this.moreX / (this.secondLimiteBack *Config.playSpeedTrue);
								}
								else{
									this.role.x=this.endX0;overx=true;
								}
							}
							else overx=true;
						}
						else{
							if(this.role.x < this.endX0){
								if(this.canOut)this.spd_x_now+=this.a_X;
								else{
									this.role.x=this.endX0;overx=true;
								}
							}
							this.spd_x_now+=this.a_X;
						}
					}
					else this.spd_x_now+=this.a_X;
				}
				if(overx==true){
					this.canX=false;
				}
			}
			if(this.canY==true){
				overy=false;
				this.role.y+=this.spd_y_now;
				if(this.moreY !=0){
					if(this.moreY > 0){
						if(this.role.y <=this.endY1){
							this.role.y=this.endY1;
							overy=true;
						}
					}
					else{
						if(this.role.y >=this.endY0){
							this.role.y=this.endY0;
							overy=true;
						}
					}
				}
				else{
					if(this.FirstY > 0){
						if(this.spd_y_now+this.a_Y <=0){
							if(this.role.y > this.endY1){
								if(this.canOut){
									this.moreY=this.role.y-this.endY1;
									this.spd_y_now=-this.moreY / (this.secondLimiteBack *Config.playSpeedTrue);
								}
								else{
									this.role.y=this.endY1;overy=true;
								}
							}
							else overy=true;
						}
						else{
							if(this.role.y > this.endY1){
								if(this.canOut)this.spd_y_now+=this.a_Y;
								else{
									this.role.y=this.endY1;overy=true;
								}
							}
							this.spd_y_now+=this.a_Y;
						}
					}
					else if(this.FirstY < 0){
						if(this.spd_y_now+this.a_Y>=0){
							if(this.role.y < this.endY0){
								if(this.canOut){
									this.moreY=this.role.y-this.endY0;
									this.spd_y_now=-this.moreY / (this.secondLimiteBack *Config.playSpeedTrue);
								}
								else{
									this.role.y=this.endY0;overy=true;
								}
							}
							else overy=true;
						}
						else{
							if(this.role.y < this.endY0){
								if(this.canOut)this.spd_y_now+=this.a_Y;
								else{
									this.role.y=this.endY0;overy=true;
								}
							}
							this.spd_y_now+=this.a_Y;
						}
					}
				}
				if(overy==true){
					this.canY=false;
				}
			}
			if(this.FunRun){
				if(this.FunVal2)this.FunRun.runWith(this.FunVal2);
				else this.FunRun.run();
			}
			if(overx==true && overy==true)this.stopF();
		}

		__proto.mcChange=function(){
			var over=true;
			if(this.spd_x_now !=0){
				over=false;
				if(this.spd_x_now > 0 && this.role.x+this.spd_x_now >=this.endX0){
					this.role.x=this.endX0;
					this.spd_x_now=0;
				}
				else if(this.spd_x_now < 0 && this.role.x+this.spd_x_now <=this.endX0){
					this.role.x=this.endX0;
					this.spd_x_now=0;
				}
				else this.role.x+=this.spd_x_now;
			}
			if(this.spd_y_now !=0){
				over=false;
				if(this.spd_y_now > 0 && this.role.y+this.spd_y_now >=this.endY0){
					this.role.y=this.endY0;
					this.spd_y_now=0;
				}
				else if(this.spd_y_now < 0 && this.role.y+this.spd_y_now <=this.endY0){
					this.role.y=this.endY0;
					this.spd_y_now=0;
				}
				else this.role.y+=this.spd_y_now;
			}
			if(this.spdAlph !=0){
				over=false;
				if(this.spdAlph > 0 && this.role.alpha+this.spdAlph >=this.endAlph){
					this.role.alpha=this.endAlph;
					this.spdAlph=0;
				}
				else if(this.spdAlph < 0 && this.role.alpha+this.spdAlph <=this.endAlph){
					this.role.alpha=this.endAlph;
					this.spdAlph=0;
				}
				else this.role.alpha+=this.spdAlph;
			}
			if(this.spdScal !=0){
				over=false;
				if(this.spdScal > 0 && this.role.scaleX+this.spdScal >=this.endScal){
					this.role.scaleX=this.endScal;
					this.role.scaleY=this.endScal;
					this.spdScal=0;
				}
				else if(this.spdScal < 0 && this.role.scaleX+this.spdScal <=this.endScal){
					this.role.scaleX=this.endScal;
					this.role.scaleY=this.endScal;
					this.spdScal=0;
				}
				else{
					this.role.scaleX+=this.spdScal;
					this.role.scaleY+=this.spdScal;
				}
			}
			if(this.spdRo !=0){
				over=false;
				var nowR=starling.utils.rad2deg(this.role.rotation);
				if(this.spdRo > 0 && nowR+this.spdRo >=this.endRo){
					this.role.rotation=starling.utils.deg2rad(this.endRo);
					this.spdRo=0;
				}
				else if(this.spdRo < 0 && nowR+this.spdRo <=this.endRo){
					this.role.rotation=starling.utils.deg2rad(this.endRo);
					this.spdRo=0;
				}
				else{
					this.role.rotation+=starling.utils.deg2rad(this.spdRo);
				}
			}
			if(this.FunRun){
				if(this.FunVal2)this.FunRun.runWith(this.FunVal2);
				else this.FunRun.run();
			}
			if(over==true){
				this.stopF();
			}
		}

		__proto.on指定参数F=function(){
			if(this.Arr_参数.length==0){
				this.stopF();
				return;
			}
			for(var i=0;i<this.Arr_参数.length;i++){
				if(this.Arr_参数Spd[i] > 0){
					if(this.role[this.Arr_参数[i]]+this.Arr_参数Spd[i] >=this.Arr_参数End[i]){
						this.on指定参数_完成一项(i--);
					}
					else this.role[this.Arr_参数[i]]+=this.Arr_参数Spd[i];
				}
				else if(this.Arr_参数Spd[i] < 0){
					if(this.role[this.Arr_参数[i]]+this.Arr_参数Spd[i] <=this.Arr_参数End[i]){
						this.on指定参数_完成一项(i--);
					}
					else this.role[this.Arr_参数[i]]+=this.Arr_参数Spd[i];
				}
				else{
					this.on指定参数_完成一项(i--);
				}
			}
			if(this.FunRun){
				if(this.FunVal2)this.FunRun.runWith(this.FunVal2);
				else this.FunRun.run();
			}
		}

		__proto.on指定参数_完成一项=function(i){
			this.role[this.Arr_参数[i]]=this.Arr_参数End[i];
			this.Arr_参数.splice(i,1);
			this.Arr_参数End.splice(i,1);
			this.Arr_参数Spd.splice(i,1);
		}

		__proto.stopF=function(auto){
			(auto===void 0)&& (auto=false);
			if(this.role==null)return;
			MainManager.getInstence().MTM.newTween(this.role,null);
			MainManager.getInstence().MEM.dispatchF("Tween结束",[this]);
			this.role=null;
			if(this.FunRun){
				this.FunRun.clear();
				this.FunRun=null;
			}
			if(auto==true){
				if(this.FunOver)this.FunOver.clear();
				this.FunOver=null;
				return;
			}
			if(this.FunOver !=null){
				if(this.FunVal==null)this.FunOver.run();
				else this.FunOver.runWith(this.FunVal);
				this.FunOver=null;
				this.FunVal=null;
			}
		}

		return MyTween;
	})()


	//class com.MyClass.Tools.Tool_ArrayUtils
	var Tool_ArrayUtils=(function(){
		function Tool_ArrayUtils(){};
		__class(Tool_ArrayUtils,'com.MyClass.Tools.Tool_ArrayUtils');
		Tool_ArrayUtils.copyArr=function(arr){
			if(arr==null)return null;
			var out=[];
			for(var i=0;i<arr.length;i++){
				out[i]=Tool_ObjUtils.getInstance().CopyF(arr[i]);
			}
			return out;
		}

		Tool_ArrayUtils.copy浅层=function(arr){
			if(arr==null)return null;
			var out=[];
			for(var i=0;i<arr.length;i++){
				out[i]=Tool_ObjUtils.getInstance().CopyF(arr[i],true);
			}
			return out;
		}

		Tool_ArrayUtils.判断相等=function(arr1,arr2){
			if(arr1==null && arr2==null)return true;
			if(arr1==null || arr2==null)return false;
			if(arr1.length !=arr2.length)return false;
			for(var i=0;i<arr1.length;i++){
				if(Tool_ObjUtils.getInstance().判断相等(arr1[i],arr2[i])==false)return false;
			}
			return true;
		}

		Tool_ArrayUtils.on删除重复数字=function(arr){
			var dic={};
			for(var i=0;i<arr.length;i++){
				if((typeof (arr[i])=='number')){
					if(dic[arr[i]]==true)arr.splice(i--,1);
					else dic[arr[i]]=true;
				}
			}
		}

		Tool_ArrayUtils.on随机排序=function(arr){
			var cloneArr=arr.slice();
			arr.length=0;
			var i=cloneArr.length;
			while (i){
				arr.push(cloneArr.splice(Tool_Function.on强制转换(Math.random()*i--),1)[0]);
			}
		}

		Tool_ArrayUtils.on数字从小到大排序=function(a,b){
			if(a < b)return-1;
			else return 1;
		}

		Tool_ArrayUtils.on数字从大到小排序=function(a,b){
			if(a > b)return-1;
			else return 1;
		}

		Tool_ArrayUtils.on查找并删除=function(arr,val){
			if(arr==null)return false;
			var po=arr.indexOf(val);
			if(po==-1)return false;
			arr.splice(po,1);
			return true;
		}

		Tool_ArrayUtils.on按名字排序=function(a,b){
			var charTable=new String("啊阿埃挨哎唉哀皑癌蔼矮艾碍爱隘鞍氨安俺按暗岸胺案肮昂盎凹敖熬翱袄傲奥懊澳芭捌扒叭吧笆八疤巴拔跋靶把耙"+
			"坝霸罢爸白柏百摆佰败拜稗斑班搬扳般颁板版扮拌伴瓣半办绊邦帮梆榜膀绑棒磅蚌镑傍谤苞胞包褒剥薄雹保堡饱宝抱报暴豹鲍爆杯碑悲卑北辈背贝钡"+
			"倍狈备惫焙被奔苯本笨崩绷甭泵蹦迸逼鼻比鄙笔彼碧蓖蔽毕毙毖币庇痹闭敝弊必辟壁臂避陛鞭边编贬扁便变卞辨辩辫遍标彪膘表鳖憋别瘪彬斌濒滨宾摈"+
			"兵冰柄丙秉饼炳病并玻菠播拨钵波博勃搏铂箔伯帛舶脖膊渤泊驳捕卜哺补埠不布步簿部怖擦猜裁材才财睬踩采彩菜蔡餐参蚕残惭惨灿苍舱仓沧藏操糙槽"+
			"曹草厕策侧册测层蹭插叉茬茶查碴搽察岔差诧拆柴豺搀掺蝉馋谗缠铲产阐颤昌猖场尝常长偿肠厂敞畅唱倡超抄钞朝嘲潮巢吵炒车扯撤掣彻澈郴臣辰尘晨忱"+
			"沉陈趁衬撑称城橙成呈乘程惩澄诚承逞骋秤吃痴持匙池迟弛驰耻齿侈尺赤翅斥炽充冲虫崇宠抽酬畴踌稠愁筹仇绸瞅丑臭初出橱厨躇锄雏滁除楚础储矗搐触"+
			"处揣川穿椽传船喘串疮窗幢床闯创吹炊捶锤垂春椿醇唇淳纯蠢戳绰疵茨磁雌辞慈瓷词此刺赐次聪葱囱匆从丛凑粗醋簇促蹿篡窜摧崔催脆瘁粹淬翠村存寸磋"+
			"撮搓措挫错搭达答瘩打大呆歹傣戴带殆代贷袋待逮怠耽担丹单郸掸胆旦氮但惮淡诞弹蛋当挡党荡档刀捣蹈倒岛祷导到稻悼道盗德得的蹬灯登等瞪凳邓堤低"+
			"滴迪敌笛狄涤翟嫡抵底地蒂第帝弟递缔颠掂滇碘点典靛垫电佃甸店惦奠淀殿碉叼雕凋刁掉吊钓调跌爹碟蝶迭谍叠丁盯叮钉顶鼎锭定订丢东冬董懂动栋侗恫"+
			"冻洞兜抖斗陡豆逗痘都督毒犊独读堵睹赌杜镀肚度渡妒端短锻段断缎堆兑队对墩吨蹲敦顿囤钝盾遁掇哆多夺垛躲朵跺舵剁惰堕蛾峨鹅俄额讹娥恶厄扼遏鄂"+
			"饿恩而儿耳尔饵洱二贰发罚筏伐乏阀法珐藩帆番翻樊矾钒繁凡烦反返范贩犯饭泛坊芳方肪房防妨仿访纺放菲非啡飞肥匪诽吠肺废沸费芬酚吩氛分纷坟焚汾"+
			"粉奋份忿愤粪丰封枫蜂峰锋风疯烽逢冯缝讽奉凤佛否夫敷肤孵扶拂辐幅氟符伏俘服浮涪福袱弗甫抚辅俯釜斧脯腑府腐赴副覆赋复傅付阜父腹负富讣附妇缚"+
			"咐噶嘎该改概钙盖溉干甘杆柑竿肝赶感秆敢赣冈刚钢缸肛纲岗港杠篙皋高膏羔糕搞镐稿告哥歌搁戈鸽胳疙割革葛格蛤阁隔铬个各给根跟耕更庚羹埂耿梗工"+
			"攻功恭龚供躬公宫弓巩汞拱贡共钩勾沟苟狗垢构购够辜菇咕箍估沽孤姑鼓古蛊骨谷股故顾固雇刮瓜剐寡挂褂乖拐怪棺关官冠观管馆罐惯灌贯光广逛瑰规圭"+
			"硅归龟闺轨鬼诡癸桂柜跪贵刽辊滚棍锅郭国果裹过哈骸孩海氦亥害骇酣憨邯韩含涵寒函喊罕翰撼捍旱憾悍焊汗汉夯杭航壕嚎豪毫郝好耗号浩呵喝荷菏核禾"+
			"和何合盒貉阂河涸赫褐鹤贺嘿黑痕很狠恨哼亨横衡恒轰哄烘虹鸿洪宏弘红喉侯猴吼厚候后呼乎忽瑚壶葫胡蝴狐糊湖弧虎唬护互沪户花哗华猾滑画划化话槐"+
			"徊怀淮坏欢环桓还缓换患唤痪豢焕涣宦幻荒慌黄磺蝗簧皇凰惶煌晃幌恍谎灰挥辉徽恢蛔回毁悔慧卉惠晦贿秽会烩汇讳诲绘荤昏婚魂浑混豁活伙火获或惑霍"+
			"货祸击圾基机畸稽积箕肌饥迹激讥鸡姬绩缉吉极棘辑籍集及急疾汲即嫉级挤几脊己蓟技冀季伎祭剂悸济寄寂计记既忌际妓继纪嘉枷夹佳家加荚颊贾甲钾假"+
			"稼价架驾嫁歼监坚尖笺间煎兼肩艰奸缄茧检柬碱硷拣捡简俭剪减荐槛鉴践贱见键箭件健舰剑饯渐溅涧建僵姜将浆江疆蒋桨奖讲匠酱降蕉椒礁焦胶交郊浇骄"+
			"娇嚼搅铰矫侥脚狡角饺缴绞剿教酵轿较叫窖揭接皆秸街阶截劫节桔杰捷睫竭洁结解姐戒藉芥界借介疥诫届巾筋斤金今津襟紧锦仅谨进靳晋禁近烬浸尽劲荆"+
			"兢茎睛晶鲸京惊精粳经井警景颈静境敬镜径痉靖竟竞净炯窘揪究纠玖韭久灸九酒厩救旧臼舅咎就疚鞠拘狙疽居驹菊局咀矩举沮聚拒据巨具距踞锯俱句惧炬"+
			"剧捐鹃娟倦眷卷绢撅攫抉掘倔爵觉决诀绝均菌钧军君峻俊竣浚郡骏喀咖卡咯开揩楷凯慨刊堪勘坎砍看康慷糠扛抗亢炕考拷烤靠坷苛柯棵磕颗科壳咳可渴克"+
			"刻客课肯啃垦恳坑吭空恐孔控抠口扣寇枯哭窟苦酷库裤夸垮挎跨胯块筷侩快宽款匡筐狂框矿眶旷况亏盔岿窥葵奎魁傀馈愧溃坤昆捆困括扩廓阔垃拉喇蜡腊"+
			"辣啦莱来赖蓝婪栏拦篮阑兰澜谰揽览懒缆烂滥琅榔狼廊郎朗浪捞劳牢老佬姥酪烙涝勒乐雷镭蕾磊累儡垒擂肋类泪棱楞冷厘梨犁黎篱狸离漓理李里鲤礼莉荔"+
			"吏栗丽厉励砾历利傈例俐痢立粒沥隶力璃哩俩联莲连镰廉怜涟帘敛脸链恋炼练粮凉梁粱良两辆量晾亮谅撩聊僚疗燎寥辽潦了撂镣廖料列裂烈劣猎琳林磷霖"+
			"临邻鳞淋凛赁吝拎玲菱零龄铃伶羚凌灵陵岭领另令溜琉榴硫馏留刘瘤流柳六龙聋咙笼窿隆垄拢陇楼娄搂篓漏陋芦卢颅庐炉掳卤虏鲁麓碌露路赂鹿潞禄录陆"+
			"戮驴吕铝侣旅履屡缕虑氯律率滤绿峦挛孪滦卵乱掠略抡轮伦仑沦纶论萝螺罗逻锣箩骡裸落洛骆络妈麻玛码蚂马骂嘛吗埋买麦卖迈脉瞒馒蛮满蔓曼慢漫谩芒"+
			"茫盲氓忙莽猫茅锚毛矛铆卯茂冒帽貌贸么玫枚梅酶霉煤没眉媒镁每美昧寐妹媚门闷们萌蒙檬盟锰猛梦孟眯醚靡糜迷谜弥米秘觅泌蜜密幂棉眠绵冕免勉娩缅"+
			"面苗描瞄藐秒渺庙妙蔑灭民抿皿敏悯闽明螟鸣铭名命谬摸摹蘑模膜磨摩魔抹末莫墨默沫漠寞陌谋牟某拇牡亩姆母墓暮幕募慕木目睦牧穆拿哪呐钠那娜纳氖"+
			"乃奶耐奈南男难囊挠脑恼闹淖呢馁内嫩能妮霓倪泥尼拟你匿腻逆溺蔫拈年碾撵捻念娘酿鸟尿捏聂孽啮镊镍涅您柠狞凝宁拧泞牛扭钮纽脓浓农弄奴努怒女暖"+
			"虐疟挪懦糯诺哦欧鸥殴藕呕偶沤啪趴爬帕怕琶拍排牌徘湃派攀潘盘磐盼畔判叛乓庞旁耪胖抛咆刨炮袍跑泡呸胚培裴赔陪配佩沛喷盆砰抨烹澎彭蓬棚硼篷膨"+
			"朋鹏捧碰坯砒霹批披劈琵毗啤脾疲皮匹痞僻屁譬篇偏片骗飘漂瓢票撇瞥拼频贫品聘乒坪苹萍平凭瓶评屏坡泼颇婆破魄迫粕剖扑铺仆莆葡菩蒲埔朴圃普浦谱"+
			"曝瀑期欺栖戚妻七凄漆柒沏其棋奇歧畦崎脐齐旗祈祁骑起岂乞企启契砌器气迄弃汽泣讫掐恰洽牵扦钎铅千迁签仟谦乾黔钱钳前潜遣浅谴堑嵌欠歉枪呛腔羌"+
			"墙蔷强抢橇锹敲悄桥瞧乔侨巧鞘撬翘峭俏窍切茄且怯窃钦侵亲秦琴勤芹擒禽寝沁青轻氢倾卿清擎晴氰情顷请庆琼穷秋丘邱球求囚酋泅趋区蛆曲躯屈驱渠取"+
			"娶龋趣去圈颧权醛泉全痊拳犬券劝缺炔瘸却鹊榷确雀裙群然燃冉染瓤壤攘嚷让饶扰绕惹热壬仁人忍韧任认刃妊纫扔仍日戎茸蓉荣融熔溶容绒冗揉柔肉茹蠕"+
			"儒孺如辱乳汝入褥软阮蕊瑞锐闰润若弱撒洒萨腮鳃塞赛三叁伞散桑嗓丧搔骚扫嫂瑟色涩森僧莎砂杀刹沙纱傻啥煞筛晒珊苫杉山删煽衫闪陕擅赡膳善汕扇缮"+
			"墒伤商赏晌上尚裳梢捎稍烧芍勺韶少哨邵绍奢赊蛇舌舍赦摄射慑涉社设砷申呻伸身深娠绅神沈审婶甚肾慎渗声生甥牲升绳省盛剩胜圣师失狮施湿诗尸虱十"+
			"石拾时什食蚀实识史矢使屎驶始式示士世柿事拭誓逝势是嗜噬适仕侍释饰氏市恃室视试收手首守寿授售受瘦兽蔬枢梳殊抒输叔舒淑疏书赎孰熟薯暑曙署蜀"+
			"黍鼠属术述树束戍竖墅庶数漱恕刷耍摔衰甩帅栓拴霜双爽谁水睡税吮瞬顺舜说硕朔烁斯撕嘶思私司丝死肆寺嗣四伺似饲巳松耸怂颂送宋讼诵搜艘擞嗽苏酥"+
			"俗素速粟僳塑溯宿诉肃酸蒜算虽隋随绥髓碎岁穗遂隧祟孙损笋蓑梭唆缩琐索锁所塌他它她塔獭挞蹋踏胎苔抬台泰酞太态汰坍摊贪瘫滩坛檀痰潭谭谈坦毯袒"+
			"碳探叹炭汤塘搪堂棠膛唐糖倘躺淌趟烫掏涛滔绦萄桃逃淘陶讨套特藤腾疼誊梯剔踢锑提题蹄啼体替嚏惕涕剃屉天添填田甜恬舔腆挑条迢眺跳贴铁帖厅听烃"+
			"汀廷停亭庭挺艇通桐酮瞳同铜彤童桶捅筒统痛偷投头透凸秃突图徒途涂屠土吐兔湍团推颓腿蜕褪退吞屯臀拖托脱鸵陀驮驼椭妥拓唾挖哇蛙洼娃瓦袜歪外豌"+
			"弯湾玩顽丸烷完碗挽晚皖惋宛婉万腕汪王亡枉网往旺望忘妄威巍微危韦违桅围唯惟为潍维苇萎委伟伪尾纬未蔚味畏胃喂魏位渭谓尉慰卫瘟温蚊文闻纹吻稳"+
			"紊问嗡翁瓮挝蜗涡窝我斡卧握沃巫呜钨乌污诬屋无芜梧吾吴毋武五捂午舞伍侮坞戊雾晤物勿务悟误昔熙析西硒矽晰嘻吸锡牺稀息希悉膝夕惜熄烯溪汐犀檄"+
			"袭席习媳喜铣洗系隙戏细瞎虾匣霞辖暇峡侠狭下厦夏吓掀锨先仙鲜纤咸贤衔舷闲涎弦嫌显险现献县腺馅羡宪陷限线相厢镶香箱襄湘乡翔祥详想响享项巷橡"+
			"像向象萧硝霄削哮嚣销消宵淆晓小孝校肖啸笑效楔些歇蝎鞋协挟携邪斜胁谐写械卸蟹懈泄泻谢屑薪芯锌欣辛新忻心信衅星腥猩惺兴刑型形邢行醒幸杏性姓"+
			"兄凶胸匈汹雄熊休修羞朽嗅锈秀袖绣墟戌需虚嘘须徐许蓄酗叙旭序畜恤絮婿绪续轩喧宣悬旋玄选癣眩绚靴薛学穴雪血勋熏循旬询寻驯巡殉汛训讯逊迅压押"+
			"鸦鸭呀丫芽牙蚜崖衙涯雅哑亚讶焉咽阉烟淹盐严研蜒岩延言颜阎炎沿奄掩眼衍演艳堰燕厌砚雁唁彦焰宴谚验殃央鸯秧杨扬佯疡羊洋阳氧仰痒养样漾邀腰妖"+
			"瑶摇尧遥窑谣姚咬舀药要耀椰噎耶爷野冶也页掖业叶曳腋夜液一壹医揖铱依伊衣颐夷遗移仪胰疑沂宜姨彝椅蚁倚已乙矣以艺抑易邑屹亿役臆逸肄疫亦裔意"+
			"毅忆义益溢诣议谊译异翼翌绎茵荫因殷音阴姻吟银淫寅饮尹引隐印英樱婴鹰应缨莹萤营荧蝇迎赢盈影颖硬映哟拥佣臃痈庸雍踊蛹咏泳涌永恿勇用幽优悠忧"+
			"尤由邮铀犹油游酉有友右佑釉诱又幼迂淤于盂榆虞愚舆余俞逾鱼愉渝渔隅予娱雨与屿禹宇语羽玉域芋郁吁遇喻峪御愈欲狱育誉浴寓裕预豫驭鸳渊冤元垣袁"+
			"原援辕园员圆猿源缘远苑愿怨院曰约越跃钥岳粤月悦阅耘云郧匀陨允运蕴酝晕韵孕匝砸杂栽哉灾宰载再在咱攒暂赞赃脏葬遭糟凿藻枣早澡蚤躁噪造皂灶燥"+
			"责择则泽贼怎增憎曾赠扎喳渣札轧铡闸眨栅榨咋乍炸诈摘斋宅窄债寨瞻毡詹粘沾盏斩辗崭展蘸栈占战站湛绽樟章彰漳张掌涨杖丈帐账仗胀瘴障招昭找沼赵"+
			"照罩兆肇召遮折哲蛰辙者锗蔗这浙珍斟真甄砧臻贞针侦枕疹诊震振镇阵蒸挣睁征狰争怔整拯正政帧症郑证芝枝支吱蜘知肢脂汁之织职直植殖执值侄址指止"+
			"趾只旨纸志挚掷至致置帜峙制智秩稚质炙痔滞治窒中盅忠钟衷终种肿重仲众舟周州洲诌粥轴肘帚咒皱宙昼骤珠株蛛朱猪诸诛逐竹烛煮拄瞩嘱主著柱助蛀贮"+
			"铸筑住注祝驻抓爪拽专砖转撰赚篆桩庄装妆撞壮状椎锥追赘坠缀谆准捉拙卓桌琢茁酌啄着灼浊兹咨资姿滋淄孜紫仔籽滓子自渍字鬃棕踪宗综总纵邹走奏揍"+
			"租足卒族祖诅阻组钻纂嘴醉最罪尊遵昨左佐柞做作坐座亍丌兀丐廿卅丕亘丞鬲孬噩丨禺丿匕乇夭爻卮氐囟胤馗毓睾鼗丶亟鼐乜乩亓芈孛啬嘏仄"+
			"厍厝厣厥厮靥赝匚叵匦匮匾赜卦卣刂刈刎刭刳刿剀剌剞剡剜蒯剽劂劁劐劓冂罔亻仃仉仂仨仡仫仞伛仳伢佤仵伥伧伉伫佞佧攸佚佝佟佗伲伽佶佴侑侉侃侏佾"+
			"佻侪佼侬侔俦俨俪俅俚俣俜俑俟俸倩偌俳倬倏倮倭俾倜倌倥倨偾偃偕偈偎偬偻傥傧傩傺僖儆僭僬僦僮儇儋仝氽佘佥俎龠汆籴兮巽黉馘冁夔勹匍訇匐凫夙兕"+
			"亠兖亳衮袤亵脔裒禀嬴蠃羸冫冱冽冼凇冖冢冥讠讦讧讪讴讵讷诂诃诋诏诎诒诓诔诖诘诙诜诟诠诤诨诩诮诰诳诶诹诼诿谀谂谄谇谌谏谑谒谔谕谖谙谛谘谝谟"+
			"谠谡谥谧谪谫谮谯谲谳谵谶卩卺阝阢阡阱阪阽阼陂陉陔陟陧陬陲陴隈隍隗隰邗邛邝邙邬邡邴邳邶邺邸邰郏郅邾郐郄郇郓郦郢郜郗郛郫郯郾鄄鄢鄞鄣鄱鄯鄹"+
			"酃酆刍奂劢劬劭劾哿勐勖勰叟燮矍廴凵凼鬯厶弁畚巯坌垩垡塾墼壅壑圩圬圪圳圹圮圯坜圻坂坩垅坫垆坼坻坨坭坶坳垭垤垌垲埏垧垴垓垠埕埘埚埙埒垸埴埯"+
			"埸埤埝堋堍埽埭堀堞堙塄堠塥塬墁墉墚墀馨鼙懿艹艽艿芏芊芨芄芎芑芗芙芫芸芾芰苈苊苣芘芷芮苋苌苁芩芴芡芪芟苄苎芤苡茉苷苤茏茇苜苴苒苘茌苻苓茑"+
			"茚茆茔茕苠苕茜荑荛荜茈莒茼茴茱莛荞茯荏荇荃荟荀茗荠茭茺茳荦荥荨茛荩荬荪荭荮莰荸莳莴莠莪莓莜莅荼莶莩荽莸荻莘莞莨莺莼菁萁菥菘堇萘萋菝菽菖"+
			"萜萸萑萆菔菟萏萃菸菹菪菅菀萦菰菡葜葑葚葙葳蒇蒈葺蒉葸萼葆葩葶蒌蒎萱葭蓁蓍蓐蓦蒽蓓蓊蒿蒺蓠蒡蒹蒴蒗蓥蓣蔌甍蔸蓰蔹蔟蔺蕖蔻蓿蓼蕙蕈蕨蕤蕞蕺"+
			"瞢蕃蕲蕻薤薨薇薏蕹薮薜薅薹薷薰藓藁藜藿蘧蘅蘩蘖蘼廾弈夼奁耷奕奚奘匏尢尥尬尴扌扪抟抻拊拚拗拮挢拶挹捋捃掭揶捱捺掎掴捭掬掊捩掮掼揲揸揠揿揄"+
			"揞揎摒揆掾摅摁搋搛搠搌搦搡摞撄摭撖摺撷撸撙撺擀擐擗擤擢攉攥攮弋忒甙弑卟叱叽叩叨叻吒吖吆呋呒呓呔呖呃吡呗呙吣吲咂咔呷呱呤咚咛咄呶呦咝哐咭"+
			"哂咴哒咧咦哓哔呲咣哕咻咿哌哙哚哜咩咪咤哝哏哞唛哧唠哽唔哳唢唣唏唑唧唪啧喏喵啉啭啁啕唿啐唼唷啖啵啶啷唳唰啜喋嗒喃喱喹喈喁喟啾嗖喑啻嗟喽喾"+
			"喔喙嗪嗷嗉嘟嗑嗫嗬嗔嗦嗝嗄嗯嗥嗲嗳嗌嗍嗨嗵嗤辔嘞嘈嘌嘁嘤嘣嗾嘀嘧嘭噘嘹噗嘬噍噢噙噜噌噔嚆噤噱噫噻噼嚅嚓嚯囔囗囝囡囵囫囹囿圄圊圉圜帏帙帔"+
			"帑帱帻帼帷幄幔幛幞幡岌屺岍岐岖岈岘岙岑岚岜岵岢岽岬岫岱岣峁岷峄峒峤峋峥崂崃崧崦崮崤崞崆崛嵘崾崴崽嵬嵛嵯嵝嵫嵋嵊嵩嵴嶂嶙嶝豳嶷巅彳彷徂徇"+
			"徉後徕徙徜徨徭徵徼衢彡犭犰犴犷犸狃狁狎狍狒狨狯狩狲狴狷猁狳猃狺狻猗猓猡猊猞猝猕猢猹猥猬猸猱獐獍獗獠獬獯獾舛夥飧夤夂饣饧饨饩饪饫饬饴饷饽"+
			"馀馄馇馊馍馐馑馓馔馕庀庑庋庖庥庠庹庵庾庳赓廒廑廛廨廪膺忄忉忖忏怃忮怄忡忤忾怅怆忪忭忸怙怵怦怛怏怍怩怫怊怿怡恸恹恻恺恂恪恽悖悚悭悝悃悒悌"+
			"悛惬悻悱惝惘惆惚悴愠愦愕愣惴愀愎愫慊慵憬憔憧憷懔懵忝隳闩闫闱闳闵闶闼闾阃阄阆阈阊阋阌阍阏阒阕阖阗阙阚丬爿戕氵汔汜汊沣沅沐沔沌汨汩汴汶沆"+
			"沩泐泔沭泷泸泱泗沲泠泖泺泫泮沱泓泯泾洹洧洌浃浈洇洄洙洎洫浍洮洵洚浏浒浔洳涑浯涞涠浞涓涔浜浠浼浣渚淇淅淞渎涿淠渑淦淝淙渖涫渌涮渫湮湎湫溲"+
			"湟溆湓湔渲渥湄滟溱溘滠漭滢溥溧溽溻溷滗溴滏溏滂溟潢潆潇漤漕滹漯漶潋潴漪漉漩澉澍澌潸潲潼潺濑濉澧澹澶濂濡濮濞濠濯瀚瀣瀛瀹瀵灏灞宀宄宕宓宥"+
			"宸甯骞搴寤寮褰寰蹇謇辶迓迕迥迮迤迩迦迳迨逅逄逋逦逑逍逖逡逵逶逭逯遄遑遒遐遨遘遢遛暹遴遽邂邈邃邋彐彗彖彘尻咫屐屙孱屣屦羼弪弩弭艴弼鬻屮妁"+
			"妃妍妩妪妣妗姊妫妞妤姒妲妯姗妾娅娆姝娈姣姘姹娌娉娲娴娑娣娓婀婧婊婕娼婢婵胬媪媛婷婺媾嫫媲嫒嫔媸嫠嫣嫱嫖嫦嫘嫜嬉嬗嬖嬲嬷孀尕尜孚孥孳孑孓"+
			"孢驵驷驸驺驿驽骀骁骅骈骊骐骒骓骖骘骛骜骝骟骠骢骣骥骧纟纡纣纥纨纩纭纰纾绀绁绂绉绋绌绐绔绗绛绠绡绨绫绮绯绱绲缍绶绺绻绾缁缂缃缇缈缋缌缏缑"+
			"缒缗缙缜缛缟缡缢缣缤缥缦缧缪缫缬缭缯缰缱缲缳缵幺畿巛甾邕玎玑玮玢玟珏珂珑玷玳珀珉珈珥珙顼琊珩珧珞玺珲琏琪瑛琦琥琨琰琮琬琛琚瑁瑜瑗瑕瑙瑷"+
			"瑭瑾璜璎璀璁璇璋璞璨璩璐璧瓒璺韪韫韬杌杓杞杈杩枥枇杪杳枘枧杵枨枞枭枋杷杼柰栉柘栊柩枰栌柙枵柚枳柝栀柃枸柢栎柁柽栲栳桠桡桎桢桄桤梃栝桕桦"+
			"桁桧桀栾桊桉栩梵梏桴桷梓桫棂楮棼椟椠棹椤棰椋椁楗棣椐楱椹楠楂楝榄楫榀榘楸椴槌榇榈槎榉楦楣楹榛榧榻榫榭槔榱槁槊槟榕槠榍槿樯槭樗樘橥槲橄樾"+
			"檠橐橛樵檎橹樽樨橘橼檑檐檩檗檫猷獒殁殂殇殄殒殓殍殚殛殡殪轫轭轱轲轳轵轶轸轷轹轺轼轾辁辂辄辇辋辍辎辏辘辚軎戋戗戛戟戢戡戥戤戬臧瓯瓴瓿甏甑"+
			"甓攴旮旯旰昊昙杲昃昕昀炅曷昝昴昱昶昵耆晟晔晁晏晖晡晗晷暄暌暧暝暾曛曜曦曩贲贳贶贻贽赀赅赆赈赉赇赍赕赙觇觊觋觌觎觏觐觑牮犟牝牦牯牾牿犄犋"+
			"犍犏犒挈挲掰搿擘耄毪毳毽毵毹氅氇氆氍氕氘氙氚氡氩氤氪氲攵敕敫牍牒牖爰虢刖肟肜肓肼朊肽肱肫肭肴肷胧胨胩胪胛胂胄胙胍胗朐胝胫胱胴胭脍脎胲胼"+
			"朕脒豚脶脞脬脘脲腈腌腓腴腙腚腱腠腩腼腽腭腧塍媵膈膂膑滕膣膪臌朦臊膻臁膦欤欷欹歃歆歙飑飒飓飕飙飚殳彀毂觳斐齑斓於旆旄旃旌旎旒旖炀炜炖炝炻"+
			"烀炷炫炱烨烊焐焓焖焯焱煳煜煨煅煲煊煸煺熘熳熵熨熠燠燔燧燹爝爨灬焘煦熹戾戽扃扈扉礻祀祆祉祛祜祓祚祢祗祠祯祧祺禅禊禚禧禳忑忐怼恝恚恧恁恙恣"+
			"悫愆愍慝憩憝懋懑戆肀聿沓泶淼矶矸砀砉砗砘砑斫砭砜砝砹砺砻砟砼砥砬砣砩硎硭硖硗砦硐硇硌硪碛碓碚碇碜碡碣碲碹碥磔磙磉磬磲礅磴礓礤礞礴龛黹黻"+
			"黼盱眄眍盹眇眈眚眢眙眭眦眵眸睐睑睇睃睚睨睢睥睿瞍睽瞀瞌瞑瞟瞠瞰瞵瞽町畀畎畋畈畛畲畹疃罘罡罟詈罨罴罱罹羁罾盍盥蠲钅钆钇钋钊钌钍钏钐钔钗钕"+
			"钚钛钜钣钤钫钪钭钬钯钰钲钴钶钷钸钹钺钼钽钿铄铈铉铊铋铌铍铎铐铑铒铕铖铗铙铘铛铞铟铠铢铤铥铧铨铪铩铫铮铯铳铴铵铷铹铼铽铿锃锂锆锇锉锊锍锎"+
			"锏锒锓锔锕锖锘锛锝锞锟锢锪锫锩锬锱锲锴锶锷锸锼锾锿镂锵镄镅镆镉镌镎镏镒镓镔镖镗镘镙镛镞镟镝镡镢镤镥镦镧镨镩镪镫镬镯镱镲镳锺矧矬雉秕秭秣"+
			"秫稆嵇稃稂稞稔稹稷穑黏馥穰皈皎皓皙皤瓞瓠甬鸠鸢鸨鸩鸪鸫鸬鸲鸱鸶鸸鸷鸹鸺鸾鹁鹂鹄鹆鹇鹈鹉鹋鹌鹎鹑鹕鹗鹚鹛鹜鹞鹣鹦鹧鹨鹩鹪鹫鹬鹱鹭鹳疒疔疖"+
			"疠疝疬疣疳疴疸痄疱疰痃痂痖痍痣痨痦痤痫痧瘃痱痼痿瘐瘀瘅瘌瘗瘊瘥瘘瘕瘙瘛瘼瘢瘠癀瘭瘰瘿瘵癃瘾瘳癍癞癔癜癖癫癯翊竦穸穹窀窆窈窕窦窠窬窨窭窳"+
			"衤衩衲衽衿袂袢裆袷袼裉裢裎裣裥裱褚裼裨裾裰褡褙褓褛褊褴褫褶襁襦襻疋胥皲皴矜耒耔耖耜耠耢耥耦耧耩耨耱耋耵聃聆聍聒聩聱覃顸颀颃颉颌颍颏颔颚"+
			"颛颞颟颡颢颥颦虍虔虬虮虿虺虼虻蚨蚍蚋蚬蚝蚧蚣蚪蚓蚩蚶蛄蚵蛎蚰蚺蚱蚯蛉蛏蚴蛩蛱蛲蛭蛳蛐蜓蛞蛴蛟蛘蛑蜃蜇蛸蜈蜊蜍蜉蜣蜻蜞蜥蜮蜚蜾蝈蜴蜱蜩蜷"+
			"蜿螂蜢蝽蝾蝻蝠蝰蝌蝮螋蝓蝣蝼蝤蝙蝥螓螯螨蟒蟆螈螅螭螗螃螫蟥螬螵螳蟋蟓螽蟑蟀蟊蟛蟪蟠蟮蠖蠓蟾蠊蠛蠡蠹蠼缶罂罄罅舐竺竽笈笃笄笕笊笫笏筇笸笪"+
			"笙笮笱笠笥笤笳笾笞筘筚筅筵筌筝筠筮筻筢筲筱箐箦箧箸箬箝箨箅箪箜箢箫箴篑篁篌篝篚篥篦篪簌篾篼簏簖簋簟簪簦簸籁籀臾舁舂舄臬衄舡舢舣舭舯舨舫"+
			"舸舻舳舴舾艄艉艋艏艚艟艨衾袅袈裘裟襞羝羟羧羯羰羲籼敉粑粝粜粞粢粲粼粽糁糇糌糍糈糅糗糨艮暨羿翎翕翥翡翦翩翮翳糸絷綦綮繇纛麸麴赳趄趔趑趱赧"+
			"赭豇豉酊酐酎酏酤酢酡酰酩酯酽酾酲酴酹醌醅醐醍醑醢醣醪醭醮醯醵醴醺豕鹾趸跫踅蹙蹩趵趿趼趺跄跖跗跚跞跎跏跛跆跬跷跸跣跹跻跤踉跽踔踝踟踬踮踣"+
			"踯踺蹀踹踵踽踱蹉蹁蹂蹑蹒蹊蹰蹶蹼蹯蹴躅躏躔躐躜躞豸貂貊貅貘貔斛觖觞觚觜觥觫觯訾謦靓雩雳雯霆霁霈霏霎霪霭霰霾龀龃龅龆龇龈龉龊龌黾鼋鼍隹隼"+
			"隽雎雒瞿雠銎銮鋈錾鍪鏊鎏鐾鑫鱿鲂鲅鲆鲇鲈稣鲋鲎鲐鲑鲒鲔鲕鲚鲛鲞鲟鲠鲡鲢鲣鲥鲦鲧鲨鲩鲫鲭鲮鲰鲱鲲鲳鲴鲵鲶鲷鲺鲻鲼鲽鳄鳅鳆鳇鳊鳋鳌鳍鳎鳏鳐"+
			"鳓鳔鳕鳗鳘鳙鳜鳝鳟鳢靼鞅鞑鞒鞔鞯鞫鞣鞲鞴骱骰骷鹘骶骺骼髁髀髅髂髋髌髑魅魃魇魉魈魍魑飨餍餮饕饔髟髡髦髯髫髻髭髹鬈鬏鬓鬟鬣麽麾縻麂麇麈麋麒"+
			"鏖麝麟黛黜黝黠黟黢黩黧黥黪黯鼢鼬鼯鼹鼷鼽鼾齄");
			var aLength=0,bLength=0,minLength=0,aIndex=0,bIndex=0;
			aLength=a.length;
			bLength=b.length;
			minLength=Math.min(aLength,bLength);
			for (var i=0;i<minLength;i++){
				aIndex=charTable.indexOf(a.substr(i,1));
				bIndex=charTable.indexOf(b.substr(i,1));
				if (aIndex<bIndex)return-1;
				else if (aIndex>bIndex)return 1;
				else if (aIndex==bIndex&&aIndex==-1&&a.substr(i,1)!=b.substr(i,1)){
					if(a < b)return-1;
					else return 1;
				}
			}
			if (aLength<bLength)return-1;
			else if (aLength==bLength)return 0;
			else return 1;
		}

		return Tool_ArrayUtils;
	})()


	//class com.MyClass.Tools.Tool_DictionUtils
	var Tool_DictionUtils=(function(){
		function Tool_DictionUtils(){};
		__class(Tool_DictionUtils,'com.MyClass.Tools.Tool_DictionUtils');
		Tool_DictionUtils.生成Dic_FromObj=function(obj){
			var dic=new Dictionary();
			Tool_DictionUtils.on遍历Dic(obj,function(key,val){
				dic.set(key,val);
			});
			return dic;
		}

		Tool_DictionUtils.copyDic=function(dic){
			if(dic==null)return null;
			var out=new Dictionary();
			for(var i=0;i<dic.keys.length;i++){
				var m=Tool_ObjUtils.getInstance().CopyF(dic.keys[i]);
				out.set(m,Tool_ObjUtils.getInstance().CopyF(dic.get(dic.keys[i])));
			}
			return out;
		}

		Tool_DictionUtils.copy浅层=function(dic){
			if(dic==null)return null;
			var out=new Dictionary();
			for(var i=0;i<dic.keys.length;i++){
				var m=dic.keys[i];
				out.set(m,Tool_ObjUtils.getInstance().CopyF(dic.get(dic.keys[i]),true));
			}
			return out;
		}

		Tool_DictionUtils.判断相等=function(dic1,dic2){
			var dicHave=new Dictionary();
			for(var n in dic1){
				dicHave[n]=true;
				if(Tool_ObjUtils.getInstance().判断相等(dic1[n],dic2[n])==false)return false;
			}
			for(n in dic2){
				if(dicHave[n]==true)continue ;
				return false;
			}
			return true;
		}

		Tool_DictionUtils.getKey排序=function(dic){
			var arrKey=[];
			for(var key in dic){
				arrKey.push(key);
			}
			arrKey.sort(Tool_ArrayUtils.on按名字排序);
			return arrKey;
		}

		Tool_DictionUtils.on遍历Dic=function(dic,f){
			if((dic instanceof Dictionary)){
				for(var i=0;i<dic.keys.length;i++){
					var key=dic.keys[i];
					var tar=dic.get(key);
					f(key,tar);
				}
				}else{
				for(key in dic){
					f(key,dic[key]);
				}
			}
		}

		return Tool_DictionUtils;
	})()


	//class com.MyClass.Tools.Tool_Function
	var Tool_Function=(function(){
		function Tool_Function(){};
		__class(Tool_Function,'com.MyClass.Tools.Tool_Function');
		Tool_Function.onNewClass=function(cl,__arg){
			var arg=[];for(var i=1,sz=arguments.length;i<sz;i++)arg.push(arguments[i]);
			var tar=Tool_Function.onNewClass_NoVer(cl,arg);
			return tar;
		}

		Tool_Function.onNewClass_NoVer=function(cl,arg){
			var c=cl;
			if(c==null)return null;
			var tar;
			try{
				if(arg==null || arg.length==0)tar=new c();
				else if(arg.length==1)tar=new c(arg[0]);
				else if(arg.length==2)tar=new c(arg[0],arg[1]);
				else if(arg.length==3)tar=new c(arg[0],arg[1],arg[2]);
				else if(arg.length==4)tar=new c(arg[0],arg[1],arg[2],arg[3]);
				else if(arg.length==5)tar=new c(arg[0],arg[1],arg[2],arg[3],arg[4]);
				}catch(e){
				Config.Log("初始化【"+cl+"】类失败！"+e.message);
			}
			return tar;
		}

		Tool_Function.addChildF=function(_parent,_child){
			if(_parent==null || _child==null){
				return;
			}
			_parent.addChild(_child);
		}

		Tool_Function.onRotationF=function(tar,ang,type){
			(type===void 0)&& (type="deg");
			if(tar!=null){
				if(type!="deg"){
					ang=starling.utils.rad2deg(ang);
				}
				tar.rotation=ang;
			}
		}

		Tool_Function.onRunFunction=function(f,__arg){
			var arg=[];for(var i=1,sz=arguments.length;i<sz;i++)arg.push(arguments[i]);
			if(f==null)return;
			if((typeof f=='function')){
				return (f).apply(null,arg);
				}else{
				return f.runWith(arg);
			}
		}

		Tool_Function.onTouchable=function(tar){
			tar.mouseEnabled=true;
			var num=0;
			try{
				num=tar.numChildren;
				}catch(e){
				return;
			}
			for(var i=0;i<num;i++){
				var child=tar.getChildAt(i);
				Tool_Function.onTouchable(child);
			}
		}

		Tool_Function.onGloableToLocal=function(tar,gp,outp){
			if(outp==null){
				outp=tar.globalToLocal(gp,true);
				}else{
				tar.globalToLocal(gp,false);
				outp=gp;
			}
			return outp;
		}

		Tool_Function.onTryError=function(fTry,args,fError){
			try{
				fTry.apply(null,args);
				}catch(e){
				fError();
			}
		}

		Tool_Function.Bind=function(context,f){
			return f;
		}

		Tool_Function.getDefinationByName=function(strName,context){
			var c;
			return c;
		}

		Tool_Function.isTypeOf=function(obj,type){
			if(obj==null)return false;
			return Laya.__typeof(obj,type);
		}

		Tool_Function.on强制转换=function(tar,type){
			(type===void 0)&& (type="int");
			if(type=="int")return parseInt(tar+"");
			if(type=="str")return tar+""
			if(type=="num")return Number(tar);
			return tar;
		}

		Tool_Function.on修改属性ByDic=function(tar,dic){
			if(tar==null || dic==null){
				return;
			}
			for(var key in dic){
				try{
					tar[key]=dic[key];
					}catch (e){
					if(Tool_ObjUtils.getInstance().hasFunction(tar,"setValue")==false){
						Config.Log(tar,"执行【on修改属性ByDic】出错："+key);
						}else{
						try {
							tar.setValue(key,dic[key]);
							}catch (e){
							Config.Log(tar,"执行【on修改属性ByDic】出错："+key);
						}
					}
				}
			}
		}

		Tool_Function.onColor_计算反色=function(col){
			var r=255-Tool_Function.onColor_getRed(col);
			var g=255-Tool_Function.onColor_getGreen(col);
			var b=255-Tool_Function.onColor_getBlue(col);
			col=Tool_Function.onColor_argb(1,r,g,b);
			return col;
		}

		Tool_Function.onColor_getRed=function(color){return (color >> 16)& 0xff;}
		Tool_Function.onColor_getGreen=function(color){return (color >> 8)& 0xff;}
		Tool_Function.onColor_getBlue=function(color){return color & 0xff;}
		Tool_Function.onColor_rgb=function(red,green,blue){
			return (red << 16)| (green << 8)| blue;
		}

		Tool_Function.onColor_argb=function(alpha,red,green,blue){
			return (alpha << 24)| (red << 16)| (green << 8)| blue;
		}

		Tool_Function.on点IN线段=function(lx1,ly1,lx2,ly2,px,py){
			if(px<lx1 && px<lx2)return false;
			if(px>lx1 && px>lx2)return false;
			if(py<ly1 && px<ly2)return false;
			if(py>ly1 && px>ly2)return false;
			return (lx1-lx2)*(py-ly2)==(px-lx2)*(ly1-ly2);
		}

		Tool_Function.on线段碰撞=function(l1p1x,l1p1y,l1p2x,l1p2y,l2p1x,l2p1y,l2p2x,l2p2y){
			var line1p1=NaN;
			line1p1=(l1p2x-l1p1x)*(l2p1y-l1p1y)-(l2p1x-l1p1x)*(l1p2y-l1p1y);
			var line1p2=NaN;
			line1p2=(l1p2x-l1p1x)*(l2p2y-l1p1y)-(l2p2x-l1p1x)*(l1p2y-l1p1y);
			var line2p1=NaN;
			line2p1=(l2p2x-l2p1x)*(l1p1y-l2p1y)-(l1p1x-l2p1x)*(l2p2y-l2p1y);
			var line2p2=NaN;
			line2p2=(l2p2x-l2p1x)*(l1p2y-l2p1y)-(l1p2x-l2p1x)*(l2p2y-l2p1y);
			if ((line1p1*line1p2<=0)&&(line2p1*line2p2<=0)){
				return true;
				}else {
				return false;
			}
		}

		Tool_Function.on点IN多边形=function(vertexList,p,px,py){
			(px===void 0)&& (px=NaN);
			(py===void 0)&& (py=NaN);
			if (vertexList==null)return false;
			if (!p){
				if (!isNaN(px)&& !isNaN(py))p=new Point(px,py);
				else return false;
			}
			if (px < 0 || py < 0)return false;
			var n=vertexList.length;
			var i=0;
			var p1;
			var p2;
			var counter=0;
			var xinters=0;
			p1=vertexList[0];
			for (i=1;i <=n;i++){
				p2=vertexList[i % n];
				if (p.y > Math.min(p1.y,p2.y)){
					if (p.y <=Math.max(p1.y,p2.y)){
						if (p.x <=Math.max(p1.x,p2.x)){
							if (p1.y !=p2.y){
								xinters=(p.y-p1.y)*(p2.x-p1.x)/ (p2.y-p1.y)+p1.x;
								if (p1.x==p2.x || p.x <=xinters)counter++;
							}
						}
					}
				}
				p1=p2;
			}
			return counter % 2 !=0;
		}

		Tool_Function.on适配区域=function(tar){
			if(Config.适配方式!=2){
				console.log("不需要适配");
				return;
			};
			var info适配;
			var i=0;
			var child;
			var dicNo={};
			if(Tool_Function.isTypeOf(tar ,SwfSprite)){
				var meta=tar.metaData;
				if(meta && meta["适配"] !=null){
					info适配=meta["适配"];
					for(var key in info适配){
						if(key.indexOf("合并")==0){
							var arrChilds=info适配[key]["包含"];
							for(i=1;i<arrChilds.length-1;i++){
								dicNo[arrChilds[i]]=true;
							}
							continue ;
						}
						child=tar.getChildByName(key);
						if(child==null){
							console.log(tar.classLink+"的meta适配信息错误，没有"+key+"子对象");
							continue ;
						}
						if(info适配[key]["类型"]=="关联"){
							var childTar=tar.getChildByName(info适配[key]["tar"]);
							if(childTar==null){
								console.log(tar.classLink+"的meta适配信息错误，"+key+"的关联父对象为null");
								continue ;
							}
							info适配[key]["x"]=child.x-childTar.x;
							info适配[key]["y"]=child.y-childTar.y;
						}
					}
				}
			};
			var w0=Config.stageW / 3;
			var h0=Config.stageH /3;
			var typex;
			var typey;
			var info={};
			for(i=0;i<tar.numChildren;i++){
				Tool_ObjUtils.getInstance().onClearObj(info);
				child=tar.getChildAt(i);
				if(child.name && dicNo[child.name]==true){continue ;};
				var rec=child.getBounds(tar);
				if(rec.x<w0){
					info["左"]=true;
				}
				if(rec.right > w0+w0){
					info["右"]=true;
				}
				if(rec.y<h0){
					info["上"]=true;
				}
				if(rec.bottom>h0+h0){
					info["下"]=true;
				}
				if(info["左"]==info["右"]){
					typex="中";
					}else if(info["左"]==true){
					typex="左";
					}else{
					typex="右";
				}
				if(info["上"]==info["下"]){
					typey="中";
					}else if(info["上"]==true){
					typey="上";
					}else{
					typey="下";
				}
				if(info适配!=null && info适配[child.name] && info适配[child.name]["类型"]!="关联"){
					typex=info适配[child.name]["类型"].charAt(0);
					typey=info适配[child.name]["类型"].charAt(1);
				}
				if(typex=="中" && typey=="中" && child.x==0 && child.y==0){
					var sx=Config._屏幕宽/Config.stageW;
					var sy=Config._屏幕高/Config.stageH;
					if(sx < sy){
						child.scaleX=Config.stageScaleInfo.屏幕w / Config.stageW;
						}else if(sx > sy){
						child.scaleY=Config.stageScaleInfo.屏幕h / Config.stageH;
					}
					}else{
					if(typex=="左"){
						}else if(typex=="右"){
						child.x=Config.stageScaleInfo.屏幕w-(Config.stageW-rec.right)-rec.width+(child.x-rec.x);
						}else if(typex=="中"){
						child.x=Config.stageScaleInfo.屏幕w/2+(rec.x+rec.width/2-Config.stageW/2)-rec.width/2;
					}
					if(typey=="上"){
						}else if(typey=="下"){
						child.y=Config.stageScaleInfo.屏幕h-(Config.stageH-rec.bottom)-rec.height+(child.y-rec.y);
						}else{
						child.y=Config.stageScaleInfo.屏幕h/2+(rec.y+rec.height/2-Config.stageH/2)-rec.height/2;
					}
				}
			}
			for(key in info适配){
				if(key.indexOf("合并")==0){
					arrChilds=info适配[key]["包含"];
					var child0=tar.getChildByName(arrChilds[0]);
					if(child0==null){
						console.log(tar.classLink+"的meta适配信息错误，合集"+key+"没有"+arrChilds[0]+"子对象");
						continue ;
					};
					var child1=tar.getChildByName(arrChilds[arrChilds.length-1]);
					if(child1==null){
						console.log(tar.classLink+"的meta适配信息错误，合集"+key+"没有"+arrChilds[arrChilds.length-1]+"子对象");
						continue ;
					}
					w0=0;
					h0=0;
					if(info适配[key]["x"] !=null){
						w0=(child1.x-child0.x)/(arrChilds.length-1);
					}
					if(info适配[key]["y"] !=null){
						h0=(child1.y-child0.y)/(arrChilds.length-1);
					}
					for(i=1;i<arrChilds.length-1;i++){
						dicNo[arrChilds[i]]=true;
						child=tar.getChildByName(arrChilds[i]);
						if(w0!=0){
							child.x=child0.x+w0 *i;
						}
						if(h0 !=0){
							child.y=child0.y+h0 *i;
						}
					}
					continue ;
				}
				if(info适配[key]!=null && info适配[key]["类型"]=="关联"){
					child=tar.getChildByName(key);
					childTar=tar.getChildByName(info适配[key]["tar"]);
					if(info适配[key]["x"]!=null){
						child.x=childTar.x+info适配[key]["x"];
					}
					if(info适配[key]["y"]!=null){
						child.y=childTar.y+info适配[key]["y"];
					}
				}
			}
		}

		Tool_Function.on计算两点距离=function(point1,point2){
			var lx=point1.x-point2.x;
			var ly=point1.y-point2.y;
			var l=lx *lx+ly *ly;
			return Math.sqrt(l);
		}

		Tool_Function.on计算两点角度=function(point1,point2){
			var ang=-1;
			var lx=point2.x-point1.x;
			var ly=point2.y-point1.y;
			if(lx==0 && ly==0){return-1;}
				if(ly==0){
				if(lx >=0){ang=90;}
					else {ang=270;}
				}else if(ly <0){
				if(lx>=0){ang=starling.utils.rad2deg(Math.atan(lx/-ly));}
					else {ang=360-starling.utils.rad2deg(Math.atan(-lx/-ly));}
				}else{
				if(lx>=0){ang=90+90-starling.utils.rad2deg(Math.atan(lx/ly));}
					else {ang=270-(90-starling.utils.rad2deg(Math.atan(-lx/ly)));}
			}
			return ang;
		}

		return Tool_Function;
	})()


	//class com.MyClass.Tools.Tool_ObjUtils
	var Tool_ObjUtils=(function(){
		function Tool_ObjUtils(){};
		__class(Tool_ObjUtils,'com.MyClass.Tools.Tool_ObjUtils');
		var __proto=Tool_ObjUtils.prototype;
		__proto.onClearObj=function(obj){
			if(obj==null)return;
			for(var key in obj){
				delete obj[key];
			}
		}

		__proto.判断相等=function(obj1,obj2){
			if(obj1==null && obj2==null)return true;
			if(obj1==null || obj2==null)return false;
			if((obj1 instanceof Array))return Tool_ArrayUtils.判断相等(obj1,obj2);
			if((typeof obj1=='string')){
				return obj1==obj2;
			}
			if((typeof obj1=='number')&& (typeof obj2=='number')){
				if(Math.abs(obj1-obj2)< 0.00001)return true;
				return false;
			}
			if((obj1 instanceof Dictionary)|| (typeof obj1=='object'))return Tool_DictionUtils.判断相等(obj1,obj2);
			return obj1==obj2;
		}

		__proto.CopyF=function(obj,浅层){
			(浅层===void 0)&& (浅层=false);
			if((typeof obj=='string')|| (typeof obj=='number')|| obj==null || Laya.__isClass(obj)|| (typeof obj=='boolean'))return obj;
			if((obj instanceof Array)){
				if(浅层)return Tool_ArrayUtils.copy浅层(obj);
				return Tool_ArrayUtils.copyArr(obj);
			}
			if((obj instanceof Dictionary)){
				if(浅层)return Tool_DictionUtils.copy浅层(obj);
				return Tool_DictionUtils.copyDic(obj);
			}
			if(浅层)return obj;
			if((obj instanceof starling.display.Image )){
				return obj;
			}
			if((typeof obj=='object')){
				var out={};
				for(var key in obj){
					out[this.CopyF(key)]=this.CopyF(obj[key]);
				}
				return out;
			}
			return obj;
		}

		__proto.on合并Object=function(obj,tar,复制){
			if(obj==null || tar==null)return;
			for(var key in tar){
				if(复制==false)obj[key]=tar[key];
				else obj[key]=this.CopyF(tar[key]);
			}
		}

		__proto.onGetValueFromObjAndDelete=function(tar,key){
			if(tar==null){
				return null;
			};
			var value=tar[key];
			delete tar[key];
			return value;
		}

		__proto.on线段碰撞=function(l1p1x,l1p1y,l1p2x,l1p2y,l2p1x,l2p1y,l2p2x,l2p2y){
			var line1p1=NaN;
			line1p1=(l1p2x-l1p1x)*(l2p1y-l1p1y)-(l2p1x-l1p1x)*(l1p2y-l1p1y);
			var line1p2=NaN;
			line1p2=(l1p2x-l1p1x)*(l2p2y-l1p1y)-(l2p2x-l1p1x)*(l1p2y-l1p1y);
			var line2p1=NaN;
			line2p1=(l2p2x-l2p1x)*(l1p1y-l2p1y)-(l1p1x-l2p1x)*(l2p2y-l2p1y);
			var line2p2=NaN;
			line2p2=(l2p2x-l2p1x)*(l1p2y-l2p1y)-(l1p2x-l2p1x)*(l2p2y-l2p1y);
			if ((line1p1*line1p2<=0)&&(line2p1*line2p2<=0)){
				return true;
				}else {
				return false;
			}
		}

		/*
		*清理任意
		*/
		__proto.destroyF_One=function(obj){
			var _$this=this;
			if(obj==null)return null;
			if((obj instanceof Array)){
				for(var i=0;i<obj.length;i++){
					this.destroyF_One(obj[i]);
				}
				obj.length=0;
			}
			else if((obj instanceof Dictionary)){
				Tool_DictionUtils.on遍历Dic(obj,function(key,val){
					_$this.destroyF_One(val);
				});
				(obj).clear();
			}
			else if((typeof obj=='number')){
				return 0;
			}
			else if((typeof obj=='boolean')){
				return false;
			}
			else if(this.hasFunction(obj,"destroyF")==true){
				obj.destroyF();
			}
			else if((obj instanceof laya.display.Node )){
				(obj).destroy();
			}
			else if((typeof obj=='object')){
				for(var n in obj){
					this.destroyF_One(obj[n]);
					delete obj[n];
					if((typeof n=='number')|| (typeof n=='string')){}
						else this.destroyF_One(n);
				}
			}
			else{
				this.destroyDisplayObj(obj);
			}
			return null;
		}

		__proto.destroyDisplayObj=function(obj){
			if((obj instanceof laya.display.Sprite )){
				(obj).destroy();
			}
		}

		__proto.destroyOrgSpr=function(spr){
			if(spr==null)return null;
			if(spr.parent)spr.parent.removeChild(spr);
			return null;
		}

		__proto.hasFunction=function(target,method){
			try{
				return (typeof (target[method])=='function');
				}catch(e){
				return false;
			}
			return true;
		}

		Tool_ObjUtils.getInstance=function(){
			if(Tool_ObjUtils.instance==null)Tool_ObjUtils.instance=new Tool_ObjUtils();
			return Tool_ObjUtils.instance;
		}

		Tool_ObjUtils.instance=null
		return Tool_ObjUtils;
	})()


	//class com.MyClass.Tools.Tool_SpriteUtils
	var Tool_SpriteUtils=(function(){
		function Tool_SpriteUtils(){};
		__class(Tool_SpriteUtils,'com.MyClass.Tools.Tool_SpriteUtils');
		Tool_SpriteUtils.getORISprite=function(__arg){
			var arg=arguments;
			if(arg.length==0){return null;}
				if(Laya.__isClass((arg[0]))){
				return new arg[0]();
				}else if((typeof (arg[0])=='string')){
				var str=arg[0];
				if(str.indexOf("__")==0){
					str="ANI_"+str.substr(2);
				};
				var SWFPath="res/"+str+".swf";
				console.log("swf="+SWFPath);
				var mc=new MovieClip();
				mc.load(SWFPath);
				return mc;
			}
			return null;
		}

		Tool_SpriteUtils.cloneSprite=function(target){
			return null;
		}

		Tool_SpriteUtils.changeColor=function(tar,color){}
		Tool_SpriteUtils._生成ImageNum=function(fName,spr,_链接名,_父swf){
			var tmp=spr.getChildByName(_链接名);
			if(tmp==null)return null;
			var classLink=tmp.classLink;
			var arr=classLink.split("_");
			if(fName==null)fName=arr[1];
			if(_父swf==null){
				for(var i=2;i<arr.length;i++){
					if(arr[i].indexOf("swf")==0){
						_父swf=arr[i].slice(3);
						if(_父swf=="SWF")_父swf+="_"+arr[i+1];
						break ;
					}
				}
				if(_父swf==null)_父swf="SWF_Default";
			};
			var num=new ImageNum(fName,_父swf);
			num.setValue("父对象",tmp);
			if(arr.length>2){
				var info={};
				for(var j=2;j<arr.length;j++){
					var one=arr[j];
					if(one.indexOf("颜色")==0){
						one=one.slice(2);
						if(one.indexOf("0x")!=0)one="0x"+one;
						num.setValue("颜色",int(one));
					}
					else if(one.indexOf("对齐")==0){
						num.setValue("对齐",one.slice(2));
					}
				}
			}
			return num;
		}

		Tool_SpriteUtils.onGetAll_ImageNum=function(spr,fName,_父swf){
			var dic=new Dictionary();
			var arrChild=[];
			for(var i=0;i<spr.numChildren;i++){
				var c=spr.getChildAt(i);
				var str=c.name;
				if(str==null || str.indexOf("num_")!=0)continue ;
				arrChild.push(str);
			}
			for(i=0;i<arrChild.length;i++){
				str=arrChild[i];
				var tmp=str.split("_");
				var name=tmp[0]+"_"+tmp[1];
				var info={"fName":fName,"swf":_父swf};
				for(var j=2;j<tmp.length;j++){
					var one=tmp[j];
					if(one.indexOf("字体")==0)info["fName"]=one.slice(2);
					else if(one.indexOf("swf")==0){
						var strSWF="";
						j++;
						while(j<tmp.length){
							if(strSWF.length>0)strSWF+="_";
							strSWF+=tmp[j++];
						}
						info["swf"]=strSWF;
						break ;
					}
					else if(one.indexOf("颜色")==0){
						one=one.slice(2);
						if(one.indexOf("0x")!=0)one="0x"+one;
						info["颜色"]=int(one);
					}
					else if(one.indexOf("对齐")==0)info["对齐"]=one.slice(2);
				};
				var num=Tool_SpriteUtils._生成ImageNum(info["fName"],spr,str,info["swf"]);
				if(info["颜色"]!=null)num.setValue("颜色",info["颜色"]);
				if(info["对齐"]!=null)num.setValue("对齐",info["对齐"]);
				dic.set(name,num);
			}
			return dic;
		}

		Tool_SpriteUtils.getMetaData_FromSPR=function(spr){
			var meta;
			if((spr instanceof lzm.starling.swf.display.SwfSprite )&& (((spr).spriteData[0])instanceof Array)==false)meta=(spr).spriteData[0];
			return meta;
		}

		Tool_SpriteUtils.onCreatAllChild=function(spr,dic,arr){
			var dic2;
			if(arr==null)dic2={"tx":true,"img":true,"spr":true,"mc":true};
			else{
				dic2={};
				for(var i=0;i<arr.length;i++){
					dic2[arr[i]]=true;
				}
			}
			for(i=0;i<spr.numChildren;i++){
				var one=spr.getChildAt(i);
				if(one.name==null || one.name.length==0)continue ;
				if(one.name.indexOf("tx")==0 && dic2["tx"]==true){
					dic[one.name]=one;
					continue ;
				};
				var cn=one.classLink;
				if(cn.indexOf("img_")==0 && dic2["img"]==true){
					dic["img_"+one.name]=one;
				}
				else if(cn.indexOf("spr_")==0 && dic2["spr"]==true){
					dic["spr_"+one.name]=one;
				}
				else if(cn.indexOf("mc_")==0 && dic2["mc"]==true){
					dic["mc_"+one.name]=one;
				}
			}
		}

		Tool_SpriteUtils.getBtn=function(spr,url){
			var B;
			var tmp=spr.getChildByName(url);
			if(tmp==null)return null;
			B=new BTN_Starling(tmp,null,null,null);
			B.set手动清理();
			B.name=url;
			return B;
		}

		Tool_SpriteUtils.onAddchild_替换父类=function(spr,child){
			spr.x=child.x;
			spr.y=child.y;
			if(child.parent){
				child.parent.addChildAt(spr,child.parent.getChildIndex(child));
			}
			spr.addChild(child);
			child.x=child.y=0;
		}

		Tool_SpriteUtils.on中心对齐到=function(spr,arrXY){
			var rec=spr.getBounds(spr);
			spr.x=arrXY[0]-rec.width/2-rec.x;
			spr.y=arrXY[1]-rec.height/2-rec.y;
		}

		Tool_SpriteUtils.on底部对齐到=function(spr,arrXY){
			var rec=spr.getBounds(spr);
			spr.x=arrXY[0]-rec.width/2-rec.x;
			spr.y=arrXY[1]-rec.height-rec.y;
		}

		Tool_SpriteUtils.on顶部对齐到=function(spr,tar,needScale){
			(needScale===void 0)&& (needScale=false);
			var x0=0;
			var y0=0;
			var rec=spr.getBounds(spr);
			if((tar instanceof laya.maths.Rectangle )){
				x0=tar.x;
				y0=tar.y;
				spr.x=x0+(tar.width-rec.width)/2-rec.x;
				spr.y=y0-rec.y;
				if(needScale==true && (rec.width > tar.width || rec.height>tar.height)){
					var sx=tar.width / rec.width;
					var sy=tar.height / rec.height;
					spr.scale=sx>sy?sx:sy;
				}
			}
			else{
				x0=tar[0];
				y0=tar[1];
				spr.x=x0-rec.width/2-rec.x;
				spr.y=y0-rec.y;
			}
		}

		Tool_SpriteUtils.on缩放适配到矩形=function(spr,rec,typeX,typeY){
			(typeX===void 0)&& (typeX="中");
			(typeY===void 0)&& (typeY="中");
			var x0=0;if(rec["x"])x0=rec["x"];
			var y0=0;if(rec["y"])y0=rec["y"];
			var w=(rec instanceof laya.maths.Rectangle )?rec.width:rec["w"];
			var h=(rec instanceof laya.maths.Rectangle )?rec.height:rec["h"];
			var recSpr=spr.getBounds(spr);
			var w0=recSpr.width;
			var h0=recSpr.height;
			var s=1;
			var px=w/w0;
			var py=h/h0;
			if(px<1 || py<1){
				s=px<py?px:py;
				(spr).scaleX=(spr).scaleY=s;
			}
			if(typeX=="中")spr.x=x0+(w-recSpr.width *s)/2-recSpr.x *s;
			else if(typeX=="左")spr.x=x0;
			else spr.x=x0+(w-recSpr.width *s)-recSpr.x *s;
			if(typeY=="中")spr.y=y0+(h-recSpr.height *s)/2-recSpr.y *s;
			else if(typeY=="上")spr.y=y0;
			else spr.y=y0+(h-recSpr.height *s)-recSpr.y *s;
		}

		Tool_SpriteUtils.onDrawToBitmapData=function(displayObject){
			return null;
		}

		Tool_SpriteUtils.on替换元件=function(mc,class0,FnewTar){
			if(mc==null)return;
			var _displayObjects=mc._displayObjects;
			var arr;
			var l=0;
			arr=_displayObjects[class0];
			if(arr==null)return;
			l=arr.length;
			for (var i=0;i < l;i++){
				var old=arr[i];
				if(FnewTar)arr[i]=FnewTar();
				else arr[i]=null;
				if(old)old.destroy();
			};
			var f=mc.currentFrame;
			if(mc.isPlaying==false)mc.gotoAndStop(f);
			else mc.gotoAndPlay(f);
		}

		return Tool_SpriteUtils;
	})()


	//class com.MyClass.Tools.Tool_StringBuild
	var Tool_StringBuild=(function(){
		function Tool_StringBuild(){};
		__class(Tool_StringBuild,'com.MyClass.Tools.Tool_StringBuild');
		Tool_StringBuild.getHTMLText=function(str,color,size,粗体){
			(size===void 0)&& (size=-1);
			(粗体===void 0)&& (粗体=false);
			var arr=Tool_StringBuild.getArr_By_split(str,"<");
			str="";
			for(var i=0;i<arr.length;i++){
				if(i>0)str+="&lt;";
				str+=arr[i];
			}
			arr=Tool_StringBuild.getArr_By_split(str,">");
			str="";
			for(i=0;i<arr.length;i++){
				if(i>0)str+="&gt;";
				str+=arr[i];
			};
			var out;
			if(size <=0)size=20;
			if(粗体==false){
				out="<FONT SIZE='"+String(size)+
				"'COLOR='#"+color.toString(16)+"'>"+str+"</FONT>";
			}
			else{
				out="<FONT SIZE='"+String(size)+
				"'COLOR='#"+color.toString(16)+"'>"+"<b>"+str+"</b>"+"</FONT>";
			}
			return out;
		}

		Tool_StringBuild.on去除空格回车=function(str){
			var arr=["\n","\t","\r"," ","	"];
			while(arr.length>0){
				str=Tool_StringBuild.replaceSTR(str,arr[0],"");
				arr.shift();
			}
			return str;
		}

		Tool_StringBuild.rebuild_by_length=function(str,len,_区分中文){
			var out="";
			if(_区分中文==false){
				out=str.substr(0,len);
			}
			else{
				var nowL=0;
				var count=0;
				while(count < str.length){
					if(nowL >=len)break ;
					var char=str.charAt(count);
					var code=str.charCodeAt(count);
					out+=char;
					if(code >=10000)nowL+=2;
					else nowL+=1;
					count++;
				}
			}
			return out;
		}

		Tool_StringBuild.getNewSTRBySlip=function(str1,str2){
			var arr=str1.split(str2);
			str1="";
			while(arr.length > 0){
				str1+=arr[0];
				arr.shift();
			}
			return str1;
		}

		Tool_StringBuild.replaceSTR=function(str,str1,str2){
			var out="";
			var arr=str.split(str1);
			for(var i=0;i<arr.length;i++){
				if(i>0)out+=str2;
				out+=arr[i];
			}
			return out;
		}

		Tool_StringBuild.getArr_By_split=function(str1,str2,_类型转换){
			var arr=str1.split(str2);
			if(_类型转换){
				var i=0;
				var l=arr.length;
				for(i=0;i<l;i++){
					if(_类型转换=="int")arr[i]=int(arr[i]);
					else if(_类型转换=="Number")arr[i]=Number(arr[i]);
				}
			}
			return arr;
		}

		Tool_StringBuild.onInsertF=function(str,index,strTar){
			var str0=str.slice(0,index);
			var str1=str.slice(index);
			return str0+strTar+str1;
		}

		Tool_StringBuild.get中文替换=function(str){
			var out="";
			var lastPo=0;
			var po=str.indexOf("$");
			if(po !=-1){
				while(true){
					out+=str.slice(lastPo,po);
					var nextPo=str.indexOf("$",po+1);
					var strID=str.slice(po+1,nextPo);
					out+=String.fromCharCode(int(strID));
					lastPo=nextPo+1;
					po=str.indexOf("$",lastPo);
					if(po==-1){
						out+=str.slice(lastPo);
						break ;
					}
				}
			}
			else{
				po=0;
				while(po < str.length){
					var char=str.charAt(po);
					var code=str.charCodeAt(po);
					if(code >=10000){
						out+="$"+code+"$";
					}
					else out+=char;
					po++;
				}
			}
			return out;
		}

		Tool_StringBuild.str2UTF8=function(str){
			var byteArray=new ByteArray();
			byteArray.writeMultiByte(str,"UTF8");
			byteArray.position=0;
			return byteArray.readMultiByte(byteArray.bytesAvailable,"UTF8");
		}

		return Tool_StringBuild;
	})()


	//class com.MyClass.VertionVo
	var VertionVo=(function(){
		function VertionVo(){
			this.Dic_Ver=null;
			this.initVer();
		}

		__class(VertionVo,'com.MyClass.VertionVo');
		var __proto=VertionVo.prototype;
		__proto.initVer=function(){}
		__proto.checkVer=function(dic){
			return null;
		}

		__proto.change版本号=function(name,ver){}
		/************************************数据**********************************************/
		__proto.change数据资源=function(name,data){}
		__proto.get数据资源=function(name){
			return null;
		}

		/************************************AS**********************************************/
		__proto.change代码资源=function(name,data){}
		__proto.get代码资源=function(name){
			return null;
		}

		__proto.on_Have_AS代码=function(name){
			return false;
		}

		/************************************SWF**********************************************/
		__proto.changeSWF资源=function(name,b,pic,_xml){}
		__proto.getSWF地址=function(name){
			return null;
		}

		__proto.getSWF_XML=function(name){
			return null;
		}

		__proto.getSWF_BitmapData=function(name,setFun){
			setFun(null);
		}

		__proto.getSWF_Bytes=function(name){
			return null;
		}

		/************************************MP3**********************************************/
		__proto.changeMP3资源=function(name,b){}
		__proto.getMP3=function(name){
			return null;
		}

		/************************************PNG**********************************************/
		__proto.changePNG资源=function(name,pic){}
		__proto.getPNG_BitmapData=function(name,setFun){
			setFun(null);
		}

		/************************************************************************************/
		__proto.getVertion=function(name){
			return 0;
		}

		__proto.upData=function(Type,sourceID,ver,Val,f){
			f(false);
		}

		VertionVo.getInstance=function(){
			if(VertionVo.instance==null)VertionVo.instance=new VertionVo();
			return VertionVo.instance;
		}

		VertionVo.getData=function(tar){
			return null;
		}

		VertionVo.StaticVer=0;
		VertionVo.Dic_StaticVer={};
		VertionVo.instance=null
		return VertionVo;
	})()


	//class Controller_BARWar
	var Controller_BARWar=(function(){
		function Controller_BARWar(){
			this.dicView=new Dictionary();
			this.meo=new MyEventManagerOne();
			this.meo.addListenerF("Title_进入",Handler.create(this,this.on进入F,null,false),"登录");
			this.meo.addListenerF("Title_离开",Handler.create(this,this.on离开F,null,false),"登录");
			this.meo.addListenerF("Fight_进入",Handler.create(this,this.on进入F,null,false),"战斗");
			this.meo.addListenerF("Fight_离开",Handler.create(this,this.on离开F,null,false),"战斗");
		}

		__class(Controller_BARWar,'Controller_BARWar');
		var __proto=Controller_BARWar.prototype;
		__proto.on进入F=function(tar,val){
			Config.Log("收到进入："+tar+"，参数="+val);
			if(this.dicView.get(tar)!=null){
				console.log("重复的界面："+tar);
				return;
			};
			var v;
			switch (tar){
				case "登录":v=Tool_Function.onNewClass(ViewClass_Login);break ;
				case "战斗":v=Tool_Function.onNewClass(ViewClass_FightMain,val);break ;
				}
			this.dicView.set(tar,v);
		}

		__proto.on离开F=function(tar){
			Config.Log("收到离开："+tar);
			if(this.dicView.get(tar)!=null){
				this.dicView.remove(tar);
			}
		}

		__proto.destroyF=function(){
			Controller_BARWar.instance=null;
			this.meo=Tool_ObjUtils.getInstance().destroyF_One(this.meo);
			this.dicView.clear();
		}

		Controller_BARWar.getInstance=function(){
			if(Controller_BARWar.instance==null){
				Controller_BARWar.instance=new Controller_BARWar();
			}
			return Controller_BARWar.instance;
		}

		Controller_BARWar.destroyF=function(){
			if(Controller_BARWar.instance){
				Controller_BARWar.instance.destroyF();
			}
		}

		Controller_BARWar.instance=null
		return Controller_BARWar;
	})()


	//class Games.Fights.Fight_ActionDefault
	var Fight_ActionDefault=(function(){
		function Fight_ActionDefault(r){
			this.Role=null;
			this.Name=null;
			this.swf=null;
			this.url=null;
			this.Arr_step=null;
			this.is无敌=false;
			this.is霸体=false;
			this.Role=r;
		}

		__class(Fight_ActionDefault,'Games.Fights.Fight_ActionDefault');
		var __proto=Fight_ActionDefault.prototype;
		__proto.checkActiveF=function(){
			return true;
		}

		__proto.resetF=function(){
			if(this.swf==null){this.swf="SWF_FightUI";}
				if(this.url==null){return;}
			this.onChangeRoleMcByURL();
		}

		__proto.onChangeRoleMcByURL=function(){
			this.Role.onChangeRoleMC(this.swf,this.url+this.Role.now方向);
		}

		__proto.enterF=function(){}
		__proto.add无敌=function(){
			if(this.is无敌==false){
				this.is无敌=true;
				this.Role.is无敌++;
			}
		}

		__proto.add霸体=function(){
			if(this.is霸体==false){
				this.is霸体=true;
				this.Role.is霸体++;
			}
		}

		__proto.breakF=function(){
			if(this.is无敌==true){
				this.is无敌=false;
				this.Role.is无敌--;
			}
			if(this.is霸体==true){
				this.is霸体=false;
				this.Role.is霸体--;
			}
		}

		__proto.destroyF=function(){
			this.Role=null;
		}

		return Fight_ActionDefault;
	})()


	//class Games.Fights.Fight_MapItem
	var Fight_MapItem=(function(){
		function Fight_MapItem(info,v){
			this.ID=null;
			this.roleID=0;
			this.mainView=null;
			this.is障碍=false;
			this.Role=null;
			this.roleMC=null;
			this.Role_x=0;
			this.Role_y=0;
			this.Role_z=0;
			this.nowRow=0;
			this.nowColumn=0;
			this._visible=false;
			this.mainView=v;
			if(info["ID"]!=null){this.ID="Item"+info["ID"];}
				if(info["roleID"]!=null){this.roleID=info["roleID"];}
		}

		__class(Fight_MapItem,'Games.Fights.Fight_MapItem');
		var __proto=Fight_MapItem.prototype;
		__proto.enterF=function(){}
		__proto.destroyF=function(){
			this.mainView=null;
			this.Role=Tool_ObjUtils.getInstance().destroyF_One(this.Role);
			if(this.roleMC){
				this.roleMC=Tool_ObjUtils.getInstance().destroyF_One(this.roleMC);
				this.roleMC=null;
			}
		}

		__getset(0,__proto,'x',function(){return this.Role_x;},function(value){
			this.Role_x=value;
			this.nowColumn=Tool_Function.on强制转换(this.Role_x / Fight_MAP.mapW0);
		});

		__getset(0,__proto,'y',function(){return this.Role_y;},function(value){
			this.Role_y=value;
			this.nowRow=Tool_Function.on强制转换(this.Role_y / Fight_MAP.mapH0);
		});

		__getset(0,__proto,'role半径',function(){return 5;});
		__getset(0,__proto,'visible',null,function(value){
			if(this._visible==value){return;}
				this._visible=value;
			if(this._visible==true){
				if(this.Role==null){
					this.Role=new Sprite1();
					}else{
					this.Role.visible=true;
				}
				if(this.roleMC==null){
					this.roleMC=MyPools.getInstance().getFromPool("地图物品",this.roleID);
					if(this.roleMC==null){
						this.roleMC=MySourceManager.getInstance().getObjFromSwf("SWF_FightUI","spr_Item"+this.roleID);
					}
					if (this.roleMC){
						this.Role.addChild(this.roleMC);
					}
				}
				}else{
				this.Role.visible=false;
				MyPools.getInstance().returnToPool("地图物品",this.roleMC);
				this.roleMC=null;
			}
		});

		return Fight_MapItem;
	})()


	//class Games.Fights.Fight_Role
	var Fight_Role=(function(){
		function Fight_Role(info,v){
			this.ID=0;
			this.RoleID=0;
			this.mainView=null;
			this.Role=null;
			this.roleMC=null;
			this.dicMCs={};
			this.Role影子=null;
			this.moveController=null;
			this.atkController=null;
			this.阵营=0;
			this.Net=0;
			this.Role_x=0;
			this.Role_y=0;
			this.Role_z=0;
			this.nowRow=0;
			this.nowColumn=0;
			this.scale_z=0;
			this.scale_weight=0;
			this.minx=0;
			this.maxx=0;
			this.miny=0;
			this.maxy=0;
			this.RoleAngle=0;
			this.RoleWeight=0;
			this.is无敌=0;
			this.is霸体=0;
			this.isDead=false;
			this.tarRole=null;
			this.Dic属性={};
			this.safe属性=null;
			this.DicBuff=null;
			this.Arr_Skill=null;
			this.action=null;
			this.nowFlag=null;
			this.now方向=null;
			this.nowMcLink=null;
			this.waiteAction=null;
			this.Dic_Actions={};
			this.angHalf45=45/2;
			this.tmpDicBuffEffect=null;
			this.mainView=v;
			if(info["ID"]!=null){this.ID=info["ID"];}
				if(info["RoleID"]!=null){this.RoleID=info["RoleID"];}
			if(info["阵营"]!=null){this.阵营=info["阵营"];}
				if(info["角度"]!=null){this.rotation=info["角度"];}
			else {this.rotation=180;}
			if(info["属性"]!=null){
				Tool_Function.on修改属性ByDic(this.Dic属性,info["属性"]);
			}
			if(this.Dic属性["hpMax"]==null){this.Dic属性["hpMax"]=this.Dic属性["hp"];}
				else if(this.Dic属性["hp"]==null){this.Dic属性["hp"]=this.Dic属性["hpMax"];}
			this.Dic属性["初始移速"]=this.Dic属性["移速"];
			this.Dic_Actions["站立"]=Tool_Function.onNewClass(Fight_Action_Stand,this,{});
			this.Dic_Actions["移动"]=Tool_Function.onNewClass(Fight_Action_Move,this,{});
			this.Dic_Actions["普攻"]=Tool_Function.onNewClass(Fight_Action_NorAtk,this,null);
			this.Dic_Actions["挨打"]=Tool_Function.onNewClass(Fight_Action_Hurt,this,null);
			if(info["技能"] !=null){
				for(var i=0;i<info["技能"].length;i++){
					this.addSkillF(info["技能"][i],null);
				}
			}
			this.Role=new Sprite1();
			if(info["x"]!=null){this.x=info.x;}
				if(info["y"]!=null){this.y=info.y;}
			this.changeRoleFlag("站立");
		}

		__class(Fight_Role,'Games.Fights.Fight_Role');
		var __proto=Fight_Role.prototype;
		__proto.addSkillF=function(s,info){
			var skill;
			var c;
			if(Tool_Function.isTypeOf(s,Number)==true){
				if(SData_Skill.getInstance().Dic[s]==null){
					console.log("没有技能"+s+"！");
					return;
				}
				c=SData_Skill.getInstance().Dic[s]["Class"];
				}else if(Tool_Function.isTypeOf(s,String)==true){
				c=Tool_Function.getDefinationByName(s,this);
				}else if(Tool_Function.isTypeOf(s,Class)==true){
				c=s;
				}else{
				console.log("无法解析的addSkillF:"+s);
				return;
			}
			if(c){
				if(info==null){
					info=Tool_ObjUtils.getInstance().CopyF(SData_Skill.getInstance().Dic[s],true);
					delete info["Class"];
				}
				skill=Tool_Function.onNewClass(c,this,info);
				if(skill){
					if(this.Arr_Skill==null){this.Arr_Skill=[];}
						this.Arr_Skill.push(skill);
					if(skill.is天赋==true){
						this.Dic_Actions["技能1"]=skill;
						}else if(skill.is被动==false){
						this.Dic_Actions["技能2"]=skill;
					}
				}
			}
		}

		__proto.changeRoleFlag=function(flag){
			if(this.action){this.action.breakF();this.action=null;}
				this.nowFlag=flag;
			this.waiteAction=null;
			if(this.Dic_Actions[this.nowFlag]==null){
				console.log(this.ID+"角色无法进入flag="+flag);
				return;
			}
			this.action=this.Dic_Actions[this.nowFlag];
			this.action.resetF();
		}

		__proto.onChangeRoleMC=function(swf,url){
			if(this.roleMC){
				this.roleMC.gotoAndStop(0);
				this.roleMC.removeFromParent();
				this.roleMC=null;
			}
			this.nowMcLink=url;
			if(this.dicMCs[url]==null){
				var mc=MySourceManager.getInstance().getMcFromSwf("SWF_FightUI",url);
				if(mc==null){
					this.dicMCs[url]=false;
					}else{
					this.roleMC=new MyMC(mc);
					this.dicMCs[url]=this.roleMC;
				}
				}else if(this.dicMCs[url]==false){
				}else{
				this.roleMC=this.dicMCs[url];
			}
			if(this.roleMC){
				this.Role.addChild(this.roleMC);
				}else{
				console.log("没有找到RID="+this.RoleID+"："+url);
			}
		}

		__proto.onRotateToTar=function(){
			if(this.tarRole){
				if(Math.abs(this.tarRole.Role_x-this.Role_x)> Config.stageW/2){
					this.tarRole=null;
					}else if(Math.abs(this.tarRole.Role_y-this.Role_y)> Config.stageH/2){
					this.tarRole=null;
					}else{
					var x0=this.tarRole.Role_x-this.Role_x;
					var y0=this.tarRole.Role_y-this.Role_y;
					var ang=0;
					if(y0==0){
						if(x0 >=0){ang=90;}
							else {ang=270;}
						}else if(y0 <0){
						if(x0>=0){ang=starling.utils.rad2deg(Math.atan(x0/-y0));}
							else {ang=360-starling.utils.rad2deg(Math.atan(-x0/-y0));}
						}else{
						if(x0>=0){ang=90+90-starling.utils.rad2deg(Math.atan(x0/y0));}
							else {ang=270-(90-starling.utils.rad2deg(Math.atan(-x0/y0)));}
					}
					this.rotation=ang;
				}
			}
		}

		__proto.enterF=function(){
			if(this.isDead==true){
				if(this.action && this.nowFlag=="挨打"){
					this.action.enterF();
				}
				return;
			}
			if(this.waiteAction){
				this.changeRoleFlag(this.waiteAction);
			}
			if(this.action){
				this.action.enterF();
			}
			if(this.Role){
				this.Role.x=this.Role_x;
				this.Role.y=this.Role_y-this.Role_z;
				this.Role.scaleX=1+this.RoleScale;
				this.Role.scaleY=1+this.RoleScale;
			}
			if(this.Role影子){
				this.Role影子.x=this.Role_x;
				this.Role影子.y=this.Role_y;
				if(this.Role){
					this.Role影子.scaleX=this.Role.scaleX;
					this.Role影子.scaleY=this.Role.scaleY;
				}
			}
		}

		__proto.get属性=function(key){
			if(this.Dic属性[key]==null){return 0;}
				return this.Dic属性[key];
		}

		__proto.change属性=function(key,value,强制){
			(强制===void 0)&& (强制=false);
			if(this.safe属性 && this.safe属性.checkF(key,value)==false){
				PlayerMain.getInstance().onErrorF(this.ID+"角色属性["+key+"]错误");
				return;
			}
			if(强制==true || value==null || Tool_Function.isTypeOf(value,Number)==false){
				this.Dic属性[key]=value;
				if(this.safe属性){
					this.safe属性.setValue(key,value);
				}
				}else{
				if(this.safe属性){
					this.safe属性.setValue(key,this.Dic属性[key]+value);
				}
				this.Dic属性[key]+=value;
			}
			if(this.safe属性 && this.safe属性.checkF(key,value)==false){
				PlayerMain.getInstance().onErrorF(this.ID+"角色属性["+key+"]错误");
			}
		}

		/**
		*检查Buff效果
		**/
		__proto.checkBuffF=function(key,info){
			if(this.tmpDicBuffEffect==null){this.tmpDicBuffEffect={};}
				}
		__proto.beHurtF=function(atk,from){
			if(from!=null && Tool_Function.isTypeOf(from,Fight_Role)==true){
				this.tarRole=from;
				this.waiteAction="挨打";
			}
		}

		__proto.destroyF=function(){
			this.mainView=null;
			this.tarRole=null;
			this.action=null;
			this.Role=Tool_ObjUtils.getInstance().destroyF_One(this.Role);
			this.roleMC=Tool_ObjUtils.getInstance().destroyF_One(this.roleMC);
			this.dicMCs=Tool_ObjUtils.getInstance().destroyF_One(this.dicMCs);
			this.Role影子=Tool_ObjUtils.getInstance().destroyF_One(this.Role影子);
			this.atkController=Tool_ObjUtils.getInstance().destroyF_One(this.atkController);
			this.moveController=Tool_ObjUtils.getInstance().destroyF_One(this.moveController);
			this.Dic_Actions=Tool_ObjUtils.getInstance().destroyF_One(this.Dic_Actions);
			this.DicBuff=Tool_ObjUtils.getInstance().destroyF_One(this.DicBuff);
			this.Dic属性=null;
			this.safe属性=Tool_ObjUtils.getInstance().destroyF_One(this.safe属性);
			this.tmpDicBuffEffect=null;
		}

		//getter，setter
		__getset(0,__proto,'moveSpd',function(){return this.get属性("移速");});
		__getset(0,__proto,'rotation',function(){return this.RoleAngle;},function(value){
			this.RoleAngle=value;
			if(this.rotation <=this.angHalf45 || this.rotation >=360-this.angHalf45){this.now方向="上";}
				else if(this.rotation <=this.angHalf45+45){this.now方向="右上";}
			else if(this.rotation <=90+this.angHalf45){this.now方向="右";}
			else if(this.rotation <=180-this.angHalf45){this.now方向="右下";}
			else if(this.rotation <=180+this.angHalf45){this.now方向="下";}
			else if(this.rotation <=270-this.angHalf45){this.now方向="左下";}
			else if(this.rotation <=270+this.angHalf45){this.now方向="左";}
			else {this.now方向="左上";}
		});

		__getset(0,__proto,'x',function(){return this.Role_x;},function(value){
			this.Role_x=value;
			this.nowColumn=Tool_Function.on强制转换(this.Role_x / Fight_MAP.mapW0);
		});

		__getset(0,__proto,'rotateSpd',function(){return this.get属性("转速");});
		__getset(0,__proto,'y',function(){return this.Role_y;},function(value){
			this.Role_y=value;
			this.nowRow=Tool_Function.on强制转换(this.Role_y / Fight_MAP.mapH0);
		});

		__getset(0,__proto,'RoleScale',function(){
			return this.scale_z+this.scale_weight;
		});

		__getset(0,__proto,'z',function(){return this.Role_z;},function(value){
			this.Role_z=value;
			if(this.Role_z<0){this.Role_z=0;}
				this.scale_z=this.Role_z / 200;
		});

		__getset(0,__proto,'role半径',function(){
			return 5;
		});

		return Fight_Role;
	})()


	//class Games.Fights.Fight_Role_AtkController
	var Fight_Role_AtkController=(function(){
		function Fight_Role_AtkController(spr,_option){
			this.option=null;
			this.sprBack=null;
			this.mkm=null;
			this.sprBack=spr;
			this.option=_option;
			if(this.option==null || this.option["键盘"]==true){
				this.mkm=new MyKeyboardManager(Config.mStage);
			}
		}

		__class(Fight_Role_AtkController,'Games.Fights.Fight_Role_AtkController');
		var __proto=Fight_Role_AtkController.prototype;
		__proto.isDownNomalAtk=function(){
			if(this.mkm && this.mkm.isDown(88)){return true;}
				return false;
		}

		__proto.isDownSkill1=function(){
			if(this.mkm && this.mkm.isDown(65)){return true;}
				return false;
		}

		__proto.isDownSkill2=function(){
			if(this.mkm && this.mkm.isDown(83)){return true;}
				return false;
		}

		__proto.isDownItem=function(){
			if(this.mkm && this.mkm.isDown(68)){return true;}
				return false;
		}

		__proto.destroyF=function(){
			this.sprBack=Tool_ObjUtils.getInstance().destroyF_One(this.sprBack);
			this.mkm=Tool_ObjUtils.getInstance().destroyF_One(this.mkm);
		}

		return Fight_Role_AtkController;
	})()


	//class Games.PlayerMain
	var PlayerMain=(function(){
		function PlayerMain(){
			this.ID=-1;
			this.昵称=null;
			this.性别=null;
			this.金币=0;
			this.钻石=0;
			this.头像=0;
			this.当前形象=0;
			this.Lv=1;
			this.Exp=0;
			this.Dic_SD={};
			this.Dic_属性=null;
			this.Dic_商城=null;
			this.Dic_每日=null;
			this.Dic_任务=null;
			this.Dic_Flag=null;
			this.C101=null;
			this.C6=null;
			this.C2=null;
			this.Columns_User_昵称="nickname";
			this.Columns_User_等级="lv";
			this.Columns_User_性别="sex";
			this.Columns_User_金币="gold";
			this.Columns_User_钻石="diamond";
			this.Columns_User_头像="head";
			this.Columns_User_每日="dic_everyday";
			this.Columns_User_属性="dic_property";
			this.Columns_User_商城="dic_shop";
			this.Columns_User_任务="dic_task";
			this.Columns_User_Flag="dic_flag";
			this.C101=new CMD101();
			this.C101.func_添加监听(this.valueChanged,false);
			this.C6=new CMD006();
			this.C6.func_添加监听(this.net弹窗,false);
			this.C2=new CMD002();
			this.C2.func_添加监听(this.net心跳,false);
			MainManager._instence.MEM.addListenF("网络断开",this.on断网F);
			var soundObj=MyLocalStorage.getF("声音信息");
			if(soundObj && soundObj["声音信息_音量"]!=null){
				SoundManagerMy.soundVal=soundObj["声音信息_音量"];
				SoundManagerMy.getInstance().setVol(SoundManagerMy.soundVal);
			}
		}

		__class(PlayerMain,'Games.PlayerMain');
		var __proto=PlayerMain.prototype;
		__proto.on断网F=function(){
			var _$this=this;
			var _账号信息=LSOManager.get("账号密码");
			if(this.ID>0 && _账号信息!=null && _账号信息["账号"]!=null && _账号信息["密码"]!=null){
				MainManager._instence.pause=true;
				MgsSocket.getInstance().need断网事件=false;
				LoadingSmall.showF(SData_Strings.Loading_联网中);
				if(MgsSocket.getInstance().now状态=="连接"){
					onConnectF(true);
					}else{
					PlayerMain.onStaticConnectF(onConnectF);
				}
				}else{
				LoadingSmall.removeF();
				AlertWindow.showF(SData_Strings.Alert_联网失败,null,Config.on重启);
			}
			function onConnectF (suc){
				if(suc==true){
					PlayerMain.onStaticLoginF(onNet重连F,_账号信息["账号"],_账号信息["密码"],true);
					}else{
					LoadingSmall.removeF();
					if((typeof suc=='string'))AlertWindow.showF(suc,null,_$this.on断网F);
					else AlertWindow.showF(SData_Strings.Alert_联网失败,null,_$this.on断网F);
				}
			}
			function onNet重连F (dic){
				if(dic["结果"]==true){
					MgsSocket.getInstance().onSend缓存(on重连指令F);
					}else{
					LoadingSmall.removeF();
					AlertWindow.showF(dic["失败原因"],null,_$this.on断网F);
				}
			}
			function on重连指令F (){
				console.log("重连指令处理完毕");
				LoadingSmall.removeF();
				MainManager._instence.pause=false;
			}
		}

		__proto.valueChanged=function(dic){
			for(var vname in dic){
				var val=dic[vname];
				var key;
				switch (vname){
					case "id":key="ID";break ;
					case this.Columns_User_昵称:key="昵称";break ;
					case this.Columns_User_等级:key="Lv";break ;
					case this.Columns_User_性别:key="性别";break ;
					case this.Columns_User_金币:key="金币";break ;
					case this.Columns_User_钻石:key="钻石";break ;
					case this.Columns_User_头像:key="头像";break ;
					case this.Columns_User_属性:key="Dic_属性";break ;
					case this.Columns_User_商城:key="Dic_商城";break ;
					case this.Columns_User_每日:key="Dic_每日";break ;
					case this.Columns_User_Flag:key="Dic_Flag";break ;
					case this.Columns_User_任务:key="Dic_任务";break ;
					default :key=vname;break ;
					}
				try{
					this[key]=val;
					}catch(e){
					this.Dic_SD[key]=val;
				}
				Config.Log("收到玩家属性：",vname,"->"+key+" =",dic[vname]);
				MainManager.getInstence().MEM.dispatchF("玩家"+key+"改变",null);
				delete dic[vname];
			}
		}

		__proto.setValue=function(want,val){
			try{
				this[want]=val;
			}
			catch(errObject){
				this.Dic_SD[want]=val;
			}
		}

		__proto.getValue=function(want,_参数){
			switch (want){
				default :
					try{
						return this[want];
					}
					catch(errObject){
						return this.Dic_SD[want];
					}
					break ;
				}
		}

		__proto.on手动修改F=function(want,val,f){
			if(f==null){
				this.valueChanged({want:val});
				return;
			}
			MainManager._instence.MEM.addListenF("玩家"+want+"改变",onNet修改属性,null,true);
			var c101=new CMD101();
			c101.writeValue_Dic(want,val);
			c101.sendF(true);
			function onNet修改属性 (){
				f();
			}
		}

		__proto.on改变Dic_每日=function(want,val,f){
			if(this.Dic_每日 && want!=null){
				if((typeof val=='number')&& this.Dic_每日[want]>=val){
					if(f)f();
					return;
				}
				if(Tool_ObjUtils.getInstance().判断相等(this.Dic_每日[want],val)==true){
					if(f)f();
					return;
				}
			}
			if(this.Dic_每日==null)this.Dic_每日={};
			if(want!=null)this.Dic_每日[want]=val;
			if(f)MainManager._instence.MEM.addListenF("玩家Dic_每日改变",onNetDic_每日,null,true);
			var c101=new CMD101();
			c101.writeValue_Dic("Dic_每日",this.Dic_每日);
			c101.sendF(true);
			function onNetDic_每日 (){
				if(f)f();
			}
		}

		__proto.on改变静态数据=function(want,val,方式){
			if(this.Dic_SD[want]==null || Laya.__isClass(val)){
				this.Dic_SD[want]=val;
				return;
			}
			if(((this.Dic_SD[want])instanceof Array)){
				if(方式=="push"){
					for(var i=0;i<val.length;i++){
						if((this.Dic_SD[want]).indexOf(val[i])==-1)
							(this.Dic_SD[want]).push(val[i]);
					}
				}
				else{
					for(var key in val){
						this.Dic_SD[want]=val[key];
					}
				}
			}
			else if((typeof (this.Dic_SD[want])=='number')|| (typeof (this.Dic_SD[want])=='string')){
				this.Dic_SD[want]=val;
			}
			else{
				for(key in val){
					this.Dic_SD[want][key]=val[key];
				}
			}
		}

		__proto.on发送当前界面=function(name){
			var sd=SData_Default.getInstance();
			if(sd.Dic["上传界面"]==false)return;
			var c105=new CMD105();
			c105.writeValue_Dic("界面",name);
			c105.sendF(false);
		}

		__proto.onErrorF=function(info){
			Config.Log("报错："+info);
			MainManager.getInstence().clearF();
			AlertWindow.showF(SData_Strings.Alert_意外错误,SData_Strings.Alert_意外错误Title,Config.on直接关闭);
		}

		__proto.net弹窗=function(dic){
			new MyNetAlertWindow(dic);
		}

		__proto.net心跳=function(val){
			console.log("收到心跳");
			var c2=new CMD002();
			c2.sendF(false);
		}

		__proto.destroyF=function(){
			PlayerMain.Instance=null;
			this.C101=Tool_ObjUtils.getInstance().destroyF_One(this.C101);
			this.C6=Tool_ObjUtils.getInstance().destroyF_One(this.C6);
			this.C2=Tool_ObjUtils.getInstance().destroyF_One(this.C2);
		}

		PlayerMain.getInstance=function(){
			if(PlayerMain.Instance==null)PlayerMain.Instance=new PlayerMain();
			return PlayerMain.Instance;
		}

		PlayerMain.onStaticConnectF=function(f){
			var message;
			var c2=new CMD002();
			c2.func_添加监听(netConnectWrongReson,true);
			function netConnectWrongReson (dic){
				message=dic["失败原因"];
			};
			var SD=SData_IP.getInstance();
			MgsSocket.getInstance().Fun_connect=onConnectEff;
			MgsSocket.getInstance().connectF(SD.Dic["ip"],SD.Dic["端口"]);
			function onConnectEff (suc){
				c2=Tool_ObjUtils.getInstance().destroyF_One(c2);
				if(suc==true){
					Tool_Function.onRunFunction(f,true);
					}else{
					if(message!=null){
						Tool_Function.onRunFunction(f,message);
						}else{
						Tool_Function.onRunFunction(f,false);
					}
				}
			}
		}

		PlayerMain.onStaticLoginF=function(f,账号,密码,重连){
			(重连===void 0)&& (重连=false);
			Starling.juggler.delayCall(onLoginTimerF,MgsSocket.getInstance().timeLimite);
			var c100=new CMD100();
			c100.func_添加监听(netLoginF,true);
			c100.writeValue_Dic("账号",账号);
			c100.writeValue_Dic("密码",密码);
			c100.writeValue_Dic("平台",Config.Main平台);
			if(Config.设备信息){
				c100.writeValue_Dic("设备信息",Config.设备信息);
			}
			c100.sendF(false);
			function netLoginF (dic){
				Starling.juggler.removeDelayedCalls(onLoginTimerF);
				Tool_Function.onRunFunction(f,dic);
			}
			function onLoginTimerF (){
				c100=Tool_ObjUtils.getInstance().destroyF_One(c100);
				Tool_Function.onRunFunction(f,{"结果":false,"失败原因":SData_Strings.Alert_联网失败});
			}
		}

		PlayerMain.Instance=null
		return PlayerMain;
	})()


	//class Games.Plugins.Plugins_sortController
	var Plugins_sortController=(function(){
		function Plugins_sortController(layer,tars,vRole,v属性,time){
			this.Layer=null;
			this.tarAll=null;
			this.value_Role=null;
			this.value_属性=null;
			this.type="升序";
			this.timeNeed=NaN;
			this.isArrayType=false;
			this.countNeed=0;
			this.arrTars=[];
			this.Layer=layer;
			this.tarAll=tars;
			this.value_Role=vRole;
			this.value_属性=v属性;
			this.timeNeed=time;
			this.isArrayType=Tool_Function.isTypeOf(this.tarAll,Array);
		}

		__class(Plugins_sortController,'Games.Plugins.Plugins_sortController');
		var __proto=Plugins_sortController.prototype;
		__proto.enterF=function(){
			if(this.countNeed--<=0){
				this.on排序F();
			}
		}

		__proto.on刷新冷却F=function(){
			this.countNeed=0;
		}

		__proto.on排序F=function(){
			this.countNeed=this.timeNeed *Config.playSpeedTrue;
			if(this.isArrayType){
				this.arrTars=this.tarAll;
				}else{
				this.arrTars.length=0;
				for(var key in this.tarAll){
					if(this.tarAll[key]!=null){
						this.arrTars.push(this.tarAll[key]);
					}
				}
			};
			var l=this.arrTars.length;
			var role0;
			var role1;
			for(var i=0;i<l-1;i++){
				role0=this.arrTars[i];
				if(role0==null){continue ;}
					for(var j=i+1;j<l;j++){
					role1=this.arrTars[j];
					if(role1==null){continue ;}
						if(role0[this.value_属性]==role1[this.value_属性]){continue ;}
					if(role0[this.value_属性] < role1[this.value_属性]){
						if(this.type=="降序"){
							this.arrTars[j]=role0;
							role0=role1;
						}
						}else{
						if(this.type=="升序"){
							this.arrTars[j]=role0;
							role0=role1;
						}
					}
				}
			}
			for(i=0;i<l;i++){
				if(this.arrTars[i]!=null && this.arrTars[i][this.value_Role]!=null){
					this.Layer.addChild(this.arrTars[i][this.value_Role]);
				}
			}
		}

		__proto.destroyF=function(){
			this.tarAll=null;
		}

		return Plugins_sortController;
	})()


	//class Games.Plugins.Plugins__map_topview_square
	var Plugins__map_topview_square=(function(){
		function Plugins__map_topview_square(_layer,_showRec,_infoMaps,funGet,_option){
			this.Layer=null;
			this.showRec=null;
			this.infoMaps=null;
			this.FunGet=null;
			this.option=null;
			this.dicGroundImg={};
			this.numShow行=0;
			this.numShow列=0;
			this.numShow行half=0;
			this.numShow列half=0;
			this.last行=-99;
			this.last列=-99;
			this.moveLimite=null;
			this.roleMoveLimite=null;
			this.pool={};
			this.Layer=_layer;
			this.showRec=_showRec;
			this.infoMaps=_infoMaps;
			this.FunGet=funGet;
			this.option=_option;
			this.numShow行=Tool_Function.on强制转换(this.showRec.height / this.infoMaps["h0"]);
			if(this.showRec.height % this.infoMaps["h0"] > 0){this.numShow行++;}
				this.numShow行half=Tool_Function.on强制转换(this.numShow行>>1);
			this.numShow列=Tool_Function.on强制转换(this.showRec.width / this.infoMaps["w0"]);
			if(this.showRec.width % this.infoMaps["w0"] > 0){this.numShow列++;}
				this.numShow列half=Tool_Function.on强制转换(this.numShow列>>1);
			Config.Log("showRec：",this.showRec);
			var widthAll=0;
			var heightAll=0;
			if(this.infoMaps["类型"]==2){
				heightAll=this.infoMaps["地面数据"].length *this.infoMaps["h0"];
				widthAll=this.infoMaps["地面数据"][0].length *this.infoMaps["w0"];
				}else{
				heightAll=this.infoMaps["行数"] *this.infoMaps["h0"];
				widthAll=this.infoMaps["地面数据"].length *this.infoMaps["w0"] / this.infoMaps["行数"];
			}
			if(this.option && this.option["边缘限制"]==true){
				this.moveLimite={};
				this.moveLimite["minx"]=this.showRec["width"]/2;
				this.moveLimite["maxx"]=widthAll-this.showRec["width"]/2;
				this.moveLimite["miny"]=this.showRec["height"]/2;
				this.moveLimite["maxy"]=heightAll-this.showRec["height"]/2;
				}else{
				this.moveLimite={};
				this.moveLimite["minx"]=-widthAll;
				this.moveLimite["maxx"]=widthAll;
				this.moveLimite["miny"]=-heightAll;
				this.moveLimite["maxy"]=heightAll;
			}
			this.roleMoveLimite={"minx":0,"maxx":widthAll,"miny":50,"maxy":heightAll};
		}

		__class(Plugins__map_topview_square,'Games.Plugins.Plugins__map_topview_square');
		var __proto=Plugins__map_topview_square.prototype;
		//miny：50，一般角色脚底为中心，为0则还是出屏幕了
		__proto.on刷新F=function(mainRole){
			var 行=0;
			var 列=0;
			if(mainRole){
				var mainx=mainRole.x;
				var mainy=mainRole.y;
				if(this.moveLimite && this.moveLimite["minx"]!=null && mainx < this.moveLimite["minx"]){
					mainx=this.moveLimite["minx"];
					}else if(this.moveLimite && this.moveLimite["maxx"]!=null && mainx > this.moveLimite["maxx"]){
					mainx=this.moveLimite["maxx"];
				}
				if(this.moveLimite && this.moveLimite["miny"]!=null && mainy < this.moveLimite["miny"]){
					mainy=this.moveLimite["miny"];
					}else if(this.moveLimite && this.moveLimite["maxy"]!=null && mainy > this.moveLimite["maxy"]){
					mainy=this.moveLimite["maxy"];
				}
				this.Layer.x=this.showRec["width"]/2-mainx;
				this.Layer.y=this.showRec["height"]/2-mainy;
				var row=Tool_Function.on强制转换(mainy / this.infoMaps["h0"]);
				var column=Tool_Function.on强制转换(mainx / this.infoMaps["w0"]);
				行=row-this.numShow行half;
				列=column-this.numShow列half;
			}
			if(行==this.last行 && 列==this.last列){}
				else{
				this.onShowF(行,列);
			}
		}

		__proto.onShowF=function(new行,new列){
			for(var i=0;i<this.numShow行+2;i++){
				var row=this.last行-1+i;
				var arr=this.dicGroundImg[row];
				if(arr){
					for(var j=0;j<arr.length;j++){
						var column=this.last列-1+j;
						if(row>=new行-1 && row<=this.numShow行+1+new行 && column>=new列-1 && column<=this.numShow列+1+new列){continue ;}
							if(arr[column]!=null){
							this.removeOne(this.getGroundValueByRC(row,column),arr[column]);
							arr[column]=null;
						}
					}
				}
			}
			for(i=0;i<this.numShow行+2;i++){
				row=new行-1+i;
				arr=this.dicGroundImg[row];
				if(arr==null){
					arr=[];
					this.dicGroundImg[row]=arr;
				}
				for(j=0;j<this.numShow列+2;j++){
					column=new列-1+j;
					if(arr[column]==null){
						var gtype=this.getGroundValueByRC(row,column);
						arr[column]=this.getNewOne(gtype);
						if(arr[column]){
							arr[column].x=this.infoMaps["w0"] *column;
							arr[column].y=this.infoMaps["h0"] *row;
						}
					}
				}
			}
			this.last行=new行;
			this.last列=new列;
			this.onShowGroundIMGNums();
		}

		__proto.onShowGroundIMGNums=function(){
			return;
			var count=0;
			for(var key in this.dicGroundImg){
				var arr=this.dicGroundImg[key];
				if(arr){
					for(var i=0;i<arr.length;i++){
						if(arr[i] !=null){count++;}
							}
				}
			}
			console.log("当前总图片："+count);
		}

		__proto.getGroundValueByRC=function(row,column){
			if(row<0 || column<0){return null;}
				if(this.infoMaps["类型"]==2){
				if(row >=this.infoMaps["地面数据"].length){return null;};
				var arr=this.infoMaps["地面数据"][row];
				if(column>=arr.length){return null;}
					return arr[column];
				}else{
				var index=row *this.infoMaps["行数"]+column;
				if(index>=this.infoMaps["地面数据"].length){return null;}
					return this.infoMaps["地面数据"][index];
			}
		}

		__proto.getNewOne=function(value){
			if(value==null){return null;};
			var img;
			if(this.pool[value]==null || this.pool[value].length==0){
				img=Tool_Function.onRunFunction(this.FunGet,value);
				}else{
				img=this.pool[value].shift();
			}
			this.Layer.addChild(img);
			return img;
		}

		__proto.removeOne=function(value,img){
			if(img==null){return;}
				img.removeFromParent();
			if(this.pool[value]==null){
				this.pool[value]=[];
			}
			this.pool[value].push(img);
		}

		//========================================
		__proto.destroyF=function(){
			if((this.FunGet instanceof laya.utils.Handler )){
				this.FunGet.clear();
			}
			this.FunGet=null;
			this.Layer=null;
			this.pool=Tool_ObjUtils.getInstance().destroyF_One(this.pool);
			this.dicGroundImg=Tool_ObjUtils.getInstance().destroyF_One(this.dicGroundImg);
		}

		return Plugins__map_topview_square;
	})()


	//class Games.Plugins.Plugins__moveControl_circleAll
	var Plugins__moveControl_circleAll=(function(){
		function Plugins__moveControl_circleAll(spr,_option){
			this.option=null;
			this.mkm=null;
			this.FunDown=null;
			this.sprBack=null;
			this.MC_Btn=null;
			this.IMG_Down=null;
			this.defaultX=0;
			this.defaultY=0;
			this._半径=0;
			this.MME=null;
			this.tmpObj1={"x":0,"y":0};
			this.tmpObj2={};
			this.sprBack=spr;
			this.option=_option;
			this.sprBack.touchGroup=false;
			this.MC_Btn=this.sprBack.getChildByName("btn");
			this.IMG_Down=this.MC_Btn.getChildByName("_down");
			var back=this.MC_Btn.getChildByName("_back");
			this._半径=back.width>>1;
			this.defaultX=this.MC_Btn.x;
			this.defaultY=this.MC_Btn.y;
			if(this.option==null || this.option["键盘"]==true){
				this.mkm=new MyKeyboardManager(Config.mStage);
			}
			this.MME=new MyMouseEventStarling(this.sprBack);
			this.MME.setValue("_开始移动距离",0);
			this.MME.setValue("down事件",this.down左右);
			this.MME.setValue("滑动",this.slide左右);
		}

		__class(Plugins__moveControl_circleAll,'Games.Plugins.Plugins__moveControl_circleAll');
		var __proto=Plugins__moveControl_circleAll.prototype;
		__proto.down左右=function(p){
			if(this.FunDown){
				Tool_Function.onRunFunction(this.FunDown);
				this.FunDown=null;
			}
			this.MC_Btn.x=p.x;
			this.MC_Btn.y=p.y;
		}

		__proto.up左右=function(){
			this.MC_Btn.x=this.defaultX;
			this.MC_Btn.y=this.defaultY;
			this.IMG_Down.x=0;
			this.IMG_Down.y=0;
		}

		__proto.slide左右=function(dic){
			if(dic["类型"]=="移动"){
				this.IMG_Down.x+=dic["x"];
				if(this.IMG_Down.x > this._半径){
					this.MC_Btn.x+=this.IMG_Down.x-this._半径;
					this.IMG_Down.x=this._半径;
				}
				else if(this.IMG_Down.x <-this._半径){
					this.MC_Btn.x+=this.IMG_Down.x+this._半径;
					this.IMG_Down.x=-this._半径;
				}
				this.IMG_Down.y+=dic["y"];
				if(this.IMG_Down.y > this._半径){
					this.MC_Btn.y+=this.IMG_Down.y-this._半径;
					this.IMG_Down.y=this._半径;
				}
				else if(this.IMG_Down.y <-this._半径){
					this.MC_Btn.y+=this.IMG_Down.y+this._半径;
					this.IMG_Down.y=-this._半径;
				}
			}
			else{
				this.up左右();
			}
		}

		/**
		*返回-1~360角度，-1表示没有按下
		*/
		__proto.getNow方向=function(){
			if(this.IMG_Down && (this.IMG_Down.x !=0 || this.IMG_Down.y!=0)){
				this.tmpObj2["x"]=this.IMG_Down.x;
				this.tmpObj2["y"]=this.IMG_Down.y;
				var ang=Tool_Function.on计算两点角度(this.tmpObj1,this.tmpObj2);
				return ang;
			}
			if(this.mkm){
				var isUp=this.mkm.isDown(38);
				var isDown=this.mkm.isDown(40);
				var isLeft=this.mkm.isDown(37);
				var isRight=this.mkm.isDown(39);
				if(isUp==true && isDown==true){
					isUp=false;
					isDown=false;
				}
				if(isLeft==true && isRight==true){
					isLeft=false;
					isRight=false;
				}
				if(isUp==true){
					if(isLeft==true){return 360-45;}
						else if(isRight==true){return 45;}
					else {return 0;}
					}else if(isDown==true){
					if(isLeft==true){return 360-135;}
						else if(isRight==true){return 135;}
					else {return 180;}
					}else if(isLeft==true){
					return 360-90;
					}else if(isRight==true){
					return 90;
				}
			}
			return-1;
		}

		__proto.isDown=function(key){
			if(this.mkm){
				return this.mkm.isDown(key);
			}
			return false;
		}

		__proto.destroyF=function(){
			this.sprBack=Tool_ObjUtils.getInstance().destroyF_One(this.sprBack);
			this.mkm=Tool_ObjUtils.getInstance().destroyF_One(this.mkm);
			this.MC_Btn=Tool_ObjUtils.getInstance().destroyF_One(this.MC_Btn);
			this.IMG_Down=Tool_ObjUtils.getInstance().destroyF_One(this.IMG_Down);
			this.MME=Tool_ObjUtils.getInstance().destroyF_One(this.MME);
		}

		return Plugins__moveControl_circleAll;
	})()


	//class lzm.util.LSOManager
	var LSOManager=(function(){
		function LSOManager(){}
		__class(LSOManager,'lzm.util.LSOManager');
		LSOManager.get=function(key){
			return null;
		}

		LSOManager.put=function(key,val){}
		return LSOManager;
	})()


	//class MainClass
	var MainClass=(function(){
		function MainClass(){
			this.isLoaded=false;
			this.isAniend=false;
			Config.适配方式=2;
			Config.stageW=1136;
			Config.stageH=640;
			Config.playSpeedTrue=60;
			Config.mainClassInstance=this;
			Config.Fun重启=this.on重启;
			if(Config.PF==null){
				Config.Platform="本地";
				this.startF();
			}
			else{
				Config.PF._登陆(this.startF);
			}
		}

		__class(MainClass,'MainClass');
		var __proto=MainClass.prototype;
		__proto.on重启=function(){
			Controller_BARWar.destroyF();
			MainManager.getInstence().destroyF();
			MgsSocket.getInstance().destroyF();
			if(SoundManagerMy.instance){
				SoundManagerMy.instance.destroyF();
			}
			PlayerMain.getInstance().destroyF();
			Config.closeStarling();
			this.startF(true);
		}

		__proto.startF=function(重启){
			(重启===void 0)&& (重启=false);
			MainManager.getInstence().init(Config.mStage);
			MgsSocket.getInstance().CMD心跳=1;
			PlayerMain.getInstance();
			Controller_BARWar.getInstance();
			Config.initStarling(this.LogoF);
		}

		__proto.LogoF=function(){
			var _$this=this;
			var source=[
			["SWF_Default","swf"]];
			MySourceManager.getInstance().addTexture(source,loadedF);
			var mc=Tool_SpriteUtils.getORISprite("__MC_Logo");
			if(mc==null){
				titleF();
				return;
			};
			var tmpMC=new TmpMovieClip_Ori(mc,titleF);
			LayerManager.getInstence().viewLayer.addChild(tmpMC);
			function titleF (){
				_$this.isAniend=true;
				onGameF();
			}
			function loadedF (){
				_$this.isLoaded=true;
				onGameF();
			}
			function onGameF (){
				if(_$this.isLoaded==true && _$this.isAniend==true){
					MainManager._instence.MEM.dispatchF("Fight_进入");
				}
			}
		}

		return MainClass;
	})()


	//class SData.SData_String
	var SData_String=(function(){
		function SData_String(){};
		__class(SData_String,'SData.SData_String');
		SData_String.setLanguage=function(lag){
			if(lag=="ENG"){}
				}
		SData_String.SWF_Default="SWF_Default";
		SData_String.SWF_LoginView="SWF_LoginView";
		SData_String.SWF_FightUI="SWF_FightUI";
		SData_String.SWF_FightUI_Ani水波="SWF_FightUI_Ani1";
		SData_String.SWF_Enemy1="SWF_Enemy1";
		SData_String.SWF_Enemy2="SWF_Enemy2";
		return SData_String;
	})()


	//class starling.animation.Juggler
	var Juggler=(function(){
		function Juggler(){
			this.countID=1;
			this.dic_ids=new Dictionary();
		}

		__class(Juggler,'starling.animation.Juggler');
		var __proto=Juggler.prototype;
		__proto.delayCall=function(f,time,__arg){
			var arg=[];for(var i=2,sz=arguments.length;i<sz;i++)arg.push(arguments[i]);
			if(this.dic_ids.indexOf(f)==-1){
				var arr=[f];
				if(arg.length > 0){
					arr=arr.concat(arg);
				}
				this.dic_ids.set(this.countID,arr);
				Laya.timer.once(time *1000,this,this.onTimerF,[this.countID++],false);
			}
		}

		__proto.onTimerF=function(id){
			if(this.dic_ids.get(id)!=null){
				var arr=this.dic_ids.get(id);
				this.dic_ids.remove(id);
				Tool_Function.onRunFunction.apply(this,arr);
			}else{}
		}

		// trace("已被清理");
		__proto.removeDelayedCalls=function(f){
			for(var i=0;i<this.dic_ids.keys.length;i++){
				var arr=this.dic_ids.get(this.dic_ids.keys[i]);
				var fun=arr[0]
				if((fun instanceof laya.utils.Handler )){
					if(((f instanceof laya.utils.Handler )&& fun==f)|| ((typeof f=='function')&& (fun).method==f)){
						this.dic_ids.remove(this.dic_ids.keys[i]);
						(fun).clear();
						i--;
					}
				}
				else if((typeof fun=='function')){
					if(((typeof f=='function')&& fun==f)|| ((f instanceof laya.utils.Handler )&& (f).method==fun)){
						this.dic_ids.remove(this.dic_ids.keys[i]);
						i--;
					}
				}
				if((f instanceof laya.utils.Handler ))(f).clear();
			}
		}

		__proto.add=function(t){
			if(Tool_Function.isTypeOf(t,starling.animation.Tween)){
				var f=null;
				if(t.tranType==null || t.tranType=="linear"){
					f=null;
				}
				else if(t.tranType=="easeOutBack"){
					f=Ease.backOut;
				}
				else if(t.tranType=="easeInOut"){
					f=Ease.backIn;
				};
				var comp;
				if(t.onComplete !=null){
					comp=t.onComplete;
					if(t.onCompleteArgs!=null){
						comp.args=t.onCompleteArgs;
					}
				}
				Tween.to(t.tarObj,t.info,t.time *1000,f,comp);
			}
		}

		__proto.remove=function(t){
			if(Tool_Function.isTypeOf(t,starling.animation.Tween)){}
				}
		return Juggler;
	})()


	//class starling.animation.Tween
	var Tween1=(function(){
		function Tween(tar,_time,tran){
			this.tarObj=null;
			this.time=NaN;
			this.tranType=null;
			this.info={};
			this.onComplete=null;
			this.onCompleteArgs=null;
			(tran===void 0)&& (tran="linear");
			this.tarObj=tar;
			this.time=_time;
			this.tranType=tran;
		}

		__class(Tween,'starling.animation.Tween',null,'Tween1');
		var __proto=Tween.prototype;
		__proto.moveTo=function(endx,endy){
			this.info["x"]=endx;
			this.info["y"]=endy;
		}

		__proto.fadeTo=function(enda){
			this.info["alpha"]=enda;
		}

		__proto.scaleTo=function(ends){
			this.info["scaleX"]=ends;
			this.info["scaleY"]=ends;
		}

		return Tween;
	})()


	//class starling.core.Starling
	var Starling=(function(){
		function Starling(){}
		__class(Starling,'starling.core.Starling');
		/**The default juggler of the currently active Starling instance. */
		__getset(1,Starling,'juggler',function(){
			if(Starling._juggler==null)Starling._juggler=new Juggler();
			return Starling._juggler;
		});

		Starling._juggler=null
		return Starling;
	})()


	/**A utility class containing predefined colors and methods converting between different
	*color representations. */
	//class starling.utils.Color
	var Color1=(function(){
		/**@private */
		function Color(){throw new starling.errors.AbstractClassError();}
		__class(Color,'starling.utils.Color',null,'Color1');
		Color.getAlpha=function(color){return (color >> 24)& 0xff;}
		Color.getRed=function(color){return (color >> 16)& 0xff;}
		Color.getGreen=function(color){return (color >> 8)& 0xff;}
		Color.getBlue=function(color){return color & 0xff;}
		Color.setAlpha=function(color,alpha){
			return (color & 0x00ffffff)| (alpha & 0xff)<< 24;
		}

		Color.setRed=function(color,red){
			return (color & 0xff00ffff)| (red & 0xff)<< 16;
		}

		Color.setGreen=function(color,green){
			return (color & 0xffff00ff)| (green & 0xff)<< 8;
		}

		Color.setBlue=function(color,blue){
			return (color & 0xffffff00)| (blue & 0xff);
		}

		Color.rgb=function(red,green,blue){
			return (red << 16)| (green << 8)| blue;
		}

		Color.argb=function(alpha,red,green,blue){
			return (alpha << 24)| (red << 16)| (green << 8)| blue;
		}

		Color.toVector=function(color,out){
			if (out==null)out=__newvec(4,0);
			out[0]=((color >> 16)& 0xff)/ 255.0;
			out[1]=((color >> 8)& 0xff)/ 255.0;
			out[2]=(color & 0xff)/ 255.0;
			out[3]=((color >> 24)& 0xff)/ 255.0;
			return out;
		}

		Color.multiply=function(color,factor){
			if (factor==0.0)return 0x0;
			var alpha=((color >> 24)& 0xff)*factor;
			var red=((color >> 16)& 0xff)*factor;
			var green=((color >> 8)& 0xff)*factor;
			var blue=(color & 0xff)*factor;
			if (alpha > 255)alpha=255;
			if (red > 255)red=255;
			if (green > 255)green=255;
			if (blue > 255)blue=255;
			return Color.argb(alpha,red,green,blue);
		}

		Color.interpolate=function(startColor,endColor,ratio){
			var startA=(startColor >> 24)& 0xff;
			var startR=(startColor >> 16)& 0xff;
			var startG=(startColor >> 8)& 0xff;
			var startB=(startColor)& 0xff;
			var endA=(endColor >> 24)& 0xff;
			var endR=(endColor >> 16)& 0xff;
			var endG=(endColor >> 8)& 0xff;
			var endB=(endColor)& 0xff;
			var newA=startA+(endA-startA)*ratio;
			var newR=startR+(endR-startR)*ratio;
			var newG=startG+(endG-startG)*ratio;
			var newB=startB+(endB-startB)*ratio;
			return (newA << 24)| (newR << 16)| (newG << 8)| newB;
		}

		Color.WHITE=0xffffff;
		Color.SILVER=0xc0c0c0;
		Color.GRAY=0x808080;
		Color.BLACK=0x000000;
		Color.RED=0xff0000;
		Color.MAROON=0x800000;
		Color.YELLOW=0xffff00;
		Color.OLIVE=0x808000;
		Color.LIME=0x00ff00;
		Color.GREEN=0x008000;
		Color.AQUA=0x00ffff;
		Color.TEAL=0x008080;
		Color.BLUE=0x0000ff;
		Color.NAVY=0x000080;
		Color.FUCHSIA=0xff00ff;
		Color.PURPLE=0x800080;
		return Color;
	})()


	//class StaticDatas.SData_Default
	var SData_Default=(function(){
		function SData_Default(){
			this.Dic=null;
			this.Dic=VertionVo.getData(this);
			if(this.Dic==null)this.on本地();
		}

		__class(SData_Default,'StaticDatas.SData_Default');
		var __proto=SData_Default.prototype;
		__proto.on本地=function(){
			this.Dic={};
			this.Dic["保存账号数量"]=5;
			this.Dic["上传界面"]=false;
			this.Dic["默认按钮音效"]="s_btn";
			this.Dic["默认背景音乐"]="Musiz_piano";
		}

		SData_Default.getInstance=function(){
			if(SData_Default.instance==null)SData_Default.instance=new SData_Default();
			return SData_Default.instance;
		}

		SData_Default.get奖励文字=function(arr){
			var str="";
			for(var i=0;i<arr.length;i++){
				if(i>0)str+="，";
				var type=arr[i]["type"];
				if(type=="文字")str+=arr[i]["内容"];
				else if(type=="道具"){
				}
				else str+=type+" x"+arr[i]["数量"];
			}
			return str;
		}

		SData_Default.instance=null
		return SData_Default;
	})()


	//class StaticDatas.SData_EventNames
	var SData_EventNames=(function(){
		function SData_EventNames(){};
		__class(SData_EventNames,'StaticDatas.SData_EventNames');
		SData_EventNames.Title_进入="Title_进入";
		SData_EventNames.Title_离开="Title_离开";
		SData_EventNames.Fight_进入="Fight_进入";
		SData_EventNames.Fight_离开="Fight_离开";
		return SData_EventNames;
	})()


	//class StaticDatas.SData_IP
	var SData_IP=(function(){
		function SData_IP(){
			this.Dic=null;
			if(this.Dic==null)this._本地数据();
			if(Config.Platform=="棱镜"){
				this.Dic["支付回调"]="http://"+this.Dic["ip"]+":"+this.Dic["端口2"]+"/ljpay";
			}
			else if(Config.Platform=="易接"){
				this.Dic["支付回调"]="http://"+this.Dic["ip"]+":"+this.Dic["端口2"]+"/1sdk_pay";
				this.Dic["登陆回调"]="http://"+this.Dic["ip"]+":"+this.Dic["端口2"]+"/1sdk_login";
			}
		}

		__class(SData_IP,'StaticDatas.SData_IP');
		var __proto=SData_IP.prototype;
		__proto._本地数据=function(){
			var dic;
			this.Dic={};
			this.Dic["类型"]="正式";
			this.Dic["ip"]="114.55.3.126";
			this.Dic["端口"]=10000;
			this.Dic["端口2"]=10001;
			this.Dic["类型"]="本地";
			this.Dic["ip"]="192.168.1.200";
			this.Dic["端口"]=10000;
			this.Dic["端口2"]=10001;
			this.Dic["类型"]="本地";
			this.Dic["ip"]="192.168.127.1";
			this.Dic["端口"]=10000;
			this.Dic["端口2"]=10001;
		}

		SData_IP.getInstance=function(){
			if(SData_IP.instance==null)SData_IP.instance=new SData_IP();
			return SData_IP.instance;
		}

		SData_IP.instance=null
		return SData_IP;
	})()


	//class StaticDatas.SData_Roles
	var SData_Roles=(function(){
		function SData_Roles(){
			this.Dic=null;
			this.Dic=VertionVo.getData(this);
			if(this.Dic==null)this.on本地();
		}

		__class(SData_Roles,'StaticDatas.SData_Roles');
		var __proto=SData_Roles.prototype;
		__proto.on本地=function(){
			this.Dic={};
			var dic;
			var rid=0;
			rid=1;dic={};this.Dic[rid]=dic;
			dic["Name"]="男剑士";
			dic["移速"]=8;
			dic["天赋技能"]=1;
			dic["普攻"]={"frame始末":[[1,16],[16,11]],"Arr_hurtFrame":[15]
				,"Arr_hurtObj":[{"角度":[-45,45],"距离":80}]
			};
			dic["挨打"]={};
		}

		SData_Roles.getInstance=function(){
			if(SData_Roles.instance==null)SData_Roles.instance=new SData_Roles();
			return SData_Roles.instance;
		}

		SData_Roles.instance=null
		return SData_Roles;
	})()


	//class StaticDatas.SData_Skill
	var SData_Skill=(function(){
		function SData_Skill(){
			this.Dic=null;
			this.Dic=VertionVo.getData(this);
			if(this.Dic==null)this.on本地();
		}

		__class(SData_Skill,'StaticDatas.SData_Skill');
		var __proto=SData_Skill.prototype;
		__proto.on本地=function(){
			this.Dic={};
			var dic;
			var sid=0;
			sid=1;dic={};this.Dic[sid]=dic;
			dic["Name"]="翻滚";
			dic["Class"]=Fight_Action_Skill1_Rush;
			dic["url"]="mc_";
		}

		SData_Skill.getInstance=function(){
			if(SData_Skill.instance==null)SData_Skill.instance=new SData_Skill();
			return SData_Skill.instance;
		}

		SData_Skill.instance=null
		return SData_Skill;
	})()


	//class StaticDatas.SData_Strings
	var SData_Strings=(function(){
		function SData_Strings(){};
		__class(SData_Strings,'StaticDatas.SData_Strings');
		SData_Strings.setLanguage=function(lag){
			if(lag=="ENG"){
			}
		}

		SData_Strings.ActionName_站立="站立";
		SData_Strings.ActionName_移动="移动";
		SData_Strings.ActionName_挨打="挨打";
		SData_Strings.ActionName_攻击="普攻";
		SData_Strings.ActionName_技能1="技能1";
		SData_Strings.ActionName_技能2="技能2";
		SData_Strings.ActionName_道具="道具";
		SData_Strings.BUFFEvent_攻击前="攻击前";
		SData_Strings.BUFFEvent_被击前="被攻击前";
		SData_Strings.BUFFEvent_被击后="被攻击后";
		SData_Strings.BUFFEffect_伤害增加="伤害增加";
		SData_Strings.SWF_默认UI="SWF_Default";
		SData_Strings.SWF_首页="SWF_LoginView";
		SData_Strings.SWF_大厅="SWF_Lobby";
		SData_Strings.SWF_战斗界面="SWF_FightUI";
		SData_Strings.Alert_默认OK="确定";
		SData_Strings.Alert_默认NO="取消";
		SData_Strings.Alert_意外错误="游戏出现意外错误，请重新启动！";
		SData_Strings.Alert_意外错误Title="哎呀出错了";
		SData_Strings.Alert_联网失败="联网失败！请检查网络！";
		SData_Strings.Alert_重连="重连";
		SData_Strings.Alert_账号密码错误="请输入账号和密码！";
		SData_Strings.Alert_重复密码错误="两次输入的密码不一致！";
		SData_Strings.Alert_账号非法字符="账号中含有特殊的字符！";
		SData_Strings.Alert_账号太长="账号长度超过限制！";
		SData_Strings.Alert_绑定手机错误="暂时无法绑定手机！";
		SData_Strings.Alert_手机号错误="请输入正确的手机号码！";
		SData_Strings.Alert_验证码错误="验证码错误！";
		SData_Strings.Alert_确认手机="即将向您输入的手机号发送验证短信，是否继续？";
		SData_Strings.Alert_验证码发送失败="发送验证码失败！请确认您的手机号。";
		SData_Strings.Alert_验证码发送成功="验证码短信已发送，请耐心等待！";
		SData_Strings.Alert_验证码正在等待="请输入您收到的验证码后点击注册按钮！";
		SData_Strings.Alert_验证码正在验证="正在验证，请稍后！";
		SData_Strings.Loading_联网中="联网中";
		SData_Strings.LOCS_账号密码="账号密码";
		SData_Strings.LOCS_声音信息="声音信息";
		SData_Strings.LOCS_声音信息_音量="声音信息_音量";
		SData_Strings.SD_Default_保存数量="保存账号数量";
		return SData_Strings;
	})()


	//class CMD.CMD002 extends com.MyClass.NetTools.Net_SocketCMD
	var CMD002=(function(_super){
		//心跳
		function CMD002(){
			CMD002.__super.call(this,2);
		}

		__class(CMD002,'CMD.CMD002',_super);
		return CMD002;
	})(Net_SocketCMD)


	//class CMD.CMD006 extends com.MyClass.NetTools.Net_SocketCMD
	var CMD006=(function(_super){
		function CMD006(){
			CMD006.__super.call(this,6);
		}

		__class(CMD006,'CMD.CMD006',_super);
		return CMD006;
	})(Net_SocketCMD)


	//class CMD.CMD100 extends com.MyClass.NetTools.Net_SocketCMD
	var CMD100=(function(_super){
		function CMD100(){
			CMD100.__super.call(this,100);
		}

		__class(CMD100,'CMD.CMD100',_super);
		return CMD100;
	})(Net_SocketCMD)


	//class CMD.CMD101 extends com.MyClass.NetTools.Net_SocketCMD
	var CMD101=(function(_super){
		function CMD101(){
			CMD101.__super.call(this,101);
		}

		__class(CMD101,'CMD.CMD101',_super);
		return CMD101;
	})(Net_SocketCMD)


	//class CMD.CMD105 extends com.MyClass.NetTools.Net_SocketCMD
	var CMD105=(function(_super){
		function CMD105(){
			CMD105.__super.call(this,105);
		}

		__class(CMD105,'CMD.CMD105',_super);
		return CMD105;
	})(Net_SocketCMD)


	//class com.MyClass.NetTools.MyByteArray extends com.MyClass.ByteArray
	var MyByteArray=(function(_super){
		function MyByteArray(cmd){
			this.CMD=0;
			this.Arr_val=null;
			this.WriteB=null;
			(cmd===void 0)&& (cmd=-1);
			MyByteArray.__super.call(this);
			this.CMD=cmd;
		}

		__class(MyByteArray,'com.MyClass.NetTools.MyByteArray',_super);
		var __proto=MyByteArray.prototype;
		__proto.writeF=function(val){
			if(this.WriteB==null)this.WriteB=new ByteArray();
			if((val instanceof Array)){
				for(var i=0;i<val.length;i++){
					this.write(val[i]);
				}
			}
			else this.write(val);
			this.clear();
			this.writeBytes(this.WriteB);
		}

		__proto.write=function(val){
			if((typeof val=='number')){
				if(!(((typeof val=='number')&& Math.floor(val)==val))){
					this.WriteB.writeByte(5);
					this.WriteB.writeDouble(val);
					return;
				};
				var n=Math.abs(val);
				if(n < 127){
					this.WriteB.writeByte(1);
					this.WriteB.writeByte(val);
				}
				else if(n < 32767){
					this.WriteB.writeByte(2);
					this.WriteB.writeShort(val);
				}
				else if(n < /*no*/this.int.MAX_VALUE){
					this.WriteB.writeByte(3);
					this.WriteB.writeInt(val);
				}
				else{
					this.WriteB.writeByte(5);
					this.WriteB.writeDouble(val);
				}
			}
			else if((typeof val=='string')){
				this.WriteB.writeByte(4);
				this.WriteB.writeUTF(val);
			}
			else if(Laya.__isClass(val)){
				this.WriteB.writeByte(4);
				this.WriteB.writeUTF("");
			}
			else if(val==null){
				this.WriteB.writeByte(8);
			}
			else if((typeof val=='boolean')){
				this.WriteB.writeByte(7);
				if(val==true)this.WriteB.writeByte(1);
				else this.WriteB.writeByte(0);
			}
			else if((val instanceof Array)){
				this.WriteB.writeByte(6);
				this.write(val.length);
				for(var i=0;i<val.length;i++){
					this.write(val[i]);
				}
				return;
			}
			else if((val instanceof com.MyClass.ByteArray )){
				this.WriteB.writeByte(10);
				this.write(val.length);
				this.WriteB.writeBytes(val,0,val.length);
			}
			else if((val instanceof Dictionary)){
				var dic=val;
				var arr_key=dic.keys;
				var arr_val=dic.values;
				this.WriteB.writeByte(9);
				this.write(arr_key.length);
				for(var i2=0;i2<arr_key.length;i2++){
					this.write(arr_key[i2]);
					this.write(arr_val[i2]);
				}
			}
			else if((typeof val=='object')){
				arr_key=[];
				arr_val=[];
				for(var key in val){
					if((typeof key=='string')|| (typeof key=='number')){
						arr_key.push(key);
						arr_val.push(val[key]);
					}
					else
					throw new Error("dic中只能用字符串做key");
				}
				this.WriteB.writeByte(9);
				this.write(arr_key.length);
				for(i2=0;i2<arr_key.length;i2++){
					this.write(arr_key[i2]);
					this.write(arr_val[i2]);
				}
			}
			else{
				this.WriteB.writeByte(8);
			}
		}

		//throw new ArgumentError("Unkownd Type In MyByteArray!");
		__proto.readF=function(buf){
			var _$this=this;
			this.Arr_val=[];
			buf.position=0;
			while(buf.bytesAvailable > 0){
				this.Arr_val.push(readNext());
			}
			function readNext (){
				var val;
				var n=buf.readByte();
				if(n==1)val=buf.readByte();
				else if(n==2)val=buf.readShort();
				else if(n==3)val=buf.readInt();
				else if(n==4){
					val=Tool_StringBuild.replaceSTR(buf.readUTF(),"\\n","\n");
				}
				else if(n==5)val=buf.readDouble();
				else if(n==6){
					var lenType=buf.readByte();
					var len=0;
					if(lenType==1)len=buf.readByte();
					else if(lenType==2)len=buf.readShort();
					var arr=[];
					for(;len>0;len--){
						arr.push(readNext());
					}
					return arr;
				}
				else if(n==7){
					val=Tool_Function.on强制转换(buf.readByte());
					if(val==0)return false;
					else return true;
				}
				else if(n==8){
					return null;
				}
				else if(n==9){
					var dic={};
					lenType=buf.readByte();
					if(lenType==1)len=buf.readByte();
					else if(lenType==2)len=buf.readShort();
					var key;
					for(;len>0;len--){
						key=readNext();
						dic[key]=readNext();
					}
					return dic;
				}
				else if(n==10){
					var b=new ByteArray();
					var l=readNext();
					buf.readBytes(b,0,l);
					val=b;
				}
				else{
					Config.Log("Unkownd Type In MyByteArray's readF!CMD=="+_$this.CMD+",n=="+n);
					return null;
				}
				return val;
			}
		}

		return MyByteArray;
	})(ByteArray)


	//class Games.Fights.Fight_Action_Hurt extends Games.Fights.Fight_ActionDefault
	var Fight_Action_Hurt=(function(_super){
		function Fight_Action_Hurt(r,info){
			this.need击飞=100;
			this.needTime=0.3;
			this.needZ=30;
			this.G=NaN;
			this.tFrame=0;
			this.spdx=NaN;
			this.spdy=NaN;
			this.spdz=NaN;
			Fight_Action_Hurt.__super.call(this,r);
			this.url="mc_"+this.Role.RoleID+"_hurt_";
			if(info==null && SData_Roles.getInstance().Dic[this.Role.RoleID]){
				info=SData_Roles.getInstance().Dic[this.Role.RoleID]["挨打"];
				if(info){}
					}
		}

		__class(Fight_Action_Hurt,'Games.Fights.Fight_Action_Hurt',_super);
		var __proto=Fight_Action_Hurt.prototype;
		__proto.resetF=function(){
			_super.prototype.resetF.call(this);
			this.Role.onRotateToTar();
			this.add无敌();
			if(this.Role.roleMC){
				this.Role.roleMC.alpha=0.5;
				this.Role.roleMC.loop=false;
			};
			var waitex=NaN;
			var waitey=NaN;
			if(this.Role.rotation <=90){
				waitex=-Math.sin(starling.utils.deg2rad(this.Role.rotation))*this.need击飞;
				waitey=Math.cos(starling.utils.deg2rad(this.Role.rotation))*this.need击飞;
				}else if(this.Role.rotation <=180){
				waitex=-Math.sin(starling.utils.deg2rad(180-this.Role.rotation))*this.need击飞;
				waitey=-Math.cos(starling.utils.deg2rad(180-this.Role.rotation))*this.need击飞;
				}else if(this.Role.rotation <=270){
				waitex=Math.sin(starling.utils.deg2rad(this.Role.rotation-180))*this.need击飞;
				waitey=-Math.cos(starling.utils.deg2rad(this.Role.rotation-180))*this.need击飞;
				}else{
				waitex=Math.sin(starling.utils.deg2rad(360-this.Role.rotation))*this.need击飞;
				waitey=Math.cos(starling.utils.deg2rad(360-this.Role.rotation))*this.need击飞;
			}
			this.tFrame=this.needTime *Config.playSpeedTrue;
			this.spdx=waitex / this.tFrame;
			this.spdy=waitey / this.tFrame;
			this.G=-this.needZ *2 / (this.tFrame *this.tFrame);
			this.spdz=-this.G *this.tFrame;
		}

		__proto.enterF=function(){
			if (this.Role.roleMC){
				this.Role.roleMC.enterPlayF();
			}
			if(this.tFrame>0){
				this.tFrame--;
				this.Role.x+=this.spdx;
				this.Role.y+=this.spdy;
				this.Role.z+=this.spdz;
				this.spdz+=this.G;
				}else{
				this.Role.z=0;
				this.Role.waiteAction="站立";
			}
		}

		__proto.breakF=function(){
			this.Role.z=0;
			if(this.Role.roleMC){
				this.Role.roleMC.alpha=1;
			}
			_super.prototype.breakF.call(this);
		}

		return Fight_Action_Hurt;
	})(Fight_ActionDefault)


	//class Games.Fights.Fight_Action_Move extends Games.Fights.Fight_ActionDefault
	var Fight_Action_Move=(function(_super){
		function Fight_Action_Move(r,info){
			this.last方向=null;
			this.ang0=45/2;
			this.ang=45;
			Fight_Action_Move.__super.call(this,r);
			this.url="mc_"+this.Role.RoleID+"_walk_";
		}

		__class(Fight_Action_Move,'Games.Fights.Fight_Action_Move',_super);
		var __proto=Fight_Action_Move.prototype;
		__proto.onChangeRoleMC属性=function(){
			if(this.Role.roleMC){
				this.Role.roleMC.loop=true;
				this.Role.roleMC.fps=12;
			}
		}

		__proto.resetF=function(){
			_super.prototype.resetF.call(this);
			this.onChangeRoleMC属性();
			this.last方向=this.Role.now方向;
		}

		__proto.enterF=function(){
			this.Role.onRotateToTar();
			if(this.Role.roleMC){
				this.Role.roleMC.enterPlayF();
			}
			if(this.Role.moveController){
				var angle=this.Role.moveController.getNow方向();
				if (angle==-1){
					this.Role.changeRoleFlag("站立");
					return;
				}
				this.on控制方向(angle);
			}
			if(this.last方向 !=this.Role.now方向){
				this.last方向=this.Role.now方向;
				this.onChangeRoleMcByURL();
				this.onChangeRoleMC属性();
			}
			if(this.Role.atkController){
				if(this.Role.atkController.isDownNomalAtk()==true){
					this.Role.waiteAction="普攻";
					return;
				}
			}
		}

		__proto.on控制方向=function(angle){
			if (angle==-1){return;};
			var spd=this.Role.moveSpd;
			var spdx=NaN;
			var spdy=NaN;
			if(this.Role.tarRole==null){
				if(angle>this.Role.rotation){
					if(angle-this.Role.rotation <=this.Role.rotateSpd){this.Role.rotation=angle;}
						else {this.Role.rotation+=this.Role.rotateSpd;}
					}else{
					if(this.Role.rotation-angle <=this.Role.rotateSpd){this.Role.rotation=angle;}
						else {this.Role.rotation-=this.Role.rotateSpd;}
				}
			}
			if (angle==0){
				spdx=0;
				spdy=-spd;
				}else if (angle <=180){
				spdx=spd *Math.sin(starling.utils.deg2rad(angle));
				spdy=-spd *Math.cos(starling.utils.deg2rad(angle));
				}else {
				angle-=360;
				spdx=-spd *Math.sin(starling.utils.deg2rad(-angle));
				spdy=-spd *Math.cos(starling.utils.deg2rad(-angle));
			}
			this.Role.x+=spdx;
			this.Role.y+=spdy;
			if(this.Role.x<this.Role.minx){this.Role.x=this.Role.minx;}
				else if(this.Role.x>this.Role.maxx){this.Role.x=this.Role.maxx;}
			if(this.Role.y<this.Role.miny){this.Role.y=this.Role.miny;}
				else if(this.Role.y>this.Role.maxy){this.Role.y=this.Role.maxy;}
		}

		return Fight_Action_Move;
	})(Fight_ActionDefault)


	//class Games.Fights.Fight_Action_SkillDefault extends Games.Fights.Fight_ActionDefault
	var Fight_Action_SkillDefault=(function(_super){
		function Fight_Action_SkillDefault(r){
			this.ID=0;
			this.cd=0;
			this.countCD=0;
			this.MCshow=null;
			this.is被动=false;
			this.is天赋=false;
			this.Arr_hurtFrame=null;
			this.Arr_hurt多段=null;
			this.Arr_hurtObj=null;
			this.Arr_打中=null;
			this.Count_动作=0;
			this.Count_硬直=0;
			this.NeedTime=0;
			this.pastTime=0;
			this.nowStep=-1;
			this.MCLight=null;
			this.MCGround=null;
			this.MCLight_AsMyMC=false;
			this.MCGround_AsMyMC=false;
			this.tmpPoint1={};
			this.tmpPoint2={};
			this.Time每帧=Tool_Function.on强制转换(1000/Config.playSpeedTrue);
			Fight_Action_SkillDefault.__super.call(this,r);
		}

		__class(Fight_Action_SkillDefault,'Games.Fights.Fight_Action_SkillDefault',_super);
		var __proto=Fight_Action_SkillDefault.prototype;
		__proto.setFramesByArr始末=function(arr始末){
			if(this.Arr_step==null){this.Arr_step=[];}
				if(arr始末==null){return;}
			for(var i=0;i<arr始末.length;i++){
				if(arr始末[i]==null){continue ;}
					if(this.Arr_step[i]==null){this.Arr_step[i]=[];}
				if(Tool_Function.isTypeOf(arr始末[i],Array)==true){
					if(arr始末[i][0]<arr始末[i][1]){
						for(var j=arr始末[i][0];j<=arr始末[i][1];j++){
							this.Arr_step[i].push(j);
						}
						}else{
						for(j=arr始末[i][0];j>=arr始末[i][1];j--){
							this.Arr_step[i].push(j);
						}
					}
					}else{
					if(arr始末[i]<arr始末[i+1]){
						for(j=arr始末[i];j<=arr始末[i+1];j++){
							this.Arr_step[i].push(j);
						}
						}else{
						for(j=arr始末[i+1];j>=arr始末[i+1];j--){
							this.Arr_step[i].push(j);
						}
					}
					i++;
				}
			}
		}

		__proto.resetF=function(){
			_super.prototype.resetF.call(this);
			this.nowStep=-1;
			this.onNextStepF();
		}

		__proto.onNextStepF=function(){
			this.Count_动作=0;
			this.pastTime=0;
			this.nowStep++;
			if(this.nowStep >=this.Arr_step.length){
				this.Role.waiteAction="站立";
				return;
			}
			this.on计算攻速();
		}

		__proto.on计算攻速=function(){
			this.NeedTime=this.Time每帧;
			var spd施法=this.Role.get属性("攻速");
			if(spd施法 !=0){
				this.NeedTime-=this.NeedTime *spd施法 *0.01;
				if(this.NeedTime<1){
					this.NeedTime=1;
				}
			}
		}

		__proto.cdF=function(){
			this.countCD--;
			if(this.countCD <=0){
				if(this.MCshow){
					this.MCshow.cdF(0);
				}
			}
			else{
				if(this.MCshow){
					this.MCshow.cdF(this.countCD/this.cd);
				}
			}
		}

		__proto.enterF=function(){
			if(this.countCD>0){this.cdF();};
			var 硬直=this.Role.get属性("霸体硬直");
			if(硬直>0){
				this.Role.change属性("霸体硬直",-1);
				this.pastTime+=this.Time每帧 / 2;
				}else{
				this.pastTime+=this.Time每帧;
			};
			var f2=Tool_Function.on强制转换(this.pastTime/this.NeedTime);
			while(this.Count_动作 < f2){
				if(this.nowStep==-1){return;}
					this.onNextFrame();
				if(this.pastTime==0){return;}
					if(this.Count_动作 >=this.Arr_step[this.nowStep].length){
					this.onNextStepF();
					break ;
				}
			}
			this.setMCLightXY();
		}

		__proto.onNextFrame=function(){
			if(this.Arr_step[this.nowStep]==null){return;}
				if(this.Count_动作 >=this.Arr_step[this.nowStep].length){return;};
			var hurtFIndex=0;
			var f=this.Arr_step[this.nowStep][this.Count_动作++]-1;
			this.onChangeRoleMcFrame(f);
			this.setMCLightFrame(f);
			hurtFIndex=-1;
			if(this.Arr_hurtFrame && this.Arr_hurtFrame[this.nowStep]!=null){
				if(Tool_Function.isTypeOf(this.Arr_hurtFrame[this.nowStep],Array)==true){
					hurtFIndex=this.Arr_hurtFrame[this.nowStep].indexOf(f+1);
					}else if(this.Arr_hurtFrame[this.nowStep]==f+1){
					hurtFIndex=0;
				}
			}
			if(hurtFIndex !=-1){
				this.onCheck攻击Obj(hurtFIndex);
			}
		}

		__proto.onChangeRoleMcFrame=function(f){
			if(this.Role.roleMC){
				this.Role.roleMC.gotoAndStop(f);
			}
		}

		__proto.onCheck攻击Obj=function(index){
			if(this.Role==null || this.Role.mainView==null || this.Arr_hurtObj==null || this.Arr_hurtObj[this.nowStep]==null){return;};
			var atkObj;
			if(Tool_Function.isTypeOf(this.Arr_hurtObj[this.nowStep],Array)==true){
				while(this.Arr_hurtObj[this.nowStep][index]==null && index>=0){
					index--;
				}
				atkObj=this.Arr_hurtObj[this.nowStep][index];
				}else{
				atkObj=this.Arr_hurtObj[this.nowStep];
			}
			if(atkObj==null){return;}
				atkObj=Tool_ObjUtils.getInstance().CopyF(atkObj);
			var dicRoles=this.Role.mainView.dicRoles;
			var tar;
			for(var nid=0 in dicRoles){
				if(nid==this.Role.ID){continue ;}
					tar=dicRoles[nid];
				if(tar==null || tar.isDead==true){continue ;}
					if(tar.阵营==this.Role.阵营){continue ;}
				if(tar.is无敌>0 || this.check范围(atkObj,tar)==false){continue ;}
					this.on攻击TarF(atkObj,tar);
			}
		}

		__proto.check范围=function(atkObj,tar){
			if(atkObj==null || tar==null){return false;}
				this.tmpPoint1.x=this.Role.Role_x;
			this.tmpPoint1.y=this.Role.Role_y;
			this.tmpPoint2.x=tar.Role_x;
			this.tmpPoint2.y=tar.Role_y;
			var L=Tool_Function.on计算两点距离(this.tmpPoint1,this.tmpPoint2);
			L-=tar.role半径;
			if(L>atkObj["距离"]){return false;};
			var ang=Tool_Function.on计算两点角度(this.tmpPoint1,this.tmpPoint2);
			var mRotation=0;
			switch(this.Role.now方向){
				case "上":mRotation=0;break ;
				case "右上":mRotation=45;break ;
				case "右":mRotation=90;break ;
				case "右下":mRotation=135;break ;
				case "下":mRotation=180;break ;
				case "左下":mRotation=180+45;break ;
				case "左":mRotation=270;break ;
				case "左上":mRotation=270+45;break ;
				}
			ang=ang-mRotation;
			for(var i=0;i<atkObj["角度"].length;i+=2){
				if(ang>=atkObj["角度"][i] && ang<=atkObj["角度"][i+1]){
					return true;
				}
			}
			return false;
		}

		/**
		*攻击其他角色
		**/
		__proto.on攻击TarF=function(atkObj,tar){
			var atk=this.Role.get属性("攻击力");
			this.Role.checkBuffF("攻击前",tar);
			if(this.Role.tmpDicBuffEffect){
				if(this.Role.tmpDicBuffEffect["伤害增加"]!=null){
					if(this.Role.tmpDicBuffEffect["伤害增加"]["百分比"]==true){
						atk+=atk *this.Role.tmpDicBuffEffect["伤害增加"]["值"];
						}else{
						atk+=this.Role.tmpDicBuffEffect["伤害增加"]["值"];
					}
				}
				Tool_ObjUtils.getInstance().onClearObj(this.Role.tmpDicBuffEffect);
			}
			tar.beHurtF(atk,this.Role);
			this.Role.tarRole=tar;
		}

		//---------------------------------------------------------------------------
		__proto.setMCLightFrame=function(f){
			if(this.MCLight){
				if(this.MCLight_AsMyMC==false){
					if(f >=this.MCLight.totalFrames){return;}
						this.MCLight.gotoAndStop(f);
				}
				else{
					(this.MCLight).nextFrame();
				}
			}
			this.setMCGroundFrame(f);
		}

		__proto.setMCGroundFrame=function(f){
			if(this.MCGround){
				if(this.MCGround_AsMyMC==false){
					if(f >=this.MCGround.totalFrames){return;}
						this.MCGround.gotoAndStop(f);
				}
				else{
					if(this.MCGround.currentFrame >=this.MCGround.totalFrames-1){
						this.MCGround=Tool_ObjUtils.getInstance().destroyF_One(this.MCGround);
					}
					else{
						(this.MCGround).nextFrame();
					}
				}
			}
		}

		__proto.setMCLightXY=function(){
			if(this.MCLight){
				this.MCLight.x=this.Role.Role_x;
				this.MCLight.y=this.Role.Role_y-this.Role.Role_z;
			}
			this.setMCGroundXY();
		}

		__proto.setMCGroundXY=function(){
			if(this.MCGround){
				this.MCGround.x=this.Role.Role_x;
				this.MCGround.y=this.Role.Role_y;
			}
		}

		__proto.onClearArr_打中=function(){
			if(this.Arr_hurt多段 !=null){
				if(this.Arr_打中==null)this.Arr_打中=[];
				for(var i=0;i<this.Arr_step.length;i++){
					if(this.Arr_打中[i]==null){
						this.Arr_打中[i]=[];
					}
					else{
						this.Arr_打中[i].length=0;
					}
				}
			}
		}

		__proto.breakF=function(){
			_super.prototype.breakF.call(this);
			this.nowStep=-1;
		}

		__proto.destroyF=function(){
			_super.prototype.destroyF.call(this);
			this.MCshow=Tool_ObjUtils.getInstance().destroyF_One(this.MCshow);
			this.tmpPoint1=null;
			this.tmpPoint2=null;
		}

		return Fight_Action_SkillDefault;
	})(Fight_ActionDefault)


	//class Games.Fights.Fight_Action_Stand extends Games.Fights.Fight_ActionDefault
	var Fight_Action_Stand=(function(_super){
		function Fight_Action_Stand(r,info){
			this.last方向=null;
			Fight_Action_Stand.__super.call(this,r);
			this.url="mc_"+this.Role.RoleID+"_stand_";
		}

		__class(Fight_Action_Stand,'Games.Fights.Fight_Action_Stand',_super);
		var __proto=Fight_Action_Stand.prototype;
		__proto.onChangeRoleMC属性=function(){
			if(this.Role.roleMC){
				this.Role.roleMC.loop=true;
			}
		}

		__proto.resetF=function(){
			_super.prototype.resetF.call(this);
			this.onChangeRoleMC属性();
			this.last方向=this.Role.now方向;
		}

		__proto.enterF=function(){
			this.Role.onRotateToTar();
			if(this.last方向 !=this.Role.now方向){
				this.last方向=this.Role.now方向;
				this.onChangeRoleMcByURL();
				this.onChangeRoleMC属性();
			}
			if(this.Role.roleMC){
				this.Role.roleMC.enterPlayF();
			}
			if(this.Role.moveController){
				var angle=this.Role.moveController.getNow方向();
				if(angle!=-1){
					this.Role.waiteAction="移动";
					return;
				}
			}
			if(this.Role.atkController){
				if(this.Role.atkController.isDownNomalAtk()==true){
					this.Role.waiteAction="普攻";
					return;
				}
			}
		}

		return Fight_Action_Stand;
	})(Fight_ActionDefault)


	//class Games.Fights.Fight_Action_NorAtk extends Games.Fights.Fight_Action_SkillDefault
	var Fight_Action_NorAtk=(function(_super){
		function Fight_Action_NorAtk(r,info){
			Fight_Action_NorAtk.__super.call(this,r);
			this.url="mc_"+this.Role.RoleID+"_atk1_";
			if(info==null && SData_Roles.getInstance().Dic[this.Role.RoleID]){
				info=SData_Roles.getInstance().Dic[this.Role.RoleID]["普攻"];
				if(info){
					if(info["frame始末"]){
						this.setFramesByArr始末(info["frame始末"]);
					}
					this.Arr_hurtFrame=info["Arr_hurtFrame"];
					this.Arr_hurtObj=Tool_ObjUtils.getInstance().CopyF(info["Arr_hurtObj"]);
				}
			}
		}

		__class(Fight_Action_NorAtk,'Games.Fights.Fight_Action_NorAtk',_super);
		return Fight_Action_NorAtk;
	})(Fight_Action_SkillDefault)


	//class Games.Fights.Fight_Action_Skill1_Rush extends Games.Fights.Fight_Action_SkillDefault
	var Fight_Action_Skill1_Rush=(function(_super){
		function Fight_Action_Skill1_Rush(r,info){
			this.ID=1;
			Fight_Action_Skill1_Rush.__super.call(this,r);
			this.is天赋=true;
			Tool_Function.on修改属性ByDic(this,info);
		}

		__class(Fight_Action_Skill1_Rush,'Games.Fights.Fight_Action_Skill1_Rush',_super);
		return Fight_Action_Skill1_Rush;
	})(Fight_Action_SkillDefault)


	//class starling.display.Sprite extends laya.display.Sprite
	var Sprite1=(function(_super){
		function Sprite(){
			this._touchable=false;
			Sprite.__super.call(this);
		}

		__class(Sprite,'starling.display.Sprite',_super,'Sprite1');
		var __proto=Sprite.prototype;
		__proto.removeFromParent=function(dispose){
			(dispose===void 0)&& (dispose=false);
			if(this.parent){
				this.parent.removeChild(this);
			}
			if(dispose){
				this.destroy();
			}
		}

		__getset(0,__proto,'touchable',function(){
			return this._touchable;
			},function(value){
			this._touchable=value;
			this.mouseEnabled=value;
		});

		__getset(0,__proto,'touchGroup',null,function(value){
		});

		return Sprite;
	})(Sprite)


	//class com.MyClass.MyView.BTN_Starling extends laya.display.Sprite
	var BTN_Starling=(function(_super){
		function BTN_Starling(tar,fClick,fd,fu){
			this.ID=null;
			this.Tar=null;
			this.Pause=false;
			this.isMc=false;
			this.isDown=false;
			this.FClick=null;
			this.FDown=null;
			this.FUp=null;
			this.BtnVir=null;
			BTN_Starling.__super.call(this);
			this.Tar=tar;
			this.mouseEnabled=true;
			Tool_SpriteUtils.onAddchild_替换父类(this,this.Tar);
			this.FClick=fClick;
			if(this.FClick)this.FClick.once=false;
			this.FDown=fd;
			if(this.FDown)this.FDown.once=false;
			this.FUp=fu;
			if(this.FUp)this.FUp.once=false;
			this.Tar.mouseEnabled=true;
			this.Tar.autoSize=true;
			this.Tar.width=this.Tar.width;
			this.Tar.height=this.Tar.height;
			this.Tar.autoSize=false;
			this.isMc=(this.Tar instanceof lzm.starling.swf.display.SwfMovieClip );
			this.Tar.on("mousedown",this,this.onDownF);
			this.Tar.on("mouseout",this,this.onOutF);
			this.Tar.on("mouseup",this,this.onUpF);
			this.onChangeFrame(0);
			var rec=this.getBounds();
			this.BtnVir={"startX":rec.x,"startT":rec.y,"endX":rec.right,"endY":rec.bottom};
		}

		__class(BTN_Starling,'com.MyClass.MyView.BTN_Starling',_super);
		var __proto=BTN_Starling.prototype;
		__proto.initTouch=function(fd,fu,fc,val){
			this.FClick=fc;
			if(this.FClick)this.FClick.once=false;
			this.FDown=fd;
			if(this.FDown)this.FDown.once=false;
			this.FUp=fu;
			if(this.FUp)this.FUp.once=false;
		}

		__proto.onDownF=function(e){
			if(this.Pause)return;
			if(this.isDown)return;
			this.isDown=true;
			if(this.FDown){
				if(this.ID==null)this.FDown.run();
				else this.FDown.runWith(this.ID);
			}
			this.onChangeFrame(1);
		}

		__proto.onUpF=function(e){
			if(this.isDown==false)return;
			this.isDown=false;
			this.onChangeFrame(0);
			if(this.Pause)return;
			if(e){
				if(this.ID==null)this.FClick.run();
				else this.FClick.runWith(this.ID);
				}else if(this.FUp){
				if(this.ID==null)this.FUp.run();
				else this.FUp.runWith(this.ID);
			}
		}

		__proto.onOutF=function(e){
			this.onUpF(null);
		}

		__proto.onChangeFrame=function(f){
			if(this.isMc==false || this.Tar==null)return;
			if((this.Tar).totalFrames <=f)return;
			(this.Tar).gotoAndStop(f,false);
		}

		__proto.set手动清理=function(){}
		__proto.destroyF=function(){
			this.removeSelf();
			this.Tar.off("mousedown",this,this.onDownF);
			this.Tar.off("mouseout",this,this.onOutF);
			this.Tar.off("mouseup",this,this.onUpF);
			this.Tar=null;
			if(this.FClick){
				this.FClick.clear();
				this.FClick=null;
			}
			if(this.FDown){
				this.FDown.clear();
				this.FDown=null;
			}
			if(this.FUp){
				this.FUp.clear();
				this.FUp=null;
			}
		}

		BTN_Starling.Frame_Nor=0;
		BTN_Starling.Frame_Down=1;
		BTN_Starling.Frame_Selected=2;
		return BTN_Starling;
	})(Sprite)


	//class com.MyClass.MyView.ImageNum extends laya.display.Sprite
	var ImageNum=(function(_super){
		function ImageNum(fname,_合并的swf){
			this.SwfName=null;
			this.FrontName=null;
			this.Layer=null;
			this.L=0;
			this.W=-1;
			this.Arr_Save=[];
			this.tm=null;
			this.NowStr=null;
			this.MidL=0;
			this.vAlin="左";
			this.MinL=-1;
			this.Col=-1;
			this.Only数字上色=false;
			this.父Type=null;
			this.is万代替=-1;
			this.FunRunover=null;
			this.NowNum=NaN;
			this.EndNum=0;
			this.SpdNum=NaN;
			this.RunTime=0;
			this.STR_head=null;
			this.STR_tail=null;
			this.Arr数字=["0","1","2","3","4","5","6","7","8","9","+","-","."];
			ImageNum.__super.call(this);
			this.SwfName=_合并的swf;
			this.FrontName=fname;
		}

		__class(ImageNum,'com.MyClass.MyView.ImageNum',_super);
		var __proto=ImageNum.prototype;
		__proto.addSource=function(arr){
			if(arr==null)arr=[];
			arr.push([this.SwfName,"swf","FrontSource/"+this.SwfName]);
			return arr;
		}

		__proto.setValue=function(str,val){
			switch (str){
				case "间隔":this.MidL=val;break ;
				case "对齐":this.vAlin=val;break ;
				case "最少位数":this.MinL=val;break ;
				case "颜色":
					if(this.Col==val)return;
					this.Col=val;
					for(var i=0;i<this.Arr_Save.length;i++){
						if(this.Only数字上色 && this.Arr_Save[i][2]==true)continue ;
					}
					break ;
				case "颜色仅数字":
					this.Only数字上色=val;
					if(this.Col !=-1){
						var tmpCol=this.Col;
						this.Col=-1;
						this.setValue("颜色",tmpCol);
					}
					break ;
				case "父对象":
					if((val instanceof starling.display.Image )){
						val.parent.addChildAt(this,val.parent.getChildIndex(val));
						val.parent.removeChild(val);
						this.x=val.x;
						this.y=val.y;
						this.父Type="img";
					}
					else if((val instanceof laya.display.Sprite )){
						(val).removeChildren();
						(val).addChild(this);
						this.父Type="spr";
					}
					break ;
				case "x":
					if(this.父Type=="spr" && (this.parent instanceof laya.display.Sprite )){
						(this.parent).x=val;
					}
					else this.x=val;
					break ;
				case "y":
					if(this.父Type=="spr" && (this.parent instanceof laya.display.Sprite )){
						(this.parent).y=val;
					}
					else this.y=val;
					break ;
				case "stage监听":
					this.on("removed",this,this.onRemoveF);
					break ;
				case "万":
					this.is万代替=val;
					break ;
				}
		}

		__proto.showF=function(val){
			if(this.Layer==null){
				this.Layer=new SwfSprite();
				this.addChild(this.Layer);
				this.tm=MySourceManager.getInstance();
			}
			else{
				this.Layer.removeChildren();
				this.clearSaveF();
			}
			if(val==null)val="";
			else if((typeof val=='number')&& this.is万代替>0 && val >=this.is万代替){
				val=int(val / 10000)+"万";
			}
			this.NowStr=String(val);
			this.L=this.NowStr.length;
			if(this.L==0)return;
			var more0=-1;
			if(this.L < this.MinL){more0=this.MinL-this.L;this.L=this.MinL;}
				for(var i=0;i<this.L;i++){
				var char=this.NowStr.charAt(i);
				if(more0-->=0)char="0";
				if(char==".")char="小数点";
				var is数字=true;
				var img;
				img=ImageNum.get缓存(this.FrontName+char,this.SwfName);
				if(img==null)img=this.tm.getImgFromSwf(this.SwfName,"img_"+this.FrontName+"Num_"+char);
				if(this.Arr数字.indexOf(char)==-1)is数字=false;
				if(is数字==false)this.Arr_Save.push([char,img]);
				else this.Arr_Save.push([char,img,true]);
				if(this.W==-1){
					var imgW=this.tm.getImgFromSwf(this.SwfName,"img_"+this.FrontName+"FrontWidth");
					if(imgW==null)this.W=img.width+img.pivotX;
					else this.W=imgW.width;
				}
				if(img){
					img.x=i *this.W+this.MidL;
					if(this.Col !=-1){
					}
					this.Layer.addChild(img);
				}
			}
			if(this.vAlin=="左")this.Layer.x=0;
			else if(this.vAlin=="中")this.Layer.x=-(this.L *this.W+(this.L-1)*this.MidL)/2+this.W/2;
			else if(this.vAlin=="右")this.Layer.x=-(this.L *this.W+(this.L-1)*this.MidL)+this.W;
		}

		__proto.runF=function(fend,s,e,t,head,tail){
			this.FunRunover=fend;
			this.NowNum=s;
			this.EndNum=e;
			this.RunTime=t;
			this.STR_head=head;if(this.STR_head==null)this.STR_head="";
			this.STR_tail=tail;if(this.STR_tail==null)this.STR_tail="";
			this.SpdNum=(this.EndNum-this.NowNum)/t;
			this.showF(this.STR_head+int(this.NowNum)+this.STR_tail);
			MainManager._instence.addEnterFrameFun(this.runCheck);
		}

		__proto.runCheck=function(){
			if(this.NowNum==this.EndNum){
				MainManager._instence.removeEnterFrameFun(this.runCheck);
				if(this.FunRunover)this.FunRunover();
				return;
			}
			this.NowNum+=this.SpdNum;
			if(this.SpdNum > 0 && this.NowNum > this.EndNum)this.NowNum=this.EndNum;
			else if(this.SpdNum < 0 && this.NowNum < this.EndNum)this.NowNum=this.EndNum;
			if(--this.RunTime <=0)this.NowNum=this.EndNum;
			this.showF(this.STR_head+int(this.NowNum)+this.STR_tail);
		}

		__proto.getValue=function(want){
			switch (want){
				case "右边x":;
					var x0=NaN;
					if(this.vAlin=="左")x0=this.x+(this.L *this.W+(this.L-1)*this.MidL);
					else if(this.vAlin=="中")x0=this.x-this.Layer.x+this.W;
					else if(this.vAlin=="右")x0=this.x;
					if(this.父Type=="spr")x0+=(this.parent).x;
					return x0;
					break ;
				default :return this[want];break ;
				}
		}

		__proto.onRemoveF=function(e){
			this.offAll();
			this.destroyF();
		}

		__proto.destroyF=function(){
			if(this.Layer){
				this.Layer.destroy();
				this.Layer=null;
			}
			this.tm=null;
			this.clearSaveF();
			this.destroy();
		}

		__proto.clearSaveF=function(){
			for(var i=0;i<this.Arr_Save.length;i++){
				if(this.Arr_Save[i][1]){
					ImageNum.add缓存(this.FrontName+this.Arr_Save[i][0],this.SwfName,this.Arr_Save[i][1]);
				}
				this.Arr_Save.splice(i--,1);
			}
		}

		ImageNum.addNeed缓存=function(fName,real){
			ImageNum.Need缓存.set(fName,real);
		}

		ImageNum.removeNeed缓存=function(fName){
			if(fName==null){
				ImageNum.Need缓存=new Dictionary();
				ImageNum.clearF();
			}
			else{
				ImageNum.Need缓存.set(fName,false);
			}
		}

		ImageNum.isNeed缓存=function(fName){
			var tar=ImageNum.Need缓存.get(fName);
			if(tar !=null){
				return tar;
			}
			return false;
		}

		ImageNum.get缓存=function(str,swf){
			if(ImageNum.isNeed缓存(str)==false)return null;
			if(ImageNum.Dic缓存==null)ImageNum.Dic缓存=new Dictionary();
			if(ImageNum.Dic缓存.keys.indexOf(swf)==-1){
				ImageNum.Dic缓存.set(swf,{});
			};
			var dicSwf=ImageNum.Dic缓存.get(swf);
			if(dicSwf[str]==null){
				dicSwf[str]=[];
			};
			var img;
			if(dicSwf[str].length > 0){
				img=dicSwf[str][0];
				(dicSwf[str]).shift();
			}
			return img;
		}

		ImageNum.add缓存=function(str,swf,obj){
			if(ImageNum.isNeed缓存(str)==false)return;
			if(ImageNum.Dic缓存==null)ImageNum.Dic缓存=new Dictionary();
			if(ImageNum.Dic缓存.keys.indexOf(swf)==-1){
				ImageNum.Dic缓存.set(swf,{});
			};
			var dicSwf=ImageNum.Dic缓存.get(swf);
			if(dicSwf[str]==null)dicSwf[str]=[];
			dicSwf[str].push(obj);
		}

		ImageNum.clearF=function(){
			if(ImageNum.Dic缓存==null)return;
			for(var j=0;j<ImageNum.Dic缓存.keys.length;j++){
				var swf=ImageNum.Dic缓存.keys[j];
				var dic=ImageNum.Dic缓存.get(swf);
				for(var key in dic){
					var arr=dic[key];
					for(var i=0;i<arr.length;i++){
						(arr[i]).destroy();
					}
					delete dic[key];
				}
			}
			ImageNum.Dic缓存=null;
		}

		ImageNum._手动缓存=function(fName,swf){
			ImageNum.addNeed缓存(fName,true);
			for(var i=0;i<10;i++){
				var count=5;
				while(count--> 0){
					ImageNum.add缓存(fName+i,swf,MySourceManager.instance.getImgFromSwf(swf,"img_"+fName+"Num_"+i));
				}
			}
		}

		ImageNum.Dic缓存=null
		__static(ImageNum,
		['Need缓存',function(){return this.Need缓存=new Dictionary();}
		]);
		return ImageNum;
	})(Sprite)


	//class com.MyClass.MyView.LoadingSmall extends laya.display.Sprite
	var LoadingSmall=(function(_super){
		function LoadingSmall(str){
			this.SWFPath="res/ANI_LoadingS.swf";
			this.mc=null;
			LoadingSmall.__super.call(this);
			MyTextInput.onHideF(true);
			this.mc=new MovieClip();
			this.mc.load(this.SWFPath);
			Laya.stage.addChild(this.mc);
		}

		__class(LoadingSmall,'com.MyClass.MyView.LoadingSmall',_super);
		var __proto=LoadingSmall.prototype;
		__proto.destroyF=function(){
			MyTextInput.onHideF(false);
			if(this.mc!=null){
				if(this.mc.parent!=null)this.mc.parent.removeChild(this.mc);
				this.mc.destroy();
				this.mc=null;
			}
		}

		LoadingSmall.showF=function(str){
			if(LoadingSmall.One==null){
				LoadingSmall.One=new LoadingSmall(str);
			}
		}

		LoadingSmall.removeF=function(e){
			if(LoadingSmall.One !=null){
				LoadingSmall.One.destroyF();
				LoadingSmall.One=null;
			}
		}

		LoadingSmall.One=null
		return LoadingSmall;
	})(Sprite)


	//class com.MyClass.MyView.MYLayaAIR_S9Image extends laya.display.Sprite
	var MYLayaAIR_S9Image=(function(_super){
		function MYLayaAIR_S9Image(){
			this.classLink=null;
			MYLayaAIR_S9Image.__super.call(this);
			var g=new AutoBitmap();
			this.graphics=g;
		}

		__class(MYLayaAIR_S9Image,'com.MyClass.MyView.MYLayaAIR_S9Image',_super);
		var __proto=MYLayaAIR_S9Image.prototype;
		__proto.destroy=function(destroyChild){
			(destroyChild===void 0)&& (destroyChild=true);
			if(this.graphics)this.graphics.destroy();
			_super.prototype.destroy.call(this,true);
		}

		__getset(0,__proto,'sizeGrid',function(){
			if ((this.graphics).sizeGrid)return (this.graphics).sizeGrid.join(",");
			return null;
			},function(value){
			(this.graphics).sizeGrid=UIUtils.fillArray(Styles.defaultSizeGrid,value,Number);
		});

		/**
		*@copy laya.ui.AutoBitmap#source
		*/
		__getset(0,__proto,'source',function(){
			return (this.graphics).source;
			},function(value){
			if (!this.graphics)return;
			(this.graphics).source=value;
			this.event("loaded");
			this.repaint();
		});

		/**@inheritDoc */
		__getset(0,__proto,'width',_super.prototype._$get_width,function(value){
			_super.prototype._$set_width.call(this,value);
			(this.graphics).width=value==0 ? 0.0000001 :value;
		});

		/**@inheritDoc */
		__getset(0,__proto,'height',_super.prototype._$get_height,function(value){
			_super.prototype._$set_height.call(this,value);
			(this.graphics).height=value==0 ? 0.0000001 :value;
		});

		return MYLayaAIR_S9Image;
	})(Sprite)


	//class com.MyClass.MyView.TmpMovieClip_Ori extends laya.display.Sprite
	var TmpMovieClip_Ori=(function(_super){
		function TmpMovieClip_Ori(mc,f,type){
			this.Arr=[];
			this.Fun=null;
			this.Type=null;
			this.End=false;
			TmpMovieClip_Ori.__super.call(this);
			(type===void 0)&& (type="nor");
			this.Type=type;
			mc.once("complete",this,this.overF);
			this.Fun=f;
			this.addMC(mc);
		}

		__class(TmpMovieClip_Ori,'com.MyClass.MyView.TmpMovieClip_Ori',_super);
		var __proto=TmpMovieClip_Ori.prototype;
		__proto.addMC=function(mc){
			this.addChild(mc);
			this.Arr.push(mc);
		}

		__proto.overF=function(){
			for(var i=0;i<this.Arr.length;i++){
				var mc=this.Arr[i];
				mc.stop();
			}
			if(this.Type=="nor"){
				this.destroyF();
			}
			else if(this.Type=="点击"){
				this.addClickF();
			}
			else if(this.Type=="屏幕点击"){
				this.addScreenClickF();
			}
			else if(this.Type=="手动"){
				if(this.Fun !=null){
					Tool_Function.onRunFunction(this.Fun);
					this.Fun=null;
				}
			}
		}

		__proto.addClickF=function(){
			this.on("click",this,this.clickF);
		}

		__proto.clickF=function(e){
			this.destroyF();
		}

		__proto.addScreenClickF=function(){
			Config.mStage.on("click",this,this.stageClickF);
		}

		__proto.stageClickF=function(){
			Config.mStage.off("click",this,this.clickF);
			this.destroyF();
		}

		__proto.stopF=function(){
			for(var i=0;i<this.Arr.length;i++){
				var mc=this.Arr[i];
				mc.stop();
			}
		}

		__proto.playF=function(){
			for(var i=0;i<this.Arr.length;i++){
				var mc=this.Arr[i];
				mc.play();
			}
		}

		__proto.destroyF=function(){
			this.End=true;
			this.offAll();
			if(this.parent)this.parent.removeChild(this);
			for(var i=0;i<this.Arr.length;i++){
				var mc=this.Arr[i];
				if(mc && mc.parent)mc.parent.removeChild(mc);
			}
			this.Arr=null;
			if(this.Fun !=null){
				Tool_Function.onRunFunction(this.Fun);
				this.Fun=null;
			}
		}

		return TmpMovieClip_Ori;
	})(Sprite)


	//class LayaMainTrue extends laya.display.Sprite
	var LayaMainTrue=(function(_super){
		function LayaMainTrue(){
			LayaMainTrue.__super.call(this);
			Config.适配方式=2;
			Config.stageW=1136;
			Config.stageH=640;
			Laya.stage.scaleMode="exactfit";
			Laya.stage.screenMode="horizontal";
			Laya.stage.alignH="center";
			Laya.stage.alignV="middle";
			Laya.stage.frameRate=String(Config.playSpeedTrue);
			Stat.show();
			Config.mStage=this.stage;
			new MainClass();
		}

		__class(LayaMainTrue,'LayaMainTrue',_super);
		return LayaMainTrue;
	})(Sprite)


	//class com.MyClass.MyView.LoadingView extends starling.display.Sprite
	var LoadingView=(function(_super){
		function LoadingView(_all,id){
			this.sprBack=null;
			this.role=null;
			this.mt=null;
			this.maxWidth=0;
			this.all=0;
			this.now=0;
			this.picBack=null;
			this.lastPer=0;
			this.nextPer=0;
			this.per=0;
			LoadingView.__super.call(this);
			(id===void 0)&& (id=0);
			this.all=_all;
			var picUrl;
			var c;
			if(LoadingView.Need外部背景图){}
				this.sprBack=MySourceManager.getInstance().getObjFromSwf("SWF_Default","spr_Loadback");
			if(this.sprBack!=null){
				this.addChild(this.sprBack);
				this.role=this.sprBack.getChildByName("_mc");
				if(this.role){
					this.role.autoSize=true;
					this.maxWidth=this.role.width;
					this.role.autoSize=false;
				}
				this.mt=new MyViewTXController(this.sprBack);
				Tool_Function.on适配区域(this.sprBack);
				Config.mStage.addChild(this);
			}
			MainManager.getInstence().MEM.addListenF("加载进度",Handler.create(this,this.setNowper,null,false));
			this.now=this.all+1;
			this.setNowper();
		}

		__class(LoadingView,'com.MyClass.MyView.LoadingView',_super);
		var __proto=LoadingView.prototype;
		__proto.setNowper=function(val){
			if(this.now <=0)return;
			if((typeof val=='number')){
				this.per=this.lastPer+(this.nextPer-this.lastPer)*val;
				if(this.role){
					this.role.scaleX=(this.all-this.now)/ this.all;
				}
				if(this.mt){
					this.mt.set文字("tx_进度",this.per+"%");
				}
				return;
			}
			this.now--;
			this.lastPer=this.per;
			if(this.all > 0){
				this.per=Tool_Function.on强制转换((this.all-this.now)*100 / this.all+"");
				this.nextPer=Tool_Function.on强制转换((this.all-this.now+1)*100 / this.all+"");
				if(this.role){
					this.role.scaleX=(this.all-this.now)/ this.all;
				}
				if(this.mt){
					this.mt.set文字("tx_进度",this.per+"%");
				}
			}
			else{
				this.per=100;
				this.nextPer=100;
				if(this.role){
					this.role.scaleX=1;
				}
				if(this.mt)this.mt.set文字("tx_进度","100%");
			}
		}

		__proto.destroyF=function(){
			MainManager.getInstence().MEM.removeListenF("加载进度",this.setNowper);
			this.destroy();
			this.mt=Tool_ObjUtils.getInstance().destroyF_One(this.mt);
			if(this.picBack){
				this.picBack.destroy();
				this.picBack=null;
			}
		}

		LoadingView.Need外部背景图=false;
		LoadingView.ArrTips=null
		return LoadingView;
	})(Sprite1)


	//class com.MyClass.MyView.MyMC extends starling.display.Sprite
	var MyMC=(function(_super){
		function MyMC(mc){
			this.mmo=null;
			this.MC=null;
			this.NeedTime=0;
			this.pastTime=0;
			this.frameFunction=null;
			this.compFun=null;
			this.isPlay=false;
			this._loop=false;
			this._fps=0;
			this._currentFrame=0;
			this._totalFrames=0;
			this._autoStopChild=false;
			MyMC.__super.call(this);
			this.TimeFrame=parseInt(""+1000/Config.playSpeedTrue);
			this.MC=mc;
			this.fps=Config.playSpeedTrue;
			this.loop=false;
			this.autoStopChild=false;
			this.isPlay=false;
			MyMC.addF(this);
			if(this.MC!=null){
				this.addChild(this.MC);
				this.MC.stop(this.autoStopChild);
			}
		}

		__class(MyMC,'com.MyClass.MyView.MyMC',_super);
		var __proto=MyMC.prototype;
		__proto.enterPlayF=function(){
			this.pastTime+=this.TimeFrame;
			var f2=parseInt(""+this.pastTime/this.NeedTime);
			while(f2>0){
				this.nextFrame();
				f2--;
				this.pastTime-=this.NeedTime;
			}
		}

		__proto.enterPrePlayF=function(){
			this.pastTime+=this.TimeFrame;
			var f2=parseInt(""+this.pastTime/this.NeedTime);
			while(f2>0){
				this.preFrame();
				f2--;
				this.pastTime-=this.NeedTime;
			}
		}

		__proto.gotoF=function(f){
			if(this.MC !=null){
				if(f>=this.MC.totalFrames){
					if(this.MC.currentFrame>=this.MC.totalFrames-1)return;
					f=this.MC.totalFrames-1;
				}
				this.MC.gotoAndStop(f,this.autoStopChild);
				if(this.frameFunction)this.frameFunction();
				if(this.compFun){
					if(this.MC.currentFrame==this.MC.totalFrames-1)this.compFun();
				}
			}
		}

		__proto.nextFrame=function(){
			if(this.MC !=null){
				if(this.MC.currentFrame==this.MC.totalFrames-1){
					if(this.loop==true)this.gotoF(0);
				}
				else{
					this.gotoF(this.MC.currentFrame+1);
				}
			}
		}

		__proto.preFrame=function(){
			if(this.MC !=null){
				if(this.MC.currentFrame==0){
					if(this.loop==true)this.gotoF(this.MC.totalFrames-1);
				}
				else{
					this.gotoF(this.MC.currentFrame-1);
				}
			}
		}

		__proto.play=function(){
			if(this.mmo){
				return;
			}
			this.mmo=new MainManagerOne();
			this.mmo.addEnterFrameFun(this.onEnterF);
		}

		__proto.onEnterF=function(){
			this.enterPlayF();
			if(this.MC==null){
				this.mmo=Tool_ObjUtils.getInstance().destroyF_One(this.mmo);
				return;
			}
			if(this.loop==true)return;
			if(this.MC.currentFrame==this.MC.totalFrames-1){
				this.stop();
			}
		}

		__proto.stop=function(){
			this.pastTime=0;
			if(this.mmo){
				this.mmo=Tool_ObjUtils.getInstance().destroyF_One(this.mmo);
			}
		}

		__proto.gotoAndStop=function(f){
			this.gotoF(f);
			this.stop();
		}

		__proto.gotoAndPlay=function(f){
			this.pastTime=0;
			this.gotoF(f);
			this.play();
		}

		__proto.pauseF=function(){
			this.stop();
		}

		__proto.resumeF=function(){
			this.play();
		}

		/****************************清理***********************************/
		__proto.destroyF=function(){
			MyMC.removeF(this);
			this.frameFunction=null;
			this.compFun=null;
			this.MC=Tool_ObjUtils.getInstance().destroyF_One(this.MC);
			this.mmo=Tool_ObjUtils.getInstance().destroyF_One(this.mmo);
			this.destroy();
		}

		__getset(0,__proto,'currentFrame',function(){
			return this.MC.currentFrame;
		});

		/******************************FPS*********************************/
		__getset(0,__proto,'loop',function(){
			return this._loop;
			},function(value){
			this._loop=value;
		});

		__getset(0,__proto,'fps',function(){
			return this._fps;
			},function(value){
			this._fps=value;
			this.NeedTime=1000/this._fps;
		});

		__getset(0,__proto,'totalFrames',function(){
			return this.MC.totalFrames;
		});

		__getset(0,__proto,'autoStopChild',function(){
			return this._autoStopChild;
			},function(value){
			this._autoStopChild=value;
		});

		MyMC.addF=function(mc){
			MyMC.dicAll.set(mc,true);
		}

		MyMC.removeF=function(mc){
			MyMC.dicAll.remove(mc);
		}

		MyMC.pauseF=function(){
			for(var i=0;i<MyMC.dicAll.keys.length;i++){
				var mc=MyMC.dicAll.keys[i];
				if(mc){
					mc.pauseF();
				}
			}
		}

		MyMC.resumeF=function(){
			for(var i=0;i<MyMC.dicAll.keys.length;i++){
				var mc=MyMC.dicAll.keys[i];
				if(mc){
					mc.resumeF();
				}
			}
		}

		MyMC.onNewByMc=function(mc){
			if(mc==null)return null;
			return new MyMC(mc);
		}

		__static(MyMC,
		['dicAll',function(){return this.dicAll=new Dictionary();}
		]);
		return MyMC;
	})(Sprite1)


	//class com.MyClass.MyView.MyTextInput extends starling.display.Sprite
	var MyTextInput=(function(_super){
		function MyTextInput(_width,_height,_size){
			this.Name=null;
			this.ID=0;
			this.W=0;
			this.H=0;
			this.inputText=null;
			this.ChangedFun=null;
			this.visibleCount=1;
			MyTextInput.__super.call(this);
			(_size===void 0)&& (_size=-1);
			if(_size <=0)_size=20;
			this.ID=MyTextInput.Count++;
			MyTextInput.Dic.set(this.ID,this);
			this.inputText=new Input();
			this.inputText.size(_width,_height);
			this.inputText.bold=true;
			this.inputText.color="#ffffff";
			this.inputText.fontSize=_size;
		}

		__class(MyTextInput,'com.MyClass.MyView.MyTextInput',_super);
		var __proto=MyTextInput.prototype;
		__proto.initF=function(){
			this.addChild(this.inputText);
		}

		__proto.setValue=function(type,val){
			switch (type){
				case "颜色":
					if((typeof val=='string')){
						if(val=="红")this.inputText.color="#ff0000";
						else if(val=="白")this.inputText.color="#ffffff";
						else if(val=="黑")this.inputText.color="#000000";
						else if(val=="黄")this.inputText.color="#ffff00";
						else this.inputText.color=val;
					}
					break ;
				case "对齐":
					if(val=="左")this.inputText.align="left";
					else if(val=="中")this.inputText.align="center";
					else if(val=="右")this.inputText.align="right";
					break ;
				case "隐藏":
					if(val==true)this.visibleCount--;
					else this.visibleCount++;
					if(this.visibleCount==1){
						this.inputText.visible=true;
					}
					else if(this.visibleCount==0){
						this.inputText.visible=false;
					}
					break ;
				case "密码":
					this.inputText.asPassword=true;
					break ;
				case "仅数字":
					this.inputText.restrict="0-9";
					break ;
				case "输入事件":
					this.ChangedFun=val;
					break ;
				case "字号":
					this.inputText.fontSize=val;
					break ;
				}
		}

		__proto.onFocusOut=function(e){
			if(this.ChangedFun){
				if((this.ChangedFun instanceof laya.utils.Handler ))(this.ChangedFun).runWith(this.Name);
				else this.ChangedFun(this.Name);
			}
		}

		__proto.destroyF=function(){
			MyTextInput.Dic.remove(this.ID);
			this.inputText.destroy();
			this.inputText=null;
			this.ChangedFun=null;
			this.destroy();
		}

		__getset(0,__proto,'text',function(){
			return this.inputText.text;
			},function(value){
			if(this.visibleCount==1)this.inputText.text=value;
		});

		MyTextInput.onHideF=function(real){
			for(var i=0;i<MyTextInput.Dic.keys.length;i++){
				var id=MyTextInput.Dic.keys[i];
				MyTextInput.Dic.get(id).setValue("隐藏",real);
			}
		}

		MyTextInput.DestroyALL=function(){
			for(var i=0;i<MyTextInput.Dic.keys.length;i++){
				var id=MyTextInput.Dic.keys[i];
				MyTextInput.Dic.get(id).destroyF();
				MyTextInput.Dic.remove(id);
				i--;
			}
		}

		MyTextInput.getNewOne=function(spr,url,size,col){
			(size===void 0)&& (size=0);
			(col===void 0)&& (col="白");
			var tmpTX=spr.getChildByName(url);
			if(size<=0)size=tmpTX.height-3;
			var TX=new MyTextInput(tmpTX.width,tmpTX.height,size);
			var arr=url.split("_");
			TX.Name="txi_"+arr[1];
			if(arr.length>2){
				var info={};
				for(var j=2;j<arr.length;j++){
					var one=arr[j];
					if(one.indexOf("颜色")==0){
						one=one.slice(2);
						if(one.length==1)col=one;
						else if(one.indexOf("0x")!=0)col=int("0x"+one);
					}
					else if(one.indexOf("对齐")==0){
						TX.setValue("对齐",one.slice(2));
					}
					else if(one.indexOf("多行")==0){
						var num=int(one.slice(2));
						size=size / (num+1);
						TX.setValue("字号",size);
					}
				}
			}
			TX.x=tmpTX.x;
			TX.y=tmpTX.y;
			TX.setValue("颜色",col);
			spr.addChild(TX);
			TX.initF();
			return TX;
		}

		MyTextInput.Count=0;
		__static(MyTextInput,
		['Dic',function(){return this.Dic=new Dictionary();}
		]);
		return MyTextInput;
	})(Sprite1)


	//class lzm.starling.swf.display.SwfSprite extends starling.display.Sprite
	var SwfSprite=(function(_super){
		function SwfSprite(){
			this.classLink=null;
			this.data=null;
			this.spriteData=null;
			this.metaData=null;
			this.hit_半径=0;
			this.hit_半径2=0;
			this.hit_半径half=0;
			SwfSprite.__super.call(this);
		}

		__class(SwfSprite,'lzm.starling.swf.display.SwfSprite',_super);
		var __proto=SwfSprite.prototype;
		/*
		*meta数据
		*/
		__proto.setSpriteData=function(data){
			this.spriteData=data;
			if(this.spriteData && ((this.spriteData[0])instanceof Array)){
				this.setMetaData(this.spriteData[0]);
			}
		}

		__proto.setMetaData=function(data){
			this.metaData=data;
			if(this.metaData["鼠标区域"]){
				if(this.metaData["鼠标区域"]["形状"]=="圆"){
					this.hit_半径=this.metaData["鼠标区域"]["半径"];
					this.hit_半径half=this.hit_半径/2;
					this.hit_半径2=this.hit_半径 *this.hit_半径;
				}
			}
		}

		return SwfSprite;
	})(Sprite1)


	//class Games.Fights.Fight_MAP extends starling.display.Sprite
	var Fight_MAP=(function(_super){
		function Fight_MAP(__arg){
			this.infos=null;
			this.Layer_Ground=null;
			this.Layer_Up=null;
			this.mainPlugin=null;
			this.sortRolePlugin=null;
			Fight_MAP.__super.call(this);
			var arg=arguments;
			this.infos=arg[0];
			this.Layer_Ground=new Sprite1();
			this.addChild(this.Layer_Ground);
			this.Layer_Up=new Sprite1();
			this.addChild(this.Layer_Up);
			var showRec=this.infos["屏幕"];
			var infoMaps=this.infos["地图"];
			Fight_MAP.mapW0=infoMaps["w0"];
			Fight_MAP.mapH0=infoMaps["h0"];
			this.mainPlugin=Tool_Function.onNewClass(Plugins__map_topview_square,this.Layer_Ground,showRec,infoMaps,Handler.create(this,this.getNewGroundImg,null,false),{"边缘限制":false});
			this.mainPlugin.on刷新F(null);
		}

		__class(Fight_MAP,'Games.Fights.Fight_MAP',_super);
		var __proto=Fight_MAP.prototype;
		__proto.on刷新F=function(mainRole){
			if(this.mainPlugin){
				this.mainPlugin.on刷新F(mainRole);
			}
			if(this.sortRolePlugin){
				this.sortRolePlugin.enterF();
			}
			this.Layer_Up.x=this.Layer_Ground.x;
			this.Layer_Up.y=this.Layer_Ground.y;
		}

		__proto.addObjectF=function(role){
			if(Tool_Function.isTypeOf(role,Fight_Role)==true){
				this.addRoleF(role);
				}else if(Tool_Function.isTypeOf(role,Fight_MapItem)==true){
				this.addItems(role);
			}
		}

		__proto.addRoleF=function(role){
			if(this.mainPlugin && this.mainPlugin.roleMoveLimite){
				role.minx=this.mainPlugin.roleMoveLimite["minx"];
				role.maxx=this.mainPlugin.roleMoveLimite["maxx"];
				role.miny=this.mainPlugin.roleMoveLimite["miny"];
				role.maxy=this.mainPlugin.roleMoveLimite["maxy"];
				if(role.x<role.minx){role.x=role.minx;}
					else if(role.x>role.maxx){role.x=role.maxx;}
				if(role.y<role.miny){role.y=role.miny;}
					else if(role.y>role.maxy){role.y=role.maxy;};
				var spr影子=MySourceManager.getInstance().getSprFromSwf("SWF_FightUI","spr_影子");
				if(spr影子){
					role.Role影子=spr影子;
					this.Layer_Up.addChildAt(spr影子,0);
				}
			}
			Tool_Function.addChildF(this.Layer_Up,role.Role);
			if(this.sortRolePlugin){this.sortRolePlugin.on刷新冷却F();}
				}
		__proto.addItems=function(item){
			if(this.sortRolePlugin){this.sortRolePlugin.on刷新冷却F();}
				}
		__proto.removeObjectF=function(role){}
		__proto.getNewGroundImg=function(val){
			var img=MySourceManager.getInstance().getImgFromSwf("SWF_FightUI","img_G"+val);
			return img;
		}

		__proto.destroyF=function(){
			Tool_ObjUtils.getInstance().destroyDisplayObj(this);
			this.Layer_Ground=Tool_ObjUtils.getInstance().destroyF_One(this.Layer_Ground);
			this.Layer_Up=Tool_ObjUtils.getInstance().destroyF_One(this.Layer_Up);
			this.mainPlugin=Tool_ObjUtils.getInstance().destroyF_One(this.mainPlugin);
			this.sortRolePlugin=Tool_ObjUtils.getInstance().destroyF_One(this.sortRolePlugin);
		}

		Fight_MAP.mapW0=0;
		Fight_MAP.mapH0=0;
		return Fight_MAP;
	})(Sprite1)


	//class Games.Fights.ViewClass_FightMain extends starling.display.Sprite
	var ViewClass_FightMain=(function(_super){
		function ViewClass_FightMain(__arg){
			this.busy=false;
			this.Map=null;
			this.mainRole=null;
			this.dicRoles={};
			ViewClass_FightMain.__super.call(this);
			this.mso=new MySourceManagerOne();
			this.mmo=new MainManagerOne();
			var arg=arguments;
			MyPools.getInstance().registF("地图物品",null);
			LayerStarlingManager.instance.LayerView.addChild(this);
			var source=[
			["SWF_FightUI","swf"]];
			this.addRoleSource(source);
			this.addMapSource(source);
			this.mso.addSource(source,Handler.create(this,this.initF),true);
		}

		__class(ViewClass_FightMain,'Games.Fights.ViewClass_FightMain',_super);
		var __proto=ViewClass_FightMain.prototype;
		__proto.addRoleSource=function(source){}
		__proto.addMapSource=function(source){}
		__proto.initF=function(){
			var infoMap={};
			var x0=0;
			var y0=0;
			if(Config.适配方式==2){
				infoMap["屏幕"]={"width":Config._屏幕宽/Config.stageScale,"height":Config._屏幕高/Config.stageScale};
				}else{
				infoMap["屏幕"]={"width":Config.stageW,"height":Config.stageH};
			};
			var arrMaps=[
			[1,2,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1]
			,[1,2,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1]
			,[1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1]
			,[1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1]
			,[1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1]
			,[1,2,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1]
			,[1,2,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1]
			,[1,2,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1]
			,[1,2,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1]
			,[1,2,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1]
			,[1,2,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1]
			,[1,2,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1]
			,[1,2,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1]
			,[1,2,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1]
			,[1,2,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,2,1,1,1,1,1,1,1,1,2,1,1,1,1,1,1]];
			infoMap["地图"]={"w0":100,"h0":100,"类型":2,"地面数据":arrMaps};
			var dicItem={1:["0-4","3-5"]};
			this.Map=Tool_Function.onNewClass(Fight_MAP,infoMap);
			Tool_Function.addChildF(this,this.Map);
			var spr方向=this.mso.getSprFromSwf("SWF_FightUI","spr_方向按钮");
			this.addChild(spr方向);
			spr方向.y=Config.stageScaleInfo.屏幕h-spr方向.height;
			this.Map.sortRolePlugin=Tool_Function.onNewClass(Plugins_sortController,this.Map.Layer_Up,this.dicRoles,"Role","Role_y",1);
			if(dicItem){
				for(var itemid=0 in dicItem){}
			}
			this.mainRole=this.addRoleF({"ID":1,"阵营":1,"RoleID":1,"技能":[1],"初始角度":180,"属性":{"hp":100,"移速":4,"转速":15}});
			this.mainRole.atkController=Tool_Function.onNewClass(Fight_Role_AtkController,null,null);
			this.mainRole.moveController=Tool_Function.onNewClass(Plugins__moveControl_circleAll,spr方向,null);
			this.mmo.addEnterFrameFun(Handler.create(this,this.enterF,null,false));
			this.addRoleF({"ID":2,"阵营":2,"RoleID":1,"x":500,"y":500,"属性":{"hp":100,"移速":6,"转速":15}});
		}

		__proto.addMapItems=function(){}
		__proto.addRoleF=function(info){
			var role=Tool_Function.onNewClass(Fight_Role,info,this);
			if(role){
				if(this.dicRoles[role.ID] !=null){
					console.log("有重复的角色！"+role.ID);
				}
				this.dicRoles[role.ID]=role;
				this.Map.addRoleF(role);
			}
			return role;
		}

		__proto.removeRoleF=function(role){
			if(this.dicRoles==null){return;}
				delete this.dicRoles[role.ID];
			this.Map.removeRoleF(role);
		}

		__proto.enterF=function(){
			this.enterRoleF();
			this.enterMapF();
		}

		__proto.enterMapF=function(){
			if(this.Map==null){return;}
				this.Map.on刷新F(this.mainRole);
		}

		__proto.enterRoleF=function(){
			if(this.dicRoles==null){return;}
				for(var ID in this.dicRoles){
				if(this.dicRoles[ID]!=null){
					this.dicRoles[ID].enterF();
				}
			}
		}

		//=======================================
		__proto.destroyF=function(){
			MyPools.getInstance().removeF("地图物品");
			Tool_ObjUtils.getInstance().destroyDisplayObj(this);
			this.mso=Tool_ObjUtils.getInstance().destroyF_One(this.mso);
			this.mmo=Tool_ObjUtils.getInstance().destroyF_One(this.mmo);
			this.Map=Tool_ObjUtils.getInstance().destroyF_One(this.Map);
			this.dicRoles=Tool_ObjUtils.getInstance().destroyF_One(this.dicRoles);
		}

		return ViewClass_FightMain;
	})(Sprite1)


	//class Games.Login.ViewClass_Login extends starling.display.Sprite
	var ViewClass_Login=(function(_super){
		function ViewClass_Login(){
			this.sprBack=null;
			this.bc=null;
			ViewClass_Login.__super.call(this);
			this.mso=new MySourceManagerOne();
			LayerStarlingManager.instance.LayerView.addChild(this);
			var source=[
			["SWF_LoginView","swf"]
			,["SWF_Default","swf"]];
			this.mso.addSource(source,Handler.create(this,this.initF),true);
		}

		__class(ViewClass_Login,'Games.Login.ViewClass_Login',_super);
		var __proto=ViewClass_Login.prototype;
		__proto.initF=function(){
			this.sprBack=this.mso.getSprFromSwf("SWF_LoginView","spr_View");
			this.addChild(this.sprBack);
			Tool_Function.on适配区域(this.sprBack);
			this.bc=new MyViewBtnController(this.sprBack,Handler.create(this,this.onClickUIF));
		}

		__proto.onClickUIF=function(btn){
			if(btn=="btn_登录"){
				this.destroyF();
				MainManager.getInstence().MEM.dispatchF("Title_离开");
			}
		}

		// MainManager.getInstence().MEM.dispatchF(SData_EventNames.Lobby_进入);
		__proto.destroyF=function(){
			Tool_ObjUtils.getInstance().destroyDisplayObj(this);
			if(this.mso){
				this.mso.Arr_source.splice(1);
			}
			this.mso=Tool_ObjUtils.getInstance().destroyF_One(this.mso);
			this.sprBack=Tool_ObjUtils.getInstance().destroyF_One(this.sprBack);
			this.bc=Tool_ObjUtils.getInstance().destroyF_One(this.bc);
		}

		return ViewClass_Login;
	})(Sprite1)


	//class starling.display.Image extends starling.display.Sprite
	var Image1=(function(_super){
		function Image(){
			Image.__super.call(this);
		}

		__class(Image,'starling.display.Image',_super,'Image1');
		return Image;
	})(Sprite1)


	//class com.MyClass.MyView.MyZMovieClip extends lzm.starling.swf.display.SwfSprite
	var MyZMovieClip=(function(_super){
		function MyZMovieClip(url,f){
			this.Name=null;
			this.URL=null;
			this.Fun=null;
			this.zSpine=null;
			this.mArmature=null;
			this._loop=false;
			this.nowLabel=null;
			this.startFrame=0;
			this.endFrame=0;
			this.completeFunction=null;
			MyZMovieClip.__super.call(this);
			MyMC.addF(this);
			this.URL=url;
			this.Fun=f;
			var index=this.URL.lastIndexOf("/");
			this.Name=this.URL.substr(index+1);
			this.zSpine=new Templet();
			this.zSpine.on("complete",this,this.parseComplete);
			this.zSpine.on("error",this,this.onError);
			this.zSpine.loadAni(url);
		}

		__class(MyZMovieClip,'com.MyClass.MyView.MyZMovieClip',_super);
		var __proto=MyZMovieClip.prototype;
		__proto.parseComplete=function(fac){
			this.zSpine.offAll();
			if(fac==null){
				Tool_Function.onRunFunction(this.Fun,false);
				}else{
				Tool_Function.onRunFunction(this.Fun,true);
			}
			this.Fun=null;
		}

		__proto.onError=function(e){
			console.log("加载spine失败："+this.URL);
			this.parseComplete(null);
		}

		__proto.initF=function(){
			this.mArmature=this.zSpine.buildArmature(0);
			this.addChild(this.mArmature);
			this.mArmature.on("stopped",this,this.completeHandler);
			this.mArmature.on("label",this,this.onEvent);
			var allLabel=this.mArmature.getAnimNum();
			for(var i=0;i<allLabel;i++){
				console.log("index="+i,this.mArmature.getAniNameByIndex(i));
			}
		}

		__proto.onEvent=function(e){
			var tEventData=e;
			console.log("spine动画收到Label事件：",tEventData);
		}

		__proto.completeHandler=function(){
			console.log("completeHandler");
			Tool_Function.onRunFunction(this.completeFunction);
		}

		__proto.play=function(rePlayChildMovie){
			(rePlayChildMovie===void 0)&& (rePlayChildMovie=true);
			if(this.nowLabel==null){
				console.log(this.Name+"：spine：play失败，不应该没有label直接播放");
				return;
			}
			this.mArmature.resume();
		}

		__proto.gotoAndPlay=function(frame,rePlayChildMovie){
			(rePlayChildMovie===void 0)&& (rePlayChildMovie=false);
			if((typeof frame=='string')){
				this.gotoAndPlayLable(frame);
				}else{
				if(this.nowLabel==null){
					console.log(this.Name+"：spine：play失败，不应该没有label直接播放");
					return;
				}
				try{
					this.mArmature.index=frame;
					}catch(e){
					console.log(this.Name+"：spine：gotoAndPlay失败："+e.message);
					return;
				}
				this.play();
			}
		}

		__proto.gotoAndPlayLable=function(label){
			if(((typeof label=='number')&& Math.floor(label)==label)){
				label=this.mArmature.getAniNameByIndex(label);
			};
			var allLabel=this.mArmature.getAnimNum();
			for(var i=0;i<allLabel;i++){
				if(label==this.mArmature.getAniNameByIndex(i)){
					this.nowLabel=label;
					this.mArmature.play(i,this.loop,true);
					return;
				}
			}
			console.log("spine动画播放label："+label+"：失败");
		}

		__proto.gotoAndStop=function(frame,stopChild){
			(stopChild===void 0)&& (stopChild=false);
			if(this.zSpine){
				this.mArmature.index=frame;
			}
		}

		__proto.gotoAndStopLable=function(label){
			this.nowLabel=label;
			var allLabel=this.mArmature.getAnimNum();
			for(var i=0;i<allLabel;i++){
				if(label==this.mArmature.getAniNameByIndex(i)){
					this.mArmature.play(i,this.loop);
					this.mArmature.index=0;
					return;
				}
			}
			console.log("spine动画播放label："+label+"：失败");
		}

		__proto.stop=function(stopChild){
			(stopChild===void 0)&& (stopChild=false);
			if(this.zSpine){
				this.mArmature.stop();
			}
		}

		// zSpine.stop();
		__proto.pauseF=function(){
			this.stop();
		}

		__proto.resumeF=function(){
			this.mArmature.resume();
		}

		__proto.destroyF=function(){
			MyMC.removeF(this);
			this.completeFunction=null;
			if(this.mArmature){
				this.mArmature.destroy();
				this.mArmature=null;
			}
			if(this.zSpine){
				this.zSpine.destroy();
				this.zSpine=null;
			}
			this.destroyF();
		}

		__getset(0,__proto,'totalFrames',function(){
			if(this.zSpine){
				return this.endFrame;
			}
			return 0;
		});

		__getset(0,__proto,'loop',function(){
			return this._loop;
			},function(real){
			this._loop=real;
		});

		__getset(0,__proto,'currentFrame',function(){
			if(this.zSpine){
				return this.mArmature.index;
			}
			return 0;
		});

		return MyZMovieClip;
	})(SwfSprite)


	//class lzm.starling.swf.display.SwfMovieClip extends lzm.starling.swf.display.SwfSprite
	var SwfMovieClip=(function(_super){
		function SwfMovieClip(frames,labels,displayObjects,ownerSwf){
			this.isPlaying=false;
			this.loop=false;
			this._fps=0;
			this.interval=0;
			this._frames=null;
			this._labels=null;
			this._labelStrings=null;
			this._displayObjects=null;
			this.__frameInfos=null;
			this._startFrame=0;
			this._endFrame=0;
			this._currentLabel=null;
			this._currentFrame=0;
			this._totalFrames=0;
			this.frameFunction=null;
			this.FunComp=null;
			this._ownerSwf=null;
			this.numMC=0;
			this.needUpdateEveryFrame=false;
			this.arrRemoved=null;
			SwfMovieClip.__super.call(this);
			this._frames=frames;
			this._labels=labels;
			this._displayObjects=displayObjects;
			this._ownerSwf=ownerSwf;
			this._startFrame=0;
			this._endFrame=this._frames.length-1;
			var k;
			var arr;
			var l=0;
			for(k in this._displayObjects){
				if(k.indexOf("mc_")==0){
					arr=this._displayObjects[k];
					if(arr==null)continue ;
					l=arr.length;
					for (var i=0;i < l;i++){
						this.numMC++;
					}
				}
			}
			this.currentFrame=0;
			this.play();
		}

		__class(SwfMovieClip,'lzm.starling.swf.display.SwfMovieClip',_super);
		var __proto=SwfMovieClip.prototype;
		__proto.on缓存重复帧=function(obj){
			for(var f=0 in obj){
				this._frames[f]=null;
			}
		}

		__proto.play=function(rePlayChildMovie){
			(rePlayChildMovie===void 0)&& (rePlayChildMovie=true);
			this.isPlaying=true;
			this.timerLoop(SwfMovieClip.PlaySpeedSecond,this,this._frameLoop,null,true);
			var k;
			var arr;
			var l=0;
			for(k in this._displayObjects){
				if(k.indexOf("mc_")==0){
					arr=this._displayObjects[k];
					if(arr==null)continue ;
					l=arr.length;
					for (var i=0;i < l;i++){
						arr[i].currentFrame=0;
						arr[i].play(rePlayChildMovie);
					}
				}
			}
		}

		__proto.stop=function(stopChild){
			(stopChild===void 0)&& (stopChild=false);
			if(this.isPlaying==true){
				this.isPlaying=false;
				this.clearTimer(this,this._frameLoop);
			};
			var k;
			var arr;
			var l=0;
			for(k in this._displayObjects){
				if(k.indexOf("mc")==0){
					arr=this._displayObjects[k];
					if(arr==null)continue ;
					l=arr.length;
					for (var i=0;i < l;i++){
						if(stopChild)arr[i].stop(stopChild);
						else arr[i].play();
					}
				}
			}
		}

		__proto._frameLoop=function(){
			if (this._style.visible==false)return;
			if(this._currentFrame >=this._endFrame){
				if(this.FunComp)Tool_Function.onRunFunction(this.FunComp);
				if(!this.loop || this._startFrame==this._endFrame){
					this.stop(false);
					return;
				}
				this._currentFrame=this._startFrame;
				}else{
				this._currentFrame++
			}
			this.currentFrame=this._currentFrame;
		}

		__proto.gotoAndStop=function(frame,stopChild){
			(stopChild===void 0)&& (stopChild=true);
			this.goTo(frame);
			this.onCheckLastNotNullFrame();
			this.stop(stopChild);
		}

		__proto.gotoAndPlay=function(frame,rePlayChildMovie){
			(rePlayChildMovie===void 0)&& (rePlayChildMovie=false);
			this.goTo(frame);
			this.onCheckLastNotNullFrame();
			this.play(rePlayChildMovie);
		}

		__proto.onCheckLastNotNullFrame=function(){
			var count=0;
			while(this.__frameInfos==null){
				this.__frameInfos=this._frames[this._currentFrame-count];
				count++;
			}
			this.onSetCurrentFrame();
		}

		__proto.goTo=function(frame){
			if(((typeof frame=='string'))){
				var labelData=this.getLabelData(frame);
				this._currentLabel=labelData[0];
				this._currentFrame=this._startFrame=labelData[1];
				this._endFrame=labelData[2];
				}else if(((typeof frame=='number')&& Math.floor(frame)==frame)){
				this._currentFrame=this._startFrame=frame;
				this._endFrame=this._frames.length-1;
			}
			this.currentFrame=this._currentFrame;
		}

		/**
		*获取标签信息
		*@param label 标签名
		*@return 返回[标签名,起始帧数,结束帧数]
		**/
		__proto.getLabelData=function(label){
			var length=this._labels.length;
			var labelData;
			for (var i=0;i < length;i++){
				labelData=this._labels[i];
				if(labelData[0]==label){
					return labelData;
				}
			}
			return null;
		}

		__proto.onSetCurrentFrame=function(){
			this.removeChildren();
			var data;
			var display;
			var useIndex=0;
			var length=this.__frameInfos.length;
			for (var i=0;i < length;i++){
				data=this.__frameInfos[i];
				useIndex=data[10];
				display=this._displayObjects[data[0]][useIndex];
				if(display==null || (this.arrRemoved !=null && this.arrRemoved.indexOf(display)!=-1))continue ;
				display.alpha=data[8];
				display.name=data[9];
				display.x=data[2];
				display.y=data[3];
				display.rotation=data[6];
				display.skewX=-data[6];
				display.skewY=data[7];
				switch(data[1]){
					case "s9":
						display.width=data[11];
						display.height=data[12];
						break ;
					case "text":;
						var tx=display;
						tx.width=data[11];
						tx.height=data[12];
						tx.font=data[13];
						tx.color=data[14];
						tx.fontSize=data[15];
						tx.align=data[16];
						tx.italic=data[17];
						tx.bold=data[18];
						if(data[19] && data[19] !="\r" && data[19] !=""){
							tx.text=data[19];
						}
						break ;
					default :
						display.scaleX=data[4];
						display.scaleY=data[5];
						break ;
					}
				console.log(display.classLink,data);
				this.addChild(display);
			}
		}

		__proto.removeChildF=function(child,dispose){
			(dispose===void 0)&& (dispose=true);
			if(this.arrRemoved==null)this.arrRemoved=[];
			if((typeof child=='string')){
				child=this.getChildByName(child);
			}
			if(child!=null){
				this.arrRemoved.push(child);
				this.removeChild(child);
				if(dispose)child.destroy();
			}
		}

		/**@inheritDoc */
		__proto.destroy=function(destroyChild){
			(destroyChild===void 0)&& (destroyChild=true);
			var k;
			var arr;
			var l=0;
			for(k in this._displayObjects){
				arr=this._displayObjects[k];
				l=arr.length;
				for (var i=0;i < l;i++){
					(arr[i]).destroy();
				}
				this._displayObjects[k]=null;
			}
			this.arrRemoved=null;
			this._displayObjects=null;
			this.stop();
			laya.display.Sprite.prototype.destroy.call(this,destroyChild);
		}

		__proto.destroyF=function(){
			if(this._displayObjects==null)return;
			this.destroy(true);
			if(this.frameFunction){
				if((this.frameFunction instanceof laya.utils.Handler )){
					(this.frameFunction).clear();
				}
				this.frameFunction=null;
			}
			if(this.FunComp){
				if((this.FunComp instanceof laya.utils.Handler )){
					(this.FunComp).clear();
				}
				this.FunComp=null;
			}
		}

		/********************************************************************************/
		__getset(0,__proto,'currentFrame',function(){
			return this._currentFrame;
			},function(value){
			this._currentFrame=value;
			this.__frameInfos=this._frames[this._currentFrame];
			if(this.frameFunction)Tool_Function.onRunFunction(this.frameFunction);
			if(this.__frameInfos==null)return;
			this.onSetCurrentFrame();
		});

		__getset(0,__proto,'currentLabel',function(){
			return this._currentLabel;
		});

		__getset(0,__proto,'fps',function(){
			return this._fps;
			},function(value){
			this._fps=value;
			this.interval=int(1000/this._fps);
		});

		__getset(0,__proto,'totalFrames',function(){
			return this._frames.length;
		});

		__static(SwfMovieClip,
		['PlaySpeedSecond',function(){return this.PlaySpeedSecond=1000/Config.swfFPS;}
		]);
		return SwfMovieClip;
	})(SwfSprite)


	//class lzm.starling.swf.display.SwfImage extends starling.display.Image
	var SwfImage=(function(_super){
		function SwfImage(){
			this.classLink=null;
			this.w0=0;
			this.h0=0;
			SwfImage.__super.call(this);
		}

		__class(SwfImage,'lzm.starling.swf.display.SwfImage',_super);
		var __proto=SwfImage.prototype;
		__getset(0,__proto,'height',_super.prototype._$get_height,function(value){
			if(this.h0>0){
				this.scaleY=value/this.h0;
			}
			_super.prototype._$set_height.call(this,value);
		});

		__getset(0,__proto,'width',_super.prototype._$get_width,function(value){
			if(this.w0 >0){
				this.scaleX=value/this.w0;
			}
			_super.prototype._$set_width.call(this,value);
		});

		return SwfImage;
	})(Image1)



})(window,document,Laya);
