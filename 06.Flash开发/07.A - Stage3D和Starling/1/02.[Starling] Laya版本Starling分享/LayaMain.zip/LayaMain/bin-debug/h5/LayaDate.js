(function(defs){
		var p=Date.prototype;
		Object.defineProperty(p,'millisecondsUTC',{get:p.getUTCMilliseconds,enumerable: false});
		Object.defineProperty(p,'minutesUTC',{get:p.getUTCMinutes,enumerable: false});
		Object.defineProperty(p,'mouthUTC',{get:p.getUTCMonth,enumerable: false});
		for(var i=0;i<defs.length;i++)
			Object.defineProperty(p,defs[i],{get:p['get'+defs[i].charAt(0).toUpperCase()+defs[i].substr(1)]})
})(['date','day','fullYear','hours','millseconds','minutes','month','seconds','time','timezoneOffset','dateUTC','dayUTC','fullYearUTC','hoursUTC']);