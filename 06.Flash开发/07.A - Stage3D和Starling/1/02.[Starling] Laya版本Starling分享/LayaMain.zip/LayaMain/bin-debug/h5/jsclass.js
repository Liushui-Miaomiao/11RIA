﻿var jsclass = {
	console:function(msg) {
		// 直接输出
		alert(msg);
	},
	callback:function(msg) {
		// 回调as，Main中的callback方法
		Main.callback(msg);
	}
};